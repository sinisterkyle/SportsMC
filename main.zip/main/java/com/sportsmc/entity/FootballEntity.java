package com.sportsmc.entity;

import com.sportsmc.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * The football while nobody is holding it: in flight (simple ballistic arc, no drag, so the server can
 * predict exactly where a throw or kick comes down) or lying loose on the field after a kick lands.
 * The PlayEngine decides catches, pickups, interceptions and incompletions.
 */
public class FootballEntity extends Entity implements ItemSupplier {

    public static final double GRAVITY = 0.035;

    private static final EntityDataAccessor<Boolean> DATA_GROUNDED =
            SynchedEntityData.defineId(FootballEntity.class, EntityDataSerializers.BOOLEAN);
    /** Field level the ball can never fall below (synced so your screen agrees). MIN_VALUE = not set. */
    private static final EntityDataAccessor<Integer> DATA_FLOOR =
            SynchedEntityData.defineId(FootballEntity.class, EntityDataSerializers.INT);
    public static final double REST_HEIGHT = 0.15;

    private int flightTicks = 0;
    private Vec3 previousPos = Vec3.ZERO;

    public FootballEntity(EntityType<? extends FootballEntity> type, Level level) {
        super(type, level);
        noPhysics = true;
    }

    /** Ticks since a running match last claimed this ball; an unclaimed ball removes itself. */
    private int unclaimedTicks;

    /** Called every tick by the match that owns this ball. */
    public void claim() {
        unclaimedTicks = 0;
    }

    public int unclaimedTicks() {
        return unclaimedTicks;
    }

    @Override
    public void tick() {
        if (!level().isClientSide && (++unclaimedTicks > FootballPlayerEntity.ORPHAN_TICKS
                || !Double.isFinite(getX()) || !Double.isFinite(getY()) || !Double.isFinite(getZ()))) {
            discard();
            return;
        }
        long t0 = level().isClientSide ? 0 : System.nanoTime();
        tickBody();
        if (!level().isClientSide) com.sportsmc.debug.SportsDebug.add(com.sportsmc.debug.SportsDebug.Part.ENTITIES, System.nanoTime() - t0);
    }

    private void tickBody() {
        super.tick();
        previousPos = position();
        flightTicks++;
        if (!isGrounded()) {
            Vec3 v = getDeltaMovement();
            int floor = entityData.get(DATA_FLOOR);
            double rest = floor + REST_HEIGHT;
            if (floor != Integer.MIN_VALUE && v.y < 0 && getY() + v.y <= rest) {
                // Reached field level: stop right where it touches down instead of falling through
                // (works even if the ground out of bounds is lower than the field, or missing).
                double f = Math.max(0, Math.min(1, (getY() - rest) / -v.y));
                setPos(getX() + v.x * f, rest, getZ() + v.z * f);
                setDeltaMovement(Vec3.ZERO);
                if (!level().isClientSide) entityData.set(DATA_GROUNDED, true);
            } else {
                setPos(getX() + v.x, getY() + v.y, getZ() + v.z);
                setDeltaMovement(v.x, v.y - GRAVITY, v.z);
            }
        }
        if (!level().isClientSide) {
            // Safety nets: a ball nobody is managing anymore, or one that somehow ended up below the world.
            if (flightTicks > 400 || getY() < level().getMinBuildHeight() - 16) discard();
        }
    }

    /** Sets the field level this ball rests on. Call before adding it to the world. */
    public void setFloorY(int floorY) {
        entityData.set(DATA_FLOOR, floorY);
    }

    /** Where the ball was at the start of this tick (for sweep tests, so fast balls can't skip past a player). */
    public Vec3 previousPos() {
        return flightTicks <= 1 ? position() : previousPos;
    }

    public int flightTicks() {
        return flightTicks;
    }

    public boolean isGrounded() {
        return entityData.get(DATA_GROUNDED);
    }

    /** The ball hit the turf: it stays put as a loose ball until someone picks it up. */
    public void land(double floorY) {
        entityData.set(DATA_GROUNDED, true);
        setDeltaMovement(Vec3.ZERO);
        setPos(getX(), floorY + REST_HEIGHT, getZ());
    }

    @Override
    public ItemStack getItem() {
        return new ItemStack(ModItems.FOOTBALL.get());
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(DATA_GROUNDED, false);
        entityData.define(DATA_FLOOR, Integer.MIN_VALUE);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return new ClientboundAddEntityPacket(this);
    }
}
