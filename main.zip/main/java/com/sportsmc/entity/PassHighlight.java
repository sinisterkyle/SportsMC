package com.sportsmc.entity;

/**
 * Client-side list of the receivers the local quarterback can throw to right now ([1], [2], [3]).
 * Filled from MatchStatePacket; FootballPlayerEntity reads it to glow green (open) or red (covered).
 * Lives in common code (no client classes) so the entity can check it safely on either side.
 */
public final class PassHighlight {

    private static volatile int[] targets = new int[0];

    private PassHighlight() {}

    public static void set(int[] ids) {
        targets = ids == null ? new int[0] : ids.clone();
    }

    public static void clear() {
        targets = new int[0];
    }

    /** 1-3 if this entity is a pass target (its throw key), else 0. */
    public static int slot(int entityId) {
        int[] t = targets;
        for (int i = 0; i < t.length; i++) if (t[i] == entityId) return i + 1;
        return 0;
    }
}
