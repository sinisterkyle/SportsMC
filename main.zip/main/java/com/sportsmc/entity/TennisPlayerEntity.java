package com.sportsmc.entity;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/**
 * A tennis player. Runs with the same steering as the football players, but always faces the net
 * (players shuffle sideways instead of turning around), and twists toward the ball when swinging:
 * a right swing turns the body right (forehand), a left swing turns it left (backhand).
 */
public class TennisPlayerEntity extends FootballPlayerEntity {

    private static final int TWIST_TICKS = 9;

    /** Yaw that faces the net from this player's end. */
    private float netYaw = 0f;
    private int twistTicks;
    private float twistAngle;

    public TennisPlayerEntity(EntityType<? extends TennisPlayerEntity> type, Level level) {
        super(type, level);
    }

    public void setNetYaw(float yaw) {
        this.netYaw = yaw;
        setIdleYaw(yaw);
        setYRot(yaw);
        yBodyRot = yaw;
        yHeadRot = yaw;
    }

    /** Swing the racket: +1 = right (forehand), -1 = left (backhand). Plays the arm swing for everyone watching. */
    public void swingRacket(int side) {
        twistTicks = TWIST_TICKS;
        twistAngle = side >= 0 ? 55f : -55f;
        swing(InteractionHand.MAIN_HAND, true);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        float twist = 0f;
        if (twistTicks > 0) {
            // Wind through the swing: full twist at the start, unwinding back to square.
            twist = twistAngle * (twistTicks / (float) TWIST_TICKS);
            twistTicks--;
        }
        float yaw = netYaw + twist;
        setYRot(yaw);
        yBodyRot = yaw;
        yHeadRot = netYaw + twist * 0.3f;
    }
}
