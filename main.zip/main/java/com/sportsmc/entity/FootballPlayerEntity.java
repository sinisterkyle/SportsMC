package com.sportsmc.entity;

import com.sportsmc.game.Role;
import com.sportsmc.lobby.Lobby;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * One football player on the field. It has no vanilla AI goals: the PlayEngine (or the human
 * controlling it) sets a wanted direction and speed every tick, and this class turns that into
 * smooth running, plus the special moves: juke, hurdle, dive and getting knocked down.
 * Entities only live for one play and are never saved to disk.
 */
public class FootballPlayerEntity extends PathfinderMob {

    private static final EntityDataAccessor<Integer> DATA_SIDE = SynchedEntityData.defineId(FootballPlayerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ROLE = SynchedEntityData.defineId(FootballPlayerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_NUMBER = SynchedEntityData.defineId(FootballPlayerEntity.class, EntityDataSerializers.INT);

    private static final double GROUND_FRICTION = 0.546; // grass: 0.6 * 0.91
    private static final double AIR_FRICTION = 0.91;

    // Server-side control state
    private Vec3 wantedDir = Vec3.ZERO;
    private double wantedSpeed = 0;
    private Vec3 runVel = Vec3.ZERO;
    private Vec3 lastApplied = Vec3.ZERO;
    private float idleYaw = Float.NaN;

    private int jukeTicks, jukeCooldown, hurdleTicks, diveTicks, stunTicks, shedTicks;
    private int blockFreezeTicks, blockImmuneTicks;
    private int blockerCooldownTicks; // as a blocker: ticks until he can lock up another defender
    private int timesBlocked;         // as a defender: blocks taken this play (players are new every play)
    private int slot;
    /** Ticks since a running match last claimed this player; unclaimed players remove themselves. */
    private int unclaimedTicks;
    public static final int ORPHAN_TICKS = 200;

    // Route (pass plays), in world coordinates
    public final List<Vec3> route = new ArrayList<>();
    public int routeIndex = 0;
    public boolean routeSettles = false;

    public FootballPlayerEntity(EntityType<? extends FootballPlayerEntity> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        setMaxUpStep(1.0f);
        setCanPickUpLoot(false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_SIDE, 0);
        entityData.define(DATA_ROLE, 0);
        entityData.define(DATA_NUMBER, 0);
    }

    // ------------------------------------------------------------------ identity

    public Lobby.Side side() { return entityData.get(DATA_SIDE) == 0 ? Lobby.Side.HOME : Lobby.Side.AWAY; }
    public Role role() { return Role.byOrdinal(entityData.get(DATA_ROLE)); }
    public int number() { return entityData.get(DATA_NUMBER); }
    public int slot() { return slot; }

    public void setup(Lobby.Side side, Role role, int number, int slot) {
        entityData.set(DATA_SIDE, side == Lobby.Side.HOME ? 0 : 1);
        entityData.set(DATA_ROLE, role.ordinal());
        entityData.set(DATA_NUMBER, number);
        this.slot = slot;
    }

    // ------------------------------------------------------------------ steering (server)

    /** Run in a world-space horizontal direction at a speed in blocks/tick. */
    public void drive(Vec3 dir, double speed) {
        wantedDir = dir.lengthSqr() < 1.0e-6 ? Vec3.ZERO : new Vec3(dir.x, 0, dir.z).normalize();
        wantedSpeed = wantedDir == Vec3.ZERO ? 0 : speed;
    }

    /** Run toward a point, easing off as it gets close. */
    public void driveTo(Vec3 target, double speed) {
        Vec3 d = new Vec3(target.x - getX(), 0, target.z - getZ());
        double len = d.length();
        if (len < 0.25) { stopRunning(); return; }
        drive(d, speed * Math.max(0.35, Math.min(1.0, len / 1.5)));
    }

    /** Scales this tick's running speed (used to slow pass rushers in the backfield). */
    public void slowDown(double factor) {
        wantedSpeed *= factor;
    }

    public void stopRunning() {
        wantedDir = Vec3.ZERO;
        wantedSpeed = 0;
    }

    /** Facing used while standing still (e.g. pre-snap). */
    public void setIdleYaw(float yaw) {
        this.idleYaw = yaw;
    }

    public Vec3 runVelocity() { return runVel; }

    // ------------------------------------------------------------------ moves

    public boolean canAct() { return stunTicks <= 0 && diveTicks <= 0 && blockFreezeTicks <= 0; }

    /** Stopped by a block right now. */
    public boolean isBlockFrozen() { return blockFreezeTicks > 0; }

    /** False while frozen or during the short window after breaking free. */
    public boolean canBeBlocked() { return blockFreezeTicks <= 0 && blockImmuneTicks <= 0; }

    /** Stopped dead by a block for `ticks`, then free (and unblockable) for `immuneAfter` ticks. */
    public void freezeByBlock(int ticks, int immuneAfter) {
        blockFreezeTicks = ticks;
        blockImmuneTicks = immuneAfter;
        runVel = Vec3.ZERO;
    }

    /** Defender side: count a block taken. */
    public void countBlocked() { timesBlocked++; }
    public int timesBlocked() { return timesBlocked; }

    /** Blocker side: can he start a new block right now? */
    public boolean canBlock() { return blockerCooldownTicks <= 0; }
    public void startBlockerCooldown(int ticks) { blockerCooldownTicks = ticks; }
    public boolean isJuking() { return jukeTicks > 0; }
    public boolean isHurdling() { return hurdleTicks > 0 && !onGround(); }
    public boolean isDiving() { return diveTicks > 0; }
    public boolean isStunned() { return stunTicks > 0; }
    public boolean isBlockedNow() { return shedTicks <= 0; }

    /** Quick cut to the left or right of the current running direction. */
    public boolean juke(boolean left) {
        if (jukeCooldown > 0 || !canAct()) return false;
        Vec3 f = runVel.lengthSqr() > 1.0e-4 ? runVel.normalize() : Vec3.directionFromRotation(0, getYRot());
        Vec3 side = new Vec3(f.z, 0, -f.x); // left of facing
        if (!left) side = side.scale(-1);
        runVel = runVel.scale(0.55).add(side.scale(0.55));
        jukeTicks = 9;
        jukeCooldown = 26;
        return true;
    }

    /** Jump / hurdle. */
    public boolean hurdle() {
        if (!onGround() || !canAct()) return false;
        Vec3 dm = getDeltaMovement();
        setDeltaMovement(dm.x, 0.45, dm.z);
        hurdleTicks = 14;
        return true;
    }

    /** Dive at a target; if the play engine doesn't call a tackle, the diver ends up on the ground. */
    public boolean dive(Vec3 toward) {
        if (!onGround() || !canAct()) return false;
        Vec3 d = new Vec3(toward.x - getX(), 0, toward.z - getZ());
        if (d.lengthSqr() < 1.0e-4) return false;
        runVel = d.normalize().scale(0.62);
        Vec3 dm = getDeltaMovement();
        setDeltaMovement(dm.x, 0.18, dm.z);
        diveTicks = 9;
        setPose(Pose.SWIMMING);
        return true;
    }

    /** Knocked down / missed a tackle: on the ground for a moment. */
    public void stun(int ticks) {
        stunTicks = Math.max(stunTicks, ticks);
        diveTicks = 0;
        runVel = runVel.scale(0.3);
        setPose(Pose.SWIMMING);
    }

    /** A defender engaged by a blocker sheds it after this many ticks of being free. */
    public void shed(int ticks) { shedTicks = ticks; }

    public void clearMoves() {
        jukeTicks = hurdleTicks = diveTicks = stunTicks = 0;
        setPose(Pose.STANDING);
    }

    // ------------------------------------------------------------------ safety

    /** Called every tick by the match that owns this player. */
    public void claim() {
        unclaimedTicks = 0;
    }

    public int unclaimedTicks() {
        return unclaimedTicks;
    }

    @Override
    public void tick() {
        if (!level().isClientSide) {
            // A player no match is running anymore (match ended abnormally), or one whose position broke: remove it
            // instead of leaving it standing in the world forever.
            if (++unclaimedTicks > ORPHAN_TICKS || !Double.isFinite(getX()) || !Double.isFinite(getY()) || !Double.isFinite(getZ())) {
                discard();
                return;
            }
            long t0 = System.nanoTime();
            super.tick();
            com.sportsmc.debug.SportsDebug.add(com.sportsmc.debug.SportsDebug.Part.ENTITIES, System.nanoTime() - t0);
            return;
        }
        super.tick();
    }

    // ------------------------------------------------------------------ movement

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();

        if (jukeTicks > 0) jukeTicks--;
        if (jukeCooldown > 0) jukeCooldown--;
        if (hurdleTicks > 0) hurdleTicks--;
        if (shedTicks > 0) shedTicks--;
        if (blockFreezeTicks > 0) blockFreezeTicks--;
        else if (blockImmuneTicks > 0) blockImmuneTicks--;
        if (blockerCooldownTicks > 0) blockerCooldownTicks--;
        if (diveTicks > 0 && --diveTicks == 0) stun(22); // dive missed
        else if (stunTicks > 0 && --stunTicks == 0) setPose(Pose.STANDING);

        Vec3 cur = getDeltaMovement();
        double friction = onGround() ? GROUND_FRICTION : AIR_FRICTION;
        // Whatever pushing/collisions added since last tick, keep (amplified) so bodies bump and block.
        Vec3 residual = new Vec3(cur.x - lastApplied.x * friction, 0, cur.z - lastApplied.z * friction);

        Vec3 target = (stunTicks > 0 || blockFreezeTicks > 0) ? Vec3.ZERO : wantedDir.scale(wantedSpeed);
        double accel = diveTicks > 0 ? 0.02 : jukeTicks > 0 ? 0.12 : onGround() ? 0.32 : 0.06;
        runVel = runVel.add(target.subtract(runVel).scale(accel));
        if (stunTicks > 0) runVel = runVel.scale(0.7);

        Vec3 apply = runVel.add(residual.scale(2.5));
        setDeltaMovement(apply.x, cur.y, apply.z);
        lastApplied = apply;

        if (runVel.lengthSqr() > 0.0009) {
            face((float) (Math.toDegrees(Math.atan2(runVel.z, runVel.x)) - 90.0));
        } else if (!Float.isNaN(idleYaw)) {
            face(idleYaw);
        }
    }

    private void face(float yaw) {
        setYRot(yaw);
        yBodyRot = yaw;
        yHeadRot = yaw;
    }

    // ------------------------------------------------------------------ pass-target highlight (client)

    /** Throw key (1-3) if the local quarterback can throw to this player right now, else 0. Client side. */
    public int passSlot() {
        return level().isClientSide ? PassHighlight.slot(getId()) : 0;
    }

    /** Colour of this receiver's throw icon: green = open, yellow = tight coverage, red = covered. */
    public int passOpenColor() {
        double nearest = 99;
        for (FootballPlayerEntity o : level().getEntitiesOfClass(FootballPlayerEntity.class, getBoundingBox().inflate(3.0))) {
            if (o.side() != side()) nearest = Math.min(nearest, distanceTo(o));
        }
        return nearest > 2.5 ? 0x4CFF4C : nearest > 1.4 ? 0xFFD23C : 0xFF4040;
    }

    // ------------------------------------------------------------------ vanilla behaviour we don't want

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypes.FELL_OUT_OF_WORLD) || source.is(DamageTypes.GENERIC_KILL)) return super.hurt(source, amount);
        return false;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean canBeLeashed(Player player) {
        return false;
    }

    @Override
    protected boolean shouldDespawnInPeaceful() {
        return false;
    }
}
