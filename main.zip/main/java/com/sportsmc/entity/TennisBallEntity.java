package com.sportsmc.entity;

import com.sportsmc.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * The tennis ball. Simple, deterministic physics (gravity, no drag, a damped bounce on the court floor)
 * that runs identically on server and client, so the ball looks smooth and the server - and the CPU - can
 * predict exactly where it's going. The match decides hits, the net, lines and points.
 */
public class TennisBallEntity extends Entity implements ItemSupplier {

    public static final double GRAVITY = 0.03;
    /** Vertical speed kept on a bounce, and horizontal speed kept (friction / topspin feel). */
    public static final double BOUNCE_UP = 0.68;
    public static final double BOUNCE_SLIDE = 0.82;
    public static final double RADIUS = 0.1;

    private static final EntityDataAccessor<Integer> DATA_FLOOR = SynchedEntityData.defineId(TennisBallEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_HELD = SynchedEntityData.defineId(TennisBallEntity.class, EntityDataSerializers.BOOLEAN);

    private Vec3 previousPos = Vec3.ZERO;
    private boolean bounced;
    private Vec3 bouncePos = Vec3.ZERO;

    public TennisBallEntity(EntityType<? extends TennisBallEntity> type, Level level) {
        super(type, level);
        noPhysics = true;
    }

    // ------------------------------------------------------------------ state

    public void setFloorY(int y) { entityData.set(DATA_FLOOR, y); }
    public int floorY() { return entityData.get(DATA_FLOOR); }

    /** Held = parked in a server's hand before the toss (no physics). */
    public void setHeld(boolean held) {
        entityData.set(DATA_HELD, held);
        if (held) setDeltaMovement(Vec3.ZERO);
    }
    public boolean isHeld() { return entityData.get(DATA_HELD); }

    public Vec3 previousPos() { return previousPos; }

    /** True once per bounce; the bounce spot is in {@link #bouncePos()}. */
    public boolean consumeBounce() {
        boolean b = bounced;
        bounced = false;
        return b;
    }
    public Vec3 bouncePos() { return bouncePos; }

    // ------------------------------------------------------------------ physics

    /** Ticks since a running match last claimed this ball; an unclaimed ball removes itself. */
    private int unclaimedTicks;

    /** Called every tick by the match that owns this ball. */
    public void claim() {
        unclaimedTicks = 0;
    }

    public int unclaimedTicks() {
        return unclaimedTicks;
    }

    @Override
    public void tick() {
        if (!level().isClientSide && (++unclaimedTicks > FootballPlayerEntity.ORPHAN_TICKS
                || !Double.isFinite(getX()) || !Double.isFinite(getY()) || !Double.isFinite(getZ()))) {
            discard();
            return;
        }
        long t0 = level().isClientSide ? 0 : System.nanoTime();
        tickBody();
        if (!level().isClientSide) com.sportsmc.debug.SportsDebug.add(com.sportsmc.debug.SportsDebug.Part.ENTITIES, System.nanoTime() - t0);
    }

    private void tickBody() {
        super.tick();
        previousPos = position();
        if (isHeld()) return;
        Vec3 v = getDeltaMovement();
        double floor = floorY() + RADIUS;
        double ny = getY() + v.y;
        if (ny <= floor && v.y < 0) {
            // Bounce at the exact spot the ball reaches the floor during this tick (not where the tick ends:
            // a fast ball moves ~half a block per tick, which would call good balls near the lines out).
            double f = Math.max(0, Math.min(1, (getY() - floor) / -v.y));
            bounced = true;
            bouncePos = new Vec3(getX() + v.x * f, floor, getZ() + v.z * f);
            setPos(bouncePos.x, floor, bouncePos.z);
            setDeltaMovement(v.x * BOUNCE_SLIDE, -v.y * BOUNCE_UP, v.z * BOUNCE_SLIDE);
        } else {
            setPos(getX() + v.x, getY() + v.y, getZ() + v.z);
            setDeltaMovement(v.x, v.y - GRAVITY, v.z);
        }
    }

    /**
     * Predicts the flight from a position and velocity with exactly the same rules as {@link #tick()}.
     * Returns one position per future tick (index 0 = after the next tick).
     */
    public static Vec3[] predict(Vec3 pos, Vec3 vel, int floorY, int ticks) {
        Vec3[] out = new Vec3[ticks];
        double x = pos.x, y = pos.y, z = pos.z, vx = vel.x, vy = vel.y, vz = vel.z;
        double floor = floorY + RADIUS;
        for (int i = 0; i < ticks; i++) {
            if (y + vy <= floor && vy < 0) {
                double f = Math.max(0, Math.min(1, (y - floor) / -vy));
                x += vx * f; z += vz * f; y = floor;
                vx *= BOUNCE_SLIDE; vz *= BOUNCE_SLIDE; vy = -vy * BOUNCE_UP;
            } else {
                x += vx; y += vy; z += vz;
                vy -= GRAVITY;
            }
            out[i] = new Vec3(x, y, z);
        }
        return out;
    }

    // ------------------------------------------------------------------ boilerplate

    @Override
    public ItemStack getItem() {
        return new ItemStack(ModItems.TENNIS_BALL.get());
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(DATA_FLOOR, 0);
        entityData.define(DATA_HELD, false);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return new ClientboundAddEntityPacket(this);
    }
}
