package com.sportsmc.match;

import com.sportsmc.field.FieldData;
import com.sportsmc.lobby.Lobby;
import com.sportsmc.network.ControlPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import javax.annotation.Nullable;
import java.util.UUID;

/** A running game of any sport (football, tennis, ...). MatchManager only talks to matches through this. */
public interface SportMatch {

    Lobby lobby();

    FieldData field();

    boolean isFinished();

    /** Sets up the field and players and starts play. */
    void kickoff(MinecraftServer server);

    void tick(MinecraftServer server);

    /** Ends the match; a non-null side wins by forfeit. Puts everyone back where they were. */
    void finish(@Nullable Lobby.Side forcedWinner);

    void forfeit(UUID player);

    boolean involves(UUID player);

    void control(UUID player, ControlPacket msg);

    /** Re-sends the HUD / camera state to a player who (re)joined. */
    void sendStateTo(ServerPlayer player);
}
