package com.sportsmc.match;

import com.sportsmc.entity.FootballPlayerEntity;
import com.sportsmc.field.FieldData;
import com.sportsmc.field.FieldGeometry;
import com.sportsmc.game.PlayEngine;
import com.sportsmc.game.PlayResult;
import com.sportsmc.game.Playbook;
import com.sportsmc.lobby.Difficulty;
import com.sportsmc.lobby.Lobby;
import com.sportsmc.network.ControlPacket;
import com.sportsmc.network.MatchStatePacket;
import com.sportsmc.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * One game: teams, field, clock, score, down & distance, kickoffs and stats. The football itself
 * (players, ball, AI, tackles, kicks) runs in {@link PlayEngine}; plays come back as {@link PlayResult}s.
 *
 * Humans watch from a broadcast camera: their own body becomes an invisible spectator parked above
 * midfield, and they steer one football player at a time. Everything is restored when the game ends.
 *
 * Ball position ("yard") is measured from HOME's goal line: 0 = HOME goal line, 100 = AWAY goal line.
 */
public class FootballMatch implements SportMatch {

    public static final int QUARTERS = 4;
    private static final int HALFTIME_BREAK_SECONDS = 8;
    private static final double BOOTH_HEIGHT = 18;

    /** Who controls a side: a human (uuid) or the CPU. */
    public record Participant(@Nullable UUID player, String name, @Nullable CpuOpponent cpu) {
        public boolean isCpu() { return cpu != null; }
    }

    private record ReturnPoint(ResourceKey<Level> dimension, Vec3 pos, float yRot, float xRot, GameType gameType) {}

    /** Box score numbers for one team. */
    private static final class TeamStats {
        int passAtt, passComp, passYds, rushAtt, rushYds, intsThrown, sacked, fgMade, fgAtt;
    }

    private final Lobby lobby;
    private final FieldData field;
    private final int quarterSeconds;
    private final Map<Lobby.Side, Participant> sides = new EnumMap<>(Lobby.Side.class);
    private final Map<Lobby.Side, Integer> score = new EnumMap<>(Lobby.Side.class);
    private final Map<Lobby.Side, TeamStats> stats = new EnumMap<>(Lobby.Side.class);
    private final Map<UUID, ReturnPoint> returnPoints = new HashMap<>();
    @Nullable private PlayEngine engine;

    private int quarter = 1;
    private int ticksLeftInQuarter;
    private int breakTicks = 0;
    private int age = 0;
    private boolean finished = false;
    private boolean clockRunning = false;

    // Possession, down & distance
    private Lobby.Side possession = Lobby.Side.HOME;
    private Lobby.Side openingReceiver = Lobby.Side.HOME;
    private double ballYard = 35;
    private double firstDownYard = 45;
    private int down = 1;
    private boolean kickoffNext = true;
    /** After a touchdown: the next snap is the try (extra point kick = 1, or run/pass from the 2 = 2). */
    private boolean tryNext = false;

    public FootballMatch(Lobby lobby, FieldData field) {
        this.lobby = lobby;
        this.field = field;
        this.quarterSeconds = lobby.quarterMinutes() * 60;
        this.ticksLeftInQuarter = quarterSeconds * 20;
        for (Lobby.Member m : lobby.members()) {
            sides.put(m.side, new Participant(m.uuid, m.name, null));
        }
        if (lobby.mode() == Lobby.Mode.VS_CPU) {
            Lobby.Side cpuSide = sides.containsKey(Lobby.Side.HOME) ? Lobby.Side.AWAY : Lobby.Side.HOME;
            Difficulty d = lobby.difficulty();
            sides.put(cpuSide, new Participant(null, "CPU (" + d.englishName() + ")", new CpuOpponent(this, cpuSide, d)));
        }
        for (Lobby.Side s : Lobby.Side.values()) {
            score.put(s, 0);
            stats.put(s, new TeamStats());
        }
    }

    // ------------------------------------------------------------------ queries

    public Lobby lobby() { return lobby; }
    public FieldData field() { return field; }
    public boolean isFinished() { return finished; }
    public boolean isBreak() { return breakTicks > 0; }
    @Nullable public Participant participant(Lobby.Side side) { return sides.get(side); }
    public int score(Lobby.Side side) { return score.get(side); }
    public Lobby.Side possession() { return possession; }
    public double ballYard() { return ballYard; }
    public double firstDownYard() { return firstDownYard; }
    public int down() { return down; }
    public boolean kickoffNext() { return kickoffNext; }
    public boolean tryNext() { return tryNext; }

    public List<UUID> humans() {
        List<UUID> out = new ArrayList<>(2);
        for (Participant p : sides.values()) if (p.player() != null) out.add(p.player());
        return out;
    }

    @Nullable
    public UUID humanOf(Lobby.Side side) {
        Participant p = sides.get(side);
        return p == null ? null : p.player();
    }

    @Nullable
    public Lobby.Side sideOf(UUID player) {
        for (Map.Entry<Lobby.Side, Participant> e : sides.entrySet()) {
            if (player.equals(e.getValue().player())) return e.getKey();
        }
        return null;
    }

    public boolean involves(UUID player) {
        return sideOf(player) != null;
    }

    // ------------------------------------------------------------------ kickoff / end

    public void kickoff(MinecraftServer server) {
        ServerLevel level = server.getLevel(ResourceKey.create(Registries.DIMENSION, field.dimension()));
        if (level == null) { finish(null); return; }

        FieldGeometry g = field.geometry();
        Vec3 booth = g.center().add(0, BOOTH_HEIGHT, 0);
        for (UUID uuid : humans()) {
            ServerPlayer sp = server.getPlayerList().getPlayer(uuid);
            if (sp == null) continue;
            com.sportsmc.match.SafeReturn.remember(sp, true);
            returnPoints.put(uuid, new ReturnPoint(sp.level().dimension(), sp.position(), sp.getYRot(), sp.getXRot(),
                    sp.gameMode.getGameModeForPlayer()));
            sp.setGameMode(GameType.SPECTATOR);
            sp.teleportTo(level, booth.x, booth.y, booth.z, g.yaw(true), 30f);
        }

        Participant home = sides.get(Lobby.Side.HOME);
        Participant away = sides.get(Lobby.Side.AWAY);
        broadcast(Component.literal("Welcome to " + field.name() + "! ").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD)
                .append(Component.literal(home.name() + " (HOME) vs " + away.name() + " (AWAY), "
                        + lobby.quarterMinutes() + "-minute quarters").withStyle(ChatFormatting.WHITE)));

        // Coin toss: the winner receives; the other side kicks off from its own 35.
        openingReceiver = level.getRandom().nextBoolean() ? Lobby.Side.HOME : Lobby.Side.AWAY;
        broadcast(Component.literal("Coin toss: " + sides.get(openingReceiver).name() + " wins and will receive.")
                .withStyle(ChatFormatting.AQUA));
        title(Component.literal(home.name() + " vs " + away.name()).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                Component.literal(sides.get(openingReceiver).name() + " won the toss"));
        setUpKickoff(openingReceiver.opposite(), 35);

        engine = new PlayEngine(this, g, level);
        engine.setupPlay();
        pushState();
    }

    /** Ends the match; a non-null winner means a forfeit/stop. Sends everyone back where they were. */
    public void finish(@Nullable Lobby.Side forcedWinner) {
        if (finished) return;
        finished = true;
        if (engine != null) engine.cleanup();

        Lobby.Side winner = forcedWinner;
        if (winner == null) {
            int h = score(Lobby.Side.HOME), a = score(Lobby.Side.AWAY);
            winner = h == a ? null : (h > a ? Lobby.Side.HOME : Lobby.Side.AWAY);
        }
        Component result = winner == null
                ? Component.literal("FINAL - it's a tie. ").withStyle(ChatFormatting.YELLOW)
                : Component.literal("FINAL - " + sides.get(winner).name() + " wins! ").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD);
        broadcast(Component.empty().append(result).append(scoreLine()));
        title(Component.literal("FINAL").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                Component.literal("HOME " + score(Lobby.Side.HOME) + " - " + score(Lobby.Side.AWAY) + " AWAY"));
        broadcastBoxScore();

        sendToAll(MatchStatePacket.inactive());
        sendPlayersBack();
    }

    public void forfeit(UUID player) {
        for (Map.Entry<Lobby.Side, Participant> e : sides.entrySet()) {
            if (player.equals(e.getValue().player())) {
                broadcast(Component.literal(e.getValue().name() + " forfeited.").withStyle(ChatFormatting.RED));
                finish(e.getKey().opposite());
                return;
            }
        }
    }

    // ------------------------------------------------------------------ plays

    public void control(UUID player, ControlPacket msg) {
        if (engine != null && !finished) engine.control(player, msg);
    }

    /** Debug: snap the ball. */
    public void snap() {
        if (engine != null) engine.snap();
    }

    /** Debug: end the play with a fixed gain (negative = loss). */
    public void endPlay(double gained) {
        if (engine != null) engine.debugEnd(gained);
    }

    /** The clock always runs during a live play; this restarts it at the snap. */
    public void startClock() {
        clockRunning = true;
    }

    /** Change of possession mid-play (interception, kick received): the camera swings around. */
    public void turnover() {
        possession = possession.opposite();
        pushState();
    }

    private void setUpKickoff(Lobby.Side kicking, double fromOwn) {
        possession = kicking;
        ballYard = kicking == Lobby.Side.HOME ? fromOwn : 100 - fromOwn;
        down = 1;
        firstDownYard = clampYard(ballYard + dir(kicking) * 10);
        kickoffNext = true;
    }

    /** Called by the engine when a play is whistled dead. Updates score, downs, stats and the spot. */
    public void applyResult(PlayResult r) {
        if (tryNext) {
            tryNext = false;
            applyTry(r);
            return;
        }
        boolean wasKickoff = kickoffNext;
        kickoffNext = false;
        recordStats(r, wasKickoff);
        int d = dir(possession);
        // The clock keeps running only after an ordinary tackle in bounds.
        clockRunning = r.kind() == PlayResult.Kind.TACKLE && !r.turnover();

        switch (r.kind()) {
            case TOUCHDOWN -> {
                Lobby.Side scorer = possession;
                score.merge(scorer, 6, Integer::sum);
                title(Component.literal("TOUCHDOWN!").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                        Component.literal(sides.get(scorer).name() + " +6"));
                broadcast(Component.literal("TOUCHDOWN " + sides.get(scorer).name() + "! ").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)
                        .append(scoreLine()));
                // The try: kick the extra point (default) or press R to go for two.
                tryNext = true;
                possession = scorer;
                double goal = scorer == Lobby.Side.HOME ? 100 : 0;
                ballYard = goal - dir(scorer) * 15;
                down = 1;
                firstDownYard = goal;
                broadcast(Component.literal("Extra point attempt - or press R to go for two.").withStyle(ChatFormatting.AQUA));
            }
            case FIELD_GOAL -> {
                Lobby.Side scorer = possession;
                score.merge(scorer, 3, Integer::sum);
                title(Component.literal("IT'S GOOD!").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                        Component.literal("Field goal, " + sides.get(scorer).name() + " +3"));
                broadcast(Component.literal("Field goal is GOOD! ").withStyle(ChatFormatting.GOLD).append(scoreLine()));
                setUpKickoff(scorer, 35);
            }
            case FIELD_GOAL_MISSED -> {
                broadcast(Component.literal("Field goal is NO GOOD.").withStyle(ChatFormatting.RED));
                title(Component.literal("NO GOOD").withStyle(ChatFormatting.RED, ChatFormatting.BOLD), Component.empty());
                possession = possession.opposite();
                ballYard = Math.max(0.5, Math.min(99.5, r.spotYard()));
                down = 1;
                firstDownYard = clampYard(ballYard + dir(possession) * 10);
            }
            case SAFETY -> {
                Lobby.Side conceding = possession;
                Lobby.Side scorer = conceding.opposite();
                score.merge(scorer, 2, Integer::sum);
                title(Component.literal("SAFETY!").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                        Component.literal(sides.get(scorer).name() + " +2"));
                broadcast(Component.literal("SAFETY! ").withStyle(ChatFormatting.GOLD).append(scoreLine()));
                setUpKickoff(conceding, 20); // free kick from the 20
            }
            case TOUCHBACK -> {
                broadcast(Component.literal("Touchback.").withStyle(ChatFormatting.AQUA));
                ballYard = r.spotYard();
                down = 1;
                firstDownYard = clampYard(ballYard + d * 10);
            }
            case INCOMPLETE -> {
                broadcast(Component.literal(r.text()).withStyle(ChatFormatting.GRAY));
                nextDown();
            }
            case TACKLE, OUT_OF_BOUNDS -> {
                broadcast(Component.literal(r.text()).withStyle(r.gained() >= 0 || r.turnover() ? ChatFormatting.WHITE : ChatFormatting.RED));
                double spot = Math.max(0.5, Math.min(99.5, r.spotYard()));
                ballYard = spot;
                if (r.turnover()) {
                    down = 1;
                    firstDownYard = clampYard(spot + d * 10);
                    if (r.playType() == Playbook.Type.PASS) {
                        title(Component.literal("TURNOVER").withStyle(ChatFormatting.RED, ChatFormatting.BOLD),
                                Component.literal(sides.get(possession).name() + " ball at " + yardLabel(spot)));
                    }
                } else if (d == 1 ? spot >= firstDownYard : spot <= firstDownYard) {
                    down = 1;
                    firstDownYard = clampYard(spot + d * 10);
                    title(Component.empty(), Component.literal("FIRST DOWN").withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD));
                } else {
                    nextDown();
                }
            }
        }
        if (!kickoffNext) announceDownAndDistance();
        pushState();
        // Overtime is sudden death: the first score wins.
        if (quarter > QUARTERS && score(Lobby.Side.HOME) != score(Lobby.Side.AWAY)) finish(null);
    }

    /** Result of the try after a touchdown, then the scoring team kicks off. */
    private void applyTry(PlayResult r) {
        Lobby.Side team = possession == r.offense() ? possession : r.offense();
        String name = sides.get(team).name();
        if (r.kind() == PlayResult.Kind.FIELD_GOAL) {
            score.merge(team, 1, Integer::sum);
            title(Component.empty(), Component.literal("Extra point is GOOD").withStyle(ChatFormatting.GOLD));
            broadcast(Component.literal("Extra point is GOOD. ").withStyle(ChatFormatting.GOLD).append(scoreLine()));
        } else if (r.kind() == PlayResult.Kind.TOUCHDOWN && !r.turnover()) {
            score.merge(team, 2, Integer::sum);
            title(Component.literal("TWO-POINT CONVERSION!").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                    Component.literal(name + " +2"));
            broadcast(Component.literal("Two-point conversion is GOOD! ").withStyle(ChatFormatting.GOLD).append(scoreLine()));
        } else if (r.kind() == PlayResult.Kind.FIELD_GOAL_MISSED) {
            title(Component.empty(), Component.literal("Extra point NO GOOD").withStyle(ChatFormatting.RED));
            broadcast(Component.literal("Extra point is NO GOOD.").withStyle(ChatFormatting.RED));
        } else {
            title(Component.empty(), Component.literal("Two-point try fails").withStyle(ChatFormatting.RED));
            broadcast(Component.literal("The two-point try fails.").withStyle(ChatFormatting.RED));
        }
        clockRunning = false;
        setUpKickoff(team, 35);
        pushState();
    }

    private void nextDown() {
        if (++down > 4) {
            possession = possession.opposite();
            down = 1;
            firstDownYard = clampYard(ballYard + dir(possession) * 10);
            broadcast(Component.literal("Turnover on downs - " + sides.get(possession).name() + " takes over.").withStyle(ChatFormatting.RED));
            title(Component.literal("TURNOVER ON DOWNS").withStyle(ChatFormatting.RED, ChatFormatting.BOLD), Component.empty());
        }
    }

    public void addScore(Lobby.Side side, int points) {
        score.merge(side, points, Integer::sum);
        broadcast(Component.literal(sides.get(side).name() + " +" + points + " ").withStyle(ChatFormatting.GOLD).append(scoreLine()));
        pushState();
    }

    private void recordStats(PlayResult r, boolean kickoff) {
        if (kickoff) return;
        TeamStats s = stats.get(r.offense());
        switch (r.playType()) {
            case PASS -> {
                if (r.kind() == PlayResult.Kind.INCOMPLETE || r.completed() || r.turnover()) s.passAtt++;
                if (r.completed()) { s.passComp++; s.passYds += (int) Math.round(r.gained()); }
                if (r.turnover() && !r.completed()) s.intsThrown++;
            }
            case RUN -> {
                if (r.sack()) s.sacked++;
                else if (!r.turnover()) { s.rushAtt++; s.rushYds += (int) Math.round(r.gained()); }
            }
            case FIELD_GOAL -> {
                s.fgAtt++;
                if (r.kind() == PlayResult.Kind.FIELD_GOAL) s.fgMade++;
            }
            default -> {}
        }
    }

    private void broadcastBoxScore() {
        broadcast(Component.literal("---- Box score ----").withStyle(ChatFormatting.GOLD));
        for (Lobby.Side side : Lobby.Side.values()) {
            TeamStats s = stats.get(side);
            String line = String.format("%s %s %d | Pass %d/%d, %d yds, %d INT | Rush %d for %d yds | Sacked %d | FG %d/%d",
                    side == Lobby.Side.HOME ? "HOME" : "AWAY", sides.get(side).name(), score(side),
                    s.passComp, s.passAtt, s.passYds, s.intsThrown, s.rushAtt, s.rushYds, s.sacked, s.fgMade, s.fgAtt);
            broadcast(Component.literal(line).withStyle(ChatFormatting.WHITE));
        }
    }

    // ------------------------------------------------------------------ clock

    public void tick(MinecraftServer server) {
        if (finished) return;
        age++;

        if (breakTicks > 0) {
            if (--breakTicks == 0 && engine != null) engine.setupPlay();
        }
        if (engine != null) {
            engine.tick();
            if (engine.consumeDirty() || age % 10 == 0) pushState();
        }
        if (age % 40 == 0) keepInBooth(server);
        if (breakTicks > 0 || finished) return;

        boolean live = engine != null && engine.isLive();
        // The try after a touchdown is untimed.
        if ((live || clockRunning) && !tryNext && ticksLeftInQuarter > 0) ticksLeftInQuarter--;

        // A quarter only ends once the current play (and any try) is over.
        if (ticksLeftInQuarter <= 0 && !live && !tryNext) endOfQuarter();
    }

    private void endOfQuarter() {
        if (quarter >= QUARTERS) {
            if (score(Lobby.Side.HOME) != score(Lobby.Side.AWAY)) { finish(null); return; }
            if (quarter > QUARTERS) { finish(null); return; } // overtime ended tied
            broadcast(Component.literal("Tied at the end of regulation - OVERTIME! Next score wins.")
                    .withStyle(ChatFormatting.LIGHT_PURPLE));
            title(Component.literal("OVERTIME").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD), Component.empty());
            quarter++;
            ticksLeftInQuarter = quarterSeconds * 20;
            clockRunning = false;
            Lobby.Side receiver = Math.random() < 0.5 ? Lobby.Side.HOME : Lobby.Side.AWAY;
            setUpKickoff(receiver.opposite(), 35);
            if (engine != null) engine.setupPlay();
            return;
        }
        quarter++;
        ticksLeftInQuarter = quarterSeconds * 20;
        clockRunning = false;
        if (quarter == 3) {
            breakTicks = HALFTIME_BREAK_SECONDS * 20;
            broadcast(Component.literal("HALFTIME ").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD).append(scoreLine()));
            title(Component.literal("HALFTIME").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD),
                    Component.literal("HOME " + score(Lobby.Side.HOME) + " - " + score(Lobby.Side.AWAY) + " AWAY"));
            setUpKickoff(openingReceiver, 35); // the team that received first kicks off the second half
        } else {
            broadcast(Component.literal("End of Q" + (quarter - 1) + ". ").withStyle(ChatFormatting.AQUA).append(scoreLine()));
        }
        pushState();
    }

    /** Spectators drift if they fly around; keep their real body above midfield so the field stays loaded. */
    private void keepInBooth(MinecraftServer server) {
        ServerLevel level = server.getLevel(ResourceKey.create(Registries.DIMENSION, field.dimension()));
        if (level == null) return;
        Vec3 booth = field.geometry().center().add(0, BOOTH_HEIGHT, 0);
        for (UUID uuid : humans()) {
            ServerPlayer sp = server.getPlayerList().getPlayer(uuid);
            if (sp == null) continue;
            if (sp.level() != level || sp.position().distanceToSqr(booth) > 36) {
                sp.teleportTo(level, booth.x, booth.y, booth.z, sp.getYRot(), sp.getXRot());
            }
            if (!sp.isSpectator()) sp.setGameMode(GameType.SPECTATOR);
        }
    }

    // ------------------------------------------------------------------ client sync

    private MatchStatePacket.Phase phase() {
        if (engine == null) return MatchStatePacket.Phase.PRE_SNAP;
        return switch (engine.state()) {
            case PRE_SNAP -> MatchStatePacket.Phase.PRE_SNAP;
            case LIVE -> MatchStatePacket.Phase.LIVE;
            case BALL_IN_AIR -> MatchStatePacket.Phase.BALL_IN_AIR;
            case DEAD -> MatchStatePacket.Phase.DEAD;
        };
    }

    private MatchStatePacket statePacketFor(UUID viewer) {
        Lobby.Side side = sideOf(viewer);
        if (side == null || finished) return MatchStatePacket.inactive();
        int follow = -1, controlled = -1, hints = 0, playClock = -1;
        int[] passTargets = new int[0];
        String callName = "";
        if (engine != null) {
            follow = engine.followEntityId();
            FootballPlayerEntity c = engine.controlledBy(viewer);
            if (c != null) controlled = c.getId();
            FootballPlayerEntity carrier = engine.carrier();
            boolean myBall = carrier != null && engine.state() != com.sportsmc.game.PlayEngine.State.PRE_SNAP
                    ? carrier.side() == side : possession == side;
            if (myBall) hints |= MatchStatePacket.HINT_OFFENSE;
            if (c != null && c == carrier) hints |= MatchStatePacket.HINT_CARRIER;
            if (c != null && c == carrier && engine.canThrow()) {
                hints |= MatchStatePacket.HINT_CAN_THROW;
                passTargets = engine.passTargetIds();
            }
            if (engine.play().run()) hints |= MatchStatePacket.HINT_RUN_PLAY;
            if (engine.isKickoff() || kickoffNext) hints |= MatchStatePacket.HINT_KICKOFF;
            if (engine.isKickoff() || engine.play().kick()) hints |= MatchStatePacket.HINT_KICK_PLAY;
            if (tryNext) hints |= MatchStatePacket.HINT_TRY;
            callName = engine.offense() == side ? engine.playName() : engine.coverage().label;
            if (engine.offense() == side) playClock = engine.playClockSeconds();
        }
        Participant home = sides.get(Lobby.Side.HOME), away = sides.get(Lobby.Side.AWAY);
        int clockSecs = (ticksLeftInQuarter + 19) / 20;
        // Lines show the line of scrimmage of the play being run (between plays: the next spot).
        float los = engine != null && engine.state() != PlayEngine.State.DEAD ? (float) engine.losYard() : (float) ballYard;
        return new MatchStatePacket(true, field.id(), phase(), possession, side, los, (float) firstDownYard,
                down, follow, controlled, callName, hints,
                home.name(), away.name(), score(Lobby.Side.HOME), score(Lobby.Side.AWAY),
                quarter, clockSecs, playClock, breakTicks > 0, passTargets,
                engine != null ? engine.boostLevel(viewer) : 1f, engine != null && engine.boostExhausted(viewer),
                engine != null && engine.onDefense(viewer));
    }

    public void pushState() {
        MinecraftServer server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        for (UUID uuid : humans()) {
            ServerPlayer sp = server.getPlayerList().getPlayer(uuid);
            if (sp != null) ModNetwork.sendTo(sp, statePacketFor(uuid));
        }
    }

    public void sendStateTo(ServerPlayer player) {
        ModNetwork.sendTo(player, statePacketFor(player.getUUID()));
    }

    private void sendToAll(MatchStatePacket packet) {
        for (ServerPlayer sp : onlineHumans()) ModNetwork.sendTo(sp, packet);
    }

    // ------------------------------------------------------------------ presentation helpers

    private List<ServerPlayer> onlineHumans() {
        List<ServerPlayer> out = new ArrayList<>(2);
        MinecraftServer server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server == null) return out;
        for (UUID uuid : humans()) {
            ServerPlayer sp = server.getPlayerList().getPlayer(uuid);
            if (sp != null) out.add(sp);
        }
        return out;
    }

    /** Big on-screen title for everyone in the game. */
    public void title(Component main, Component sub) {
        for (ServerPlayer sp : onlineHumans()) {
            sp.connection.send(new ClientboundSetTitlesAnimationPacket(4, 36, 10));
            sp.connection.send(new ClientboundSetSubtitleTextPacket(sub));
            sp.connection.send(new ClientboundSetTitleTextPacket(main));
        }
    }

    /**
     * Plays a sound at a spot on the field for the players in this game. Sent directly so it reaches
     * them even though their real bodies are up in the booth; it is heard from the camera's position.
     */
    public void sound(Vec3 at, SoundEvent sound, float volume, float pitch) {
        for (ServerPlayer sp : onlineHumans()) {
            sp.connection.send(new ClientboundSoundPacket(BuiltInRegistries.SOUND_EVENT.wrapAsHolder(sound), SoundSource.PLAYERS,
                    at.x, at.y, at.z, volume, pitch, sp.level().getRandom().nextLong()));
        }
    }

    /** Particles on the field for the players in this game (long-distance so the booth doesn't matter). */
    public <T extends ParticleOptions> void particles(T type, Vec3 at, int count, double dx, double dy, double dz, double speed) {
        for (ServerPlayer sp : onlineHumans()) {
            sp.serverLevel().sendParticles(sp, type, true, at.x, at.y, at.z, count, dx, dy, dz, speed);
        }
    }

    private void announceDownAndDistance() {
        broadcast(Component.literal(sides.get(possession).name() + ": ").withStyle(ChatFormatting.AQUA)
                .append(Component.literal(downAndDistance() + " at " + yardLabel(ballYard)).withStyle(ChatFormatting.WHITE)));
    }

    public String downAndDistance() {
        if (kickoffNext) return "Kickoff";
        if (tryNext) return "Try (PAT / 2-pt)";
        String ord = switch (down) { case 1 -> "1st"; case 2 -> "2nd"; case 3 -> "3rd"; default -> "4th"; };
        boolean goal = firstDownYard <= 0 || firstDownYard >= 100;
        if (goal) return ord + " & Goal";
        double togo = Math.abs(firstDownYard - ballYard);
        return ord + " & " + (togo < 1 ? "Inches" : String.valueOf((int) Math.ceil(togo - 0.001)));
    }

    /** "HOME 25", "the 50", "AWAY 34" - the side of the field the ball is on. */
    public static String yardLabel(double yard) {
        int y = (int) Math.round(yard);
        if (y == 50) return "the 50";
        return y < 50 ? "HOME " + y : "AWAY " + (100 - y);
    }

    private Component scoreLine() {
        return Component.literal("[HOME " + score(Lobby.Side.HOME) + " - " + score(Lobby.Side.AWAY) + " AWAY]")
                .withStyle(ChatFormatting.WHITE);
    }

    public void broadcast(Component msg) {
        Component full = Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD).append(msg);
        for (ServerPlayer sp : onlineHumans()) sp.sendSystemMessage(full);
    }

    /** Message just for the human on one side (if any). */
    public void notifySide(Lobby.Side side, Component msg) {
        UUID uuid = humanOf(side);
        if (uuid == null) return;
        for (ServerPlayer sp : onlineHumans()) {
            if (sp.getUUID().equals(uuid)) sp.sendSystemMessage(Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD).append(msg));
        }
    }

    // ------------------------------------------------------------------ helpers

    private void sendPlayersBack() {
        MinecraftServer server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        for (Map.Entry<UUID, ReturnPoint> e : returnPoints.entrySet()) {
            ServerPlayer sp = server.getPlayerList().getPlayer(e.getKey());
            ReturnPoint rp = e.getValue();
            ServerLevel level = server.getLevel(rp.dimension());
            if (sp == null || level == null) continue;
            sp.setGameMode(rp.gameType());
            sp.teleportTo(level, rp.pos().x, rp.pos().y, rp.pos().z, rp.yRot(), rp.xRot());
            com.sportsmc.match.SafeReturn.forget(sp);
        }
        returnPoints.clear();
    }

    private static int dir(Lobby.Side side) {
        return side == Lobby.Side.HOME ? 1 : -1;
    }

    private static double clampYard(double y) {
        return Math.max(0, Math.min(100, y));
    }
}
