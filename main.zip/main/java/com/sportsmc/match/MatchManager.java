package com.sportsmc.match;

import com.sportsmc.SportsMC;
import com.sportsmc.field.FieldData;
import com.sportsmc.lobby.Lobby;
import com.sportsmc.lobby.LobbyManager;
import com.sportsmc.network.AirHockeyStatePacket;
import com.sportsmc.network.MatchStatePacket;
import com.sportsmc.network.ModNetwork;
import com.sportsmc.network.TennisStatePacket;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Runs every active match (one per lobby).
 *
 * Every call into a match is guarded: an error inside a match's tick would otherwise propagate into the
 * server tick and crash the whole server. Instead the broken match is logged, stopped, its players are
 * sent back, and everyone else keeps playing.
 */
public final class MatchManager {

    private static final MatchManager INSTANCE = new MatchManager();

    private final Map<UUID, SportMatch> matches = new HashMap<>(); // lobbyId -> match
    /** Matches that hit an error; removed on the next cleanup even if finish() itself failed. */
    private final Set<SportMatch> aborted = Collections.newSetFromMap(new IdentityHashMap<>());

    private MatchManager() {}

    public static MatchManager get() {
        return INSTANCE;
    }

    public void start(Lobby lobby, @Nullable FieldData field) {
        if (field == null && lobby.sport().fieldType != null) return;
        SportMatch match;
        try {
            match = switch (lobby.sport()) {
                case TENNIS -> new com.sportsmc.tennis.TennisMatch(lobby, field);
                case AIR_HOCKEY -> new com.sportsmc.airhockey.AirHockeyMatch(lobby);
                case CARD_DOJO -> new com.sportsmc.cards.CardMatch(lobby);
                case BOWLING -> new com.sportsmc.bowling.BowlingMatch(lobby, field);
                default -> new FootballMatch(lobby, field);
            };
        } catch (Exception e) {
            SportsMC.LOGGER.error("SportsMC: couldn't create a {} match", lobby.sport(), e);
            tellLobby(lobby, "The match couldn't start because of an error (details are in the server log).");
            return;
        }
        matches.put(lobby.id(), match);
        lobby.setState(Lobby.State.IN_MATCH);
        MinecraftServer server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        try {
            match.kickoff(server);
        } catch (Exception | StackOverflowError e) {
            abort(match, "kickoff", e);
            cleanup();
        }
    }

    @Nullable
    public SportMatch matchFor(Lobby lobby) {
        return matches.get(lobby.id());
    }

    /** True if this player is in a match that's still running. */
    public boolean isPlaying(UUID player) {
        for (SportMatch m : matches.values()) {
            if (!m.isFinished() && !aborted.contains(m) && safeInvolves(m, player)) return true;
        }
        return false;
    }

    /** Routes a player's controls to the match they're in. */
    public void control(ServerPlayer player, com.sportsmc.network.ControlPacket msg) {
        for (SportMatch m : new ArrayList<>(matches.values())) {
            if (m.isFinished() || aborted.contains(m) || !safeInvolves(m, player.getUUID())) continue;
            try {
                m.control(player.getUUID(), msg);
            } catch (Exception | StackOverflowError e) {
                abort(m, "player input", e);
                cleanup();
            }
            return;
        }
    }

    /** Air hockey: a player's mallet (and, on their half, the puck) from their game. */
    public void airHockeyInput(ServerPlayer player, com.sportsmc.network.AirHockeyInputPacket msg) {
        for (SportMatch m : new ArrayList<>(matches.values())) {
            if (!(m instanceof com.sportsmc.airhockey.AirHockeyMatch ah) || m.isFinished() || aborted.contains(m)
                    || !safeInvolves(m, player.getUUID())) continue;
            try {
                ah.input(player, msg);
            } catch (Exception | StackOverflowError e) {
                abort(m, "air hockey input", e);
                cleanup();
            }
            return;
        }
    }

    /** Card Dojo: a player plays a card. */
    public void cardPick(ServerPlayer player, com.sportsmc.network.CardPickPacket msg) {
        for (SportMatch m : new ArrayList<>(matches.values())) {
            if (!(m instanceof com.sportsmc.cards.CardMatch cm) || m.isFinished() || aborted.contains(m)
                    || !safeInvolves(m, player.getUUID())) continue;
            try {
                cm.pick(player, msg);
            } catch (Exception | StackOverflowError e) {
                abort(m, "card pick", e);
                cleanup();
            }
            return;
        }
    }

    /** Bowling: the bowler lets go of the ball. */
    public void bowlingThrow(ServerPlayer player, com.sportsmc.network.BowlingThrowPacket msg) {
        for (SportMatch m : new ArrayList<>(matches.values())) {
            if (!(m instanceof com.sportsmc.bowling.BowlingMatch bm) || m.isFinished() || aborted.contains(m)
                    || !safeInvolves(m, player.getUUID())) continue;
            try {
                bm.throwBall(player, msg);
            } catch (Exception | StackOverflowError e) {
                abort(m, "bowling throw", e);
                cleanup();
            }
            return;
        }
    }

    /** Re-sends the line state to a player who (re)joins mid-match. */
    public void resync(ServerPlayer player) {
        for (SportMatch m : new ArrayList<>(matches.values())) {
            if (m.isFinished() || aborted.contains(m) || !safeInvolves(m, player.getUUID())) continue;
            try {
                m.sendStateTo(player);
            } catch (Exception e) {
                abort(m, "resync", e);
            }
        }
        cleanup();
    }

    public boolean isFieldInUse(UUID fieldId) {
        for (SportMatch m : matches.values()) {
            if (!m.isFinished() && !aborted.contains(m) && m.field() != null && m.field().id().equals(fieldId)) return true;
        }
        return false;
    }

    public void forfeit(Lobby lobby, UUID player) {
        SportMatch match = matches.get(lobby.id());
        if (match != null && !aborted.contains(match)) {
            try {
                match.forfeit(player);
            } catch (Exception | StackOverflowError e) {
                abort(match, "forfeit", e);
            }
        }
        cleanup();
    }

    public void tick(MinecraftServer server) {
        for (SportMatch match : new ArrayList<>(matches.values())) {
            if (match.isFinished() || aborted.contains(match)) continue;
            long t0 = System.nanoTime();
            try {
                match.tick(server);
            } catch (Exception | StackOverflowError e) {
                abort(match, "tick", e);
            }
            com.sportsmc.debug.SportsDebug.add(switch (match.lobby().sport()) {
                case TENNIS -> com.sportsmc.debug.SportsDebug.Part.TENNIS;
                case AIR_HOCKEY -> com.sportsmc.debug.SportsDebug.Part.AIR_HOCKEY;
                case CARD_DOJO -> com.sportsmc.debug.SportsDebug.Part.CARDS;
                case BOWLING -> com.sportsmc.debug.SportsDebug.Part.BOWLING;
                default -> com.sportsmc.debug.SportsDebug.Part.FOOTBALL;
            }, System.nanoTime() - t0);
        }
        cleanup();
    }

    /** Server shutting down: end every match so players get their game mode and position back. */
    public void stopAll() {
        for (SportMatch m : new ArrayList<>(matches.values())) {
            try {
                m.finish(null);
            } catch (Exception | StackOverflowError e) {
                SportsMC.LOGGER.error("SportsMC: error ending a match during shutdown", e);
            }
        }
        cleanup();
    }

    /** One line per running match, for /sportsmc debug. */
    public List<String> describe() {
        List<String> out = new ArrayList<>();
        for (SportMatch m : matches.values()) {
            if (m.isFinished()) continue;
            List<String> names = new ArrayList<>();
            for (Lobby.Member member : m.lobby().members()) names.add(member.name);
            String vs = m.lobby().mode() == Lobby.Mode.VS_CPU ? " vs CPU (" + m.lobby().difficulty().englishName() + ")" : "";
            out.add(m.lobby().sport().displayName + ": " + String.join(" vs ", names) + vs
                    + (m.field() != null ? " on \"" + m.field().name() + "\"" : ""));
        }
        return out;
    }

    public void reset() {
        matches.clear();
        aborted.clear();
    }

    // ------------------------------------------------------------------ error handling

    /** A match threw: log it, try to end it normally, and make sure its players aren't left stranded. */
    private void abort(SportMatch m, String during, Throwable error) {
        if (!aborted.add(m)) return;
        Lobby lobby = m.lobby();
        SportsMC.LOGGER.error("SportsMC: the {} match in {}'s lobby hit an error during {} and was stopped to protect the server. "
                + "Please report this with the stack trace below.", lobby.sport(), hostName(lobby), during, error);
        try {
            m.finish(null);
        } catch (Exception | StackOverflowError e) {
            SportsMC.LOGGER.error("SportsMC: ending the broken match also failed", e);
        }
        MinecraftServer server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        for (Lobby.Member member : lobby.members()) {
            ServerPlayer sp = server.getPlayerList().getPlayer(member.uuid);
            if (sp == null) continue;
            try {
                // finish() normally does all of this; repeat it in case finish() is what broke.
                ModNetwork.sendTo(sp, MatchStatePacket.inactive());
                ModNetwork.sendTo(sp, TennisStatePacket.inactive());
                ModNetwork.sendTo(sp, AirHockeyStatePacket.inactive());
                ModNetwork.sendTo(sp, com.sportsmc.network.CardStatePacket.inactive());
                ModNetwork.sendTo(sp, com.sportsmc.network.BowlingStatePacket.inactive());
                SafeReturn.restoreIfStranded(sp);
                sp.sendSystemMessage(Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD)
                        .append(Component.literal("The match hit an error and was stopped (details are in the server log). Sorry!")
                                .withStyle(ChatFormatting.RED)));
            } catch (Exception e) {
                SportsMC.LOGGER.error("SportsMC: couldn't reset {} after a broken match", sp.getGameProfile().getName(), e);
            }
        }
    }

    private static boolean safeInvolves(SportMatch m, UUID player) {
        try {
            return m.involves(player);
        } catch (Exception e) {
            return false;
        }
    }

    private static String hostName(Lobby lobby) {
        Lobby.Member host = lobby.member(lobby.host());
        return host != null ? host.name : "?";
    }

    private static void tellLobby(Lobby lobby, String text) {
        MinecraftServer server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        for (Lobby.Member member : lobby.members()) {
            ServerPlayer sp = server.getPlayerList().getPlayer(member.uuid);
            if (sp != null) sp.sendSystemMessage(Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD)
                    .append(Component.literal(text).withStyle(ChatFormatting.RED)));
        }
    }

    private void cleanup() {
        List<SportMatch> done = new ArrayList<>();
        for (SportMatch m : matches.values()) if (m.isFinished() || aborted.contains(m)) done.add(m);
        for (SportMatch m : done) {
            matches.remove(m.lobby().id());
            aborted.remove(m);
            try {
                LobbyManager.get().onMatchEnded(m.lobby());
            } catch (Exception e) {
                SportsMC.LOGGER.error("SportsMC: error resetting a lobby after its match", e);
            }
        }
    }
}
