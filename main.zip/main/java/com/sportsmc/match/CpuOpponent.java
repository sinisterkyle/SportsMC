package com.sportsmc.match;

import com.sportsmc.game.TeamSkill;
import com.sportsmc.lobby.Difficulty;
import com.sportsmc.lobby.Lobby;

/**
 * The CPU side of a match. All CPU decisions (play calls, QB reads, coverage, pursuit) are made by the
 * PlayEngine; this class turns the difficulty into the numbers it plays with.
 */
public class CpuOpponent {

    private final FootballMatch match;
    private final Lobby.Side side;
    private final Difficulty difficulty;

    public CpuOpponent(FootballMatch match, Lobby.Side side, Difficulty difficulty) {
        this.match = match;
        this.side = side;
        this.difficulty = difficulty;
    }

    public Lobby.Side side() { return side; }
    public Difficulty difficulty() { return difficulty; }

    public TeamSkill skill() {
        return switch (difficulty) {
            //                       tackle  INT   cushion  QB err  react  hold
            case ROOKIE -> new TeamSkill(0.10, 0.12, 3.0, 1.30, 14, 60);
            case PRO -> new TeamSkill(0.17, 0.25, 2.0, 0.80, 9, 50);
            case ALL_PRO -> new TeamSkill(0.24, 0.36, 1.3, 0.50, 5, 42);
            case LEGEND -> new TeamSkill(0.32, 0.48, 0.8, 0.30, 2, 36);
        };
    }

    public void tick() {
        // CPU decisions happen inside PlayEngine each tick.
    }
}
