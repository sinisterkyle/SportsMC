package com.sportsmc.match;

import com.sportsmc.SportsMC;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;

/**
 * A backup of where a player was before a match, stored on the player itself (saved with their player data).
 * Matches already send players back when they end normally; this covers the cases where they can't:
 * the server crashed, was killed, or a match hit an error. On the next login a player who still has a
 * backup and isn't in a match gets their position, game mode and invulnerability put back.
 */
public final class SafeReturn {

    private static final String KEY = "sportsmc_return";

    private SafeReturn() {}

    /** Remembers the player's spot, game mode and invulnerability. Keeps an older backup if one exists. */
    public static void remember(ServerPlayer sp, boolean moved) {
        CompoundTag root = sp.getPersistentData();
        if (root.contains(KEY)) return; // still stranded from an earlier match: keep the original spot
        CompoundTag t = new CompoundTag();
        t.putBoolean("moved", moved);
        t.putString("dim", sp.level().dimension().location().toString());
        t.putDouble("x", sp.getX());
        t.putDouble("y", sp.getY());
        t.putDouble("z", sp.getZ());
        t.putFloat("yRot", sp.getYRot());
        t.putFloat("xRot", sp.getXRot());
        t.putInt("mode", sp.gameMode.getGameModeForPlayer().getId());
        t.putBoolean("invulnerable", sp.isInvulnerable());
        root.put(KEY, t);
    }

    /** The match ended normally and put the player back itself. */
    public static void forget(ServerPlayer sp) {
        sp.getPersistentData().remove(KEY);
    }

    /** Puts a player back if a match never got to (call on login, when they aren't in a match). */
    public static void restoreIfStranded(ServerPlayer sp) {
        CompoundTag root = sp.getPersistentData();
        if (!root.contains(KEY)) return;
        CompoundTag t = root.getCompound(KEY);
        root.remove(KEY);
        try {
            sp.setInvulnerable(t.getBoolean("invulnerable"));
            if (t.getBoolean("moved")) {
                sp.setGameMode(GameType.byId(t.getInt("mode")));
                ResourceLocation dim = ResourceLocation.tryParse(t.getString("dim"));
                ServerLevel level = dim == null ? null : sp.server.getLevel(ResourceKey.create(Registries.DIMENSION, dim));
                if (level == null) level = sp.server.overworld();
                sp.teleportTo(level, t.getDouble("x"), t.getDouble("y"), t.getDouble("z"), t.getFloat("yRot"), t.getFloat("xRot"));
            }
            SportsMC.LOGGER.info("Restored {} to where they were before an unfinished SportsMC match.", sp.getGameProfile().getName());
        } catch (Exception e) {
            SportsMC.LOGGER.error("Couldn't restore {} after an unfinished match", sp.getGameProfile().getName(), e);
        }
    }
}
