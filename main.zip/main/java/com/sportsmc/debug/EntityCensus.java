package com.sportsmc.debug;

import com.sportsmc.entity.FootballEntity;
import com.sportsmc.entity.FootballPlayerEntity;
import com.sportsmc.entity.TennisBallEntity;
import com.sportsmc.entity.TennisPlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;

import java.util.ArrayList;
import java.util.List;

/** Counts SportsMC's entities in every loaded dimension, and removes leftovers no running match owns. */
public final class EntityCensus {

    /** Not claimed by a running match for this long = a leftover. */
    private static final int LEFTOVER_TICKS = 40;

    private EntityCensus() {}

    /** [football players, footballs, tennis players, tennis balls, leftovers]. */
    public static int[] count(MinecraftServer server) {
        int[] c = new int[5];
        for (ServerLevel level : server.getAllLevels()) {
            for (Entity e : level.getAllEntities()) {
                if (e instanceof TennisPlayerEntity t) { c[2]++; if (t.unclaimedTicks() > LEFTOVER_TICKS) c[4]++; }
                else if (e instanceof FootballPlayerEntity f) { c[0]++; if (f.unclaimedTicks() > LEFTOVER_TICKS) c[4]++; }
                else if (e instanceof FootballEntity b) { c[1]++; if (b.unclaimedTicks() > LEFTOVER_TICKS) c[4]++; }
                else if (e instanceof TennisBallEntity b) { c[3]++; if (b.unclaimedTicks() > LEFTOVER_TICKS) c[4]++; }
            }
        }
        return c;
    }

    /** Removes SportsMC entities no running match has claimed lately. Returns how many. */
    public static int cleanup(MinecraftServer server) {
        List<Entity> doomed = new ArrayList<>();
        for (ServerLevel level : server.getAllLevels()) {
            for (Entity e : level.getAllEntities()) {
                int unclaimed = e instanceof FootballPlayerEntity f ? f.unclaimedTicks()
                        : e instanceof FootballEntity fb ? fb.unclaimedTicks()
                        : e instanceof TennisBallEntity tb ? tb.unclaimedTicks() : -1;
                if (unclaimed > LEFTOVER_TICKS) doomed.add(e);
            }
        }
        for (Entity e : doomed) e.discard(); // outside the loop: don't change the entity list while walking it
        return doomed.size();
    }
}
