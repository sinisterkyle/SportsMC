package com.sportsmc.debug;

import com.sportsmc.SportsMC;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Measures how much server time SportsMC itself uses, split by part, over the last 5 seconds, plus packets per
 * second by type. Always on (timing a few calls per tick costs microseconds). Read it with /sportsmc debug.
 *
 * Also: /sportsmc debug watch shows a live line on your action bar, /sportsmc debug log writes a summary to the
 * server console every 30 s, and any single tick where SportsMC takes over 20 ms is logged as a warning with
 * the breakdown (at most once every 5 s).
 */
public final class SportsDebug {

    public enum Part {
        LOBBY("Lobbies & invites"), FOOTBALL("Football matches"), TENNIS("Tennis matches"),
        AIR_HOCKEY("Air hockey matches"), CARDS("Card Dojo matches"), BOWLING("Bowling games"), ENTITIES("SportsMC entities (players & balls)"), PACKETS("Handling packets from players");

        public final String label;
        Part(String label) { this.label = label; }
    }

    public static final int WINDOW = 100; // ticks = 5 s
    private static final long SPIKE_NS = 20_000_000L;

    private static final long[][] samples = new long[Part.values().length][WINDOW];
    private static final long[] current = new long[Part.values().length];
    private static int index, filled;
    private static long serverTicks;

    private static final Map<String, AtomicLong> sentThisSecond = new ConcurrentHashMap<>(), recvThisSecond = new ConcurrentHashMap<>();
    private static Map<String, Long> sentLastSecond = Map.of(), recvLastSecond = Map.of();

    private static final Set<UUID> watchers = new HashSet<>();
    private static boolean consoleLog;
    private static long lastSpikeLog = -1_000;

    private SportsDebug() {}

    // ------------------------------------------------------------------ recording

    public static void add(Part part, long nanos) {
        current[part.ordinal()] += nanos;
    }

    public static void packetSent(Object msg) {
        sentThisSecond.computeIfAbsent(name(msg), k -> new AtomicLong()).incrementAndGet();
    }

    public static void packetReceived(Object msg) {
        recvThisSecond.computeIfAbsent(name(msg), k -> new AtomicLong()).incrementAndGet();
    }

    private static String name(Object msg) {
        return msg.getClass().getSimpleName().replace("Packet", "");
    }

    /** Called once at the end of every server tick. */
    public static void endTick(MinecraftServer server) {
        serverTicks++;
        long total = 0;
        for (int p = 0; p < current.length; p++) {
            samples[p][index] = current[p];
            total += current[p];
        }
        if (total > SPIKE_NS && serverTicks - lastSpikeLog >= 100) {
            lastSpikeLog = serverTicks;
            StringBuilder sb = new StringBuilder();
            for (Part part : Part.values()) {
                long ns = current[part.ordinal()];
                if (ns > 100_000) sb.append(part.label).append(' ').append(ms(ns)).append(" ms, ");
            }
            SportsMC.LOGGER.warn("[SportsMC debug] Slow tick: SportsMC took {} ms this tick ({})", ms(total), sb);
            for (ServerPlayer sp : watcherPlayers(server)) {
                sp.sendSystemMessage(Component.literal("[SportsMC debug] Slow tick: " + ms(total) + " ms (" + sb + ")")
                        .withStyle(ChatFormatting.RED));
            }
        }
        java.util.Arrays.fill(current, 0);
        index = (index + 1) % WINDOW;
        filled = Math.min(WINDOW, filled + 1);

        if (serverTicks % 20 == 0) {
            sentLastSecond = snapshot(sentThisSecond);
            recvLastSecond = snapshot(recvThisSecond);
            for (ServerPlayer sp : watcherPlayers(server)) sp.displayClientMessage(liveLine(server), true);
        }
        if (consoleLog && serverTicks % 600 == 0) {
            for (Component line : report(server, false)) SportsMC.LOGGER.info("[SportsMC debug] {}", line.getString());
        }
    }

    private static Map<String, Long> snapshot(Map<String, AtomicLong> counters) {
        Map<String, Long> out = new TreeMap<>();
        for (Map.Entry<String, AtomicLong> e : counters.entrySet()) {
            long n = e.getValue().getAndSet(0);
            if (n > 0) out.put(e.getKey(), n);
        }
        return out;
    }

    // ------------------------------------------------------------------ reading

    /** Average and max milliseconds per tick for one part (or all parts when part is null) over the window. */
    public static double[] stats(Part part) {
        if (filled == 0) return new double[]{0, 0};
        long sum = 0, max = 0;
        for (int i = 0; i < filled; i++) {
            long v = 0;
            if (part == null) for (long[] s : samples) v += s[i];
            else v = samples[part.ordinal()][i];
            sum += v;
            max = Math.max(max, v);
        }
        return new double[]{sum / (double) filled / 1e6, max / 1e6};
    }

    private static long totalOf(Map<String, Long> m) {
        long t = 0;
        for (long v : m.values()) t += v;
        return t;
    }

    public static Component liveLine(MinecraftServer server) {
        double[] all = stats(null);
        double mspt = server.getAverageTickTime();
        return Component.literal(String.format("SportsMC %.2f ms/tick (max %.1f) • server %.1f ms/tick • %d matches • pkts/s out %d in %d",
                all[0], all[1], mspt, com.sportsmc.match.MatchManager.get().describe().size(),
                totalOf(sentLastSecond), totalOf(recvLastSecond))).withStyle(all[1] > 20 ? ChatFormatting.RED : ChatFormatting.AQUA);
    }

    /** The full /sportsmc debug report. */
    public static java.util.List<Component> report(MinecraftServer server, boolean withHints) {
        java.util.List<Component> out = new java.util.ArrayList<>();
        double mspt = server.getAverageTickTime();
        double[] all = stats(null);
        out.add(Component.literal("==== SportsMC " + SportsMC.VERSION + " debug (last " + filled / 20 + " s) ====").withStyle(ChatFormatting.GOLD));
        out.add(Component.literal(String.format("Server: %.2f ms per tick (%.1f TPS; 50 ms = limit)", mspt, Math.min(20, 1000 / Math.max(mspt, 50f))))
                .withStyle(mspt > 45 ? ChatFormatting.RED : ChatFormatting.WHITE));
        out.add(Component.literal(String.format("SportsMC: %.3f ms avg, %.2f ms worst tick = %.1f%% of the server's tick time",
                all[0], all[1], mspt > 0 ? all[0] / mspt * 100 : 0)).withStyle(all[0] > 5 ? ChatFormatting.RED : ChatFormatting.GREEN));
        for (Part part : Part.values()) {
            double[] s = stats(part);
            out.add(Component.literal(String.format("  %s: %.3f avg / %.2f max ms", part.label, s[0], s[1]))
                    .withStyle(s[1] > 10 ? ChatFormatting.RED : ChatFormatting.GRAY));
        }
        java.util.List<String> matches = com.sportsmc.match.MatchManager.get().describe();
        out.add(Component.literal("Matches running: " + matches.size() + (matches.isEmpty() ? "" : " - " + String.join("; ", matches))));
        out.add(Component.literal("Lobbies: " + com.sportsmc.lobby.LobbyManager.get().lobbyCount()
                + ", pending invites: " + com.sportsmc.lobby.LobbyManager.get().inviteCount()
                + ", saved fields: " + com.sportsmc.field.FieldRegistry.get(server).all().size()));
        out.add(entityLine(server));
        out.add(Component.literal("Packets/s sent: " + totalOf(sentLastSecond) + " " + sentLastSecond));
        out.add(Component.literal("Packets/s received: " + totalOf(recvLastSecond) + " " + recvLastSecond));
        Runtime rt = Runtime.getRuntime();
        out.add(Component.literal(String.format("Memory (whole server): %d / %d MB used", (rt.totalMemory() - rt.freeMemory()) >> 20, rt.maxMemory() >> 20)));
        if (withHints) {
            out.add(Component.literal("Tip: /sportsmc debug watch = live line, /sportsmc debug log = console every 30 s, "
                    + "/sportsmc debug cleanup = remove leftover SportsMC entities").withStyle(ChatFormatting.DARK_GRAY));
        }
        return out;
    }

    private static Component entityLine(MinecraftServer server) {
        int[] counts = EntityCensus.count(server);
        String text = String.format("Entities: %d football players, %d footballs, %d tennis players, %d tennis balls - %d unclaimed (leftovers)",
                counts[0], counts[1], counts[2], counts[3], counts[4]);
        return Component.literal(text).withStyle(counts[4] > 0 ? ChatFormatting.RED : ChatFormatting.WHITE);
    }

    // ------------------------------------------------------------------ toggles

    /** Returns true if the player is now watching. */
    public static boolean toggleWatch(UUID player) {
        if (watchers.remove(player)) return false;
        watchers.add(player);
        return true;
    }

    public static boolean toggleConsoleLog() {
        consoleLog = !consoleLog;
        return consoleLog;
    }

    private static java.util.List<ServerPlayer> watcherPlayers(MinecraftServer server) {
        java.util.List<ServerPlayer> out = new java.util.ArrayList<>();
        if (watchers.isEmpty()) return out;
        for (UUID id : watchers) {
            ServerPlayer sp = server.getPlayerList().getPlayer(id);
            if (sp != null) out.add(sp);
        }
        return out;
    }

    public static void reset() {
        for (long[] s : samples) java.util.Arrays.fill(s, 0);
        java.util.Arrays.fill(current, 0);
        index = filled = 0;
        watchers.clear();
        consoleLog = false;
    }

    private static String ms(long ns) {
        return String.format("%.1f", ns / 1e6);
    }
}
