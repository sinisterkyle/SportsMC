package com.sportsmc.airhockey;

import javax.annotation.Nullable;

/**
 * The air hockey table physics, shared by the server and both players' games so everyone simulates the
 * puck exactly the same way. Pure math (no Minecraft classes), safe on either side.
 *
 * Table frame: x from -0.5 to 0.5 (width 1), y from -1 to 1 (length 2). HOME defends the goal at y = -1,
 * AWAY the goal at y = +1. Speeds are per tick; each tick runs in small sub-steps so fast shots can't pass
 * through mallets or walls.
 */
public final class AirHockeyPhysics {

    public static final double HALF_W = 0.5, HALF_L = 1.0;
    /** Real-table proportions: puck ~7% and mallet ~11% of the table's width, goal mouth about a third. */
    public static final double PUCK_R = 0.035, MALLET_R = 0.055, GOAL_HALF = 0.17;
    public static final int SUBSTEPS = 10;
    public static final double FRICTION = 0.993;        // per tick (air table: very little)
    public static final double MAX_PUCK_SPEED = 0.115;  // per tick (about 1 table length in 0.9 s)
    public static final double MAX_MALLET_STEP = 0.32;  // how far a mallet can move in one tick
    public static final double WALL_BOUNCE = 0.88, MALLET_BOUNCE = 0.92;
    /** A puck that sits nearly still for this long floats back toward the middle (like the table's air). */
    public static final int DRIFT_AFTER = 40;

    // Events reported by step().
    public static final int HIT_HOME = 1, HIT_AWAY = 2, WALL = 4, GOAL_FOR_HOME = 8, GOAL_FOR_AWAY = 16;

    private AirHockeyPhysics() {}

    /** The puck's state. Mutable; copy() before experimenting with it. */
    public static final class Puck {
        public double x, y, vx, vy;
        public int slowTicks;
        /** Strength (0..1) of the hardest mallet hit during the last step. */
        public double lastHitStrength;

        public Puck() {}

        public Puck(double x, double y, double vx, double vy) {
            this.x = x; this.y = y; this.vx = vx; this.vy = vy;
        }

        public Puck copy() {
            Puck p = new Puck(x, y, vx, vy);
            p.slowTicks = slowTicks;
            return p;
        }

        public void set(Puck o) {
            x = o.x; y = o.y; vx = o.vx; vy = o.vy; slowTicks = o.slowTicks;
        }

        public boolean finite() {
            return Double.isFinite(x) && Double.isFinite(y) && Double.isFinite(vx) && Double.isFinite(vy);
        }
    }

    /**
     * One tick. Each mallet moves in a straight line from `from` to `to` during the tick (pass nulls to leave a
     * mallet out, e.g. for a quick prediction). Returns the events that happened (bits above). On a goal the
     * step stops right there with the puck just past the goal line.
     */
    public static int step(Puck p, @Nullable double[] homeFrom, @Nullable double[] homeTo,
                           @Nullable double[] awayFrom, @Nullable double[] awayTo) {
        int events = 0;
        p.lastHitStrength = 0;
        for (int i = 1; i <= SUBSTEPS; i++) {
            double f = i / (double) SUBSTEPS;
            if (homeFrom != null && homeTo != null) events |= collideMallet(p, homeFrom, homeTo, f, true);
            if (awayFrom != null && awayTo != null) events |= collideMallet(p, awayFrom, awayTo, f, false);
            p.x += p.vx / SUBSTEPS;
            p.y += p.vy / SUBSTEPS;
            int w = walls(p);
            events |= w;
            if ((w & (GOAL_FOR_HOME | GOAL_FOR_AWAY)) != 0) return events;
        }
        p.vx *= FRICTION;
        p.vy *= FRICTION;
        // Never let the puck die in a corner: after sitting still for a moment it drifts toward the middle.
        if (Math.sqrt(p.vx * p.vx + p.vy * p.vy) < 0.003) {
            if (++p.slowTicks > DRIFT_AFTER) {
                double dx = -p.x, dy = -p.y, len = Math.sqrt(dx * dx + dy * dy);
                if (len < 1e-6) { dx = 0; dy = 1; len = 1; }
                p.vx = dx / len * 0.02;
                p.vy = dy / len * 0.02;
                p.slowTicks = 0;
            }
        } else {
            p.slowTicks = 0;
        }
        return events;
    }

    /** Mallet moving from a to b this tick, at sub-step fraction f: push the puck out and bounce it off. */
    private static int collideMallet(Puck p, double[] a, double[] b, double f, boolean home) {
        double mx = a[0] + (b[0] - a[0]) * f, my = a[1] + (b[1] - a[1]) * f;
        double mvx = b[0] - a[0], mvy = b[1] - a[1];
        double dx = p.x - mx, dy = p.y - my;
        double dist = Math.sqrt(dx * dx + dy * dy), minDist = PUCK_R + MALLET_R;
        if (dist >= minDist) return 0;
        double nx, ny;
        if (dist < 1e-6) { nx = 0; ny = home ? 1 : -1; }
        else { nx = dx / dist; ny = dy / dist; }
        p.x = mx + nx * minDist;
        p.y = my + ny * minDist;
        double rel = (p.vx - mvx) * nx + (p.vy - mvy) * ny;
        if (rel >= 0) return 0;
        p.vx -= (1 + MALLET_BOUNCE) * rel * nx;
        p.vy -= (1 + MALLET_BOUNCE) * rel * ny;
        double speed = Math.sqrt(p.vx * p.vx + p.vy * p.vy);
        if (speed > MAX_PUCK_SPEED) { p.vx *= MAX_PUCK_SPEED / speed; p.vy *= MAX_PUCK_SPEED / speed; speed = MAX_PUCK_SPEED; }
        p.lastHitStrength = Math.max(p.lastHitStrength, Math.min(1, speed / MAX_PUCK_SPEED));
        return home ? HIT_HOME : HIT_AWAY;
    }

    /** Rails, goal posts and goals. */
    private static int walls(Puck p) {
        int events = 0;
        if (p.x < -HALF_W + PUCK_R) { p.x = -HALF_W + PUCK_R; p.vx = Math.abs(p.vx) * WALL_BOUNCE; events |= WALL; }
        if (p.x > HALF_W - PUCK_R) { p.x = HALF_W - PUCK_R; p.vx = -Math.abs(p.vx) * WALL_BOUNCE; events |= WALL; }
        boolean inMouth = Math.abs(p.x) < GOAL_HALF;
        if (!inMouth) {
            if (p.y < -HALF_L + PUCK_R) { p.y = -HALF_L + PUCK_R; p.vy = Math.abs(p.vy) * WALL_BOUNCE; events |= WALL; }
            if (p.y > HALF_L - PUCK_R) { p.y = HALF_L - PUCK_R; p.vy = -Math.abs(p.vy) * WALL_BOUNCE; events |= WALL; }
        } else {
            // Goal posts: the corners of the goal mouth.
            for (double postX : new double[]{-GOAL_HALF, GOAL_HALF}) {
                for (double postY : new double[]{-HALF_L, HALF_L}) {
                    double dx = p.x - postX, dy = p.y - postY, d = Math.sqrt(dx * dx + dy * dy);
                    if (d < PUCK_R && d > 1e-6) {
                        double nx = dx / d, ny = dy / d;
                        p.x = postX + nx * PUCK_R;
                        p.y = postY + ny * PUCK_R;
                        double rel = p.vx * nx + p.vy * ny;
                        if (rel < 0) { p.vx -= (1 + WALL_BOUNCE) * rel * nx; p.vy -= (1 + WALL_BOUNCE) * rel * ny; events |= WALL; }
                    }
                }
            }
            // In the goal mouth, once the puck's center is over the end line it drops into the slot.
            if (p.y < -HALF_L) return events | GOAL_FOR_AWAY;
            if (p.y > HALF_L) return events | GOAL_FOR_HOME;
        }
        return events;
    }

    // ------------------------------------------------------------------ helpers

    public static double[] stepToward(double[] from, double[] to, double max) {
        double dx = to[0] - from[0], dy = to[1] - from[1], d = Math.sqrt(dx * dx + dy * dy);
        if (d <= max || d < 1e-9) return new double[]{to[0], to[1]};
        return new double[]{from[0] + dx / d * max, from[1] + dy / d * max};
    }

    /** Keeps a mallet on the table and in its own half. */
    public static double[] clampToHalf(boolean home, double x, double y) {
        if (!Double.isFinite(x) || !Double.isFinite(y)) return new double[]{0, home ? -0.8 : 0.8};
        double cx = Math.max(-HALF_W + MALLET_R, Math.min(HALF_W - MALLET_R, x));
        double cy = home
                ? Math.max(-HALF_L + MALLET_R, Math.min(-MALLET_R, y))
                : Math.max(MALLET_R, Math.min(HALF_L - MALLET_R, y));
        return new double[]{cx, cy};
    }

    /** True if the puck is on that side's half of the table. */
    public static boolean onHalf(boolean home, double y) {
        return home ? y < 0 : y > 0;
    }
}
