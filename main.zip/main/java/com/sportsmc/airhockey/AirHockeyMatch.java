package com.sportsmc.airhockey;

import com.sportsmc.field.FieldData;
import com.sportsmc.lobby.Difficulty;
import com.sportsmc.lobby.Lobby;
import com.sportsmc.match.SportMatch;
import com.sportsmc.network.AirHockeyInputPacket;
import com.sportsmc.network.AirHockeyStatePacket;
import com.sportsmc.network.AirHockeyStatePacket.Phase;
import com.sportsmc.network.ControlPacket;
import com.sportsmc.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Air hockey, played on an on-screen table (no field in the world). The server runs the physics so both
 * players see the same game; each client draws the table and sends where its mouse wants the mallet.
 *
 * Table frame: x from -0.5 to 0.5 (width 1), y from -1 to 1 (length 2). HOME defends the goal at y = -1,
 * AWAY the goal at y = +1. Each mallet stays in its own half. Speeds are per tick; the physics runs in
 * small sub-steps every tick so fast shots can't pass through mallets or walls.
 */
public class AirHockeyMatch implements SportMatch {

    // ---- table & feel (the physics itself lives in AirHockeyPhysics, shared with the clients) ------------
    public static final double HALF_W = AirHockeyPhysics.HALF_W, HALF_L = AirHockeyPhysics.HALF_L;
    public static final double PUCK_R = AirHockeyPhysics.PUCK_R, MALLET_R = AirHockeyPhysics.MALLET_R,
            GOAL_HALF = AirHockeyPhysics.GOAL_HALF;
    private static final double MAX_PUCK_SPEED = AirHockeyPhysics.MAX_PUCK_SPEED;
    private static final double MAX_MALLET_STEP = AirHockeyPhysics.MAX_MALLET_STEP;
    private static final int COUNTDOWN_TICKS = 60, GOAL_PAUSE = 40, END_PAUSE = 80;
    /** A player whose game sent nothing for this long has closed the table (or lagged out): the server takes over. */
    private static final int ACTIVE_TICKS = 20;
    /** Most ticks a client is told to run the puck forward to catch up with "now". */
    private static final int MAX_LEAD = 10;

    private record Participant(@Nullable UUID player, String name, @Nullable Difficulty cpu) {}

    private final Lobby lobby;
    private final int goalsToWin;
    private final Map<Lobby.Side, Participant> sides = new EnumMap<>(Lobby.Side.class);
    private final Map<Lobby.Side, Integer> score = new EnumMap<>(Lobby.Side.class);
    private final Map<Lobby.Side, double[]> mallet = new EnumMap<>(Lobby.Side.class);   // current x, y
    private final Map<Lobby.Side, double[]> target = new EnumMap<>(Lobby.Side.class);   // wanted x, y
    private final Map<Lobby.Side, Integer> shots = new EnumMap<>(Lobby.Side.class);
    private final Map<UUID, Boolean> wasInvulnerable = new HashMap<>();
    private final RandomSource random = RandomSource.create();

    private double px, py, vx, vy;
    private Phase phase = Phase.COUNTDOWN;
    private int phaseTicks;
    private int lastScorer;
    private String message = "";
    private boolean finished;
    @Nullable private Lobby.Side winner;
    private int hitSoundCooldown, wallSoundCooldown;
    private int cpuThinkIn;
    private double cpuAimX;
    private double[] cpuGoal = {0, 0.8};
    private double cpuLastVX, cpuLastVY, cpuBlockErr;
    private boolean cpuBank;
    private int slowTicks;

    // ---- netcode: the player whose half the puck is on runs it in their own game ------------------
    private int serverTick;
    private final Map<Lobby.Side, AirHockeyInputPacket> pendingReport = new EnumMap<>(Lobby.Side.class);
    private final Map<Lobby.Side, Integer> lastSeq = new EnumMap<>(Lobby.Side.class);
    private final Map<Lobby.Side, Integer> lastInputTick = new EnumMap<>(Lobby.Side.class);
    private int lastReportTick = -100;
    /** How old (in ticks) the puck state is compared with real time: the reporting player's delay. */
    private int puckAge;
    /** Ticks the server has been holding the puck at a player's goal line, waiting for their game's verdict. */
    private int holdTicks;

    public AirHockeyMatch(Lobby lobby) {
        this.lobby = lobby;
        this.goalsToWin = lobby.airGoals();
        for (Lobby.Member m : lobby.members()) sides.put(m.side, new Participant(m.uuid, m.name, null));
        if (lobby.mode() == Lobby.Mode.VS_CPU) {
            Lobby.Side cpuSide = sides.containsKey(Lobby.Side.HOME) ? Lobby.Side.AWAY : Lobby.Side.HOME;
            sides.put(cpuSide, new Participant(null, "CPU (" + lobby.difficulty().englishName() + ")", lobby.difficulty()));
        }
        for (Lobby.Side s : Lobby.Side.values()) {
            score.put(s, 0);
            shots.put(s, 0);
            double y = s == Lobby.Side.HOME ? -0.8 : 0.8;
            mallet.put(s, new double[]{0, y});
            target.put(s, new double[]{0, y});
        }
    }

    // ================================================================== SportMatch

    @Override public Lobby lobby() { return lobby; }
    @Override @Nullable public FieldData field() { return null; }
    @Override public boolean isFinished() { return finished; }

    @Override
    public boolean involves(UUID player) {
        return sideOf(player) != null;
    }

    @Nullable
    private Lobby.Side sideOf(UUID player) {
        for (Map.Entry<Lobby.Side, Participant> e : sides.entrySet()) if (player.equals(e.getValue().player())) return e.getKey();
        return null;
    }

    /** The client sends where its mouse wants the mallet (table frame) in the ControlPacket's move fields. */
    @Override
    public void control(UUID player, ControlPacket msg) {
        Lobby.Side s = sideOf(player);
        if (s == null || finished) return;
        target.put(s, clampToHalf(s, msg.moveX(), msg.moveZ()));
    }

    /** A player's mallet, and the puck while their game is running it (see AirHockeyInputPacket). */
    public void input(ServerPlayer player, AirHockeyInputPacket msg) {
        Lobby.Side s = sideOf(player.getUUID());
        if (s == null || finished) return;
        Integer prev = lastSeq.get(s);
        if (prev != null && msg.seq() <= prev && prev - msg.seq() < 100_000) return; // old or repeated
        lastSeq.put(s, msg.seq());
        lastInputTick.put(s, serverTick);
        target.put(s, clampToHalf(s, msg.malletX(), msg.malletY()));
        if (msg.hasPuck()) pendingReport.put(s, msg); // the latest one this tick wins
    }

    @Override
    public void kickoff(MinecraftServer server) {
        for (ServerPlayer sp : online()) {
            // The game is on screen; keep your body safe in the world while you play.
            com.sportsmc.match.SafeReturn.remember(sp, false);
            wasInvulnerable.put(sp.getUUID(), sp.isInvulnerable());
            sp.setInvulnerable(true);
        }
        Participant home = sides.get(Lobby.Side.HOME), away = sides.get(Lobby.Side.AWAY);
        broadcast(Component.literal("Air hockey: ").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD)
                .append(Component.literal(home.name() + " vs " + away.name() + ", first to " + goalsToWin + ". Move your mallet with the mouse!")
                        .withStyle(ChatFormatting.WHITE)));
        faceOff(random.nextBoolean() ? Lobby.Side.HOME : Lobby.Side.AWAY);
        phase = Phase.COUNTDOWN;
        phaseTicks = 0;
        pushState();
    }

    @Override
    public void finish(@Nullable Lobby.Side forcedWinner) {
        if (finished) return;
        finished = true;
        Lobby.Side w = forcedWinner != null ? forcedWinner : winner;
        if (w == null) {
            int h = score.get(Lobby.Side.HOME), a = score.get(Lobby.Side.AWAY);
            w = h == a ? null : h > a ? Lobby.Side.HOME : Lobby.Side.AWAY;
        }
        String line = "HOME " + score.get(Lobby.Side.HOME) + " - " + score.get(Lobby.Side.AWAY) + " AWAY";
        if (w != null) {
            broadcast(Component.literal(sides.get(w).name() + " wins the air hockey match! ").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)
                    .append(Component.literal(line).withStyle(ChatFormatting.WHITE)));
            title(Component.literal(sides.get(w).name() + " WINS").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), Component.literal(line));
        } else {
            broadcast(Component.literal("Air hockey match ended. " + line).withStyle(ChatFormatting.YELLOW));
        }
        for (Lobby.Side s : Lobby.Side.values()) {
            broadcast(Component.literal((s == Lobby.Side.HOME ? "HOME " : "AWAY ") + sides.get(s).name() + ": "
                    + score.get(s) + " goals, " + shots.get(s) + " shots").withStyle(ChatFormatting.GRAY));
        }
        for (ServerPlayer sp : online()) {
            sp.setInvulnerable(wasInvulnerable.getOrDefault(sp.getUUID(), false));
            com.sportsmc.match.SafeReturn.forget(sp);
            ModNetwork.sendTo(sp, AirHockeyStatePacket.inactive());
        }
    }

    @Override
    public void forfeit(UUID player) {
        Lobby.Side s = sideOf(player);
        if (s == null) return;
        broadcast(Component.literal(sides.get(s).name() + " left the table.").withStyle(ChatFormatting.RED));
        finish(s.opposite());
    }

    @Override
    public void sendStateTo(ServerPlayer player) {
        ModNetwork.sendTo(player, stateFor(player.getUUID()));
    }

    // ================================================================== tick

    @Override
    public void tick(MinecraftServer server) {
        if (finished) return;
        phaseTicks++;
        serverTick++;
        if (hitSoundCooldown > 0) hitSoundCooldown--;
        if (wallSoundCooldown > 0) wallSoundCooldown--;

        for (Lobby.Side s : Lobby.Side.values()) if (sides.get(s).cpu() != null) cpuThink(s);

        switch (phase) {
            case COUNTDOWN -> {
                moveMalletsOnly();
                int left = (COUNTDOWN_TICKS - phaseTicks + 19) / 20;
                message = left > 0 ? String.valueOf(left) : "GO!";
                if (phaseTicks >= COUNTDOWN_TICKS) { phase = Phase.PLAY; phaseTicks = 0; message = ""; }
            }
            case PLAY -> playTick();
            case GOAL -> {
                moveMalletsOnly();
                if (phaseTicks >= GOAL_PAUSE) {
                    Lobby.Side scorer = lastScorer == 1 ? Lobby.Side.HOME : Lobby.Side.AWAY;
                    if (score.get(scorer) >= goalsToWin) {
                        winner = scorer;
                        phase = Phase.OVER;
                        phaseTicks = 0;
                        message = sides.get(scorer).name() + " WINS!";
                        sound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                    } else {
                        faceOff(scorer.opposite()); // the player who was scored on gets the puck
                        phase = Phase.COUNTDOWN;
                        phaseTicks = COUNTDOWN_TICKS - 20; // short "GO!" after a goal
                    }
                }
            }
            case OVER -> {
                moveMalletsOnly();
                if (phaseTicks >= END_PAUSE) finish(winner);
            }
        }
        pendingReport.clear();
        if (!finished) pushState();
    }

    /** Puck placed still on one side, in front of that player's mallet. */
    private void faceOff(Lobby.Side side) {
        px = (random.nextDouble() - 0.5) * 0.3;
        py = side == Lobby.Side.HOME ? -0.4 : 0.4;
        vx = vy = 0;
    }

    private void moveMalletsOnly() {
        for (Lobby.Side s : Lobby.Side.values()) {
            double[] m = mallet.get(s), t = target.get(s);
            double[] next = stepToward(m, t, MAX_MALLET_STEP);
            m[0] = next[0];
            m[1] = next[1];
        }
    }

    // ------------------------------------------------------------------ physics + netcode

    private boolean isActive(Lobby.Side s) {
        if (sides.get(s).cpu() != null) return false;
        Integer t = lastInputTick.get(s);
        return t != null && serverTick - t <= ACTIVE_TICKS;
    }

    /** The human whose game is running the puck right now (it's on their half and their table is open), or null. */
    @Nullable
    private Lobby.Side puckOwner() {
        Lobby.Side s = py < 0 ? Lobby.Side.HOME : Lobby.Side.AWAY;
        return isActive(s) ? s : null;
    }

    private void playTick() {
        // Mallets move every tick whatever runs the puck.
        Map<Lobby.Side, double[]> from = new EnumMap<>(Lobby.Side.class), to = new EnumMap<>(Lobby.Side.class);
        for (Lobby.Side s : Lobby.Side.values()) {
            double[] m = mallet.get(s);
            from.put(s, m.clone());
            // Humans: their game already limits the mallet's speed; allow a little extra for packets that bunch up.
            double max = sides.get(s).cpu() != null ? MAX_MALLET_STEP : MAX_MALLET_STEP * 2;
            double[] next = AirHockeyPhysics.stepToward(m, target.get(s), max);
            m[0] = next[0];
            m[1] = next[1];
            to.put(s, next);
        }

        // A goal a player's game says went in against them is always believed if the puck is in their goal mouth.
        for (Lobby.Side s : Lobby.Side.values()) {
            AirHockeyInputPacket r = pendingReport.get(s);
            if (r != null && validReport(r) && (r.events() & AirHockeyInputPacket.EV_GOAL_AGAINST) != 0 && inGoalMouth(s, r.puckX(), r.puckY())) {
                px = r.puckX();
                py = r.puckY();
                goal(s.opposite());
                return;
            }
        }

        // A report from the player whose half the puck is on (or is crossing into) replaces the server's own step.
        Lobby.Side reporter = null;
        AirHockeyInputPacket report = null;
        for (Lobby.Side s : Lobby.Side.values()) {
            AirHockeyInputPacket r = pendingReport.get(s);
            if (r == null || !validReport(r)) continue;
            boolean home = s == Lobby.Side.HOME;
            boolean serverOnMine = AirHockeyPhysics.onHalf(home, py);
            // Their game is ahead of the server by their delay, so it sees the puck cross a little earlier.
            double margin = 0.25 + MAX_PUCK_SPEED * (oneWayTicks(s) + 1);
            boolean crossingToMe = AirHockeyPhysics.onHalf(home, r.puckY()) && Math.abs(py) < margin && (home ? vy < 0 : vy > 0);
            if (serverOnMine) { reporter = s; report = r; break; }
            if (crossingToMe && reporter == null) { reporter = s; report = r; }
        }
        if (report != null) {
            holdTicks = 0;
            applyReport(reporter, report);
        } else {
            serverStep(from, to);
            if (serverTick - lastReportTick > 3) puckAge = 0;
        }
    }

    private static boolean validReport(AirHockeyInputPacket r) {
        return Float.isFinite(r.puckX()) && Float.isFinite(r.puckY()) && Float.isFinite(r.puckVX()) && Float.isFinite(r.puckVY())
                && Math.abs(r.puckX()) <= HALF_W + 0.05 && Math.abs(r.puckY()) <= HALF_L + 0.15;
    }

    /** Takes the puck from the player's game (sanity-checked), and plays their hits for the other player. */
    private void applyReport(Lobby.Side s, AirHockeyInputPacket r) {
        px = Math.max(-HALF_W + PUCK_R, Math.min(HALF_W - PUCK_R, r.puckX()));
        py = Math.max(-HALF_L - 0.1, Math.min(HALF_L + 0.1, r.puckY()));
        vx = r.puckVX();
        vy = r.puckVY();
        double speed = Math.sqrt(vx * vx + vy * vy), cap = MAX_PUCK_SPEED * 1.05;
        if (speed > cap) { vx *= cap / speed; vy *= cap / speed; }
        if (speed > 0.003) slowTicks = 0;
        lastReportTick = serverTick;
        puckAge = oneWayTicks(s);

        boolean home = s == Lobby.Side.HOME;
        if ((r.events() & AirHockeyInputPacket.EV_HIT) != 0) {
            float strength = Math.max(0, Math.min(1, r.hitStrength()));
            soundExcept(s, SoundEvents.NOTE_BLOCK_HAT.value(), 0.6f + 0.5f * strength, 1.4f + 0.5f * strength);
            if (strength > 0.45) shots.merge(s, 1, Integer::sum);
        }
        if ((r.events() & AirHockeyInputPacket.EV_WALL) != 0) soundExcept(s, SoundEvents.NOTE_BLOCK_HAT.value(), 0.4f, 1.0f);
    }

    private static boolean inGoalMouth(Lobby.Side s, double x, double y) {
        return Math.abs(x) < GOAL_HALF + PUCK_R && (s == Lobby.Side.HOME ? y < -HALF_L + 0.1 : y > HALF_L - 0.1);
    }

    /** The server runs the puck itself: on a CPU's half, or when the player whose half it's on isn't sending. */
    private void serverStep(Map<Lobby.Side, double[]> from, Map<Lobby.Side, double[]> to) {
        Lobby.Side quiet = puckOwner(); // that player's game is running this puck too and plays its own sounds
        AirHockeyPhysics.Puck p = new AirHockeyPhysics.Puck(px, py, vx, vy);
        p.slowTicks = slowTicks;
        int ev = AirHockeyPhysics.step(p, from.get(Lobby.Side.HOME), to.get(Lobby.Side.HOME),
                from.get(Lobby.Side.AWAY), to.get(Lobby.Side.AWAY));
        px = p.x; py = p.y; vx = p.vx; vy = p.vy; slowTicks = p.slowTicks;

        if ((ev & (AirHockeyPhysics.HIT_HOME | AirHockeyPhysics.HIT_AWAY)) != 0 && hitSoundCooldown == 0) {
            float strength = (float) p.lastHitStrength;
            soundExcept(quiet, SoundEvents.NOTE_BLOCK_HAT.value(), 0.6f + 0.5f * strength, 1.4f + 0.5f * strength);
            hitSoundCooldown = 3;
            if (strength > 0.45) shots.merge((ev & AirHockeyPhysics.HIT_HOME) != 0 ? Lobby.Side.HOME : Lobby.Side.AWAY, 1, Integer::sum);
        }
        if ((ev & AirHockeyPhysics.WALL) != 0 && wallSoundCooldown == 0) {
            soundExcept(quiet, SoundEvents.NOTE_BLOCK_HAT.value(), 0.4f, 1.0f);
            wallSoundCooldown = 3;
        }
        Lobby.Side scorer = (ev & AirHockeyPhysics.GOAL_FOR_HOME) != 0 ? Lobby.Side.HOME
                : (ev & AirHockeyPhysics.GOAL_FOR_AWAY) != 0 ? Lobby.Side.AWAY : null;
        if (scorer != null) {
            Lobby.Side conceding = scorer.opposite();
            // That player's game decides goals on their half (they may already have saved it on their screen):
            // hold the puck at the line for about one round trip, waiting for their game's report. No save by then = goal.
            if (isActive(conceding) && ++holdTicks <= 2 * oneWayTicks(conceding) + 6) {
                py = conceding == Lobby.Side.HOME ? -HALF_L + 0.001 : HALF_L - 0.001;
                vx = vy = 0;
            } else {
                holdTicks = 0;
                goal(scorer);
            }
        }
    }

    /** Half the player's ping, in ticks (0 for the CPU or an unknown player). */
    private int oneWayTicks(@Nullable Lobby.Side s) {
        if (s == null || sides.get(s).player() == null) return 0;
        MinecraftServer srv = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (srv == null) return 0;
        ServerPlayer sp = srv.getPlayerList().getPlayer(sides.get(s).player());
        return sp == null ? 0 : Math.max(0, Math.min(MAX_LEAD, Math.round(sp.latency / 100f)));
    }

    private void goal(Lobby.Side scorer) {
        score.merge(scorer, 1, Integer::sum);
        lastScorer = scorer == Lobby.Side.HOME ? 1 : 2;
        phase = Phase.GOAL;
        phaseTicks = 0;
        vx = vy = 0;
        message = "GOAL! " + sides.get(scorer).name();
        holdTicks = 0;
        sound(SoundEvents.NOTE_BLOCK_BELL.value(), 1f, 1.2f);
        sound(SoundEvents.PLAYER_LEVELUP, 0.7f, 1.4f);
    }

    // ------------------------------------------------------------------ CPU

    /**
     * CPU mallet. Guards its goal between the puck and the net, blocks shots coming in, attacks a puck on its
     * side by getting behind it and driving through (straight or banked off a side rail), and backs off a puck
     * stuck against its end wall so it can drift out. Difficulty sets top speed, reaction time after each hit,
     * and how much it misjudges where a shot will go (tuned so a hard shot beats a Rookie ~35% of the time,
     * Pro ~19%, All-Pro ~9%, Legend ~2%).
     */
    private void cpuThink(Lobby.Side s) {
        Difficulty d = sides.get(s).cpu();
        double speed = switch (d) { case ROOKIE -> 0.032; case PRO -> 0.045; case ALL_PRO -> 0.058; case LEGEND -> 0.068; };
        int react = switch (d) { case ROOKIE -> 7; case PRO -> 5; case ALL_PRO -> 3; case LEGEND -> 3; };
        double err = switch (d) { case ROOKIE -> 0.11; case PRO -> 0.075; case ALL_PRO -> 0.05; case LEGEND -> 0.04; };
        double sloppiness = err * 0.6;
        double[] m = mallet.get(s);

        // Each time the puck is hit, the CPU needs a moment to react, and it reads the shot a bit wrong.
        boolean hitNow = (cpuLastVX - vx) * (cpuLastVX - vx) + (cpuLastVY - vy) * (cpuLastVY - vy) > 0.0004;
        cpuLastVX = vx;
        cpuLastVY = vy;
        if (hitNow) {
            cpuThinkIn = react;
            cpuBlockErr = random.nextGaussian() * err;
        }
        if (--cpuThinkIn > 0) {
            target.put(s, stepToward(m, cpuGoal, speed));
            return;
        }
        cpuThinkIn = react;

        double sgn = s == Lobby.Side.HOME ? -1 : 1;  // which end is the CPU's goal
        boolean onMySide = py * sgn > 0;
        boolean comingAtMe = vy * sgn > 0.004;
        double[] want;
        if (phase != Phase.PLAY) {
            want = new double[]{0, sgn * 0.8};
        } else if (!onMySide) {
            want = new double[]{px * 0.45, sgn * 0.84};
            cpuAimX = (random.nextDouble() - 0.5) * GOAL_HALF * 1.6;
            cpuBank = random.nextDouble() < 0.4;
        } else if (comingAtMe && Math.abs(py) < 0.8) {
            want = new double[]{predictX(sgn * 0.8) + cpuBlockErr, sgn * 0.82};
        } else if (Math.abs(py) > 0.86 || (Math.abs(px) > HALF_W - PUCK_R - 0.04 && Math.abs(py) > 0.7)) {
            want = new double[]{px * 0.3, sgn * 0.6}; // pinned against my end: back off, let it drift out
        } else {
            double gx = cpuAimX;
            if (cpuBank) {
                double w = HALF_W - PUCK_R;
                gx = (px < 0 ? 1 : -1) * 2 * w - gx; // aim at the goal's mirror image: one bounce off a side rail
            }
            double gy = -sgn * HALF_L;
            double ax = gx - px, ay = gy - py, len = Math.sqrt(ax * ax + ay * ay);
            ax /= len;
            ay /= len;
            double bx = px - ax * (PUCK_R + MALLET_R + 0.02), by = py - ay * (PUCK_R + MALLET_R + 0.02);
            double behindDist = Math.hypot(m[0] - bx, m[1] - by);
            boolean behind = (m[1] - py) * sgn > -0.01;
            if (behindDist > 0.05 || !behind) want = new double[]{bx, by + sgn * (behind ? 0 : 0.05)};
            else want = new double[]{px + ax * 0.25, py + ay * 0.25};
            want[0] += (random.nextDouble() - 0.5) * sloppiness;
        }
        cpuGoal = clampToHalf(s, (float) want[0], (float) want[1]);
        target.put(s, stepToward(m, cpuGoal, speed));
    }

    /** Where the puck crosses y = lineY, following bounces off the side rails. */
    private double predictX(double lineY) {
        if (Math.abs(vy) < 1e-4) return px;
        double t = (lineY - py) / vy;
        if (t < 0) return px;
        double x = px + vx * t, w = HALF_W - PUCK_R;
        // Reflect into the table (unfold the bounces).
        double span = 2 * w;
        double u = ((x + w) % (2 * span) + 2 * span) % (2 * span);
        return u <= span ? u - w : 2 * span - u - w;
    }

    // ------------------------------------------------------------------ helpers

    private static double[] stepToward(double[] from, double[] to, double max) {
        return AirHockeyPhysics.stepToward(from, to, max);
    }

    /** Keeps a mallet on the table and in its own half. */
    private static double[] clampToHalf(Lobby.Side s, float x, float y) {
        return AirHockeyPhysics.clampToHalf(s == Lobby.Side.HOME, x, y);
    }

    private AirHockeyStatePacket stateFor(UUID viewer) {
        Lobby.Side side = sideOf(viewer);
        if (side == null || finished) return AirHockeyStatePacket.inactive();
        double[] h = mallet.get(Lobby.Side.HOME), a = mallet.get(Lobby.Side.AWAY);
        Lobby.Side owner = phase == Phase.PLAY ? puckOwner() : null;
        return new AirHockeyStatePacket(true, side, phase, phaseTicks, (float) px, (float) py, (float) vx, (float) vy,
                (float) h[0], (float) h[1], (float) a[0], (float) a[1],
                score.get(Lobby.Side.HOME), score.get(Lobby.Side.AWAY), goalsToWin,
                sides.get(Lobby.Side.HOME).name(), sides.get(Lobby.Side.AWAY).name(), lastScorer, message,
                owner == null ? 0 : owner == Lobby.Side.HOME ? 1 : 2,
                Math.min(MAX_LEAD, (owner != null || serverTick - lastReportTick <= 3 ? puckAge : 0) + oneWayTicks(side)), serverTick,
                lastSeq.getOrDefault(side, 0));
    }

    private void pushState() {
        for (ServerPlayer sp : online()) ModNetwork.sendTo(sp, stateFor(sp.getUUID()));
    }

    private List<ServerPlayer> online() {
        List<ServerPlayer> out = new ArrayList<>(2);
        MinecraftServer srv = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (srv == null) return out;
        for (Participant p : sides.values()) {
            if (p.player() == null) continue;
            ServerPlayer sp = srv.getPlayerList().getPlayer(p.player());
            if (sp != null) out.add(sp);
        }
        return out;
    }

    /** Like sound(), but skips one side's player (whose own game already played it). */
    private void soundExcept(@Nullable Lobby.Side skip, SoundEvent sound, float volume, float pitch) {
        UUID skipId = skip == null ? null : sides.get(skip).player();
        for (ServerPlayer sp : online()) {
            if (sp.getUUID().equals(skipId)) continue;
            sp.connection.send(new ClientboundSoundPacket(BuiltInRegistries.SOUND_EVENT.wrapAsHolder(sound), SoundSource.PLAYERS,
                    sp.getX(), sp.getEyeY(), sp.getZ(), volume, pitch, sp.level().getRandom().nextLong()));
        }
    }

    /** Table sounds, played right at each player (the table is on their screen). */
    private void sound(SoundEvent sound, float volume, float pitch) {
        for (ServerPlayer sp : online()) {
            sp.connection.send(new ClientboundSoundPacket(BuiltInRegistries.SOUND_EVENT.wrapAsHolder(sound), SoundSource.PLAYERS,
                    sp.getX(), sp.getEyeY(), sp.getZ(), volume, pitch, sp.level().getRandom().nextLong()));
        }
    }

    private void title(Component main, Component sub) {
        for (ServerPlayer sp : online()) {
            sp.connection.send(new ClientboundSetTitlesAnimationPacket(5, 50, 15));
            sp.connection.send(new ClientboundSetSubtitleTextPacket(sub));
            sp.connection.send(new ClientboundSetTitleTextPacket(main));
        }
    }

    private void broadcast(Component msg) {
        Component full = Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD).append(msg);
        for (ServerPlayer sp : online()) sp.sendSystemMessage(full);
    }
}
