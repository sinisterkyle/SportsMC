package com.sportsmc.cards;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * Card Dojo: the card set and the rules. Shared by the server (which runs the game) and the client (which
 * draws the cards), so a card travels over the network as just its id.
 *
 * Rules: each round both players secretly pick a card from their hand of 5, then both are revealed.
 * Fire melts Ice, Ice freezes Water, Water puts out Fire. Same element: the higher number wins; same
 * element and number: a tie. The winning card goes into its owner's bank; the other is discarded.
 * You win the game when your bank holds either three cards of ONE element in three different colors,
 * or one card of EACH element in three different colors.
 */
public final class CardRules {

    public enum Element {
        FIRE("Fire", 0xFFFF6A1A), WATER("Water", 0xFF2E8BFF), ICE("Ice", 0xFF9FE8FF);

        public final String label;
        public final int color;
        Element(String label, int color) { this.label = label; this.color = color; }

        /** True if this element beats the other one. */
        public boolean beats(Element o) {
            return (this == FIRE && o == ICE) || (this == ICE && o == WATER) || (this == WATER && o == FIRE);
        }
    }

    public enum CardColor {
        RED("Red", 0xFFE53935), ORANGE("Orange", 0xFFFB8C00), YELLOW("Yellow", 0xFFFDD835),
        GREEN("Green", 0xFF43A047), BLUE("Blue", 0xFF1E88E5), PURPLE("Purple", 0xFF8E24AA);

        public final String label;
        public final int rgb;
        CardColor(String label, int rgb) { this.label = label; this.rgb = rgb; }
    }

    public record Card(int id, String name, Element element, int value, CardColor color) {}

    /** The card set: 10 per element, numbers 2-12, every element in every color. */
    public static final List<Card> CARDS = build();

    private static List<Card> build() {
        Object[][] defs = {
                // Fire
                {"Spark", Element.FIRE, 2, CardColor.YELLOW}, {"Ember Pup", Element.FIRE, 3, CardColor.ORANGE},
                {"Torch Bearer", Element.FIRE, 4, CardColor.RED}, {"Fire Kick", Element.FIRE, 5, CardColor.GREEN},
                {"Lava Fist", Element.FIRE, 6, CardColor.PURPLE}, {"Blaze Monk", Element.FIRE, 7, CardColor.BLUE},
                {"Magma Golem", Element.FIRE, 8, CardColor.RED}, {"Flame Fox", Element.FIRE, 9, CardColor.ORANGE},
                {"Phoenix", Element.FIRE, 11, CardColor.YELLOW}, {"Inferno Dragon", Element.FIRE, 12, CardColor.PURPLE},
                // Water
                {"Ripple", Element.WATER, 2, CardColor.BLUE}, {"Rain Spirit", Element.WATER, 3, CardColor.PURPLE},
                {"Splash Kick", Element.WATER, 4, CardColor.GREEN}, {"Coral Guard", Element.WATER, 5, CardColor.ORANGE},
                {"Tide Turner", Element.WATER, 6, CardColor.YELLOW}, {"Whirlpool", Element.WATER, 7, CardColor.RED},
                {"Geyser", Element.WATER, 8, CardColor.BLUE}, {"Wave Rider", Element.WATER, 10, CardColor.GREEN},
                {"Tsunami", Element.WATER, 11, CardColor.RED}, {"Kraken", Element.WATER, 12, CardColor.YELLOW},
                // Ice
                {"Snowflake", Element.ICE, 2, CardColor.GREEN}, {"Frost Bite", Element.ICE, 3, CardColor.RED},
                {"Icicle", Element.ICE, 4, CardColor.BLUE}, {"Snow Fort", Element.ICE, 5, CardColor.YELLOW},
                {"Hailstorm", Element.ICE, 6, CardColor.ORANGE}, {"Frozen Fist", Element.ICE, 7, CardColor.PURPLE},
                {"Glacier", Element.ICE, 8, CardColor.GREEN}, {"Blizzard", Element.ICE, 9, CardColor.BLUE},
                {"Yeti", Element.ICE, 10, CardColor.ORANGE}, {"Avalanche", Element.ICE, 12, CardColor.RED},
        };
        List<Card> out = new ArrayList<>();
        for (int i = 0; i < defs.length; i++) {
            Object[] d = defs[i];
            out.add(new Card(i, (String) d[0], (Element) d[1], (Integer) d[2], (CardColor) d[3]));
        }
        return List.copyOf(out);
    }

    private CardRules() {}

    @Nullable
    public static Card card(int id) {
        return id >= 0 && id < CARDS.size() ? CARDS.get(id) : null;
    }

    /** 1 if a wins, -1 if b wins, 0 for a tie. */
    public static int compare(Card a, Card b) {
        if (a.element() != b.element()) return a.element().beats(b.element()) ? 1 : -1;
        return Integer.compare(a.value(), b.value());
    }

    /** A winning set in this bank (3 card ids), or null. Prefers three of a kind, then one of each element. */
    @Nullable
    public static int[] winningSet(List<Card> bank) {
        int n = bank.size();
        int[] best = null;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                for (int k = j + 1; k < n; k++) {
                    Card a = bank.get(i), b = bank.get(j), c = bank.get(k);
                    if (a.color() == b.color() || a.color() == c.color() || b.color() == c.color()) continue;
                    boolean same = a.element() == b.element() && b.element() == c.element();
                    boolean all = a.element() != b.element() && a.element() != c.element() && b.element() != c.element();
                    if (same) return new int[]{a.id(), b.id(), c.id()};
                    if (all && best == null) best = new int[]{a.id(), b.id(), c.id()};
                }
            }
        }
        return best;
    }

    /**
     * How useful adding this card would be to a bank (0 = no help, 1 = progress, 3 = completes a win).
     * Used by the CPU, both for its own bank and to guess what its opponent wants.
     */
    public static int usefulness(List<Card> bank, Card card) {
        List<Card> with = new ArrayList<>(bank);
        with.add(card);
        if (winningSet(with) != null) return 3;
        boolean newColorForElement = true, newColorAnywhere = true;
        for (Card c : bank) {
            if (c.element() == card.element() && c.color() == card.color()) newColorForElement = false;
            if (c.color() == card.color()) newColorAnywhere = false;
        }
        return newColorForElement ? (newColorAnywhere ? 2 : 1) : 0;
    }
}
