package com.sportsmc.cards;

import com.sportsmc.cards.CardRules.Card;
import com.sportsmc.cards.CardRules.Element;
import com.sportsmc.field.FieldData;
import com.sportsmc.lobby.Difficulty;
import com.sportsmc.lobby.Lobby;
import com.sportsmc.match.SafeReturn;
import com.sportsmc.match.SportMatch;
import com.sportsmc.network.CardPickPacket;
import com.sportsmc.network.CardStatePacket;
import com.sportsmc.network.ControlPacket;
import com.sportsmc.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;

import javax.annotation.Nullable;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * A Card Dojo match (rules in {@link CardRules}). The server deals, keeps both hands secret, reveals the
 * cards together and decides every round, so nobody can peek or cheat. Each player's game draws the cards
 * and animates the deal, the flip, the clash and the winning card flying into the bank.
 */
public class CardMatch implements SportMatch {

    public static final int HAND = 5;
    private static final int DEAL_TICKS = 30, PICK_TICKS = 400, REVEAL_TICKS = 60, GAME_OVER_TICKS = 110, MATCH_OVER_TICKS = 80;

    private record Participant(@Nullable UUID player, String name, @Nullable Difficulty cpu) {}

    private static final class Hand {
        final int[] slots = new int[HAND];
        final Deque<Integer> deck = new ArrayDeque<>();
        final List<Integer> bank = new ArrayList<>();
        int pick = -1;
        int cpuPickAt;
        int played = -1; // card played this round (shown face up during REVEAL)

        Hand() { Arrays.fill(slots, -1); }
    }

    private final Lobby lobby;
    private final int gamesToWin;
    private final Map<Lobby.Side, Participant> sides = new EnumMap<>(Lobby.Side.class);
    private final Map<Lobby.Side, Hand> hands = new EnumMap<>(Lobby.Side.class);
    private final Map<Lobby.Side, Integer> gamesWon = new EnumMap<>(Lobby.Side.class);
    private final Map<UUID, Boolean> wasInvulnerable = new HashMap<>();
    private final RandomSource random = RandomSource.create();

    private int phase = CardStatePacket.DEAL;
    private int phaseTicks;
    private int round;
    /** The round's winner (null = tie) during REVEAL / GAME_OVER. */
    @Nullable private Lobby.Side roundWinner;
    @Nullable private Lobby.Side gameWinner;
    private List<Integer> winningSet = List.of();
    private String message = "";
    private boolean finished;
    private boolean dirty = true;

    public CardMatch(Lobby lobby) {
        this.lobby = lobby;
        this.gamesToWin = Math.max(1, Math.min(5, lobby.airGoals())); // the lobby's "target" setting: games to win
        for (Lobby.Member m : lobby.members()) sides.put(m.side, new Participant(m.uuid, m.name, null));
        if (lobby.mode() == Lobby.Mode.VS_CPU) {
            Lobby.Side cpuSide = sides.containsKey(Lobby.Side.HOME) ? Lobby.Side.AWAY : Lobby.Side.HOME;
            sides.put(cpuSide, new Participant(null, "CPU Sensei (" + lobby.difficulty().englishName() + ")", lobby.difficulty()));
        }
        for (Lobby.Side s : Lobby.Side.values()) gamesWon.put(s, 0);
    }

    // ================================================================== SportMatch

    @Override public Lobby lobby() { return lobby; }
    @Override @Nullable public FieldData field() { return null; }
    @Override public boolean isFinished() { return finished; }

    @Override
    public boolean involves(UUID player) {
        return sideOf(player) != null;
    }

    @Nullable
    private Lobby.Side sideOf(UUID player) {
        for (Map.Entry<Lobby.Side, Participant> e : sides.entrySet()) if (player.equals(e.getValue().player())) return e.getKey();
        return null;
    }

    @Override
    public void control(UUID player, ControlPacket msg) {} // Card Dojo uses CardPickPacket

    @Override
    public void kickoff(MinecraftServer server) {
        for (ServerPlayer sp : online()) {
            SafeReturn.remember(sp, false);
            wasInvulnerable.put(sp.getUUID(), sp.isInvulnerable());
            sp.setInvulnerable(true); // the game is on screen; keep your body safe in the world meanwhile
        }
        broadcast(Component.literal("Card Dojo: ").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD)
                .append(Component.literal(sides.get(Lobby.Side.HOME).name() + " vs " + sides.get(Lobby.Side.AWAY).name()
                        + ". Fire melts Ice, Ice freezes Water, Water puts out Fire. Bank 3 of one element or one of each, all different colors!")
                        .withStyle(ChatFormatting.WHITE)));
        startGame();
    }

    @Override
    public void finish(@Nullable Lobby.Side forcedWinner) {
        if (finished) return;
        finished = true;
        Lobby.Side w = forcedWinner;
        if (w == null) {
            int h = gamesWon.get(Lobby.Side.HOME), a = gamesWon.get(Lobby.Side.AWAY);
            w = h == a ? null : h > a ? Lobby.Side.HOME : Lobby.Side.AWAY;
        }
        String line = "HOME " + gamesWon.get(Lobby.Side.HOME) + " - " + gamesWon.get(Lobby.Side.AWAY) + " AWAY";
        if (w != null) {
            broadcast(Component.literal(sides.get(w).name() + " wins the Card Dojo match! ").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)
                    .append(Component.literal(line).withStyle(ChatFormatting.WHITE)));
        } else {
            broadcast(Component.literal("Card Dojo match ended. " + line).withStyle(ChatFormatting.YELLOW));
        }
        for (ServerPlayer sp : online()) {
            sp.setInvulnerable(wasInvulnerable.getOrDefault(sp.getUUID(), false));
            SafeReturn.forget(sp);
            ModNetwork.sendTo(sp, CardStatePacket.inactive());
        }
    }

    @Override
    public void forfeit(UUID player) {
        Lobby.Side s = sideOf(player);
        if (s == null) return;
        broadcast(Component.literal(sides.get(s).name() + " left the dojo.").withStyle(ChatFormatting.RED));
        finish(s.opposite());
    }

    @Override
    public void sendStateTo(ServerPlayer player) {
        ModNetwork.sendTo(player, stateFor(player.getUUID()));
    }

    // ================================================================== input

    public void pick(ServerPlayer player, CardPickPacket msg) {
        Lobby.Side s = sideOf(player.getUUID());
        if (s == null || finished || phase != CardStatePacket.PICK || msg.round() != round) return;
        Hand h = hands.get(s);
        if (h.pick >= 0 || msg.slot() < 0 || msg.slot() >= HAND || h.slots[msg.slot()] < 0) return;
        h.pick = msg.slot();
        dirty = true;
    }

    // ================================================================== flow

    private void startGame() {
        for (Lobby.Side s : Lobby.Side.values()) {
            Hand h = new Hand();
            refill(h);
            for (int i = 0; i < HAND; i++) h.slots[i] = draw(h);
            hands.put(s, h);
        }
        roundWinner = null;
        gameWinner = null;
        winningSet = List.of();
        message = "";
        setPhase(CardStatePacket.DEAL);
    }

    private void setPhase(int p) {
        phase = p;
        phaseTicks = 0;
        dirty = true;
    }

    @Override
    public void tick(MinecraftServer server) {
        if (finished) return;
        phaseTicks++;
        switch (phase) {
            case CardStatePacket.DEAL -> {
                if (phaseTicks >= DEAL_TICKS) beginRound();
            }
            case CardStatePacket.PICK -> {
                for (Lobby.Side s : Lobby.Side.values()) {
                    Hand h = hands.get(s);
                    if (sides.get(s).cpu() != null && h.pick < 0 && phaseTicks >= h.cpuPickAt) {
                        h.pick = cpuPick(s);
                        dirty = true;
                    }
                }
                if (phaseTicks >= PICK_TICKS) {
                    // Time's up: anyone who hasn't chosen plays a random card.
                    for (Lobby.Side s : Lobby.Side.values()) {
                        Hand h = hands.get(s);
                        if (h.pick < 0) {
                            h.pick = randomSlot(h);
                            notify(s, "Time's up - a random card was played for you.");
                        }
                    }
                }
                if (hands.get(Lobby.Side.HOME).pick >= 0 && hands.get(Lobby.Side.AWAY).pick >= 0) reveal();
            }
            case CardStatePacket.REVEAL -> {
                if (phaseTicks >= REVEAL_TICKS) {
                    for (Hand h : hands.values()) {
                        for (int i = 0; i < HAND; i++) if (h.slots[i] < 0) h.slots[i] = draw(h);
                    }
                    beginRound();
                }
            }
            case CardStatePacket.GAME_OVER -> {
                if (phaseTicks >= GAME_OVER_TICKS) {
                    if (gamesWon.get(gameWinner) >= gamesToWin) setPhase(CardStatePacket.MATCH_OVER);
                    else startGame();
                }
            }
            case CardStatePacket.MATCH_OVER -> {
                if (phaseTicks >= MATCH_OVER_TICKS) finish(gameWinner);
            }
            default -> {}
        }
        if (!finished && (dirty || phaseTicks % 10 == 0)) {
            dirty = false;
            pushState();
        }
    }

    private void beginRound() {
        round++;
        roundWinner = null;
        message = "";
        for (Lobby.Side s : Lobby.Side.values()) {
            Hand h = hands.get(s);
            h.pick = -1;
            h.played = -1;
            h.cpuPickAt = 20 + random.nextInt(35);
        }
        setPhase(CardStatePacket.PICK);
    }

    private void reveal() {
        Hand home = hands.get(Lobby.Side.HOME), away = hands.get(Lobby.Side.AWAY);
        home.played = home.slots[home.pick];
        away.played = away.slots[away.pick];
        home.slots[home.pick] = -1;
        away.slots[away.pick] = -1;
        Card a = CardRules.card(home.played), b = CardRules.card(away.played);
        int cmp = CardRules.compare(a, b);
        roundWinner = cmp > 0 ? Lobby.Side.HOME : cmp < 0 ? Lobby.Side.AWAY : null;
        message = describe(a, b, cmp);
        if (roundWinner != null) {
            Hand w = hands.get(roundWinner);
            w.bank.add(w.played);
            int[] set = CardRules.winningSet(cards(w.bank));
            if (set != null) {
                gameWinner = roundWinner;
                winningSet = List.of(set[0], set[1], set[2]);
                gamesWon.merge(roundWinner, 1, Integer::sum);
                message = sides.get(roundWinner).name() + " completes a set and wins the game!";
                title(Component.literal(sides.get(roundWinner).name() + " WINS").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                        Component.literal("Games: HOME " + gamesWon.get(Lobby.Side.HOME) + " - " + gamesWon.get(Lobby.Side.AWAY) + " AWAY"));
                setPhase(CardStatePacket.GAME_OVER);
                return;
            }
        }
        setPhase(CardStatePacket.REVEAL);
    }

    private static String describe(Card a, Card b, int cmp) {
        if (cmp == 0) return "Tie! Both cards are discarded.";
        Card win = cmp > 0 ? a : b, lose = cmp > 0 ? b : a;
        if (win.element() == lose.element()) return win.value() + " beats " + lose.value() + "!";
        return switch (win.element()) {
            case FIRE -> "Fire melts Ice!";
            case ICE -> "Ice freezes Water!";
            case WATER -> "Water puts out Fire!";
        };
    }

    // ================================================================== deck

    private void refill(Hand h) {
        List<Integer> ids = new ArrayList<>();
        for (Card c : CardRules.CARDS) ids.add(c.id());
        // Don't put cards back that are in this hand right now.
        for (int id : h.slots) ids.remove(Integer.valueOf(id));
        Collections.shuffle(ids, new java.util.Random(random.nextLong()));
        h.deck.addAll(ids);
    }

    private int draw(Hand h) {
        if (h.deck.isEmpty()) refill(h);
        return h.deck.isEmpty() ? 0 : h.deck.poll();
    }

    private int randomSlot(Hand h) {
        List<Integer> filled = new ArrayList<>();
        for (int i = 0; i < HAND; i++) if (h.slots[i] >= 0) filled.add(i);
        return filled.isEmpty() ? 0 : filled.get(random.nextInt(filled.size()));
    }

    private static List<Card> cards(List<Integer> ids) {
        List<Card> out = new ArrayList<>(ids.size());
        for (int id : ids) {
            Card c = CardRules.card(id);
            if (c != null) out.add(c);
        }
        return out;
    }

    // ================================================================== CPU

    /**
     * Scores every card in hand: the chance it wins the round (against the cards the opponent is likely to
     * play), how much it helps the CPU's own sets, and how bad losing it would be if the opponent is close to
     * a set. Rookies mostly play at random; harder CPUs think more and guess less.
     */
    private int cpuPick(Lobby.Side s) {
        Difficulty d = sides.get(s).cpu();
        Hand me = hands.get(s), them = hands.get(s.opposite());
        if (d == Difficulty.ROOKIE && random.nextFloat() < 0.6f) return randomSlot(me);
        double noise = switch (d) { case ROOKIE -> 0.6; case PRO -> 0.3; case ALL_PRO -> 0.15; case LEGEND -> 0.05; };
        boolean readsOpponent = d == Difficulty.ALL_PRO || d == Difficulty.LEGEND;

        List<Card> myBank = cards(me.bank), theirBank = cards(them.bank);
        // What the opponent wants (for reading them, and for blocking).
        Map<Element, Integer> theirNeed = new EnumMap<>(Element.class);
        for (Element e : Element.values()) theirNeed.put(e, 0);
        for (Card c : CardRules.CARDS) theirNeed.merge(c.element(), CardRules.usefulness(theirBank, c), Math::max);
        boolean theyAreClose = theirNeed.containsValue(3);

        // How likely each element is to come from them: even, or tilted toward what they need.
        Map<Element, Double> w = new EnumMap<>(Element.class);
        double total = 0;
        for (Element e : Element.values()) {
            double v = readsOpponent ? 1 + theirNeed.get(e) * 0.6 : 1;
            w.put(e, v);
            total += v;
        }
        for (Element e : Element.values()) w.put(e, w.get(e) / total);

        int best = randomSlot(me);
        double bestScore = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < HAND; i++) {
            Card c = CardRules.card(me.slots[i]);
            if (c == null) continue;
            double pWin = 0, pLose = 0;
            for (Element e : Element.values()) {
                if (c.element().beats(e)) pWin += w.get(e);
                else if (e.beats(c.element())) pLose += w.get(e);
                else { // same element: decided by number
                    pWin += w.get(e) * (c.value() - 2) / 10.0;
                    pLose += w.get(e) * (12 - c.value()) / 10.0;
                }
            }
            int own = CardRules.usefulness(myBank, c);
            double threat = theyAreClose ? 2.0 : 0.6;
            double score = pWin * (1 + own * 0.8) - pLose * threat + random.nextGaussian() * noise;
            if (score > bestScore) { bestScore = score; best = i; }
        }
        return best;
    }

    // ================================================================== sync

    private CardStatePacket stateFor(UUID viewer) {
        Lobby.Side side = sideOf(viewer);
        if (side == null || finished) return CardStatePacket.inactive();
        Lobby.Side other = side.opposite();
        Hand me = hands.get(side), them = hands.get(other);
        List<Integer> hand = new ArrayList<>(HAND);
        for (int id : me.slots) hand.add(id);
        int oppCount = 0;
        for (int id : them.slots) if (id >= 0) oppCount++;
        boolean showPlayed = phase == CardStatePacket.REVEAL || phase == CardStatePacket.GAME_OVER || phase == CardStatePacket.MATCH_OVER;
        int result = roundWinner == null ? 0 : roundWinner == side ? 1 : -1;
        int gw = gameWinner == null ? 0 : gameWinner == side ? 1 : -1;
        int pickLeft = phase == CardStatePacket.PICK ? Math.max(0, PICK_TICKS - phaseTicks) : 0;
        return new CardStatePacket(true, phase, phaseTicks, round, pickLeft, hand, oppCount,
                phase == CardStatePacket.PICK ? me.pick : -1, phase == CardStatePacket.PICK && them.pick >= 0,
                showPlayed ? me.played : -1, showPlayed ? them.played : -1, result,
                List.copyOf(me.bank), List.copyOf(them.bank), winningSet, gw,
                gamesWon.get(side), gamesWon.get(other), gamesToWin,
                sides.get(side).name(), sides.get(other).name(), message);
    }

    private void pushState() {
        for (ServerPlayer sp : online()) ModNetwork.sendTo(sp, stateFor(sp.getUUID()));
    }

    private List<ServerPlayer> online() {
        List<ServerPlayer> out = new ArrayList<>(2);
        MinecraftServer srv = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (srv == null) return out;
        for (Participant p : sides.values()) {
            if (p.player() == null) continue;
            ServerPlayer sp = srv.getPlayerList().getPlayer(p.player());
            if (sp != null) out.add(sp);
        }
        return out;
    }

    private void title(Component main, Component sub) {
        for (ServerPlayer sp : online()) {
            sp.connection.send(new ClientboundSetTitlesAnimationPacket(5, 50, 15));
            sp.connection.send(new ClientboundSetSubtitleTextPacket(sub));
            sp.connection.send(new ClientboundSetTitleTextPacket(main));
        }
    }

    private void broadcast(Component msg) {
        Component full = Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD).append(msg);
        for (ServerPlayer sp : online()) sp.sendSystemMessage(full);
    }

    private void notify(Lobby.Side side, String text) {
        UUID id = sides.get(side).player();
        if (id == null) return;
        for (ServerPlayer sp : online()) {
            if (sp.getUUID().equals(id)) sp.sendSystemMessage(Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD)
                    .append(Component.literal(text).withStyle(ChatFormatting.YELLOW)));
        }
    }
}
