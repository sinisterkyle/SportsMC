package com.sportsmc.lobby;

import net.minecraft.network.chat.Component;

/** CPU skill levels. Later these will drive AI reaction time, play-calling and accuracy. */
public enum Difficulty {
    ROOKIE("rookie", "Rookie"),
    PRO("pro", "Pro"),
    ALL_PRO("all_pro", "All-Pro"),
    LEGEND("legend", "Legend");

    private final String key;
    private final String englishName;

    Difficulty(String key, String englishName) {
        this.key = key;
        this.englishName = englishName;
    }

    /** Plain name for server-side chat (dedicated servers don't load mod lang files). */
    public String englishName() {
        return englishName;
    }

    public String key() {
        return key;
    }

    public Component displayName() {
        return Component.translatable("difficulty.sportsmc." + key);
    }

    public Difficulty next() {
        return values()[(ordinal() + 1) % values().length];
    }

    public static Difficulty byOrdinal(int ordinal) {
        Difficulty[] v = values();
        return ordinal >= 0 && ordinal < v.length ? v[ordinal] : PRO;
    }

    public static Difficulty byKey(String key) {
        for (Difficulty d : values()) {
            if (d.key.equalsIgnoreCase(key) || d.name().equalsIgnoreCase(key)) return d;
        }
        return null;
    }
}
