package com.sportsmc.lobby;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** A pre-game room: up to two humans, one per side. A lone host can play the CPU instead. */
public class Lobby {

    public enum Mode { HEAD_TO_HEAD, VS_CPU }

    public enum State { WAITING, IN_MATCH }

    public enum Side {
        HOME, AWAY;

        public Side opposite() {
            return this == HOME ? AWAY : HOME;
        }
    }

    public static final int MAX_HUMANS = 2;

    public static final class Member {
        public final UUID uuid;
        public final String name;
        public Side side;
        public boolean ready;

        Member(UUID uuid, String name, Side side) {
            this.uuid = uuid;
            this.name = name;
            this.side = side;
        }
    }

    private final UUID id = UUID.randomUUID();
    private UUID host;
    private final Map<UUID, Member> members = new LinkedHashMap<>();
    private Mode mode = Mode.HEAD_TO_HEAD;
    private State state = State.WAITING;
    private Difficulty difficulty = Difficulty.PRO;
    private int quarterMinutes = 3;

    /** Quarter lengths the host can pick from. */
    public static final int[] QUARTER_OPTIONS = {1, 2, 3, 5, 8};
    @javax.annotation.Nullable private UUID selectedField;

    private final Sport sport;
    /** Tennis: 2v2 (each side is a human or CPU controlling two players) instead of 1v1. */
    private boolean doubles = false;
    /** Tennis: best-of-N games (first to N/2 + 1 wins). */
    private int tennisGames = 3;
    public static final int[] TENNIS_GAME_OPTIONS = {1, 3, 5, 7};
    /** Air hockey: first to N goals. */
    private int airGoals = 7;
    public static final int[] AIR_GOAL_OPTIONS = {3, 5, 7, 10};

    public Lobby(UUID host, String hostName) {
        this(host, hostName, Sport.FOOTBALL);
    }

    public Lobby(UUID host, String hostName, Sport sport) {
        this.sport = sport;
        this.host = host;
        if (sport == Sport.CARD_DOJO) airGoals = 1; // for cards this setting is "games to win"
        if (sport == Sport.BOWLING) airGoals = 10; // for bowling it's the number of frames
        members.put(host, new Member(host, hostName, Side.HOME));
    }

    public UUID id() { return id; }
    public UUID host() { return host; }
    public boolean isHost(UUID uuid) { return host.equals(uuid); }
    public Collection<Member> members() { return members.values(); }
    public Member member(UUID uuid) { return members.get(uuid); }
    public boolean contains(UUID uuid) { return members.containsKey(uuid); }
    public int size() { return members.size(); }
    public boolean isFull() { return members.size() >= MAX_HUMANS; }
    public boolean isEmpty() { return members.isEmpty(); }

    public Mode mode() { return mode; }
    public void setMode(Mode mode) { this.mode = mode; }
    public State state() { return state; }
    public void setState(State state) { this.state = state; }
    public Difficulty difficulty() { return difficulty; }
    public void setDifficulty(Difficulty difficulty) { this.difficulty = difficulty; }
    public int quarterMinutes() { return quarterMinutes; }
    public void setQuarterMinutes(int minutes) { this.quarterMinutes = Math.max(1, Math.min(15, minutes)); }
    @javax.annotation.Nullable public UUID selectedField() { return selectedField; }
    public Sport sport() { return sport; }
    public boolean doubles() { return doubles; }
    public void setDoubles(boolean doubles) { this.doubles = doubles; }
    public int tennisGames() { return tennisGames; }
    public int airGoals() { return airGoals; }
    public void setAirGoals(int goals) { this.airGoals = Math.max(1, Math.min(21, goals)); }
    public static final int[] CARD_GAME_OPTIONS = {1, 2, 3};
    /** Bowling: frames per game (the airGoals setting). */
    public static final int[] BOWLING_FRAME_OPTIONS = {3, 5, 10};
    public void setTennisGames(int games) { this.tennisGames = Math.max(1, Math.min(9, games | 1)); }
    public void setSelectedField(@javax.annotation.Nullable UUID field) { this.selectedField = field; }

    /** Adds a player on whichever side is free. */
    public void add(UUID uuid, String name) {
        Side free = Side.HOME;
        for (Member m : members.values()) {
            if (m.side == Side.HOME) free = Side.AWAY;
        }
        members.put(uuid, new Member(uuid, name, free));
        resetReady();
    }

    /** Removes a player; hands host to whoever is left. */
    public void remove(UUID uuid) {
        members.remove(uuid);
        if (host.equals(uuid) && !members.isEmpty()) {
            host = members.keySet().iterator().next();
        }
        resetReady();
    }

    public void swapSides() {
        for (Member m : members.values()) m.side = m.side.opposite();
        resetReady();
    }

    public boolean allReady() {
        if (members.isEmpty()) return false;
        for (Member m : members.values()) if (!m.ready) return false;
        return true;
    }

    public void resetReady() {
        for (Member m : members.values()) m.ready = false;
    }
}
