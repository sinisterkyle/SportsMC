package com.sportsmc.lobby;

import com.sportsmc.field.FieldData;
import com.sportsmc.field.FieldRegistry;
import com.sportsmc.match.MatchManager;
import com.sportsmc.network.LobbyActionPacket;
import com.sportsmc.network.LobbySyncPacket;
import com.sportsmc.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.server.ServerLifecycleHooks;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Server-side owner of all lobbies and invites. All calls happen on the server thread
 * (packets use consumerMainThread, commands and ticks run there too), so no locking is needed.
 */
public final class LobbyManager {

    private static final LobbyManager INSTANCE = new LobbyManager();
    private static final long INVITE_TIMEOUT_TICKS = 20L * 60; // 60 seconds

    private final Map<UUID, Lobby> lobbies = new HashMap<>();          // lobbyId -> lobby
    private final Map<UUID, UUID> playerLobby = new HashMap<>();       // player -> lobbyId
    private final Map<UUID, Map<UUID, Long>> invites = new HashMap<>(); // invitee -> (lobbyId -> expiry tick)
    private long tick = 0;

    private LobbyManager() {}

    public static LobbyManager get() {
        return INSTANCE;
    }

    // ------------------------------------------------------------------ packet entry point

    public void handleAction(ServerPlayer player, LobbyActionPacket msg) {
        switch (msg.action()) {
            case REQUEST_SYNC -> sync(player);
            case CREATE_LOBBY -> createLobby(player, Sport.byOrdinal(msg.arg()));
            case INVITE -> {
                ServerPlayer target = player(msg.target());
                if (target != null) invite(player, target);
                else fail(player, "That player is no longer online.");
            }
            case ACCEPT_INVITE -> acceptInvite(player, msg.target());
            case DECLINE_INVITE -> declineInvite(player, msg.target());
            case LEAVE -> leave(player);
            case KICK -> kick(player, msg.target());
            case TOGGLE_READY -> toggleReady(player);
            case SWAP_SIDES -> swapSides(player);
            case START_MATCH -> startMatch(player);
            // arg = difficulty ordinal in the low byte, sport ordinal above it (sport is used if a lobby has to be created)
            case START_CPU_MATCH -> startCpuMatch(player, Difficulty.byOrdinal(msg.arg() & 0xFF), msg.target(),
                    Sport.byOrdinal(msg.arg() >> 8));
            case SET_DOUBLES -> {
                Lobby lobby = lobbyOf(player.getUUID());
                if (lobby != null && lobby.isHost(player.getUUID()) && lobby.state() == Lobby.State.WAITING) {
                    lobby.setDoubles(msg.arg() != 0);
                    syncAll();
                }
            }
            case SET_AIR_GOALS -> {
                Lobby lobby = lobbyOf(player.getUUID());
                if (lobby != null && lobby.isHost(player.getUUID()) && lobby.state() == Lobby.State.WAITING) {
                    lobby.setAirGoals(msg.arg());
                    syncAll();
                }
            }
            case SET_TENNIS_GAMES -> {
                Lobby lobby = lobbyOf(player.getUUID());
                if (lobby != null && lobby.isHost(player.getUUID()) && lobby.state() == Lobby.State.WAITING) {
                    lobby.setTennisGames(msg.arg());
                    syncAll();
                }
            }
            case SET_DIFFICULTY -> setDifficulty(player, Difficulty.byOrdinal(msg.arg()));
            case SELECT_FIELD -> selectField(player, msg.target());
            case SET_QUARTER_LENGTH -> {
                Lobby lobby = lobbyOf(player.getUUID());
                if (lobby != null && lobby.isHost(player.getUUID()) && lobby.state() == Lobby.State.WAITING) {
                    lobby.setQuarterMinutes(msg.arg());
                    syncAll();
                }
            }
        }
    }

    // ------------------------------------------------------------------ actions

    public void createLobby(ServerPlayer player) {
        createLobby(player, Sport.FOOTBALL);
    }

    public void createLobby(ServerPlayer player, Sport sport) {
        if (lobbyOf(player.getUUID()) != null) {
            fail(player, "You're already in a lobby.");
            return;
        }
        Lobby lobby = new Lobby(player.getUUID(), name(player), sport);
        lobbies.put(lobby.id(), lobby);
        playerLobby.put(player.getUUID(), lobby.id());
        info(player, sport.displayName + " lobby created. Invite a friend or play the CPU.");
        syncAll();
    }

    public void invite(ServerPlayer host, ServerPlayer target) {
        Lobby lobby = lobbyOf(host.getUUID());
        if (lobby == null) {
            // Convenience: inviting without a lobby creates one.
            createLobby(host);
            lobby = lobbyOf(host.getUUID());
            if (lobby == null) return;
        }
        if (!lobby.isHost(host.getUUID())) { fail(host, "Only the lobby host can invite."); return; }
        if (lobby.state() != Lobby.State.WAITING) { fail(host, "A match is already in progress."); return; }
        if (lobby.isFull()) { fail(host, "Your lobby is full."); return; }
        if (target.getUUID().equals(host.getUUID())) { fail(host, "You can't invite yourself."); return; }
        if (lobbyOf(target.getUUID()) != null) { fail(host, name(target) + " is already in a lobby."); return; }

        invites.computeIfAbsent(target.getUUID(), k -> new HashMap<>())
                .put(lobby.id(), tick + INVITE_TIMEOUT_TICKS);

        info(host, "Invite sent to " + name(target) + ".");
        target.sendSystemMessage(inviteMessage(name(host), lobby.sport()));
        syncAll();
    }

    /** Accept by lobby id (from the GUI). */
    public void acceptInvite(ServerPlayer player, @Nullable UUID lobbyId) {
        if (lobbyId == null) return;
        Map<UUID, Long> mine = invites.get(player.getUUID());
        if (mine == null || !mine.containsKey(lobbyId)) { fail(player, "That invite has expired."); syncAll(); return; }
        mine.remove(lobbyId);

        Lobby lobby = lobbies.get(lobbyId);
        if (lobby == null) { fail(player, "That lobby no longer exists."); syncAll(); return; }
        if (lobby.isFull() || lobby.state() != Lobby.State.WAITING) { fail(player, "That lobby can't take players right now."); syncAll(); return; }

        // If the player is sitting alone in their own lobby, drop it so they can join.
        Lobby current = lobbyOf(player.getUUID());
        if (current != null) {
            if (current.size() == 1 && current.state() == Lobby.State.WAITING) removeFromLobby(player.getUUID());
            else { fail(player, "Leave your current lobby first."); return; }
        }

        lobby.add(player.getUUID(), name(player));
        lobby.setMode(Lobby.Mode.HEAD_TO_HEAD);
        playerLobby.put(player.getUUID(), lobby.id());
        broadcastToLobby(lobby, Component.literal(name(player) + " joined the lobby.").withStyle(ChatFormatting.GREEN));
        syncAll();
    }

    /** Accept by host (from the clickable chat message / command). */
    public void acceptInviteFromHost(ServerPlayer player, ServerPlayer host) {
        Lobby lobby = lobbyOf(host.getUUID());
        if (lobby == null) { fail(player, name(host) + " doesn't have a lobby."); return; }
        acceptInvite(player, lobby.id());
    }

    public void declineInvite(ServerPlayer player, @Nullable UUID lobbyId) {
        Map<UUID, Long> mine = invites.get(player.getUUID());
        if (mine == null || mine.isEmpty()) { fail(player, "You have no pending invites."); return; }
        if (lobbyId == null) lobbyId = mine.keySet().iterator().next(); // command form: decline the oldest
        mine.remove(lobbyId);
        Lobby lobby = lobbies.get(lobbyId);
        if (lobby != null) {
            ServerPlayer host = player(lobby.host());
            if (host != null) info(host, name(player) + " declined your invite.");
        }
        info(player, "Invite declined.");
        syncAll();
    }

    public void leave(ServerPlayer player) {
        Lobby lobby = lobbyOf(player.getUUID());
        if (lobby == null) { fail(player, "You're not in a lobby."); return; }
        if (lobby.state() == Lobby.State.IN_MATCH) {
            MatchManager.get().forfeit(lobby, player.getUUID());
        }
        removeFromLobby(player.getUUID());
        info(player, "You left the lobby.");
        if (!lobby.isEmpty()) broadcastToLobby(lobby, Component.literal(name(player) + " left the lobby.").withStyle(ChatFormatting.YELLOW));
        syncAll();
    }

    public void kick(ServerPlayer host, @Nullable UUID target) {
        Lobby lobby = lobbyOf(host.getUUID());
        if (lobby == null || target == null || !lobby.isHost(host.getUUID()) || !lobby.contains(target) || target.equals(host.getUUID())) return;
        if (lobby.state() == Lobby.State.IN_MATCH) { fail(host, "You can't kick during a match."); return; }
        removeFromLobby(target);
        ServerPlayer kicked = player(target);
        if (kicked != null) info(kicked, "You were removed from the lobby.");
        syncAll();
    }

    public void toggleReady(ServerPlayer player) {
        Lobby lobby = lobbyOf(player.getUUID());
        if (lobby == null || lobby.state() != Lobby.State.WAITING) return;
        Lobby.Member m = lobby.member(player.getUUID());
        m.ready = !m.ready;
        syncAll();
    }

    public void swapSides(ServerPlayer player) {
        Lobby lobby = lobbyOf(player.getUUID());
        if (lobby == null || !lobby.isHost(player.getUUID()) || lobby.state() != Lobby.State.WAITING) return;
        lobby.swapSides();
        syncAll();
    }

    public void setDifficulty(ServerPlayer player, Difficulty difficulty) {
        Lobby lobby = lobbyOf(player.getUUID());
        if (lobby == null || !lobby.isHost(player.getUUID())) return;
        lobby.setDifficulty(difficulty);
        syncAll();
    }

    /** Head-to-head kickoff: needs two humans, both ready. */
    public void startMatch(ServerPlayer player) {
        Lobby lobby = lobbyOf(player.getUUID());
        if (lobby == null) { fail(player, "You're not in a lobby."); return; }
        if (!lobby.isHost(player.getUUID())) { fail(player, "Only the host can start the match."); return; }
        if (lobby.state() != Lobby.State.WAITING) return;
        if (lobby.size() < Lobby.MAX_HUMANS) { fail(player, "You need an opponent - invite someone or play the CPU."); return; }
        if (!lobby.allReady()) { fail(player, "Both players must be ready."); return; }

        lobby.setMode(Lobby.Mode.HEAD_TO_HEAD);
        FieldChoice choice = resolveField(player, lobby);
        if (!choice.ok) return;
        clearInvitesFor(lobby.id());
        MatchManager.get().start(lobby, choice.field);
        syncAll();
    }

    /** CPU match: works from anywhere, including plain singleplayer. Creates a lobby if needed. */
    public void startCpuMatch(ServerPlayer player, Difficulty difficulty, @Nullable UUID fieldId) {
        startCpuMatch(player, difficulty, fieldId, Sport.FOOTBALL);
    }

    public void startCpuMatch(ServerPlayer player, Difficulty difficulty, @Nullable UUID fieldId, Sport sportIfNew) {
        Lobby lobby = lobbyOf(player.getUUID());
        if (lobby == null) {
            createLobby(player, sportIfNew);
            lobby = lobbyOf(player.getUUID());
            if (lobby == null) return;
        }
        if (!lobby.isHost(player.getUUID())) { fail(player, "Only the host can start the match."); return; }
        if (lobby.state() != Lobby.State.WAITING) return;
        if (lobby.size() > 1) { fail(player, "You have a human opponent - use Kick Off, or have them leave first."); return; }

        lobby.setDifficulty(difficulty);
        if (fieldId != null) lobby.setSelectedField(fieldId);
        FieldChoice choice = resolveField(player, lobby);
        if (!choice.ok) { syncAll(); return; }
        lobby.setMode(Lobby.Mode.VS_CPU);
        clearInvitesFor(lobby.id());
        MatchManager.get().start(lobby, choice.field);
        syncAll();
    }

    public void selectField(ServerPlayer player, @Nullable UUID fieldId) {
        Lobby lobby = lobbyOf(player.getUUID());
        if (lobby == null || !lobby.isHost(player.getUUID()) || lobby.state() != Lobby.State.WAITING) return;
        FieldData field = FieldRegistry.get(player.server).get(fieldId);
        if (field == null) { fail(player, "That field no longer exists."); syncAll(); return; }
        if (field.type() != lobby.sport().fieldType) {
            fail(player, "\"" + field.name() + "\" isn't a " + lobby.sport().fieldType.displayName.toLowerCase() + ".");
            return;
        }
        lobby.setSelectedField(field.id());
        broadcastToLobby(lobby, Component.literal("Field set to \"" + field.name() + "\".").withStyle(ChatFormatting.AQUA));
        syncAll();
    }

    /** Clears a deleted field from any lobby that had picked it. */
    public void onFieldDeleted(UUID fieldId) {
        for (Lobby lobby : lobbies.values()) {
            if (fieldId.equals(lobby.selectedField())) lobby.setSelectedField(null);
        }
    }

    private record FieldChoice(boolean ok, @Nullable FieldData field) {}

    /**
     * Picks the field for kickoff: the lobby's choice, else the first free field.
     * With no fields built yet, the match still runs in place (so the mod is playable before anyone builds one).
     */
    private FieldChoice resolveField(ServerPlayer host, Lobby lobby) {
        FieldRegistry reg = FieldRegistry.get(host.server);
        com.sportsmc.field.FieldType wanted = lobby.sport().fieldType;
        if (wanted == null) return new FieldChoice(true, null); // played on screen, no field needed
        String noun = wanted.noun.toLowerCase();
        List<FieldData> footballFields = new ArrayList<>(); // fields of this lobby's sport
        for (FieldData f : reg.all()) if (f.type() == wanted) footballFields.add(f);
        FieldData field = reg.get(lobby.selectedField());
        if (field != null && field.type() != wanted) field = null;
        if (field != null && MatchManager.get().isFieldInUse(field.id())) {
            fail(host, "\"" + field.name() + "\" is in use by another match - pick a different " + noun + ".");
            return new FieldChoice(false, null);
        }
        if (field == null) {
            for (FieldData f : footballFields) {
                if (!MatchManager.get().isFieldInUse(f.id())) { field = f; break; }
            }
            if (field == null && !footballFields.isEmpty()) {
                fail(host, "Every " + noun + " is in use right now - wait for a match to end or build another one.");
                return new FieldChoice(false, null);
            }
        }
        if (field == null) {
            fail(host, "You need a " + wanted.displayName.toLowerCase() + " to play on. Craft a Field Blueprint (paper + green dye + white dye), "
                    + "set it to " + wanted.displayName + ", mark it and save it.");
            return new FieldChoice(false, null);
        } else {
            lobby.setSelectedField(field.id());
            if (com.sportsmc.field.FieldService.levelOf(host, field) == null) {
                fail(host, "\"" + field.name() + "\" is in a dimension that isn't loaded.");
                return new FieldChoice(false, null);
            }
        }
        return new FieldChoice(true, field);
    }

    // ------------------------------------------------------------------ lifecycle hooks

    public void onLogin(ServerPlayer player) {
        // Back from a crash or restart mid-match: put them back where they were before it.
        if (!MatchManager.get().isPlaying(player.getUUID())) com.sportsmc.match.SafeReturn.restoreIfStranded(player);
        syncAll();
        MatchManager.get().resync(player);
    }

    public void onLogout(ServerPlayer player) {
        UUID uuid = player.getUUID();
        invites.remove(uuid);
        Lobby lobby = lobbyOf(uuid);
        if (lobby != null) {
            if (lobby.state() == Lobby.State.IN_MATCH) MatchManager.get().forfeit(lobby, uuid);
            removeFromLobby(uuid);
            if (!lobby.isEmpty()) broadcastToLobby(lobby, Component.literal(name(player) + " disconnected.").withStyle(ChatFormatting.YELLOW));
        }
        syncAll(uuid);
    }

    /** Called every server tick; expires stale invites. */
    public void tick() {
        tick++;
        if (tick % 20 != 0) return;
        boolean changed = false;
        for (Iterator<Map.Entry<UUID, Map<UUID, Long>>> it = invites.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Map<UUID, Long>> e = it.next();
            changed |= e.getValue().values().removeIf(expiry -> expiry < tick);
            if (e.getValue().isEmpty()) it.remove();
        }
        if (changed) syncAll();
    }

    public void reset() {
        lobbies.clear();
        playerLobby.clear();
        invites.clear();
        tick = 0;
    }

    /** Called by the match when it ends so the lobby can rematch. */
    public void onMatchEnded(Lobby lobby) {
        if (!lobbies.containsKey(lobby.id())) return;
        lobby.setState(Lobby.State.WAITING);
        lobby.resetReady();
        syncAll();
    }

    // ------------------------------------------------------------------ queries

    public int lobbyCount() {
        return lobbies.size();
    }

    public int inviteCount() {
        int n = 0;
        for (Map<UUID, Long> m : invites.values()) n += m.size();
        return n;
    }

    @Nullable
    public Lobby lobbyOf(UUID player) {
        UUID id = playerLobby.get(player);
        return id == null ? null : lobbies.get(id);
    }

    // ------------------------------------------------------------------ sync

    public void syncAll() {
        syncAll(null);
    }

    /** Sends a fresh snapshot to every online player (optionally skipping one who is logging out). */
    private void syncAll(@Nullable UUID skip) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (!p.getUUID().equals(skip)) sync(p);
        }
    }

    public void sync(ServerPlayer viewer) {
        MinecraftServer server = viewer.getServer();
        if (server == null) return;

        LobbySyncPacket.LobbyView view = null;
        Lobby lobby = lobbyOf(viewer.getUUID());
        if (lobby != null) {
            List<LobbySyncPacket.MemberView> members = new ArrayList<>();
            for (Lobby.Member m : lobby.members()) {
                members.add(new LobbySyncPacket.MemberView(m.uuid, m.name, m.side, m.ready));
            }
            view = new LobbySyncPacket.LobbyView(lobby.id(), lobby.host(), lobby.mode(), lobby.state(), lobby.difficulty(),
                    lobby.quarterMinutes(), lobby.sport(), lobby.doubles(), lobby.tennisGames(), lobby.airGoals(),
                    lobby.selectedField(), members);
        }

        List<ServerPlayer> online = server.getPlayerList().getPlayers();
        List<LobbySyncPacket.PlayerView> invitable = new ArrayList<>();
        for (ServerPlayer p : online) {
            if (p == viewer || lobbyOf(p.getUUID()) != null) continue;
            invitable.add(new LobbySyncPacket.PlayerView(p.getUUID(), name(p)));
        }

        List<LobbySyncPacket.InviteView> pending = new ArrayList<>();
        Map<UUID, Long> mine = invites.get(viewer.getUUID());
        if (mine != null) {
            for (UUID lobbyId : mine.keySet()) {
                Lobby l = lobbies.get(lobbyId);
                if (l == null) continue;
                Lobby.Member host = l.member(l.host());
                pending.add(new LobbySyncPacket.InviteView(lobbyId, host != null ? host.name : "?"));
            }
        }

        // Plain singleplayer (not opened to LAN) can't host anyone else.
        boolean multiplayer = server.isDedicatedServer() || server.isPublished() || online.size() > 1;
        boolean alone = online.size() <= 1;

        List<LobbySyncPacket.FieldView> fields = new ArrayList<>();
        for (FieldData f : FieldRegistry.get(server).all()) {
            fields.add(new LobbySyncPacket.FieldView(f, MatchManager.get().isFieldInUse(f.id())));
        }

        ModNetwork.sendTo(viewer, new LobbySyncPacket(view, invitable, pending, fields, multiplayer, alone));
    }

    // ------------------------------------------------------------------ helpers

    private void removeFromLobby(UUID uuid) {
        UUID id = playerLobby.remove(uuid);
        if (id == null) return;
        Lobby lobby = lobbies.get(id);
        if (lobby == null) return;
        lobby.remove(uuid);
        if (lobby.isEmpty()) {
            lobbies.remove(id);
            clearInvitesFor(id);
        }
    }

    private void clearInvitesFor(UUID lobbyId) {
        for (Map<UUID, Long> m : invites.values()) m.remove(lobbyId);
        invites.values().removeIf(Map::isEmpty);
    }

    private static MutableComponent inviteMessage(String hostName, Sport sport) {
        MutableComponent accept = Component.literal("[ACCEPT]").withStyle(Style.EMPTY
                .withColor(ChatFormatting.GREEN).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/sportsmc accept " + hostName))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Join " + hostName + "'s lobby"))));
        MutableComponent decline = Component.literal("[DECLINE]").withStyle(Style.EMPTY
                .withColor(ChatFormatting.RED).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/sportsmc decline")));
        return Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD)
                .append(Component.literal(hostName + " invited you to a " + sport.displayName.toLowerCase()
                        + (sport == Sport.TENNIS ? " match! " : " game! ")).withStyle(ChatFormatting.WHITE))
                .append(accept).append(" ").append(decline);
    }

    private void broadcastToLobby(Lobby lobby, Component msg) {
        for (Lobby.Member m : lobby.members()) {
            ServerPlayer p = player(m.uuid);
            if (p != null) p.sendSystemMessage(Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD).append(msg));
        }
    }

    @Nullable
    private static ServerPlayer player(@Nullable UUID uuid) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        return server == null || uuid == null ? null : server.getPlayerList().getPlayer(uuid);
    }

    private static String name(ServerPlayer p) {
        return p.getGameProfile().getName();
    }

    private static void info(ServerPlayer p, String text) {
        p.sendSystemMessage(Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD)
                .append(Component.literal(text).withStyle(ChatFormatting.WHITE)));
    }

    private static void fail(ServerPlayer p, String text) {
        p.sendSystemMessage(Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD)
                .append(Component.literal(text).withStyle(ChatFormatting.RED)));
    }
}
