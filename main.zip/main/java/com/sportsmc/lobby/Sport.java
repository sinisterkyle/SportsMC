package com.sportsmc.lobby;

import com.sportsmc.field.FieldType;

/** The sport a lobby plays. Each sport plays on its own kind of field. */
public enum Sport {
    FOOTBALL("Football", FieldType.FOOTBALL),
    TENNIS("Tennis", FieldType.TENNIS),
    /** Played in an on-screen table; needs no field. */
    AIR_HOCKEY("Air Hockey", null),
    /** Elemental card duel on screen; needs no field. */
    CARD_DOJO("Card Dojo", null),
    /** Ten-pin bowling on a lane built with the Field Blueprint. */
    BOWLING("Bowling", FieldType.BOWLING);

    public final String displayName;
    /** Null for sports that don't need a field in the world. */
    @javax.annotation.Nullable public final FieldType fieldType;

    Sport(String displayName, @javax.annotation.Nullable FieldType fieldType) {
        this.displayName = displayName;
        this.fieldType = fieldType;
    }

    public static Sport byOrdinal(int i) {
        Sport[] v = values();
        return i >= 0 && i < v.length ? v[i] : FOOTBALL;
    }
}
