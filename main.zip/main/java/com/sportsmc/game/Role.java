package com.sportsmc.game;

/** Football positions used by the 7-on-7 squads. Speed is top running speed in blocks per tick. */
public enum Role {
    QB("QB", true, 0.27),
    RB("RB", true, 0.31),
    WR("WR", true, 0.32),
    OL("OL", true, 0.235),
    DL("DL", false, 0.25),
    LB("LB", false, 0.285),
    CB("CB", false, 0.315),
    S("S", false, 0.30);

    public final String label;
    public final boolean offense;
    public final double speed;

    Role(String label, boolean offense, double speed) {
        this.label = label;
        this.offense = offense;
        this.speed = speed;
    }

    public static Role byOrdinal(int i) {
        Role[] v = values();
        return i >= 0 && i < v.length ? v[i] : WR;
    }
}
