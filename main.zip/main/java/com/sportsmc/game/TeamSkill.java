package com.sportsmc.game;

/**
 * How well a team's AI players play.
 *
 * @param tackle       chance per tick that an AI defender in contact makes the tackle
 * @param intercept    chance an AI defender who reaches the ball first intercepts it (else breaks it up)
 * @param cushion      yards a cornerback gives his receiver in man coverage
 * @param qbError      blocks of random error on AI throws (doubled under pressure)
 * @param reaction     ticks before AI defenders break on a thrown ball
 * @param qbHold       base ticks an AI quarterback waits for a receiver to come open
 */
public record TeamSkill(double tackle, double intercept, double cushion, double qbError, int reaction, int qbHold) {

    /** The AI teammates of a human-controlled team. */
    public static final TeamSkill HUMAN_TEAM = new TeamSkill(0.19, 0.28, 1.6, 0.6, 7, 48);
}
