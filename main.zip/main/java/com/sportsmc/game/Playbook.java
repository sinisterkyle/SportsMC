package com.sportsmc.game;

import java.util.List;

/**
 * Built-in plays. Route points are in YARDS relative to where the player lines up:
 *   x = downfield (toward the end zone being attacked), y = toward the player's own sideline ("outside";
 *   negative = toward the middle of the field).
 * A play gives routes for WR1 (left), WR2 (right) and the RB. Run plays hand the ball to the RB;
 * Punt and Field Goal are special-teams plays the offense can call on any down.
 */
public final class Playbook {

    public enum Type { PASS, RUN, PUNT, FIELD_GOAL }

    /** Defensive calls, chosen by the defense before the snap. */
    public enum Coverage {
        MAN("Man Coverage"), ZONE("Cover 2 Zone"), BLITZ("Blitz");

        public final String label;

        Coverage(String label) { this.label = label; }

        public Coverage next() { return values()[(ordinal() + 1) % values().length]; }
    }

    public record Pt(double down, double out) {}

    public record Route(List<Pt> points, boolean settles) {
        static Route of(boolean settles, double... xy) {
            Pt[] pts = new Pt[xy.length / 2];
            for (int i = 0; i < pts.length; i++) pts[i] = new Pt(xy[i * 2], xy[i * 2 + 1]);
            return new Route(List.of(pts), settles);
        }
    }

    public record Play(String name, Type type, Route wr1, Route wr2, Route rb) {
        public boolean run() { return type == Type.RUN; }
        public boolean kick() { return type == Type.PUNT || type == Type.FIELD_GOAL; }
    }

    private static final Route NONE = Route.of(true, 0, 0);
    private static final Route GUNNER = Route.of(false, 45, 0);

    public static final List<Play> PLAYS = List.of(
            new Play("Slants", Type.PASS,
                    Route.of(false, 2, 0, 7, -5, 18, -10),
                    Route.of(false, 2, 0, 7, -5, 18, -10),
                    Route.of(true, 1, 3, 3, 8)),
            new Play("Verticals", Type.PASS,
                    Route.of(false, 45, 0),
                    Route.of(false, 45, 0),
                    Route.of(true, 2, 3, 6, 5)),
            new Play("Curls", Type.PASS,
                    Route.of(true, 12, 0, 10, -1),
                    Route.of(true, 12, 0, 10, -1),
                    Route.of(true, 3, 4)),
            new Play("Post / Corner", Type.PASS,
                    Route.of(false, 10, 0, 30, -12),
                    Route.of(false, 10, 0, 24, 9),
                    Route.of(true, 5, 0)),
            new Play("Mesh Drag", Type.PASS,
                    Route.of(false, 5, 0, 6, -20, 7, -30),
                    Route.of(true, 14, 0, 14, -8),
                    Route.of(true, 1, 4, 2, 9)),
            new Play("HB Dive", Type.RUN,
                    Route.of(true, 5, -2),
                    Route.of(true, 5, -2),
                    Route.of(false, 0, -1.5, 30, -1.5)),
            new Play("HB Toss", Type.RUN,
                    Route.of(true, 4, -1),
                    Route.of(true, 4, -1),
                    Route.of(false, -1, 6, 25, 10)),
            new Play("Punt", Type.PUNT, GUNNER, GUNNER, NONE),
            new Play("Field Goal", Type.FIELD_GOAL, NONE, NONE, NONE)
    );

    private Playbook() {}

    public static Play get(int index) {
        return PLAYS.get(Math.floorMod(index, PLAYS.size()));
    }

    public static int indexOf(Type type) {
        for (int i = 0; i < PLAYS.size(); i++) if (PLAYS.get(i).type() == type) return i;
        return 0;
    }

    /** Offensive plays the CPU picks from on downs 1-3. */
    public static int randomScrimmagePlay(net.minecraft.util.RandomSource random) {
        int n = 0;
        for (Play p : PLAYS) if (!p.kick()) n++;
        return random.nextInt(n);
    }
}
