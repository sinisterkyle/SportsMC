package com.sportsmc.game;

import com.sportsmc.entity.FootballEntity;
import com.sportsmc.entity.FootballPlayerEntity;
import com.sportsmc.field.FieldGeometry;
import com.sportsmc.game.Playbook.Coverage;
import com.sportsmc.lobby.Lobby;
import com.sportsmc.match.FootballMatch;
import com.sportsmc.network.ControlPacket;
import com.sportsmc.registry.ModEntities;
import com.sportsmc.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Runs the actual football: lines both 7-man squads up, snaps, runs every AI player each tick,
 * applies the humans' controls to whichever player they control, flies the ball, and decides
 * catches, interceptions, tackles, kicks, touchdowns and out-of-bounds. Results go back to
 * FootballMatch, which keeps score, downs and the clock.
 *
 * Positions are reasoned about in field yards (see FieldGeometry). "offense" is the team that
 * snaps the ball (on a kickoff, the kicking team); d = dir(offense) is the way it's going
 * (+1 = toward AWAY's end zone).
 */
public class PlayEngine {

    public enum State { PRE_SNAP, LIVE, BALL_IN_AIR, DEAD }

    private enum Kick { NONE, KICKOFF, PUNT, FIELD_GOAL }

    private static final int DEAD_TICKS = 55;
    public static final int HUMAN_PLAY_CLOCK = 20 * 20;
    private static final double TACKLE_RANGE = 1.0;
    private static final double DIVE_TACKLE_RANGE = 1.45;
    /** Pass speed in blocks/tick. Lower = more hang time (higher arc). Was 0.95. */
    private static final double THROW_SPEED = 0.65;
    /** Longest a pass may hang in the air (ticks): deep balls get thrown a bit faster instead of higher (peak ~5 blocks). */
    private static final double PASS_MAX_TICKS = 30;
    /** How far ahead (blocks) the QB may lead a receiver, and how much of his speed he trusts. */
    private static final double MAX_LEAD = 5.0, LEAD_FACTOR = 0.85;
    private static final double HUMAN_RUN = 0.92, HUMAN_SPRINT = 1.18;
    /**
     * Boost (CTRL sprint) for the player you control. The bar refills every play. Defense gets the better boost:
     * a faster top speed, a bigger tank and quicker recharge, so a human defender can close down a ball carrier.
     */
    private static final double OFF_BOOST_SPEED = 1.18, DEF_BOOST_SPEED = 1.34;
    private static final double OFF_BOOST_DRAIN = 1.0 / 120, DEF_BOOST_DRAIN = 1.0 / 170;  // full bar = 6 s / 8.5 s
    private static final double OFF_BOOST_REGEN = 1.0 / 140, DEF_BOOST_REGEN = 1.0 / 80;   // per tick after a short pause
    private static final int BOOST_REGEN_DELAY = 15;
    private static final double BOOST_RECOVER = 0.25;  // empty bar: no boost until it's back to 25%

    private static final class Boost {
        double level = 1;
        boolean exhausted;
        int sinceUse = 99;
    }

    private final Map<UUID, Boost> boosts = new HashMap<>();
    /** Pass-rush tuning: raise toward 1.0 for a faster rush, lower for more time in the pocket. */
    /** Block tuning: how long a blocked player is stopped (ticks, 20 = 1 s) and how long he can't be re-blocked. */
    private static final int BLOCK_MIN_TICKS = 15;          // a block holds a defender 0.75 - 1.5 s
    private static final int BLOCK_MAX_TICKS = 30;
    private static final int BLOCK_IMMUNE_TICKS = 60;       // then he's free for 3 s before anyone can block him again
    private static final int BLOCKER_COOLDOWN_TICKS = 50;   // a blocker needs 2.5 s after releasing before his next block
    private static final int MAX_BLOCKS_PER_DEFENDER = 2;   // nobody gets locked up more than twice in one play
    private static final double BLOCK_RANGE = 1.0;
    private static final int RUSH_DELAY_TICKS = 35;      // 1.75 s slow start for the rush after the snap
    private static final double RUSH_FIRST_STEP = 0.45;  // speed during that slow start
    private static final int SACK_GRACE_TICKS = 30;      // 1.5 s after the snap the QB can't be sacked (time to read)
    private static final double RUSH_BACKFIELD = 0.65;   // speed once past the line of scrimmage

    private final FootballMatch match;
    private final FieldGeometry g;
    private final ServerLevel level;
    private final RandomSource random;

    private final List<FootballPlayerEntity> players = new ArrayList<>();
    private final Map<UUID, Control> controls = new HashMap<>();
    private final Map<UUID, FootballPlayerEntity> selected = new HashMap<>();
    /** Players already stepped through with switch since the last pause, so repeated presses reach everyone. */
    private final Map<UUID, java.util.Set<FootballPlayerEntity>> switchVisited = new HashMap<>();
    private final Map<UUID, Integer> lastSwitchAt = new HashMap<>();
    private int engineTicks;
    private final Map<Lobby.Side, Integer> playIndex = new EnumMap<>(Lobby.Side.class);
    private final Map<Lobby.Side, Coverage> coverageCall = new EnumMap<>(Lobby.Side.class);

    private State state = State.DEAD;
    private int stateTicks;
    private int cpuSnapDelay;
    private int qbHold;
    private Lobby.Side offense = Lobby.Side.HOME;
    private double losYard;
    private Playbook.Play play = Playbook.get(0);
    private Coverage coverage = Coverage.MAN;
    private Kick kick = Kick.NONE;
    private boolean kickGood;
    private int kickFlight;
    @Nullable private FootballPlayerEntity carrier;
    @Nullable private FootballEntity ball;
    @Nullable private FootballPlayerEntity intendedReceiver;
    @Nullable private FootballPlayerEntity thrower;
    private boolean looseBall;
    private int looseTicks;
    @Nullable private FootballPlayerEntity returner;
    private Vec3 ballAim = Vec3.ZERO;
    private boolean thrown, handedOff, turnover, completed, qbScramble, labelsShown, kicked;
    private boolean dirty = true;

    private static final class Control {
        Vec3 move = Vec3.ZERO;
        boolean sprint;
        int pending;
    }

    public PlayEngine(FootballMatch match, FieldGeometry geometry, ServerLevel level) {
        this.match = match;
        this.g = geometry;
        this.level = level;
        this.random = level.getRandom();
    }

    // ================================================================== public API

    public State state() { return state; }
    public boolean isLive() { return state == State.LIVE || state == State.BALL_IN_AIR; }
    @Nullable public FootballPlayerEntity carrier() { return carrier; }
    public Playbook.Play play() { return play; }
    public Lobby.Side offense() { return offense; }
    public Coverage coverage() { return coverage; }
    public boolean isKickoff() { return kick == Kick.KICKOFF; }

    public String playName() {
        if (kick == Kick.KICKOFF) return "Kickoff";
        if (match.tryNext() && play.type() == Playbook.Type.FIELD_GOAL) return "Extra Point";
        return play.name();
    }

    /** Line of scrimmage of the play being run (a 2-point try snaps from the 2, an extra point from the 15). */
    public double losYard() {
        return losYard;
    }

    /** Seconds left on the play clock when a human must snap, else -1. */
    public int playClockSeconds() {
        if (state != State.PRE_SNAP || match.humanOf(offense) == null) return -1;
        return Math.max(0, (HUMAN_PLAY_CLOCK - stateTicks + 19) / 20);
    }

    public boolean consumeDirty() {
        boolean d = dirty;
        dirty = false;
        return d;
    }

    public void control(UUID player, ControlPacket msg) {
        Control c = controls.computeIfAbsent(player, k -> new Control());
        Vec3 mv = new Vec3(msg.moveX(), 0, msg.moveZ());
        c.move = mv.lengthSqr() > 1 ? mv.normalize() : mv;
        c.sprint = msg.sprint();
        c.pending |= msg.actions();
    }

    /** Which player entity a human is steering right now (null if none). */
    @Nullable
    public FootballPlayerEntity controlledBy(UUID human) {
        Lobby.Side side = match.sideOf(human);
        if (side == null || players.isEmpty()) return null;
        if (state == State.PRE_SNAP && side == offense) return find(offense, Role.QB, 0);
        if (carrier != null && carrier.side() == side) return carrier;
        FootballPlayerEntity sel = selected.get(human);
        if (sel == null || sel.isRemoved() || sel.side() != side) {
            sel = nearestToBall(side);
            if (sel != null) selected.put(human, sel);
        }
        return sel;
    }

    /** Entity the camera should follow: ball carrier, else the ball in flight, else -1 (the line of scrimmage). */
    public int followEntityId() {
        if (carrier != null && state != State.PRE_SNAP) return carrier.getId();
        if (ball != null) return ball.getId();
        return -1;
    }

    public boolean canThrow() {
        return state == State.LIVE && kick == Kick.NONE && carrier != null && carrier.role() == Role.QB
                && carrier.side() == offense && !thrown && !handedOff && !turnover;
    }

    /** Entity ids of the receivers a quarterback can throw to with 1 / 2 / 3 (-1 if missing). */
    public int[] passTargetIds() {
        FootballPlayerEntity[] who = {find(offense, Role.WR, 1), find(offense, Role.WR, 2), find(offense, Role.RB, 0)};
        int[] ids = new int[3];
        for (int i = 0; i < 3; i++) ids[i] = who[i] == null || who[i] == carrier ? -1 : who[i].getId();
        return ids;
    }

    /** Ball is snapped (human pressed SPACE, CPU decided, play clock ran out, or a debug command). */
    public void snap() {
        if (state != State.PRE_SNAP) return;
        state = State.LIVE;
        stateTicks = 0;
        FootballPlayerEntity qb = find(offense, Role.QB, 0);
        setCarrier(qb);
        qbHold = skill(offense).qbHold() + random.nextInt(25);
        for (FootballPlayerEntity p : players) p.setIdleYaw(Float.NaN);
        if (qb != null) match.sound(qb.position(), SoundEvents.NOTE_BLOCK_BASEDRUM.value(), 1f, 0.6f);
        if (kick == Kick.NONE) {
            prepareRoutes();
            if (match.humanOf(offense) != null) showLabels(true);
        } else {
            buildRoute(find(offense, Role.WR, 1), play.wr1(), dir(offense));
            buildRoute(find(offense, Role.WR, 2), play.wr2(), dir(offense));
        }
        match.startClock();
        dirty = true;
    }

    /** Debug: end the current play with a fixed gain. */
    public void debugEnd(double gained) {
        if (state == State.PRE_SNAP) snap();
        if (state == State.DEAD) return;
        endPlay(PlayResult.Kind.TACKLE, losYard + dir(offense) * gained, "Debug play");
    }

    public void cleanup() {
        for (FootballPlayerEntity p : players) p.discard();
        players.clear();
        if (ball != null) ball.discard();
        ball = null;
        carrier = null;
        intendedReceiver = null;
        returner = null;
    }

    // ================================================================== play setup

    /** Lines both squads up for the next play (scrimmage play, punt, field goal or kickoff). */
    public void setupPlay() {
        setupPlay(true);
    }

    /**
     * @param fresh true for a new play; false when re-forming the same play after the offense or defense
     *              changed its call with R (so a chosen Punt / Field Goal isn't reset).
     */
    private void setupPlay(boolean fresh) {
        cleanup();
        offense = match.possession();
        losYard = match.ballYard();
        thrown = handedOff = turnover = completed = qbScramble = labelsShown = kicked = false;
        if (fresh) boosts.clear(); // full boost bar every play
        looseBall = false;
        looseTicks = 0;
        thrower = null;
        stateTicks = 0;
        state = State.PRE_SNAP;
        cpuSnapDelay = 60 + random.nextInt(50);
        Lobby.Side def = offense.opposite();

        // Play calls.
        if (match.kickoffNext()) {
            kick = Kick.KICKOFF;
        } else {
            boolean isTry = match.tryNext();
            int fg = Playbook.indexOf(Playbook.Type.FIELD_GOAL);
            if (match.humanOf(offense) == null) {
                playIndex.put(offense, isTry ? fg : cpuPlayCall());
            } else if (fresh) {
                // A new play: after a touchdown default to kicking the extra point; otherwise start from
                // a normal play (Punt / Field Goal are always one or two presses of R away).
                if (isTry) playIndex.put(offense, fg);
                else if (Playbook.get(playIndex.getOrDefault(offense, 0)).kick()) playIndex.put(offense, 0);
            }
            // No punting on a try.
            if (isTry && Playbook.get(playIndex.getOrDefault(offense, 0)).type() == Playbook.Type.PUNT) {
                playIndex.put(offense, Math.floorMod(playIndex.get(offense) + 1, Playbook.PLAYS.size()));
            }
            play = Playbook.get(playIndex.getOrDefault(offense, 0));
            kick = play.type() == Playbook.Type.PUNT ? Kick.PUNT : play.type() == Playbook.Type.FIELD_GOAL ? Kick.FIELD_GOAL : Kick.NONE;
            if (isTry) {
                // Extra point is kicked from the 15; a 2-point try is run from the 2.
                double goal = goalLineOf(offense.opposite());
                losYard = goal - dir(offense) * (kick == Kick.FIELD_GOAL ? 15 : 2);
            }
        }
        if (match.humanOf(def) == null) coverageCall.put(def, cpuCoverage());
        coverage = coverageCall.getOrDefault(def, Coverage.MAN);

        switch (kick) {
            case KICKOFF -> lineUpKickoff(def);
            case PUNT -> lineUpPunt(def);
            case FIELD_GOAL -> lineUpFieldGoal(def);
            default -> lineUpScrimmage(def);
        }

        for (UUID h : match.humans()) selected.remove(h);
        switchVisited.clear();
        if (returner != null) {
            UUID h = match.humanOf(def);
            if (h != null) selected.put(h, returner);
        }
        FootballPlayerEntity holder = kick == Kick.KICKOFF ? find(offense, Role.QB, 0) : find(offense, Role.OL, 0);
        if (holder != null) holder.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.FOOTBALL.get()));
        dirty = true;
    }

    private int cpuPlayCall() {
        if (match.down() == 4) {
            double togo = Math.abs(match.firstDownYard() - losYard);
            boolean pastMid = (losYard - 50) * dir(offense) > -5;
            if (fieldGoalDistance() <= 52) return Playbook.indexOf(Playbook.Type.FIELD_GOAL);
            if (togo <= 2 && pastMid) return Playbook.randomScrimmagePlay(random);
            return Playbook.indexOf(Playbook.Type.PUNT);
        }
        return Playbook.randomScrimmagePlay(random);
    }

    private Coverage cpuCoverage() {
        double togo = Math.abs(match.firstDownYard() - losYard);
        float r = random.nextFloat();
        if (match.down() >= 3 && togo > 6) return r < 0.4f ? Coverage.BLITZ : r < 0.7f ? Coverage.ZONE : Coverage.MAN;
        return r < 0.45f ? Coverage.MAN : r < 0.85f ? Coverage.ZONE : Coverage.BLITZ;
    }

    private double wrLat() {
        double half = g.halfWidthYards();
        return Math.min(half * 0.72, half - 2.5);
    }

    private void lineUpScrimmage(Lobby.Side def) {
        int d = dir(offense);
        double half = g.halfWidthYards(), wr = wrLat();
        spawn(offense, Role.OL, 52, 0, losYard - d * 0.6, 0);
        spawn(offense, Role.OL, 66, -1, losYard - d * 0.6, -1.6);
        spawn(offense, Role.OL, 70, 1, losYard - d * 0.6, 1.6);
        spawn(offense, Role.QB, 12, 0, losYard - d * 5, 0);
        spawn(offense, Role.RB, 28, 0, losYard - d * 5.5, 1.8);
        spawn(offense, Role.WR, 81, 1, losYard - d * 0.6, -wr);
        spawn(offense, Role.WR, 84, 2, losYard - d * 0.6, wr);

        spawn(def, Role.DL, 91, 1, losYard + d * 1.2, -1.0);
        spawn(def, Role.DL, 97, 2, losYard + d * 1.2, 1.0);
        spawn(def, Role.LB, 54, 0, losYard + d * 5, 0);
        spawn(def, Role.CB, 24, 1, losYard + d * (coverage == Coverage.ZONE ? 7 : 6), -wr);
        spawn(def, Role.CB, 21, 2, losYard + d * (coverage == Coverage.ZONE ? 7 : 6), wr);
        spawn(def, Role.S, 31, 1, losYard + d * 13, -half * 0.35);
        spawn(def, Role.S, 42, 2, losYard + d * 13, half * 0.35);
    }

    private void lineUpPunt(Lobby.Side def) {
        int d = dir(offense);
        double wr = wrLat();
        double recvGoal = goalLineOf(def);
        spawn(offense, Role.OL, 52, 0, losYard - d * 0.6, 0);
        spawn(offense, Role.OL, 66, -1, losYard - d * 0.6, -1.6);
        spawn(offense, Role.OL, 70, 1, losYard - d * 0.6, 1.6);
        spawn(offense, Role.QB, 4, 0, losYard - d * 12, 0);       // punter
        spawn(offense, Role.RB, 33, 0, losYard - d * 5, 0);       // personal protector
        spawn(offense, Role.WR, 18, 1, losYard - d * 0.6, -wr);   // gunners
        spawn(offense, Role.WR, 19, 2, losYard - d * 0.6, wr);

        spawn(def, Role.DL, 91, 1, losYard + d * 1.2, -1.0);
        spawn(def, Role.DL, 97, 2, losYard + d * 1.2, 1.0);
        spawn(def, Role.LB, 54, 0, losYard + d * 5, 0);
        spawn(def, Role.CB, 24, 1, losYard + d * 1.5, -wr);
        spawn(def, Role.CB, 21, 2, losYard + d * 1.5, wr);
        double deep = clampInField(losYard + d * 40, recvGoal, d);
        spawn(def, Role.S, 31, 1, deep, 0);                         // returner
        spawn(def, Role.S, 42, 2, clampInField(losYard + d * 28, recvGoal, d), 4);
        returner = find(def, Role.S, 1);
    }

    private void lineUpFieldGoal(Lobby.Side def) {
        int d = dir(offense);
        spawn(offense, Role.OL, 52, 0, losYard - d * 0.6, 0);
        spawn(offense, Role.OL, 66, -1, losYard - d * 0.6, -1.6);
        spawn(offense, Role.OL, 70, 1, losYard - d * 0.6, 1.6);
        spawn(offense, Role.QB, 3, 0, losYard - d * 7, -0.6);     // kicker
        spawn(offense, Role.RB, 8, 0, losYard - d * 6, 0.6);      // holder
        spawn(offense, Role.WR, 85, 1, losYard - d * 0.8, -3.2);  // wings
        spawn(offense, Role.WR, 86, 2, losYard - d * 0.8, 3.2);

        spawn(def, Role.DL, 91, 1, losYard + d * 1.2, -1.0);
        spawn(def, Role.DL, 97, 2, losYard + d * 1.2, 1.0);
        spawn(def, Role.LB, 54, 0, losYard + d * 1.5, 0);
        spawn(def, Role.CB, 24, 1, losYard + d * 1.5, -4);
        spawn(def, Role.CB, 21, 2, losYard + d * 1.5, 4);
        spawn(def, Role.S, 31, 1, losYard + d * 8, -3);
        spawn(def, Role.S, 42, 2, losYard + d * 8, 3);
    }

    private void lineUpKickoff(Lobby.Side recv) {
        int d = dir(offense);
        double half = g.halfWidthYards();
        double recvGoal = goalLineOf(recv);
        spawn(offense, Role.QB, 2, 0, losYard - d * 5, 0);         // kicker
        double[] lanes = {-0.75, -0.45, -0.15, 0.15, 0.45, 0.75};
        Role[] roles = {Role.WR, Role.OL, Role.RB, Role.OL, Role.OL, Role.WR};
        int[] numbers = {11, 50, 23, 58, 59, 13};
        int[] slots = {1, -1, 0, 0, 1, 2};
        for (int i = 0; i < lanes.length; i++) {
            spawn(offense, roles[i], numbers[i], slots[i], losYard - d * 1, lanes[i] * half);
        }
        spawn(recv, Role.S, 26, 1, recvGoal - d * 5, 0);           // returner
        spawn(recv, Role.S, 42, 2, recvGoal - d * 12, -half * 0.3);
        spawn(recv, Role.CB, 24, 1, recvGoal - d * 25, -half * 0.5);
        spawn(recv, Role.CB, 21, 2, recvGoal - d * 25, half * 0.5);
        spawn(recv, Role.LB, 54, 0, recvGoal - d * 30, 0);
        spawn(recv, Role.DL, 91, 1, losYard + d * 12, -half * 0.25);
        spawn(recv, Role.DL, 97, 2, losYard + d * 12, half * 0.25);
        returner = find(recv, Role.S, 1);
    }

    private double clampInField(double yard, double recvGoal, int d) {
        double limit = recvGoal - d * 3;
        return d == 1 ? Math.min(yard, limit) : Math.max(yard, limit);
    }

    private void spawn(Lobby.Side side, Role role, int number, int slot, double yard, double lat) {
        FootballPlayerEntity e = ModEntities.FOOTBALL_PLAYER.get().create(level);
        if (e == null) return;
        double edge = g.halfWidthYards() - 0.8;
        lat = Math.max(-edge, Math.min(edge, lat));
        e.setup(side, role, number, slot);
        Vec3 pos = g.at(yard, lat, g.floorY);
        float yaw = g.yaw(side == Lobby.Side.HOME);
        e.moveTo(pos.x, pos.y, pos.z, yaw, 0f);
        e.setYHeadRot(yaw);
        e.setYBodyRot(yaw);
        e.setIdleYaw(yaw);
        level.addFreshEntity(e);
        players.add(e);
    }

    // ================================================================== tick

    public void tick() {
        stateTicks++;
        engineTicks++;
        players.removeIf(p -> p.isRemoved());
        for (FootballPlayerEntity p : players) p.claim();
        if (ball != null) ball.claim();
        if (players.isEmpty() && state != State.DEAD) {
            state = State.DEAD;
            stateTicks = 0;
        }

        if (match.isBreak()) { // halftime: everyone waits
            for (FootballPlayerEntity p : players) p.stopRunning();
            for (Control c : controls.values()) c.pending = 0;
            return;
        }

        handleHumanActions();

        switch (state) {
            case PRE_SNAP -> tickPreSnap();
            case LIVE, BALL_IN_AIR -> tickLive();
            case DEAD -> {
                for (FootballPlayerEntity p : players) p.stopRunning();
                if (stateTicks >= DEAD_TICKS && !match.isFinished() && !match.isBreak()) setupPlay();
            }
        }
    }

    private void tickPreSnap() {
        for (FootballPlayerEntity p : players) p.stopRunning();
        boolean humanOffense = match.humanOf(offense) != null;
        if (humanOffense && stateTicks == HUMAN_PLAY_CLOCK - 100) {
            match.notifySide(offense, Component.literal("Play clock: 5 seconds - press SPACE to snap").withStyle(ChatFormatting.YELLOW));
        }
        if (stateTicks % 20 == 0) dirty = true; // play clock display
        if (humanOffense ? stateTicks >= HUMAN_PLAY_CLOCK : stateTicks >= cpuSnapDelay) snap();
    }

    private void tickLive() {
        for (FootballPlayerEntity p : players) {
            UUID human = humanControlling(p);
            Control hc = human != null ? controls.get(human) : null;
            boolean handsOff = hc == null || hc.move.length() < 0.1;
            if (human != null && state == State.BALL_IN_AIR && p == intendedReceiver && kick == Kick.NONE) {
                // Catch assist: the receiver runs to where the ball comes down. Your keys only nudge him (they're
                // usually still held from moving the QB, which used to send him the wrong way).
                Vec3 toBall = horiz(ballAim.subtract(p.position()));
                double dist = toBall.length();
                if (handsOff || dist > 1.5) {
                    Vec3 dirv = dist > 1e-3 ? toBall.scale(1.0 / dist) : Vec3.ZERO;
                    if (!handsOff) dirv = dirv.scale(1.6).add(hc.move.scale(0.4));
                    double speed = p.role().speed * (hc != null && hc.sprint ? 1.1 : 1.0);
                    if (dist < 0.4) p.stopRunning();
                    else p.drive(dirv, speed * Math.max(0.35, Math.min(1.0, dist / 1.5)));
                } else {
                    moveHuman(p, hc, human); // under the ball: fine-tune with your keys
                }
            } else if (human != null) {
                moveHuman(p, hc, human);
            } else {
                think(p);
            }
        }
        applyBlocking();
        applyRushSlowdown();

        if (labelsShown && !canThrow()) showLabels(false);
        // AI quarterbacks hand off on run plays automatically; a human QB chooses: G to hand off, or 1/2/3 to throw.
        if (play.run() && kick == Kick.NONE && carrier != null && carrier.role() == Role.QB && !handedOff && !thrown
                && stateTicks > 6 && humanControlling(carrier) == null) {
            tryHandoff(carrier, 3.0); // dive = handoff, toss = short pitch
        }
        if (kick != Kick.NONE && !kicked && carrier != null && carrier.role() == Role.QB && carrier.side() == offense) {
            int kickAt = kick == Kick.KICKOFF ? 26 : kick == Kick.PUNT ? 20 : 16;
            if (stateTicks >= kickAt) kickBall(carrier);
        }

        if (state == State.BALL_IN_AIR) tickBall();
        else checkCarrier();
    }

    // ================================================================== humans

    @Nullable
    private UUID humanControlling(FootballPlayerEntity p) {
        for (UUID h : match.humans()) if (controlledBy(h) == p) return h;
        return null;
    }

    private void moveHuman(FootballPlayerEntity p, @Nullable Control c, UUID human) {
        Boost b = boosts.computeIfAbsent(human, k -> new Boost());
        if (c == null || !p.canAct()) { if (c == null) p.stopRunning(); rechargeBoost(b, p.side() != ballSide()); return; }
        // The kicker runs his approach automatically.
        if (kick != Kick.NONE && !kicked && p == carrier) { think(p); return; }
        boolean defense = p.side() != ballSide();
        boolean moving = c.move.lengthSqr() > 0.01;
        boolean boosting = c.sprint && moving && !b.exhausted && b.level > 0;
        if (boosting) {
            b.level = Math.max(0, b.level - (defense ? DEF_BOOST_DRAIN : OFF_BOOST_DRAIN));
            b.sinceUse = 0;
            if (b.level <= 0) b.exhausted = true;
        } else {
            rechargeBoost(b, defense);
        }
        double mult = boosting ? (defense ? DEF_BOOST_SPEED : OFF_BOOST_SPEED) : HUMAN_RUN;
        p.drive(c.move, p.role().speed * mult * Math.min(1.0, c.move.length()));
    }

    private static void rechargeBoost(Boost b, boolean defense) {
        b.sinceUse++;
        if (b.sinceUse > BOOST_REGEN_DELAY) b.level = Math.min(1, b.level + (defense ? DEF_BOOST_REGEN : OFF_BOOST_REGEN));
        if (b.exhausted && b.level >= BOOST_RECOVER) b.exhausted = false;
    }

    /** Boost bar for the HUD (0..1). */
    public float boostLevel(UUID human) {
        Boost b = boosts.get(human);
        return b == null ? 1f : (float) b.level;
    }

    public boolean boostExhausted(UUID human) {
        Boost b = boosts.get(human);
        return b != null && b.exhausted;
    }

    /** Is this human's team without the ball right now (gets the defensive boost)? */
    public boolean onDefense(UUID human) {
        Lobby.Side s = match.sideOf(human);
        return s != null && s != ballSide();
    }

    private void handleHumanActions() {
        for (Map.Entry<UUID, Control> e : controls.entrySet()) {
            Control c = e.getValue();
            int a = c.pending;
            if (a == 0) continue;
            c.pending = 0;
            UUID human = e.getKey();
            Lobby.Side side = match.sideOf(human);
            if (side == null) continue;
            FootballPlayerEntity me = controlledBy(human);

            if ((a & ControlPacket.CYCLE_PLAY) != 0 && state == State.PRE_SNAP && kick != Kick.KICKOFF) {
                if (side == offense) {
                    int next = Math.floorMod(playIndex.getOrDefault(offense, 0) + 1, Playbook.PLAYS.size());
                    playIndex.put(offense, next);
                    setupPlayKeepingClock();
                } else {
                    coverageCall.put(side, coverageCall.getOrDefault(side, Coverage.MAN).next());
                    setupPlayKeepingClock();
                }
            }
            if ((a & ControlPacket.HIKE_OR_JUMP) != 0) {
                if (state == State.PRE_SNAP) { if (side == offense) snap(); }
                else if (me != null) me.hurdle();
            }
            // Switch player (right-click): works before the snap too, whenever your team doesn't have the ball.
            boolean canSwitch = state == State.PRE_SNAP ? side != offense : (carrier == null || carrier.side() != side);
            if ((a & ControlPacket.SWITCH) != 0 && canSwitch) {
                FootballPlayerEntity next = nextSelectable(human, side, me);
                if (next != null) {
                    selected.put(human, next);
                    me = next;
                    dirty = true;
                }
            }
            if (me == null || state == State.DEAD || state == State.PRE_SNAP) continue;

            if (me == carrier && canThrow()) {
                FootballPlayerEntity target = null;
                if ((a & ControlPacket.THROW_1) != 0) target = find(offense, Role.WR, 1);
                if ((a & ControlPacket.THROW_2) != 0) target = find(offense, Role.WR, 2);
                if ((a & ControlPacket.THROW_3) != 0) target = find(offense, Role.RB, 0);
                if (target != null) throwTo(me, target);
                else if ((a & ControlPacket.HANDOFF) != 0) tryHandoff(me, 6.0);
            }
            if (me == carrier) {
                if ((a & ControlPacket.JUKE_LEFT) != 0) me.juke(true);
                if ((a & ControlPacket.JUKE_RIGHT) != 0) me.juke(false);
            }
            if ((a & ControlPacket.TACKLE) != 0 && carrier != null && carrier.side() != side) {
                if (me.distanceTo(carrier) < 5.0) me.dive(predict(carrier, 4));
            }
        }
    }

    /** A play/coverage change before the snap re-forms the players without resetting the play clock. */
    private void setupPlayKeepingClock() {
        int t = stateTicks;
        setupPlay(false);
        stateTicks = t;
    }

    // ================================================================== AI

    private void think(FootballPlayerEntity p) {
        if (!p.canAct()) { p.stopRunning(); return; }
        Lobby.Side ballSide = ballSide();
        boolean withBall = p.side() == ballSide;

        if (kick != Kick.NONE && !kicked) { aiBeforeKick(p); return; }
        if (state == State.BALL_IN_AIR) {
            if (kick != Kick.NONE) aiKickInAir(p);
            else aiBallInAir(p, withBall);
            return;
        }
        if (p == carrier) { aiCarrier(p); return; }

        boolean developing = carrier != null && carrier.role() == Role.QB && !thrown && !handedOff && !turnover
                && !qbScramble && !pastLos(carrier) && kick == Kick.NONE;
        if (withBall) {
            if (developing) offenseAssignment(p);
            else blockFor(p);
        } else {
            if (developing) defenseAssignment(p);
            else pursue(p);
        }
    }

    private void offenseAssignment(FootballPlayerEntity p) {
        int d = dir(offense);
        switch (p.role()) {
            case OL -> passBlock(p);
            case WR, RB -> {
                if (play.run()) {
                    if (p.role() == Role.RB) { runRoute(p); return; }
                    FootballPlayerEntity cb = nearestOpponent(p, 12.0);
                    if (cb != null) p.driveTo(cb.position(), p.role().speed * 0.9);
                    else p.stopRunning();
                } else {
                    runRoute(p);
                }
            }
            default -> p.stopRunning();
        }
    }

    private void passBlock(FootballPlayerEntity p) {
        int d = dir(offense);
        FootballPlayerEntity qb = carrier;
        FootballPlayerEntity rusher = nearestOpponent(p, 7.0);
        if (rusher != null && qb != null) {
            Vec3 toQb = horiz(qb.position().subtract(rusher.position()));
            Vec3 spot = rusher.position().add(toQb.lengthSqr() > 1e-4 ? toQb.normalize().scale(0.7) : Vec3.ZERO);
            p.driveTo(spot, p.role().speed);
        } else {
            p.driveTo(g.at(losYard - d * 1.5, g.latOf(p.position()), g.floorY), p.role().speed * 0.5);
        }
    }

    /**
     * Receivers: run the route, cutting away from a defender who's right on them; when the route is done (or
     * would take them out the back of the end zone or out of bounds) they work back to open space.
     */
    private void runRoute(FootballPlayerEntity p) {
        if (p.route.isEmpty()) { getOpen(p); return; }
        if (p.routeIndex < p.route.size()) {
            Vec3 t = p.route.get(p.routeIndex);
            Vec3 to = horiz(t.subtract(p.position()));
            if (to.length() < 0.8) p.routeIndex++;
            else {
                p.drive(to.normalize().add(separation(p, 1.8).scale(0.7)), p.role().speed);
                return;
            }
        }
        if (!p.routeSettles && p.route.size() >= 2 && !nearFieldEdge(p)) {
            Vec3 a = p.route.get(p.route.size() - 2), b = p.route.get(p.route.size() - 1);
            Vec3 leg = horiz(b.subtract(a));
            if (leg.lengthSqr() > 1e-4) {
                p.drive(leg.normalize().add(separation(p, 2.2).scale(0.8)), p.role().speed * 0.85);
                return;
            }
        }
        getOpen(p);
    }

    /** Within a few yards of the back of the end zone being attacked, or of a sideline. */
    private boolean nearFieldEdge(FootballPlayerEntity p) {
        int d = dir(offense);
        double yard = g.yardOf(p.position());
        boolean nearBack = d == 1 ? yard > 106.5 : yard < -6.5;
        boolean nearSide = Math.abs(g.latOf(p.position())) > g.halfWidthYards() - 2.0;
        return nearBack || nearSide;
    }

    /**
     * Find open space: drift away from the closest defender, never out the back of the end zone, out of
     * bounds or behind the line of scrimmage. Settle (stand and wait for the ball) once nobody is close.
     */
    private void getOpen(FootballPlayerEntity p) {
        int d = dir(offense);
        FootballPlayerEntity def = nearestOpponent(p, 7.0);
        Vec3 want = Vec3.ZERO;
        if (def != null) {
            Vec3 away = horiz(p.position().subtract(def.position()));
            if (away.lengthSqr() > 1e-4) want = away.normalize();
        }
        double yard = g.yardOf(p.position()), lat = g.latOf(p.position());
        double back = d == 1 ? 108 : -8;
        if ((yard - back) * d > -1.5) want = want.add(g.worldDir(-d, 0).scale(1.5));          // back of end zone
        if (Math.abs(lat) > g.halfWidthYards() - 2.0) want = want.add(g.worldDir(0, -Math.signum(lat)).scale(1.2)); // sideline
        if ((yard - losYard) * d < 2) want = want.add(g.worldDir(d, 0));                       // stay downfield
        if (want.lengthSqr() < 0.04) { p.stopRunning(); return; }
        double close = def == null ? 99 : p.distanceTo(def);
        p.drive(want, p.role().speed * (close < 2.5 ? 1.0 : 0.6));
    }

    /** Push away from defenders within `radius` blocks (stronger the closer they are). */
    private Vec3 separation(FootballPlayerEntity p, double radius) {
        Vec3 sum = Vec3.ZERO;
        for (FootballPlayerEntity o : players) {
            if (o.side() == p.side()) continue;
            Vec3 away = horiz(p.position().subtract(o.position()));
            double dist = away.length();
            if (dist < 1e-3 || dist > radius) continue;
            sum = sum.add(away.scale(1.0 / dist).scale((radius - dist) / radius));
        }
        return sum;
    }

    private void defenseAssignment(FootballPlayerEntity p) {
        int d = dir(offense);
        TeamSkill skill = skill(p.side());
        FootballPlayerEntity qb = carrier;
        boolean blitzing = coverage == Coverage.BLITZ && (p.role() == Role.LB || (p.role() == Role.S && p.slot() == 1));
        if (p.role() == Role.DL || blitzing) {
            if (qb != null) p.driveTo(qb.position(), p.role().speed);
            return;
        }
        switch (p.role()) {
            case LB -> {
                FootballPlayerEntity threat = nearestOpponentOfRole(p, 5.0, Role.WR, Role.RB);
                Vec3 zone = g.at(losYard + d * 5, qb != null ? g.latOf(qb.position()) * 0.5 : 0, g.floorY);
                p.driveTo(threat != null ? threat.position() : zone, p.role().speed * 0.95);
            }
            case CB -> {
                FootballPlayerEntity wr = find(offense, Role.WR, p.slot());
                if (coverage == Coverage.ZONE) {
                    // Cover 2: corners own the flats on their side, then jump anything that enters.
                    double sideSign = p.slot() == 1 ? -1 : 1;
                    Vec3 zone = g.at(losYard + d * 6, sideSign * wrLat() * 0.9, g.floorY);
                    FootballPlayerEntity in = nearestOpponentOfRole(p, 6.0, Role.WR, Role.RB);
                    p.driveTo(in != null && in.position().distanceTo(zone) < 8 ? in.position() : zone, p.role().speed);
                } else if (wr != null) {
                    Vec3 target = wr.position().add(g.worldDir(d, 0).scale(skill.cushion() * g.blocksPerYard()));
                    p.driveTo(target, p.role().speed);
                } else {
                    p.stopRunning();
                }
            }
            case S -> {
                double sideSign = p.slot() == 1 ? -1 : 1;
                if (coverage == Coverage.BLITZ) sideSign = 0; // lone deep safety plays the middle
                double depth = 12;
                for (FootballPlayerEntity o : players) {
                    if (o.side() != offense || (o.role() != Role.WR && o.role() != Role.RB)) continue;
                    if (sideSign != 0 && Math.signum(g.latOf(o.position())) != sideSign) continue;
                    depth = Math.max(depth, (g.yardOf(o.position()) - losYard) * d + 4);
                }
                p.driveTo(g.at(losYard + d * depth, sideSign * g.halfWidthYards() * 0.35, g.floorY), p.role().speed);
            }
            default -> p.stopRunning();
        }
    }

    private void blockFor(FootballPlayerEntity p) {
        if (carrier == null) { p.stopRunning(); return; }
        FootballPlayerEntity threat = nearestOpponentTo(carrier, p.side(), 10.0);
        if (threat != null && p.distanceTo(threat) < 14) {
            Vec3 toCarrier = horiz(carrier.position().subtract(threat.position()));
            Vec3 between = threat.position().add(toCarrier.lengthSqr() > 1e-4 ? toCarrier.normalize().scale(0.6) : Vec3.ZERO);
            p.driveTo(between, p.role().speed);
        } else {
            p.driveTo(carrier.position().add(g.worldDir(dir(carrier.side()), 0).scale(3)), p.role().speed * 0.8);
        }
    }

    private void pursue(FootballPlayerEntity p) {
        if (carrier == null) { p.stopRunning(); return; }
        double t = Math.min(20, p.distanceTo(carrier) / Math.max(0.1, p.role().speed) * 0.5);
        p.driveTo(predict(carrier, t), p.role().speed);
    }

    private void aiCarrier(FootballPlayerEntity p) {
        if (p.role() == Role.QB && kick == Kick.NONE && !thrown && !handedOff && !turnover && !qbScramble && !pastLos(p)) {
            aiQuarterback(p);
            return;
        }
        int d = dir(p.side());
        Vec3 want = g.worldDir(d, 0);
        FootballPlayerEntity nearest = null;
        double nearestDist = 99;
        for (FootballPlayerEntity o : players) {
            if (o.side() == p.side() || !o.canAct()) continue;
            double dist = p.distanceTo(o);
            if (dist < nearestDist) { nearestDist = dist; nearest = o; }
            if (dist < 6) {
                Vec3 away = horiz(p.position().subtract(o.position()));
                if (away.lengthSqr() > 1e-4) want = want.add(away.normalize().scale(1.7 / (dist * dist + 0.4)));
            }
        }
        double lat = g.latOf(p.position()), edge = g.halfWidthYards() - 2.5;
        if (Math.abs(lat) > edge) want = want.add(g.worldDir(0, -Math.signum(lat)).scale(0.8));
        p.drive(want, p.role().speed);

        if (nearest != null && nearestDist < 1.9 && random.nextFloat() < 0.07f) {
            Vec3 toDef = horiz(nearest.position().subtract(p.position()));
            Vec3 left = new Vec3(want.z, 0, -want.x);
            p.juke(toDef.dot(left) < 0);
        }
    }

    private void aiQuarterback(FootballPlayerEntity qb) {
        int d = dir(offense);

        if (play.run()) {
            FootballPlayerEntity rb = find(offense, Role.RB, 0);
            if (rb != null) qb.driveTo(rb.position(), qb.role().speed * 0.6);
            return;
        }

        if (stateTicks < 22) {
            qb.driveTo(g.at(losYard - d * 7, 0, g.floorY), qb.role().speed * 0.8);
            return;
        }
        FootballPlayerEntity rusher = nearestOpponent(qb, 4.0);
        boolean pressured = rusher != null && qb.distanceTo(rusher) < 2.3;
        if (rusher != null) qb.drive(horiz(qb.position().subtract(rusher.position())), qb.role().speed * 0.55);
        else qb.stopRunning();

        if (stateTicks < qbHold && !pressured) return;

        FootballPlayerEntity best = null;
        double bestScore = -1;
        for (FootballPlayerEntity r : players) {
            if (r.side() != offense || (r.role() != Role.WR && r.role() != Role.RB)) continue;
            double sep = 99;
            for (FootballPlayerEntity o : players) if (o.side() != offense) sep = Math.min(sep, r.distanceTo(o));
            double downfield = (g.yardOf(r.position()) - losYard) * d;
            double score = sep + Math.max(0, Math.min(25, downfield)) * 0.12;
            if (sep > 1.4 && score > bestScore) { bestScore = score; best = r; }
        }
        if (best != null) throwTo(qb, best);
        else if (pressured && random.nextFloat() < 0.04f) qbScramble = true;
        else if (stateTicks > qbHold + 70) {
            if (random.nextBoolean()) qbScramble = true;
            else throwTo(qb, find(offense, Role.WR, 1 + random.nextInt(2)));
        }
    }

    private void aiBallInAir(FootballPlayerEntity p, boolean withBall) {
        if (withBall) {
            if (p == intendedReceiver) p.driveTo(ballAim, p.role().speed);
            else if (p.role() == Role.WR || p.role() == Role.RB) runRoute(p);
            else p.stopRunning();
            return;
        }
        TeamSkill skill = skill(p.side());
        double dist = horiz(ballAim.subtract(p.position())).length();
        if (stateTicks > skill.reaction() && dist < 18) p.driveTo(ballAim, p.role().speed);
        else defenseAssignment(p);
    }

    // ------------------------------------------------------------------ special teams AI

    private void aiBeforeKick(FootballPlayerEntity p) {
        int d = dir(offense);
        if (p == carrier) {
            // Kicker's approach: kickoff run-up, punt/FG step forward.
            double speed = kick == Kick.KICKOFF ? p.role().speed * 0.7 : 0.08;
            p.driveTo(g.at(losYard - d * (kick == Kick.KICKOFF ? 0.5 : 6), 0, g.floorY), speed);
            return;
        }
        if (kick == Kick.KICKOFF) {
            if (p.side() == offense) p.drive(g.worldDir(d, 0), p.role().speed * 0.35); // creep toward the line
            else p.stopRunning();
            return;
        }
        if (p.side() == offense) {
            if (p.role() == Role.OL || p.role() == Role.RB) passBlock(p);
            else if (kick == Kick.PUNT && p.role() == Role.WR) runRoute(p); // gunners release early
            else p.stopRunning();
        } else {
            if (p == returner) p.stopRunning();
            else if (p.role() == Role.DL || p.role() == Role.LB || (kick == Kick.FIELD_GOAL && p.role() == Role.CB)) {
                if (carrier != null) p.driveTo(carrier.position(), p.role().speed);
            } else if (kick == Kick.PUNT && p.role() == Role.CB) {
                FootballPlayerEntity gunner = find(offense, Role.WR, p.slot());
                if (gunner != null) p.driveTo(gunner.position().add(g.worldDir(d, 0).scale(1.0)), p.role().speed);
            } else {
                p.stopRunning();
            }
        }
    }

    private void aiKickInAir(FootballPlayerEntity p) {
        if (kick == Kick.FIELD_GOAL) { p.stopRunning(); return; }
        if (p.side() == offense) {
            // Coverage team sprints to where the ball will come down; the kicker trails.
            if (p.role() == Role.QB) p.driveTo(ballAim, p.role().speed * 0.5);
            else p.driveTo(ballAim, p.role().speed);
        } else if (p == returner) {
            p.driveTo(ballAim, p.role().speed);
        } else {
            FootballPlayerEntity cover = nearestOpponent(p, 30.0);
            if (cover != null) p.driveTo(cover.position(), p.role().speed * 0.9);
            else p.stopRunning();
        }
    }

    /** Defenders engaged by a blocker are slowed until they shed the block. */
    /**
     * Blocks: when a blocker meets a defender (a pass rusher, a blitzer, someone chasing the runner), the
     * defender is stopped dead for 1-2 seconds, then breaks free and can't be re-blocked for a moment so he
     * still gets a shot. Works the same on CPU defenders and the one a human controls. The blocker holds
     * his ground for the same time (unless a human is steering him).
     */
    private void applyBlocking() {
        if (state == State.BALL_IN_AIR) return; // no blocking while a pass or kick is in the air
        Lobby.Side withBall = ballSide();
        // While the QB is still looking to pass, only linemen and the running back block;
        // receivers are running routes and shouldn't freeze the corners covering them.
        boolean passDeveloping = carrier != null && carrier.role() == Role.QB && !thrown && !handedOff
                && !turnover && kick == Kick.NONE;
        for (FootballPlayerEntity def : players) {
            if (def.side() == withBall || def == carrier || !def.canBeBlocked() || def.isStunned()) continue;
            if (def.timesBlocked() >= MAX_BLOCKS_PER_DEFENDER) continue;
            for (FootballPlayerEntity blk : players) {
                if (blk.side() == def.side() || blk == carrier || blk.role() == Role.QB || !blk.canAct() || !blk.canBlock()) continue;
                if (blk.distanceTo(def) >= BLOCK_RANGE) continue;
                if (passDeveloping && blk.role() != Role.OL && blk.role() != Role.RB) continue;

                int ticks = BLOCK_MIN_TICKS + random.nextInt(BLOCK_MAX_TICKS - BLOCK_MIN_TICKS + 1);
                def.freezeByBlock(ticks, BLOCK_IMMUNE_TICKS);
                def.countBlocked();
                if (humanControlling(blk) == null) blk.freezeByBlock(ticks, 0);
                blk.startBlockerCooldown(ticks + BLOCKER_COOLDOWN_TICKS);

                Vec3 mid = def.position().add(blk.position()).scale(0.5).add(0, 1.1, 0);
                match.sound(mid, SoundEvents.SHIELD_BLOCK, 0.9f, 0.8f + random.nextFloat() * 0.3f);
                match.particles(net.minecraft.core.particles.ParticleTypes.CRIT, mid, 10, 0.25, 0.25, 0.25, 0.15);
                break;
            }
        }
    }

    /**
     * Gives the quarterback time: while he still has the ball (before a throw or handoff), defenders get a
     * slow first step off the snap, and any defender who has crossed the line of scrimmage into the
     * backfield moves slower. Applies to CPU defenders and to the defender a human controls.
     */
    private void applyRushSlowdown() {
        if (kick != Kick.NONE || carrier == null || carrier.role() != Role.QB || carrier.side() != offense
                || thrown || handedOff || turnover) return;
        int d = dir(offense);
        boolean firstStep = stateTicks < RUSH_DELAY_TICKS;
        for (FootballPlayerEntity p : players) {
            if (p.side() == offense) continue;
            boolean inBackfield = (g.yardOf(p.position()) - losYard) * d < 0;
            if (firstStep) p.slowDown(RUSH_FIRST_STEP);
            else if (inBackfield) p.slowDown(RUSH_BACKFIELD);
        }
    }

    // ================================================================== ball: passes

    private void tryHandoff(FootballPlayerEntity qb, double range) {
        FootballPlayerEntity rb = find(offense, Role.RB, 0);
        if (rb == null || qb.distanceTo(rb) > range) return;
        handedOff = true;
        setCarrier(rb);
    }

    private void throwTo(FootballPlayerEntity qb, @Nullable FootballPlayerEntity receiver) {
        if (receiver == null || ball != null) return;
        TeamSkill skill = skill(offense);
        boolean human = match.humanOf(offense) != null;
        FootballPlayerEntity rusher = nearestOpponent(qb, 3.0);
        double err = (human ? 0.35 : skill.qbError()) * (rusher != null ? 2.0 : 1.0);

        Vec3 dirToR = horiz(receiver.position().subtract(qb.position()));
        // Start the ball clear of the quarterback's body so he can't "catch" his own pass.
        Vec3 from = qb.position().add(0, 1.6, 0).add(dirToR.lengthSqr() > 1e-4 ? dirToR.normalize().scale(1.2) : Vec3.ZERO);
        // Lead the receiver, but only a few blocks: routes turn and settle, so a long straight-line lead overthrows him.
        Vec3 aim = receiver.position().add(0, 1.2, 0);
        double t = passTime(horiz(aim.subtract(from)).length());
        for (int i = 0; i < 3; i++) {
            Vec3 lead = receiver.runVelocity().scale(t * LEAD_FACTOR);
            if (lead.length() > MAX_LEAD) lead = lead.normalize().scale(MAX_LEAD);
            aim = receiver.position().add(lead).add(0, 1.2, 0);
            t = passTime(horiz(aim.subtract(from)).length());
        }
        aim = aim.add((random.nextDouble() * 2 - 1) * err, 0, (random.nextDouble() * 2 - 1) * err);
        if (!launchTimed(from, aim, passTime(horiz(aim.subtract(from)).length()))) return;
        match.sound(qb.position(), SoundEvents.ARROW_SHOOT, 0.8f, 0.7f);

        intendedReceiver = receiver;
        thrower = qb;
        thrown = true;
        setCarrier(null);
        state = State.BALL_IN_AIR;
        stateTicks = 0;
        // You stay on the quarterback while the ball is in the air; the receiver (CPU) goes up for the catch.
        UUID offenseHuman = match.humanOf(offense);
        if (offenseHuman != null) selected.put(offenseHuman, qb);
        dirty = true;
    }

    /** Flight time of a pass over a distance: a steady throwing speed, capped so deep balls don't sail too high. */
    private static double passTime(double dist) {
        return Math.max(6, Math.min(PASS_MAX_TICKS, dist / THROW_SPEED));
    }

    /** Spawns the ball flying from `from` so it passes through `aim`. Returns the flight time via kickFlight. */
    private boolean launch(Vec3 from, Vec3 aim, double speed) {
        return launchTimed(from, aim, Math.max(5, horiz(aim.subtract(from)).length() / speed));
    }

    /** Same, with the flight time given directly (ticks). */
    private boolean launchTimed(Vec3 from, Vec3 aim, double t) {
        Vec3 flat = horiz(aim.subtract(from));
        Vec3 h = flat.scale(1.0 / t);
        // Exact for the ball's tick-by-tick physics (move, then gravity), so it arrives at aim height, not above it.
        double vy = (aim.y - from.y + FootballEntity.GRAVITY * t * (t - 1) / 2) / t;
        FootballEntity fb = ModEntities.FOOTBALL.get().create(level);
        if (fb == null) return false;
        fb.moveTo(from.x, from.y, from.z, 0, 0);
        fb.setDeltaMovement(h.x, vy, h.z);
        fb.setFloorY(g.floorY);
        level.addFreshEntity(fb);
        ball = fb;
        ballAim = new Vec3(aim.x, g.floorY, aim.z);
        kickFlight = (int) Math.round(t);
        return true;
    }

    private void tickBall() {
        if (ball == null || ball.isRemoved()) { endIncomplete("Incomplete"); return; }
        if (kick != Kick.NONE) { tickKickInAir(); return; }

        Vec3 pos = ball.position();
        if (ball.isGrounded() || pos.y <= g.floorY + FootballEntity.REST_HEIGHT + 0.01 || ball.flightTicks() > 120) {
            endIncomplete("Incomplete - the pass falls to the turf");
            return;
        }
        if (Math.abs(g.latOf(pos)) > g.halfWidthYards() + 1.5) { endIncomplete("Incomplete - thrown out of bounds"); return; }

        FootballPlayerEntity best = null;
        double bestDist = 99;
        for (FootballPlayerEntity p : players) {
            if (p == thrower) continue; // the passer can't catch his own throw
            if (p.side() == offense && (p.role() == Role.OL || p.role() == Role.QB)) continue; // ineligible
            if (!touchesBall(p, 1.0)) continue; // catch reach around the body (was 0.45)
            double dist = p.position().add(0, 1.0, 0).distanceTo(pos);
            if (dist < bestDist) { bestDist = dist; best = p; }
        }
        if (best == null) return;

        if (best.side() == offense) {
            boolean contested = false;
            for (FootballPlayerEntity o : players) if (o.side() != offense && o.distanceTo(best) < 1.6) contested = true;
            if (random.nextFloat() < (contested ? 0.75f : 0.97f)) catchBall(best, false);
            else endIncomplete("Dropped by #" + best.number() + "!");
        } else {
            double intChance = humanControlling(best) != null ? 0.45 : skill(best.side()).intercept();
            if (random.nextFloat() < intChance) catchBall(best, true);
            else endIncomplete("Broken up by #" + best.number() + "!");
        }
    }

    private void catchBall(FootballPlayerEntity p, boolean interception) {
        if (ball != null) ball.discard();
        ball = null;
        setCarrier(p);
        state = State.LIVE;
        stateTicks = 0;
        if (interception) {
            turnover = true;
            match.turnover();
            match.title(Component.literal("INTERCEPTED!").withStyle(ChatFormatting.RED, ChatFormatting.BOLD),
                    Component.literal("Picked off by #" + p.number()));
            match.sound(p.position(), SoundEvents.ANVIL_LAND, 0.5f, 1.6f);
        } else {
            completed = true;
            match.sound(p.position(), SoundEvents.ITEM_PICKUP, 1f, 0.8f);
        }
        dirty = true;
    }

    // ================================================================== ball: kicks

    private void kickBall(FootballPlayerEntity kicker) {
        int d = dir(offense);
        Lobby.Side recv = offense.opposite();
        double recvGoal = goalLineOf(recv);
        Vec3 from = kicker.position().add(0, 0.4, 0);
        Vec3 aim;
        double speed;

        switch (kick) {
            case KICKOFF -> {
                double fromGoal = -4 + random.nextDouble() * 16; // negative = lands in the end zone
                double lat = (random.nextDouble() * 2 - 1) * g.halfWidthYards() * 0.4;
                aim = g.at(recvGoal - d * fromGoal, lat, g.floorY + 1.4);
                speed = 0.9;
            }
            case PUNT -> {
                double dist = 40 + (random.nextDouble() * 16 - 8);
                double landing = losYard + d * dist;
                double maxDeep = recvGoal + d * 8;
                if (d == 1 ? landing > maxDeep : landing < maxDeep) landing = maxDeep;
                double lat = (random.nextDouble() * 2 - 1) * g.halfWidthYards() * 0.35;
                aim = g.at(landing, lat, g.floorY + 1.4);
                speed = 0.72;
            }
            default -> { // FIELD_GOAL
                double distance = fieldGoalDistance();
                kickGood = random.nextFloat() < fieldGoalChance(distance);
                double endLine = goalLineOf(recv) + d * 10;
                double halfGap = 3.08 * 0.85;
                double lat = kickGood ? (random.nextDouble() * 2 - 1) * halfGap
                        : (random.nextBoolean() ? 1 : -1) * (3.6 + random.nextDouble() * 2.5);
                double over = kickGood ? 1.5 + random.nextDouble() * 2 : 0.5 + random.nextDouble() * 2;
                aim = g.at(endLine, lat, g.floorY + crossbarHeight() + over);
                speed = 0.85;
                match.notifySide(offense, Component.literal(Math.round(distance) + "-yard attempt...").withStyle(ChatFormatting.GRAY));
            }
        }
        if (!launch(from, aim, speed)) return;
        if (kick == Kick.FIELD_GOAL) ballAim = aim; // keep the height for the result check
        match.sound(kicker.position(), SoundEvents.PLAYER_ATTACK_STRONG, 1.2f, 0.6f);
        kicked = true;
        setCarrier(null);
        state = State.BALL_IN_AIR;
        stateTicks = 0;
        for (UUID h : match.humans()) {
            if (match.sideOf(h) == recv && returner != null) selected.put(h, returner);
        }
        dirty = true;
    }

    private void tickKickInAir() {
        Vec3 pos = ball.position();
        Lobby.Side recv = offense.opposite();
        int d = dir(offense);

        if (kick == Kick.FIELD_GOAL) {
            if (ball.flightTicks() >= kickFlight) resolveFieldGoal();
            return;
        }

        // Any receiving-team player under it (or running over it once it's loose) fields the kick.
        for (FootballPlayerEntity p : players) {
            if (p.side() != recv) continue;
            boolean fielded = looseBall ? horiz(p.position().subtract(pos)).length() < 1.3 : touchesBall(p, 1.0);
            if (!fielded) continue;
            ball.discard();
            ball = null;
            looseBall = false;
            setCarrier(p);
            turnover = true;
            match.turnover();
            state = State.LIVE;
            stateTicks = 0;
            match.sound(p.position(), SoundEvents.ITEM_PICKUP, 1f, 0.8f);
            dirty = true;
            return;
        }

        if (!looseBall && (ball.isGrounded() || pos.y <= g.floorY + FootballEntity.REST_HEIGHT + 0.01 || ball.flightTicks() > 250)) {
            double landing = g.yardOf(pos);
            double recvGoal = goalLineOf(recv);
            boolean inEndZone = d == 1 ? landing >= recvGoal : landing <= recvGoal;
            boolean outOfBounds = Math.abs(g.latOf(pos)) > g.halfWidthYards();
            if (inEndZone || outOfBounds) {
                kickDead(landing, inEndZone);
                return;
            }
            // Live ball on the turf: the receiving team can scoop it up and return it.
            looseBall = true;
            looseTicks = 0;
            ball.land(g.floorY);
            ballAim = ball.position();
            for (UUID h : match.humans()) {
                if (match.sideOf(h) == recv) {
                    FootballPlayerEntity n = nearestToBall(recv);
                    if (n != null) selected.put(h, n);
                }
            }
            dirty = true;
            return;
        }

        if (looseBall) {
            looseTicks++;
            // The kicking team touching it first, or nobody getting to it, downs it where it lies.
            for (FootballPlayerEntity p : players) {
                if (p.side() == recv || p.role() == Role.QB) continue;
                if (horiz(p.position().subtract(pos)).length() < 1.0) { kickDead(g.yardOf(pos), false); return; }
            }
            if (looseTicks > 100) kickDead(g.yardOf(pos), false);
        }
    }

    /** Ends a kick that nobody returned: touchback, or downed where it stopped. */
    private void kickDead(double yard, boolean touchback) {
        Lobby.Side recv = offense.opposite();
        match.turnover();
        turnover = true;
        looseBall = false;
        setCarrier(null);
        if (touchback) {
            double spot = ownYard(recv, kick == Kick.KICKOFF ? 25 : 20);
            finish(new PlayResult(PlayResult.Kind.TOUCHBACK, spot, true, 0, "Touchback", offense, Playbook.Type.PUNT, false, false));
        } else {
            double spot = Math.max(1, Math.min(99, yard));
            finish(new PlayResult(PlayResult.Kind.TACKLE, spot, true, 0,
                    "Kick downed at " + FootballMatch.yardLabel(spot), offense, Playbook.Type.PUNT, false, false));
        }
    }

    /**
     * True if the ball passed through (or is inside) this player's body this tick, widened by `reach`.
     * Sweeps the ball's path so a fast ball can't skip past a player between two ticks.
     */
    private boolean touchesBall(FootballPlayerEntity p, double reach) {
        if (ball == null) return false;
        net.minecraft.world.phys.AABB box = p.getBoundingBox().inflate(reach);
        Vec3 now = ball.position(), before = ball.previousPos();
        return box.contains(now) || box.clip(before, now).isPresent();
    }

    private void resolveFieldGoal() {
        if (kickGood) {
            match.sound(ball.position(), SoundEvents.FIREWORK_ROCKET_TWINKLE, 1.5f, 1f);
            sparkle(ball.position(), 30);
            finish(new PlayResult(PlayResult.Kind.FIELD_GOAL, losYard, false, 0, "The kick is GOOD!", offense, Playbook.Type.FIELD_GOAL, false, false));
        } else {
            finish(new PlayResult(PlayResult.Kind.FIELD_GOAL_MISSED, losYard, true, 0, "The kick is NO GOOD.", offense, Playbook.Type.FIELD_GOAL, false, false));
        }
    }

    private double fieldGoalDistance() {
        return Math.abs(goalLineOf(offense.opposite()) - losYard) + 17;
    }

    private static double fieldGoalChance(double yards) {
        if (yards <= 30) return 0.97;
        if (yards <= 40) return 0.9;
        if (yards <= 45) return 0.82;
        if (yards <= 50) return 0.7;
        if (yards <= 55) return 0.5;
        if (yards <= 60) return 0.3;
        return 0.1;
    }

    private double crossbarHeight() {
        return Math.max(2.5, 3.33 * g.blocksPerYard());
    }

    // ================================================================== whistles

    private void checkCarrier() {
        if (carrier == null) return;
        Vec3 pos = carrier.position();
        double yard = g.yardOf(pos);
        int d = dir(carrier.side());

        if (d == 1 ? yard >= 100 : yard <= 0) { endPlay(PlayResult.Kind.TOUCHDOWN, yard, "TOUCHDOWN"); return; }
        if (Math.abs(g.latOf(pos)) > g.halfWidthYards()) { endPlay(PlayResult.Kind.OUT_OF_BOUNDS, yard, "Out of bounds"); return; }
        if (d == 1 ? yard < -10 : yard > 110) { endPlay(PlayResult.Kind.OUT_OF_BOUNDS, yard, "Out of the back of the end zone"); return; }

        // Pocket time: right after the snap a quarterback who still has the ball can't be brought down.
        boolean pocketGrace = kick == Kick.NONE && carrier.role() == Role.QB && carrier.side() == offense
                && !thrown && !handedOff && !turnover && stateTicks < SACK_GRACE_TICKS;
        if (pocketGrace) return;

        for (FootballPlayerEntity o : players) {
            if (o.side() == carrier.side() || o.isStunned() || o.isBlockFrozen()) continue;
            double dist = horiz(o.position().subtract(pos)).length();
            if (Math.abs(o.getY() - carrier.getY()) > 1.6) continue;
            boolean diving = o.isDiving();
            if (dist > (diving ? DIVE_TACKLE_RANGE : TACKLE_RANGE)) continue;

            double chance = diving ? 0.85 : (humanControlling(o) != null ? 0.35 : skill(o.side()).tackle());
            if (carrier.isJuking()) chance *= 0.3;
            if (carrier.isHurdling()) chance *= diving ? 0.2 : 0.4;

            if (random.nextFloat() < chance) {
                o.clearMoves();
                carrier.stun(30);
                match.sound(pos, SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1f, 0.7f);
                endPlay(PlayResult.Kind.TACKLE, yard, "Tackled by #" + o.number());
                return;
            }
            if (carrier.isJuking() || carrier.isHurdling() || diving) o.stun(16); // broken tackle
        }
    }

    private void endIncomplete(String text) {
        if (ball != null) ball.discard();
        ball = null;
        setCarrier(null);
        finish(new PlayResult(PlayResult.Kind.INCOMPLETE, losYard, false, 0, text, offense, Playbook.Type.PASS, false, false));
    }

    private void endPlay(PlayResult.Kind kind, double yard, String how) {
        Lobby.Side ballSide = carrier != null ? carrier.side() : offense;
        int dB = dir(ballSide);
        boolean inOwnEndZone = dB == 1 ? yard <= 0 : yard >= 100;
        double spot = yard;
        if ((kind == PlayResult.Kind.TACKLE || kind == PlayResult.Kind.OUT_OF_BOUNDS) && inOwnEndZone) {
            kind = turnover ? PlayResult.Kind.TOUCHBACK : PlayResult.Kind.SAFETY;
            if (turnover) spot = ownYard(ballSide, 20);
        }

        double gained = (yard - losYard) * dir(offense);
        boolean sack = !turnover && kick == Kick.NONE && carrier != null && carrier.role() == Role.QB && !thrown && gained < 0;
        String text;
        if (kind == PlayResult.Kind.TOUCHDOWN) text = "TOUCHDOWN!";
        else if (kind == PlayResult.Kind.SAFETY) text = "SAFETY!";
        else if (kind == PlayResult.Kind.TOUCHBACK) text = "Touchback";
        else if (turnover) text = how + " - return to " + FootballMatch.yardLabel(yard);
        else if (sack) text = "SACK! Loss of " + Math.round(-gained);
        else text = how + " - " + (Math.round(gained) == 0 ? "no gain" : gained > 0 ? "gain of " + Math.round(gained) : "loss of " + Math.round(-gained));

        if (kind == PlayResult.Kind.TOUCHDOWN && carrier != null) {
            match.sound(carrier.position(), SoundEvents.FIREWORK_ROCKET_LARGE_BLAST, 2f, 1f);
            match.sound(carrier.position(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            sparkle(carrier.position(), 80);
            Vec3 ez = g.at(goalLineOf(carrier.side().opposite()) + dB * 5, 0, g.floorY);
            sparkle(ez, 60);
        }
        Playbook.Type type = kick != Kick.NONE ? Playbook.Type.PUNT : (thrown || completed) ? Playbook.Type.PASS : Playbook.Type.RUN;
        finish(new PlayResult(kind, spot, turnover, gained, text, offense, type, completed, sack));
    }

    /** Whistle: the play is dead. */
    private void finish(PlayResult result) {
        if (ball != null) ball.discard();
        ball = null;
        showLabels(false);
        state = State.DEAD;
        stateTicks = 0;
        Vec3 at = carrier != null ? carrier.position() : ballAim;
        match.sound(at, SoundEvents.NOTE_BLOCK_FLUTE.value(), 1.2f, 2.0f);
        match.applyResult(result);
        dirty = true;
    }

    private void sparkle(Vec3 at, int count) {
        match.particles(ParticleTypes.FIREWORK, at.add(0, 1.5, 0), count, 1.2, 1.8, 1.2, 0.12);
        match.particles(ParticleTypes.TOTEM_OF_UNDYING, at.add(0, 1.0, 0), count / 2, 1.0, 1.0, 1.0, 0.3);
    }

    // ================================================================== helpers

    private void setCarrier(@Nullable FootballPlayerEntity p) {
        for (FootballPlayerEntity e : players) {
            if (e != p && !e.getMainHandItem().isEmpty()) e.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        }
        carrier = p;
        if (p != null) p.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.FOOTBALL.get()));
        dirty = true;
    }

    private Lobby.Side ballSide() {
        if (carrier != null) return carrier.side();
        if (state == State.BALL_IN_AIR) return offense;
        return match.possession();
    }

    private TeamSkill skill(Lobby.Side side) {
        FootballMatch.Participant part = match.participant(side);
        return part != null && part.isCpu() ? part.cpu().skill() : TeamSkill.HUMAN_TEAM;
    }

    private static int dir(Lobby.Side side) {
        return side == Lobby.Side.HOME ? 1 : -1;
    }

    /** Yard line of the goal a side defends. */
    private static double goalLineOf(Lobby.Side side) {
        return side == Lobby.Side.HOME ? 0 : 100;
    }

    /** "Own N yard line" for a side, as a field yard. */
    private static double ownYard(Lobby.Side side, double n) {
        return side == Lobby.Side.HOME ? n : 100 - n;
    }

    private boolean pastLos(FootballPlayerEntity p) {
        return (g.yardOf(p.position()) - losYard) * dir(offense) > 0.5;
    }

    @Nullable
    private FootballPlayerEntity find(Lobby.Side side, Role role, int slot) {
        for (FootballPlayerEntity p : players) if (p.side() == side && p.role() == role && p.slot() == slot) return p;
        return null;
    }

    @Nullable
    private FootballPlayerEntity nearestOpponent(FootballPlayerEntity p, double max) {
        return nearestOpponentTo(p, p.side(), max);
    }

    /** Nearest player NOT on `side` to `to`. */
    @Nullable
    private FootballPlayerEntity nearestOpponentTo(FootballPlayerEntity to, Lobby.Side side, double max) {
        FootballPlayerEntity best = null;
        double bd = max;
        for (FootballPlayerEntity o : players) {
            if (o.side() == side) continue;
            double dd = o.distanceTo(to);
            if (dd < bd) { bd = dd; best = o; }
        }
        return best;
    }

    @Nullable
    private FootballPlayerEntity nearestOpponentOfRole(FootballPlayerEntity p, double max, Role... roles) {
        FootballPlayerEntity best = null;
        double bd = max;
        for (FootballPlayerEntity o : players) {
            if (o.side() == p.side()) continue;
            boolean ok = false;
            for (Role r : roles) if (o.role() == r) ok = true;
            if (!ok) continue;
            double dd = o.distanceTo(p);
            if (dd < bd) { bd = dd; best = o; }
        }
        return best;
    }

    @Nullable
    private FootballPlayerEntity nearestToBall(Lobby.Side side) {
        Vec3 at = carrier != null ? carrier.position() : ball != null ? ballAim : g.at(losYard, 0, g.floorY);
        FootballPlayerEntity best = null;
        double bd = Double.MAX_VALUE;
        for (FootballPlayerEntity p : players) {
            if (p.side() != side) continue;
            double dd = p.position().distanceToSqr(at);
            if (dd < bd) { bd = dd; best = p; }
        }
        return best;
    }

    /**
     * Next player to control on a switch: the teammate nearest the ball that you haven't already stepped
     * through, so pressing repeatedly walks through the whole team, closest first. Pause for 3 seconds and it
     * starts again from the closest.
     */
    @Nullable
    private FootballPlayerEntity nextSelectable(UUID human, Lobby.Side side, @Nullable FootballPlayerEntity current) {
        Vec3 at = carrier != null ? carrier.position() : ball != null ? ballAim : g.at(losYard, 0, g.floorY);
        List<FootballPlayerEntity> mine = new ArrayList<>();
        for (FootballPlayerEntity p : players) if (p.side() == side && !p.isRemoved()) mine.add(p);
        if (mine.isEmpty()) return null;
        mine.sort(java.util.Comparator.comparingDouble(p -> p.position().distanceToSqr(at)));

        java.util.Set<FootballPlayerEntity> visited = switchVisited.computeIfAbsent(human, k -> new java.util.HashSet<>());
        Integer last = lastSwitchAt.get(human);
        if (last == null || engineTicks - last > 60) visited.clear();
        lastSwitchAt.put(human, engineTicks);
        if (current != null) visited.add(current);
        visited.removeIf(p -> p.isRemoved() || !players.contains(p));

        for (FootballPlayerEntity p : mine) if (!visited.contains(p)) { visited.add(p); return p; }
        // Been through everyone: start over from the closest (other than the one you're on).
        visited.clear();
        if (current != null) visited.add(current);
        for (FootballPlayerEntity p : mine) if (p != current) { visited.add(p); return p; }
        return current;
    }

    private Vec3 predict(FootballPlayerEntity p, double ticks) {
        return p.position().add(p.runVelocity().scale(ticks));
    }

    private void showLabels(boolean show) {
        if (labelsShown != show) dirty = true;
        labelsShown = show;
        // The quarterback's player sees 1 / 2 / 3 icons over the receivers (drawn client-side by
        // FootballPlayerRenderer from the pass targets in MatchStatePacket), so no name tags are needed.
    }

    private void buildRoute(@Nullable FootballPlayerEntity p, Playbook.Route route, int d) {
        if (p == null) return;
        p.route.clear();
        p.routeIndex = 0;
        p.routeSettles = route.settles();
        double y0 = g.yardOf(p.position()), lat0 = g.latOf(p.position());
        double out = lat0 >= 0 ? 1 : -1;
        double edge = g.halfWidthYards() - 1.0;
        // Never route anyone past the back of the end zone (deep routes end up to 1.5 yards inside it).
        double backLimit = d == 1 ? 108.5 : -8.5;
        for (Playbook.Pt pt : route.points()) {
            double lat = Math.max(-edge, Math.min(edge, lat0 + out * pt.out()));
            double yard = y0 + d * pt.down();
            yard = d == 1 ? Math.min(yard, backLimit) : Math.max(yard, backLimit);
            p.route.add(g.at(yard, lat, g.floorY));
        }
    }

    private void prepareRoutes() {
        int d = dir(offense);
        buildRoute(find(offense, Role.WR, 1), play.wr1(), d);
        buildRoute(find(offense, Role.WR, 2), play.wr2(), d);
        buildRoute(find(offense, Role.RB, 0), play.rb(), d);
    }

    private static Vec3 horiz(Vec3 v) {
        return new Vec3(v.x, 0, v.z);
    }
}
