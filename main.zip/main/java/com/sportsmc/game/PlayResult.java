package com.sportsmc.game;

import com.sportsmc.lobby.Lobby;

/**
 * How a play ended.
 *
 * @param spotYard  where the ball is dead / next snap (yards from HOME's goal line); for TOUCHBACK the new spot
 * @param turnover  possession changed during the play (interception, or a kick received)
 * @param gained    yards gained by the team that snapped it (negative = loss)
 * @param text      play-by-play line, e.g. "Gain of 7" or "SACK! Loss of 4"
 * @param offense   team that snapped the ball (for stats)
 * @param playType  what kind of play it was (for stats)
 * @param completed a pass that was caught by the offense
 * @param sack      QB tackled behind the line before throwing
 */
public record PlayResult(Kind kind, double spotYard, boolean turnover, double gained, String text,
                         Lobby.Side offense, Playbook.Type playType, boolean completed, boolean sack) {

    public enum Kind { TACKLE, OUT_OF_BOUNDS, INCOMPLETE, TOUCHDOWN, SAFETY, TOUCHBACK, FIELD_GOAL, FIELD_GOAL_MISSED }
}
