package com.sportsmc.server;

import com.sportsmc.SportsMC;
import com.sportsmc.lobby.LobbyManager;
import com.sportsmc.match.MatchManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Forge-bus events that run on both the integrated (singleplayer/LAN) and dedicated server. */
@Mod.EventBusSubscriber(modid = SportsMC.MODID)
public final class ServerEvents {

    private ServerEvents() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        SportsCommands.register(event.getDispatcher());
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        long t0 = System.nanoTime();
        try {
            LobbyManager.get().tick();
        } catch (Exception e) {
            SportsMC.LOGGER.error("SportsMC: error in the lobby tick (ignored so the server keeps running)", e);
        }
        com.sportsmc.debug.SportsDebug.add(com.sportsmc.debug.SportsDebug.Part.LOBBY, System.nanoTime() - t0);
        var server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        MatchManager.get().tick(server); // guards and times each match itself
        com.sportsmc.debug.SportsDebug.endTick(server);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) LobbyManager.get().onLogin(sp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) LobbyManager.get().onLogout(sp);
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        MatchManager.get().stopAll();
    }

    /** Singleplayer worlds reuse the JVM, so wipe state between worlds. */
    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        MatchManager.get().reset();
        LobbyManager.get().reset();
        com.sportsmc.debug.SportsDebug.reset();
    }
}
