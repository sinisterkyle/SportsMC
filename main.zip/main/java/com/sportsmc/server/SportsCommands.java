package com.sportsmc.server;

import com.sportsmc.lobby.Difficulty;
import com.sportsmc.lobby.Lobby;
import com.sportsmc.lobby.LobbyManager;
import com.sportsmc.match.FootballMatch;
import com.sportsmc.match.MatchManager;
import com.sportsmc.field.FieldData;
import com.sportsmc.field.FieldRegistry;
import com.sportsmc.field.FieldService;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.ChatFormatting;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.Arrays;
import java.util.List;

/**
 * /sportsmc ... - mirrors every hub button so everything is testable from chat,
 * and backs the clickable [ACCEPT]/[DECLINE] invite message.
 */
public final class SportsCommands {

    private SportsCommands() {}

    /** Operators, or the host of a singleplayer / LAN world. */
    private static boolean canDebug(CommandSourceStack s) {
        if (s.hasPermission(2)) return true;
        ServerPlayer p = s.getPlayer();
        return p != null && s.getServer().isSingleplayerOwner(p.getGameProfile());
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        LobbyManager lm = LobbyManager.get();

        com.mojang.brigadier.tree.LiteralCommandNode<CommandSourceStack> root = dispatcher.register(Commands.literal("sportsmc")
                .then(Commands.literal("create").executes(ctx -> {
                    lm.createLobby(ctx.getSource().getPlayerOrException());
                    return 1;
                })
                        .then(Commands.literal("football").executes(ctx -> {
                            lm.createLobby(ctx.getSource().getPlayerOrException(), com.sportsmc.lobby.Sport.FOOTBALL);
                            return 1;
                        }))
                        .then(Commands.literal("tennis").executes(ctx -> {
                            lm.createLobby(ctx.getSource().getPlayerOrException(), com.sportsmc.lobby.Sport.TENNIS);
                            return 1;
                        }))
                        .then(Commands.literal("airhockey").executes(ctx -> {
                            lm.createLobby(ctx.getSource().getPlayerOrException(), com.sportsmc.lobby.Sport.AIR_HOCKEY);
                            return 1;
                        }))
                        .then(Commands.literal("cards").executes(ctx -> {
                            lm.createLobby(ctx.getSource().getPlayerOrException(), com.sportsmc.lobby.Sport.CARD_DOJO);
                            return 1;
                        }))
                        .then(Commands.literal("bowling").executes(ctx -> {
                            lm.createLobby(ctx.getSource().getPlayerOrException(), com.sportsmc.lobby.Sport.BOWLING);
                            return 1;
                        })))
                .then(Commands.literal("invite")
                        .then(Commands.argument("player", EntityArgument.player()).executes(ctx -> {
                            lm.invite(ctx.getSource().getPlayerOrException(), EntityArgument.getPlayer(ctx, "player"));
                            return 1;
                        })))
                .then(Commands.literal("accept")
                        .then(Commands.argument("host", EntityArgument.player()).executes(ctx -> {
                            lm.acceptInviteFromHost(ctx.getSource().getPlayerOrException(), EntityArgument.getPlayer(ctx, "host"));
                            return 1;
                        })))
                .then(Commands.literal("debug").requires(SportsCommands::canDebug)
                        .executes(ctx -> {
                            for (Component line : com.sportsmc.debug.SportsDebug.report(ctx.getSource().getServer(), true)) {
                                ctx.getSource().sendSystemMessage(line);
                            }
                            return 1;
                        })
                        .then(Commands.literal("watch").executes(ctx -> {
                            boolean on = com.sportsmc.debug.SportsDebug.toggleWatch(ctx.getSource().getPlayerOrException().getUUID());
                            ctx.getSource().sendSystemMessage(Component.literal(on
                                    ? "[SportsMC debug] Live line on your action bar (and slow-tick alerts in chat). Run again to stop."
                                    : "[SportsMC debug] Stopped watching.").withStyle(ChatFormatting.AQUA));
                            return 1;
                        }))
                        .then(Commands.literal("log").executes(ctx -> {
                            boolean on = com.sportsmc.debug.SportsDebug.toggleConsoleLog();
                            ctx.getSource().sendSystemMessage(Component.literal(on
                                    ? "[SportsMC debug] Writing a summary to the server console/log every 30 s. Run again to stop."
                                    : "[SportsMC debug] Console summaries off.").withStyle(ChatFormatting.AQUA));
                            return 1;
                        }))
                        .then(Commands.literal("cleanup").executes(ctx -> {
                            int n = com.sportsmc.debug.EntityCensus.cleanup(ctx.getSource().getServer());
                            ctx.getSource().sendSystemMessage(Component.literal("[SportsMC debug] Removed " + n
                                    + " leftover SportsMC entities (ones no running match owns).").withStyle(ChatFormatting.AQUA));
                            return n;
                        })))
                .then(Commands.literal("decline").executes(ctx -> {
                    lm.declineInvite(ctx.getSource().getPlayerOrException(), null);
                    return 1;
                }))
                .then(Commands.literal("leave").executes(ctx -> {
                    lm.leave(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("ready").executes(ctx -> {
                    lm.toggleReady(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("start").executes(ctx -> {
                    lm.startMatch(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("cpu")
                        .executes(ctx -> {
                            lm.startCpuMatch(ctx.getSource().getPlayerOrException(), Difficulty.PRO, null);
                            return 1;
                        })
                        .then(Commands.argument("difficulty", StringArgumentType.word())
                                .suggests((ctx, b) -> SharedSuggestionProvider.suggest(
                                        Arrays.stream(Difficulty.values()).map(Difficulty::key), b))
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    Difficulty d = Difficulty.byKey(StringArgumentType.getString(ctx, "difficulty"));
                                    if (d == null) {
                                        ctx.getSource().sendFailure(Component.literal("Unknown difficulty. Use rookie, pro, all_pro or legend."));
                                        return 0;
                                    }
                                    lm.startCpuMatch(p, d, null);
                                    return 1;
                                })))
                // Saved fields (built with the Field Blueprint).
                .then(Commands.literal("field")
                        .then(Commands.literal("list").executes(ctx -> {
                            List<FieldData> fields = FieldRegistry.get(ctx.getSource().getServer()).all();
                            if (fields.isEmpty()) {
                                ctx.getSource().sendSuccess(() -> Component.literal("No fields yet - craft a Field Blueprint (paper + green dye + white dye).").withStyle(ChatFormatting.YELLOW), false);
                                return 0;
                            }
                            for (FieldData f : fields) {
                                String busy = MatchManager.get().isFieldInUse(f.id()) ? " [in use]" : "";
                                ctx.getSource().sendSuccess(() -> Component.literal("- " + f.name() + busy + " [" + f.type().displayName + "]: " + f.geometry().summary()
                                        + " in " + f.dimension() + ", by " + f.creatorName()).withStyle(ChatFormatting.AQUA), false);
                            }
                            return fields.size();
                        }))
                        .then(Commands.literal("select").then(fieldArg().executes(ctx -> {
                            FieldData f = field(ctx);
                            if (f == null) return 0;
                            lm.selectField(ctx.getSource().getPlayerOrException(), f.id());
                            return 1;
                        })))
                        .then(Commands.literal("tp").then(fieldArg().executes(ctx -> {
                            FieldData f = field(ctx);
                            if (f == null) return 0;
                            FieldService.teleport(ctx.getSource().getPlayerOrException(), f.id());
                            return 1;
                        })))
                        .then(Commands.literal("delete").then(fieldArg().executes(ctx -> {
                            FieldData f = field(ctx);
                            if (f == null) return 0;
                            FieldService.delete(ctx.getSource().getPlayerOrException(), f.id());
                            return 1;
                        }))))
                // Debug helpers for testing the match shell (op only).
                .then(Commands.literal("debug").requires(src -> src.hasPermission(2))
                        .then(Commands.literal("score")
                                .then(Commands.argument("side", StringArgumentType.word())
                                        .suggests((ctx, b) -> SharedSuggestionProvider.suggest(new String[]{"home", "away"}, b))
                                        .then(Commands.argument("points", IntegerArgumentType.integer(1, 8)).executes(ctx -> {
                                            FootballMatch match = currentMatch(ctx.getSource().getPlayerOrException());
                                            if (match == null) {
                                                ctx.getSource().sendFailure(Component.literal("You're not in a match."));
                                                return 0;
                                            }
                                            Lobby.Side side = StringArgumentType.getString(ctx, "side").equalsIgnoreCase("away")
                                                    ? Lobby.Side.AWAY : Lobby.Side.HOME;
                                            match.addScore(side, IntegerArgumentType.getInteger(ctx, "points"));
                                            return 1;
                                        }))))
                        .then(Commands.literal("snap").executes(ctx -> {
                            FootballMatch match = currentMatch(ctx.getSource().getPlayerOrException());
                            if (match == null) {
                                ctx.getSource().sendFailure(Component.literal("You're not in a match."));
                                return 0;
                            }
                            match.snap();
                            return 1;
                        }))
                        .then(Commands.literal("endplay")
                                .then(Commands.argument("yards", IntegerArgumentType.integer(-99, 99)).executes(ctx -> {
                                    FootballMatch match = currentMatch(ctx.getSource().getPlayerOrException());
                                    if (match == null) {
                                        ctx.getSource().sendFailure(Component.literal("You're not in a match."));
                                        return 0;
                                    }
                                    match.endPlay(IntegerArgumentType.getInteger(ctx, "yards"));
                                    return 1;
                                })))
                        .then(Commands.literal("endmatch").executes(ctx -> {
                            FootballMatch match = currentMatch(ctx.getSource().getPlayerOrException());
                            if (match == null) {
                                ctx.getSource().sendFailure(Component.literal("You're not in a match."));
                                return 0;
                            }
                            match.finish(null);
                            return 1;
                        }))));

        // Shortcut: /football invite <player>, /football cpu, ... (same as /sportsmc ...).
        dispatcher.register(Commands.literal("football").redirect(root));
    }

    private static RequiredArgumentBuilder<CommandSourceStack, String> fieldArg() {
        return Commands.argument("name", StringArgumentType.greedyString())
                .suggests((ctx, b) -> SharedSuggestionProvider.suggest(
                        FieldRegistry.get(ctx.getSource().getServer()).all().stream().map(FieldData::name), b));
    }

    private static FieldData field(CommandContext<CommandSourceStack> ctx) {
        String name = StringArgumentType.getString(ctx, "name");
        FieldData f = FieldRegistry.get(ctx.getSource().getServer()).byName(name);
        if (f == null) ctx.getSource().sendFailure(Component.literal("No field named \"" + name + "\". Try /sportsmc field list"));
        return f;
    }

    private static FootballMatch currentMatch(ServerPlayer player) {
        Lobby lobby = LobbyManager.get().lobbyOf(player.getUUID());
        return lobby != null && MatchManager.get().matchFor(lobby) instanceof FootballMatch fm ? fm : null;
    }
}
