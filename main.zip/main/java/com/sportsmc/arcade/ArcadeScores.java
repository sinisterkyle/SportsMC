package com.sportsmc.arcade;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** The server's top-10 board for each arcade game (data/sportsmc_arcade.dat in the overworld). */
public class ArcadeScores extends SavedData {

    private static final String DATA_NAME = "sportsmc_arcade";
    public static final int TOP = 10;
    /** Scores above this are rejected as impossible. */
    public static final int MAX_SCORE = 50_000_000;

    public record Entry(UUID player, String name, int score) {}

    private final Map<ArcadeGame, List<Entry>> boards = new EnumMap<>(ArcadeGame.class);

    public ArcadeScores() {
        for (ArcadeGame g : ArcadeGame.values()) boards.put(g, new ArrayList<>());
    }

    public static ArcadeScores get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(ArcadeScores::load, ArcadeScores::new, DATA_NAME);
    }

    public List<Entry> board(ArcadeGame game) {
        return List.copyOf(boards.get(game));
    }

    /**
     * Records a score. Each player keeps only their best on a board. Returns the new rank (1 = top) if it made
     * the board, or 0 if it didn't.
     */
    public int submit(ArcadeGame game, UUID player, String name, int score) {
        if (score <= 0 || score > MAX_SCORE) return 0;
        List<Entry> list = boards.get(game);
        for (Entry e : list) {
            if (e.player().equals(player) && e.score() >= score) return 0; // not a personal best
        }
        list.removeIf(e -> e.player().equals(player));
        list.add(new Entry(player, name, score));
        list.sort((a, b) -> Integer.compare(b.score(), a.score()));
        while (list.size() > TOP) list.remove(list.size() - 1);
        setDirty();
        for (int i = 0; i < list.size(); i++) if (list.get(i).player().equals(player)) return i + 1;
        return 0;
    }

    public static ArcadeScores load(CompoundTag tag) {
        ArcadeScores s = new ArcadeScores();
        for (ArcadeGame g : ArcadeGame.values()) {
            ListTag list = tag.getList(g.name(), Tag.TAG_COMPOUND);
            for (int i = 0; i < list.size(); i++) {
                CompoundTag e = list.getCompound(i);
                try {
                    s.boards.get(g).add(new Entry(e.getUUID("id"), e.getString("name"), e.getInt("score")));
                } catch (Exception ignored) {
                    // skip a damaged entry
                }
            }
        }
        return s;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        for (Map.Entry<ArcadeGame, List<Entry>> b : boards.entrySet()) {
            ListTag list = new ListTag();
            for (Entry e : b.getValue()) {
                CompoundTag t = new CompoundTag();
                t.putUUID("id", e.player());
                t.putString("name", e.name());
                t.putInt("score", e.score());
                list.add(t);
            }
            tag.put(b.getKey().name(), list);
        }
        return tag;
    }
}
