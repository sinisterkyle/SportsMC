package com.sportsmc.arcade;

/**
 * The games in the Arcade. They run entirely on the player's own screen (no server work, no lag); only
 * scores go to the server, for the shared top-10 boards. To add a game: add it here, give it a screen,
 * and open that screen from ArcadeScreen.
 */
public enum ArcadeGame {
    BLOCK_STACK("Block Stack", "Stack falling blocks, clear lines, survive the speed-up.",
            "← → move   ↓ soft drop", "SPACE hard drop", "↑ / X rotate   Z rotate back", "C / SHIFT hold"),
    STAR_SWARM("Star Swarm", "Blast the alien swarm before it dive-bombs you.",
            "← → (A D) move", "SPACE fire (2 shots at a time)"),
    MAZE_MUNCHER("Maze Muncher", "Eat every pellet; power pellets turn the ghosts blue.",
            "ARROWS / WASD steer", "Turns are remembered: press early", "Eat blue ghosts: 200-1600"),
    NEON_SNAKE("Neon Snake", "Grow the snake. Every orb makes you faster.",
            "ARROWS / WASD turn", "Gold stars = bonus points"),
    BRICK_BLITZ("Brick Blitz", "Smash every brick. Catch the power-ups.",
            "MOUSE or ← → move paddle", "SPACE / click launch", "W wide  M multi-ball  S slow  + life"),
    ROCK_BLASTER("Rock Blaster", "Shoot the space rocks before they hit you.",
            "← → turn   ↑ thrust", "SPACE fire   ↓ warp"),
    BUBBLE_BURST("Bubble Burst", "Pop groups of 3 bubbles before they reach the line.",
            "MOUSE aim + click (or ← → + SPACE)", "RIGHT-CLICK / X swap bubble", "Bounce shots off the walls"),
    SMOOTHIE_SWIRL("Smoothie Swirl", "Fire flavors into the chain before it hits the blender.",
            "MOUSE aim + click (or ← → + SPACE)", "RIGHT-CLICK / X swap flavor", "Matching gaps snap shut = combos"),
    ATOM_LAB("Atom Lab", "Swap atoms, make 3 in a row, fill the beaker in time.",
            "CLICK atom + neighbor (or drag)", "4 = charged  L/T = unstable", "5 = supercharged (swap to use)"),
    SPACE_PINBALL("Space Pinball", "Lower the force fields, charge the lasers, attack!",
            "L-CLICK / Z  left flipper", "R-CLICK / M  right flipper", "Hold SPACE, let go to launch", "Ramps + orbit + wormhole = combos");

    public final String title;
    public final String blurb;
    /** Control hints shown in the arcade menu (P pause and ESC menu work in every game). */
    public final String[] controls;

    ArcadeGame(String title, String blurb, String... controls) {
        this.title = title;
        this.blurb = blurb;
        this.controls = controls;
    }

    public static ArcadeGame byOrdinal(int i) {
        ArcadeGame[] v = values();
        return i >= 0 && i < v.length ? v[i] : BLOCK_STACK;
    }
}
