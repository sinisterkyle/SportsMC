package com.sportsmc.field;

/**
 * What a field is for. The Field Blueprint switches between these, every saved field remembers its type,
 * and each sport's lobby only offers fields of its own type. To add a sport's field later, add an entry
 * here (plus its lines in FieldRenderer and its measurements in BlueprintScreen).
 * A bowling alley is several Bowling Lanes side by side: each lane is its own field with its own game.
 *
 * Every type is marked the same way: click two opposite corners of the playing area. The longer side
 * is the length.
 *
 * @param minLength / minWidth  smallest playable size in blocks
 * @param regulation            real-size hint shown to the builder (1 block = 1 m)
 */
public enum FieldType {
    FOOTBALL("football", "Football", "Football Field", "Field", 20, 9,
            "100 x 53 blocks goal line to goal line (end zones added beyond)",
            "Corner 1 = HOME goal line", "Corner 2 = AWAY goal line, opposite corner"),
    TENNIS("tennis", "Tennis", "Tennis Court", "Court", 10, 5,
            "24 x 11 blocks baseline to baseline (doubles sidelines)",
            "Corner 1 = a baseline corner", "Corner 2 = opposite corner, other baseline"),
    BOWLING("bowling", "Bowling", "Bowling Lane", "Lane", 12, 2,
            "about 20 x 2-3 blocks foul line to pit, gutters included",
            "Corner 1 = foul line corner (bowler's end)", "Corner 2 = far corner, past the pins");

    public final String key;
    /** "Football" / "Tennis" - the sport, for compact labels. */
    public final String sport;
    public final String displayName;
    /** "Field" / "Court", used in messages like "Court saved". */
    public final String noun;
    public final int minLength;
    public final int minWidth;
    public final String regulation;
    public final String corner1Hint;
    public final String corner2Hint;

    FieldType(String key, String sport, String displayName, String noun, int minLength, int minWidth, String regulation,
              String corner1Hint, String corner2Hint) {
        this.key = key;
        this.sport = sport;
        this.displayName = displayName;
        this.noun = noun;
        this.minLength = minLength;
        this.minWidth = minWidth;
        this.regulation = regulation;
        this.corner1Hint = corner1Hint;
        this.corner2Hint = corner2Hint;
    }

    public FieldType next() {
        return values()[(ordinal() + 1) % values().length];
    }

    /** Unknown or missing keys (fields saved before types existed) are football fields. */
    public static FieldType byKey(String key) {
        for (FieldType t : values()) if (t.key.equalsIgnoreCase(key)) return t;
        return FOOTBALL;
    }
}
