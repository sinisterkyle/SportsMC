package com.sportsmc.field;

import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Geometry of a football field measured goal line to goal line.
 *
 * The two clicked corners mark the playing field only. Its longer side is the 100 yards between the
 * goal lines (corner 1 = HOME's goal line, corner 2 = AWAY's). A 10-yard end zone is then added BEYOND
 * each goal line, outside the clicked area:
 *   [10-yd HOME end zone] | corner 1 ... 100 yards ... corner 2 | [10-yd AWAY end zone]
 * Any size works and the yards scale to fit.
 *
 * Terms: "u" = coordinate along the length (HOME end -> AWAY end), "v" = across the field.
 * Edges are block EDGES (doubles). "Yard" positions are measured from HOME's goal line:
 * 0 = HOME goal line, 50 = midfield, 100 = AWAY goal line (negative / over 100 = inside an end zone).
 */
public final class FieldGeometry {

    public static final double FIELD_YARDS = 100.0;
    public static final double TOTAL_YARDS = 120.0;
    public static final double END_ZONE_YARDS = 10.0;
    public static final double NFL_WIDTH_YARDS = 53.3;
    public static final int MIN_LENGTH = 20;   // blocks, goal line to goal line
    public static final int MIN_WIDTH = 9;

    public enum Axis {
        X("East-West"), Z("North-South");

        public final String label;

        Axis(String label) { this.label = label; }
    }

    /** Result of validating the clicked corners: exactly one of geometry/error is set. */
    public record Result(@Nullable FieldGeometry geometry, @Nullable String error) {
        public boolean ok() { return geometry != null; }
    }

    public final BlockPos corner1, corner2;
    public final int floorY;
    public final Axis axis;
    public final int dir;          // +1 if AWAY's end (corner 2) lies toward increasing u
    public final double backA, goalA, goalB, backB;
    public final double side0, side1;

    /** Non-validating constructor; use {@link #validate} for user input. */
    public FieldGeometry(BlockPos corner1, BlockPos corner2, int floorY) {
        this.corner1 = corner1.immutable();
        this.corner2 = corner2.immutable();
        this.floorY = floorY;

        int extX = Math.abs(corner1.getX() - corner2.getX()) + 1;
        int extZ = Math.abs(corner1.getZ() - corner2.getZ()) + 1;
        this.axis = extX >= extZ ? Axis.X : Axis.Z;

        int u1 = u(corner1), u2 = u(corner2);
        this.dir = u2 >= u1 ? 1 : -1;
        if (dir == 1) { goalA = u1; goalB = u2 + 1; }
        else { goalA = u1 + 1; goalB = u2; }

        double ez = END_ZONE_YARDS * blocksPerYard();
        backA = goalA - dir * ez;
        backB = goalB + dir * ez;

        side0 = Math.min(v(corner1), v(corner2));
        side1 = Math.max(v(corner1), v(corner2)) + 1;
    }

    public static Result validate(BlockPos c1, BlockPos c2) {
        return validate(c1, c2, FieldType.FOOTBALL);
    }

    /**
     * Checks two clicked corners for a field of the given type. For football the corners sit on the goal lines;
     * for tennis they're the corners of the court (baselines / doubles sidelines). The longer side is the length.
     */
    public static Result validate(BlockPos c1, BlockPos c2, FieldType type) {
        String noun = type.noun.toLowerCase();
        if (c1.getX() == c2.getX() && c1.getZ() == c2.getZ()) {
            return new Result(null, "Both corners are the same spot - click the OPPOSITE corner of the " + noun + ".");
        }
        int extX = Math.abs(c1.getX() - c2.getX()) + 1;
        int extZ = Math.abs(c1.getZ() - c2.getZ()) + 1;
        if (extX == extZ) {
            return new Result(null, "The area is square (" + extX + " x " + extZ + "), so there's no long side. Make it longer than it is wide.");
        }
        int length = Math.max(extX, extZ), width = Math.min(extX, extZ);
        String along = type == FieldType.TENNIS ? "baseline to baseline" : type == FieldType.BOWLING ? "foul line to pit" : "goal to goal";
        if (length < type.minLength) {
            return new Result(null, "Only " + length + " blocks " + along + " - a " + noun + " needs at least " + type.minLength + ".");
        }
        if (width < type.minWidth) {
            return new Result(null, "Only " + width + " blocks wide - a " + noun + " needs at least " + type.minWidth + ".");
        }
        // A stray click far away would make a giant field (players spread over unloaded chunks, a booth miles up).
        int maxLength = type == FieldType.TENNIS ? 120 : type == FieldType.BOWLING ? 64 : 400;
        int maxWidth = type == FieldType.TENNIS ? 60 : type == FieldType.BOWLING ? 6 : 250;
        if (length > maxLength || width > maxWidth) {
            return new Result(null, length + " x " + width + " blocks is too big - a " + noun + " can be at most "
                    + maxLength + " x " + maxWidth + ". Check you clicked the right corners.");
        }
        if (type == FieldType.BOWLING && length < width * 6) {
            return new Result(null, "A lane " + width + " blocks wide needs to be at least " + width * 6
                    + " blocks long (yours is " + length + ") - make it longer or narrower.");
        }
        return new Result(new FieldGeometry(c1, c2, c1.getY() + 1), null);
    }

    /** u-coordinate at a fraction of the clicked length (0 = corner 1's end, 1 = corner 2's end). */
    public double uAtFraction(double f) {
        return goalA + dir * f * length();
    }

    /** v-coordinate at a fraction of the width (0 = one sideline, 1 = the other). */
    public double vAtFraction(double f) {
        return side0 + f * width();
    }

    // ------------------------------------------------------------------ measurements

    /** End line to end line, end zones included (= 120 yards). */
    public double totalLength() { return Math.abs(backB - backA); }
    /** Goal line to goal line, the clicked area (= 100 yards). */
    public double length() { return Math.abs(goalB - goalA); }
    public double width() { return side1 - side0; }
    public double blocksPerYard() { return Math.abs(goalB - goalA) / FIELD_YARDS; }
    public double endZoneDepth() { return END_ZONE_YARDS * blocksPerYard(); }
    public double widthYards() { return width() / blocksPerYard(); }

    /** u-coordinate of a yard position (yards from HOME's goal line). */
    public double uAtYard(double yardsFromHomeGoal) {
        return goalA + dir * yardsFromHomeGoal * blocksPerYard();
    }

    public double vCenter() { return (side0 + side1) / 2.0; }

    /** Field coordinates -> world position. */
    public Vec3 world(double u, double v, double y) {
        return axis == Axis.X ? new Vec3(u, y, v) : new Vec3(v, y, u);
    }

    /** Midfield-line position at a given yard, centered across the field. */
    public Vec3 atYard(double yard) {
        return world(uAtYard(yard), vCenter(), floorY);
    }

    /** Yaw for a player looking toward AWAY's end zone (towardAway) or HOME's. */
    public float yaw(boolean towardAway) {
        int d = towardAway ? dir : -dir;
        double dx = axis == Axis.X ? d : 0;
        double dz = axis == Axis.Z ? d : 0;
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    // ------------------------------------------------------------------ field coordinates (yard, lateral)
    // yard = yards from HOME's goal line toward AWAY; lat = yards from the middle of the field toward side1.

    public double halfWidthYards() { return widthYards() / 2.0; }

    public Vec3 at(double yard, double lat, double y) {
        return world(uAtYard(yard), vCenter() + lat * blocksPerYard(), y);
    }

    public double yardOf(Vec3 p) {
        double u = axis == Axis.X ? p.x : p.z;
        return (u - goalA) * dir / blocksPerYard();
    }

    public double latOf(Vec3 p) {
        double v = axis == Axis.X ? p.z : p.x;
        return (v - vCenter()) / blocksPerYard();
    }

    /** Horizontal world unit vector for a direction in field terms (dYard toward AWAY, dLat toward side1). */
    public Vec3 worldDir(double dYard, double dLat) {
        double du = dYard * dir;
        Vec3 w = axis == Axis.X ? new Vec3(du, 0, dLat) : new Vec3(dLat, 0, du);
        return w.lengthSqr() < 1.0e-9 ? Vec3.ZERO : w.normalize();
    }

    public Vec3 center() {
        return atYard(50);
    }

    public String summary() {
        return fmt(length()) + " x " + fmt(width()) + " blocks";
    }

    /** Goal-line corner blocks for a field whose goal lines sit at these edges (used to convert old saves). */
    public static BlockPos goalCorner(Axis axis, double goalEdge, int dirIntoField, int v, int y) {
        int u = (int) Math.round(goalEdge);
        if (dirIntoField == -1) u -= 1; // the block on the field side of the edge
        return axis == Axis.X ? new BlockPos(u, y, v) : new BlockPos(v, y, u);
    }

    // ------------------------------------------------------------------ helpers

    public int u(BlockPos p) { return axis == Axis.X ? p.getX() : p.getZ(); }
    public int v(BlockPos p) { return axis == Axis.X ? p.getZ() : p.getX(); }

    public static String fmt(double d) {
        if (Math.abs(d - Math.round(d)) < 0.005) return String.valueOf(Math.round(d));
        return String.format("%.2f", d);
    }
}
