package com.sportsmc.field;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** All saved fields for a world, stored in data/sportsmc_fields.dat of the overworld (covers every dimension). */
public class FieldRegistry extends SavedData {

    private static final String DATA_NAME = "sportsmc_fields";
    /** Fields saved before the rename to SportsMC; copied over once if the new file is empty. */
    private static final String LEGACY_DATA_NAME = "madden" + "mc_fields";

    private boolean migrationChecked = false;

    private final Map<UUID, FieldData> fields = new LinkedHashMap<>();

    public static FieldRegistry get(MinecraftServer server) {
        var storage = server.overworld().getDataStorage();
        FieldRegistry reg = storage.computeIfAbsent(FieldRegistry::load, FieldRegistry::new, DATA_NAME);
        if (!reg.migrationChecked) {
            reg.migrationChecked = true;
            if (reg.fields.isEmpty()) {
                FieldRegistry old = storage.get(FieldRegistry::load, LEGACY_DATA_NAME);
                if (old != null && !old.fields.isEmpty()) {
                    reg.fields.putAll(old.fields);
                    reg.setDirty();
                }
            }
        }
        return reg;
    }

    public FieldRegistry() {}

    public static FieldRegistry load(CompoundTag tag) {
        FieldRegistry reg = new FieldRegistry();
        ListTag list = tag.getList("Fields", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            FieldData f = FieldData.load(list.getCompound(i));
            reg.fields.put(f.id(), f);
        }
        return reg;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (FieldData f : fields.values()) list.add(f.save());
        tag.put("Fields", list);
        return tag;
    }

    /** Fields sorted by name. */
    public List<FieldData> all() {
        List<FieldData> out = new ArrayList<>(fields.values());
        out.sort(Comparator.comparing(f -> f.name().toLowerCase()));
        return out;
    }

    @Nullable
    public FieldData get(@Nullable UUID id) {
        return id == null ? null : fields.get(id);
    }

    @Nullable
    public FieldData byName(String name) {
        for (FieldData f : fields.values()) if (f.name().equalsIgnoreCase(name)) return f;
        return null;
    }

    public void add(FieldData field) {
        fields.put(field.id(), field);
        setDirty();
    }

    public boolean remove(UUID id) {
        boolean removed = fields.remove(id) != null;
        if (removed) setDirty();
        return removed;
    }
}
