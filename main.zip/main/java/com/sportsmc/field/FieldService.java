package com.sportsmc.field;

import com.sportsmc.item.FieldBlueprintItem;
import com.sportsmc.lobby.LobbyManager;
import com.sportsmc.match.MatchManager;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.UUID;

/** Server-side handling of everything the Field Blueprint screen and /sportsmc field commands can do. */
public final class FieldService {

    private FieldService() {}

    public static void save(ServerPlayer player, String rawName) {
        ItemStack stack = findBlueprint(player);
        if (stack.isEmpty()) { fail(player, "Hold a Field Blueprint to save a field."); return; }

        String name = cleanName(rawName);
        if (name.isEmpty()) { fail(player, "Give the field a name first."); return; }

        FieldGeometry.Result result = FieldBlueprintItem.layout(stack);
        if (result == null) { fail(player, "Mark both corners of the field first."); return; }
        if (!result.ok()) { fail(player, result.error()); return; }

        String dim = FieldBlueprintItem.getDimension(stack);
        if (dim == null) dim = player.level().dimension().location().toString();

        FieldRegistry reg = FieldRegistry.get(player.server);
        if (reg.byName(name) != null) { fail(player, "A field called \"" + name + "\" already exists."); return; }

        FieldType type = FieldBlueprintItem.getType(stack);
        FieldData field = new FieldData(UUID.randomUUID(), name, new ResourceLocation(dim),
                player.getUUID(), player.getGameProfile().getName(), result.geometry(), type);
        reg.add(field);
        FieldBlueprintItem.clear(stack);

        player.level().playSound(null, player.blockPosition(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 0.7f, 1.0f);
        String details = type == FieldType.TENNIS
                ? result.geometry().summary() + " baseline to baseline. Pick it in the Tennis lobby with M."
                : type == FieldType.BOWLING
                ? result.geometry().summary() + " foul line to pit. Pick it in the Bowling lobby with M."
                : result.geometry().summary() + " goal to goal, " + FieldGeometry.fmt(result.geometry().blocksPerYard())
                  + " blocks/yard. Pick it in the Football lobby with M.";
        player.sendSystemMessage(prefix().append(Component.literal(type.displayName + " \"" + name + "\" saved (" + details + ")")
                .withStyle(ChatFormatting.GREEN)));
        LobbyManager.get().syncAll();
    }

    /** Switches the held blueprint between field types (Football Field, Tennis Court, ...). */
    public static void cycleType(ServerPlayer player) {
        ItemStack stack = findBlueprint(player);
        if (stack.isEmpty()) return;
        FieldType type = FieldBlueprintItem.cycleType(stack);
        player.displayClientMessage(Component.literal("Blueprint now marks: " + type.displayName).withStyle(ChatFormatting.GOLD), true);
        player.level().playSound(null, player.blockPosition(), SoundEvents.BOOK_PAGE_TURN, SoundSource.PLAYERS, 1.0f, 1.3f);
    }

    public static void undo(ServerPlayer player) {
        ItemStack stack = findBlueprint(player);
        if (stack.isEmpty()) return;
        FieldBlueprintItem.undo(stack);
    }

    public static void clear(ServerPlayer player) {
        ItemStack stack = findBlueprint(player);
        if (stack.isEmpty()) return;
        FieldBlueprintItem.clear(stack);
        player.displayClientMessage(Component.literal("Blueprint cleared.").withStyle(ChatFormatting.YELLOW), true);
    }

    public static void delete(ServerPlayer player, @Nullable UUID id) {
        FieldRegistry reg = FieldRegistry.get(player.server);
        FieldData field = reg.get(id);
        if (field == null) { fail(player, "That field no longer exists."); return; }
        if (!canManage(player, field)) { fail(player, "Only " + field.creatorName() + " or an operator can delete this field."); return; }
        if (MatchManager.get().isFieldInUse(field.id())) { fail(player, "A match is being played on \"" + field.name() + "\" right now."); return; }

        reg.remove(field.id());
        LobbyManager.get().onFieldDeleted(field.id());
        player.sendSystemMessage(prefix().append(Component.literal("Deleted field \"" + field.name() + "\".").withStyle(ChatFormatting.YELLOW)));
        LobbyManager.get().syncAll();
    }

    /** Takes a field's creator (or an operator) to midfield for inspection. */
    public static void teleport(ServerPlayer player, @Nullable UUID id) {
        FieldData field = FieldRegistry.get(player.server).get(id);
        if (field == null) { fail(player, "That field no longer exists."); return; }
        if (!canManage(player, field)) { fail(player, "Only " + field.creatorName() + " or an operator can visit this field from here."); return; }
        ServerLevel level = levelOf(player, field);
        if (level == null) { fail(player, "That field's dimension isn't loaded."); return; }
        Vec3 c = field.geometry().center();
        player.teleportTo(level, c.x, c.y, c.z, field.geometry().yaw(true), 0f);
    }

    // ------------------------------------------------------------------ helpers

    public static boolean canManage(ServerPlayer player, FieldData field) {
        return field.creator().equals(player.getUUID()) || player.hasPermissions(2);
    }

    @Nullable
    public static ServerLevel levelOf(ServerPlayer player, FieldData field) {
        ResourceKey<Level> key = ResourceKey.create(Registries.DIMENSION, field.dimension());
        return player.server.getLevel(key);
    }

    private static ItemStack findBlueprint(ServerPlayer player) {
        for (InteractionHand hand : InteractionHand.values()) {
            ItemStack s = player.getItemInHand(hand);
            if (s.getItem() instanceof FieldBlueprintItem) return s;
        }
        return ItemStack.EMPTY;
    }

    public static String cleanName(String raw) {
        String s = raw.replace("§", "").trim().replaceAll("\\s+", " ");
        return s.length() > FieldData.MAX_NAME_LENGTH ? s.substring(0, FieldData.MAX_NAME_LENGTH) : s;
    }

    private static net.minecraft.network.chat.MutableComponent prefix() {
        return Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD);
    }

    private static void fail(ServerPlayer p, String text) {
        p.sendSystemMessage(prefix().append(Component.literal(text).withStyle(ChatFormatting.RED)));
    }
}
