package com.sportsmc.field;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;

import java.util.UUID;

/** A saved, named football field. Immutable; the geometry is rebuilt from the stored corners. */
public final class FieldData {

    public static final int MAX_NAME_LENGTH = 24;

    private final UUID id;
    private final String name;
    private final ResourceLocation dimension;
    private final UUID creator;
    private final String creatorName;
    private final FieldGeometry geometry;
    private final FieldType type;

    public FieldData(UUID id, String name, ResourceLocation dimension, UUID creator, String creatorName, FieldGeometry geometry,
                     FieldType type) {
        this.id = id;
        this.name = name;
        this.dimension = dimension;
        this.creator = creator;
        this.creatorName = creatorName;
        this.geometry = geometry;
        this.type = type;
    }

    public UUID id() { return id; }
    public String name() { return name; }
    public ResourceLocation dimension() { return dimension; }
    public UUID creator() { return creator; }
    public String creatorName() { return creatorName; }
    public FieldGeometry geometry() { return geometry; }
    public FieldType type() { return type; }

    // ------------------------------------------------------------------ NBT (world save)

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putUUID("Id", id);
        t.putString("Name", name);
        t.putString("Dim", dimension.toString());
        t.putUUID("Creator", creator);
        t.putString("CreatorName", creatorName);
        t.putInt("Format", 3);
        t.putLong("Corner1", geometry.corner1.asLong());
        t.putLong("Corner2", geometry.corner2.asLong());
        t.putInt("FloorY", geometry.floorY);
        t.putString("Type", type.key);
        return t;
    }

    public static FieldData load(CompoundTag t) {
        FieldGeometry g;
        if (!t.contains("Corner1")) g = fromLegacy(t);
        else {
            g = new FieldGeometry(BlockPos.of(t.getLong("Corner1")), BlockPos.of(t.getLong("Corner2")), t.getInt("FloorY"));
            if (t.getInt("Format") == 2) g = fromWholeField(g);
        }
        // Fields saved before types existed have no "Type" and are football fields.
        return new FieldData(t.getUUID("Id"), t.getString("Name"), new ResourceLocation(t.getString("Dim")),
                t.getUUID("Creator"), t.getString("CreatorName"), g, FieldType.byKey(t.getString("Type")));
    }

    /**
     * Draft-2 fields were saved as two end zone boxes: keep their goal lines (the inner edges of the boxes).
     */
    private static FieldGeometry fromLegacy(CompoundTag t) {
        BlockPos aMin = BlockPos.of(t.getLong("AMin")), aMax = BlockPos.of(t.getLong("AMax"));
        BlockPos bMin = BlockPos.of(t.getLong("BMin")), bMax = BlockPos.of(t.getLong("BMax"));
        int y = t.getInt("FloorY") - 1;
        boolean alongX = aMax.getX() < bMin.getX() || bMax.getX() < aMin.getX();
        int aLo = alongX ? aMin.getX() : aMin.getZ(), aHi = alongX ? aMax.getX() : aMax.getZ();
        int bLo = alongX ? bMin.getX() : bMin.getZ(), bHi = alongX ? bMax.getX() : bMax.getZ();
        int vLo = alongX ? aMin.getZ() : aMin.getX(), vHi = alongX ? aMax.getZ() : aMax.getX();
        boolean homeLow = aHi < bLo;
        int homeGoalBlock = homeLow ? aHi + 1 : aLo - 1;
        int awayGoalBlock = homeLow ? bLo - 1 : bHi + 1;
        BlockPos c1 = alongX ? new BlockPos(homeGoalBlock, y, vLo) : new BlockPos(vLo, y, homeGoalBlock);
        BlockPos c2 = alongX ? new BlockPos(awayGoalBlock, y, vHi) : new BlockPos(vHi, y, awayGoalBlock);
        return new FieldGeometry(c1, c2, t.getInt("FloorY"));
    }

    /**
     * Draft-3 fields were measured end line to end line (120 yards). Pull the corners in to the goal lines.
     */
    private static FieldGeometry fromWholeField(FieldGeometry whole) {
        double total = Math.abs(whole.goalB - whole.goalA); // under the new rules these edges are the old end lines
        double ez = total / FieldGeometry.TOTAL_YARDS * FieldGeometry.END_ZONE_YARDS;
        int d = whole.dir;
        double homeGoal = whole.goalA + d * ez;
        double awayGoal = whole.goalB - d * ez;
        int y = whole.corner1.getY();
        BlockPos c1 = FieldGeometry.goalCorner(whole.axis, homeGoal, d, (int) whole.side0, y);
        BlockPos c2 = FieldGeometry.goalCorner(whole.axis, awayGoal, -d, (int) whole.side1 - 1, y);
        return new FieldGeometry(c1, c2, whole.floorY);
    }

    // ------------------------------------------------------------------ network

    public void encode(FriendlyByteBuf buf) {
        buf.writeUUID(id);
        buf.writeUtf(name, MAX_NAME_LENGTH * 4);
        buf.writeResourceLocation(dimension);
        buf.writeUUID(creator);
        buf.writeUtf(creatorName, 64);
        buf.writeBlockPos(geometry.corner1);
        buf.writeBlockPos(geometry.corner2);
        buf.writeVarInt(geometry.floorY);
        buf.writeEnum(type);
    }

    public static FieldData decode(FriendlyByteBuf buf) {
        UUID id = buf.readUUID();
        String name = buf.readUtf(MAX_NAME_LENGTH * 4);
        ResourceLocation dim = buf.readResourceLocation();
        UUID creator = buf.readUUID();
        String creatorName = buf.readUtf(64);
        FieldGeometry g = new FieldGeometry(buf.readBlockPos(), buf.readBlockPos(), buf.readVarInt());
        FieldType type = buf.readEnum(FieldType.class);
        return new FieldData(id, name, dim, creator, creatorName, g, type);
    }
}
