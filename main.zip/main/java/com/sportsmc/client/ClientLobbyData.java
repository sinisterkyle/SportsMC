package com.sportsmc.client;

import com.sportsmc.client.screen.FootballHubScreen;
import com.sportsmc.network.LobbySyncPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.toasts.SystemToast;
import net.minecraft.network.chat.Component;

import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Latest lobby snapshot from the server; the hub screen reads only from here. */
public final class ClientLobbyData {

    @Nullable private static LobbySyncPacket latest;
    private static final Set<UUID> seenInvites = new HashSet<>();

    private ClientLobbyData() {}

    @Nullable
    public static LobbySyncPacket get() {
        return latest;
    }

    public static void apply(LobbySyncPacket packet) {
        latest = packet;
        Minecraft mc = Minecraft.getInstance();

        // Pop a toast the first time we see each invite.
        Set<UUID> current = new HashSet<>();
        for (LobbySyncPacket.InviteView invite : packet.invites()) {
            current.add(invite.lobbyId());
            if (seenInvites.add(invite.lobbyId())) {
                SystemToast.add(mc.getToasts(), SystemToast.SystemToastIds.TUTORIAL_HINT,
                        Component.literal("Football invite!"),
                        Component.literal(invite.hostName() + " - press M to respond"));
            }
        }
        seenInvites.retainAll(current);

        if (mc.screen instanceof FootballHubScreen hub) hub.refresh();
        else if (mc.screen instanceof com.sportsmc.client.screen.SportsMenuScreen menu) menu.refresh();
        else if (mc.screen instanceof com.sportsmc.client.screen.BlueprintScreen bp) bp.refresh();
    }

    public static void clear() {
        latest = null;
        seenInvites.clear();
    }
}
