package com.sportsmc.client;

import com.sportsmc.entity.TennisBallEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;

/** The tennis ball as a small, always-bright sprite with a shadow (helps judge its height). */
public class TennisBallRenderer extends ThrownItemRenderer<TennisBallEntity> {

    public TennisBallRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, 0.7f, true);
        this.shadowRadius = 0.15f;
        this.shadowStrength = 0.9f;
    }
}
