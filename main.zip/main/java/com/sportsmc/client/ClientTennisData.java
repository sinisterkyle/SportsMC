package com.sportsmc.client;

import com.sportsmc.network.TennisStatePacket;

import javax.annotation.Nullable;

/** Latest tennis match state for the local player (null when not in a tennis match). */
public final class ClientTennisData {

    @Nullable private static TennisStatePacket state;

    private ClientTennisData() {}

    @Nullable
    public static TennisStatePacket get() {
        return state != null && state.active() ? state : null;
    }

    public static void apply(TennisStatePacket packet) {
        state = packet;
    }

    public static void clear() {
        state = null;
    }
}
