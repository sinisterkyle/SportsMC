package com.sportsmc.client;

import com.sportsmc.client.screen.BlueprintScreen;
import com.sportsmc.item.FieldBlueprintItem;
import com.sportsmc.network.LobbyActionPacket;
import com.sportsmc.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

/** Client-only entry points called from common code through DistExecutor. */
public final class ClientHooks {

    private ClientHooks() {}

    public static void openBlueprintScreen() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen == null) {
            mc.setScreen(new BlueprintScreen());
            ModNetwork.sendToServer(LobbyActionPacket.of(LobbyActionPacket.Action.REQUEST_SYNC));
        }
    }

    /** The blueprint the local player is holding (main hand first), or EMPTY. */
    public static ItemStack heldBlueprint() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return ItemStack.EMPTY;
        for (InteractionHand hand : InteractionHand.values()) {
            ItemStack s = mc.player.getItemInHand(hand);
            if (s.getItem() instanceof FieldBlueprintItem) return s;
        }
        return ItemStack.EMPTY;
    }
}
