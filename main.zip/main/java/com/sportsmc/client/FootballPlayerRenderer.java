package com.sportsmc.client;

import com.sportsmc.SportsMC;
import com.sportsmc.entity.FootballPlayerEntity;
import com.sportsmc.lobby.Lobby;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.Font;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;

/**
 * Player-shaped renderer with HOME (blue) / AWAY (red) uniforms; the held football shows in hand.
 * When you're the quarterback and can throw, each receiver gets a floating throw icon - his key
 * (1, 2 or 3) in green (open), yellow (tight) or red (covered) - instead of any outline on the model.
 */
public class FootballPlayerRenderer extends HumanoidMobRenderer<FootballPlayerEntity, PlayerModel<FootballPlayerEntity>> {

    private static final ResourceLocation HOME = new ResourceLocation(SportsMC.MODID, "textures/entity/player_home.png");
    private static final ResourceLocation AWAY = new ResourceLocation(SportsMC.MODID, "textures/entity/player_away.png");

    private static final float ICON_SCALE = 0.06f;        // about twice a name tag
    private static final int ICON_BACKGROUND = 0xA0101820; // dark badge behind the number

    public FootballPlayerRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(FootballPlayerEntity entity) {
        return entity.side() == Lobby.Side.HOME ? HOME : AWAY;
    }

    @Override
    public void render(FootballPlayerEntity entity, float entityYaw, float partialTicks, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
        int slot = entity.passSlot();
        if (slot > 0) renderThrowIcon(entity, slot, poseStack, buffer);
    }

    private void renderThrowIcon(FootballPlayerEntity entity, int slot, PoseStack poseStack, MultiBufferSource buffer) {
        String text = " " + slot + " ";
        int color = 0xFF000000 | entity.passOpenColor();
        Font font = getFont();

        poseStack.pushPose();
        poseStack.translate(0.0, entity.getBbHeight() + 0.85, 0.0);
        poseStack.mulPose(entityRenderDispatcher.cameraOrientation()); // always face the camera
        poseStack.scale(-ICON_SCALE, -ICON_SCALE, ICON_SCALE);
        Matrix4f matrix = poseStack.last().pose();
        float x = -font.width(text) / 2f;

        // Seen through other players (so a receiver in traffic still shows his number), then drawn crisp on top.
        font.drawInBatch(text, x, 0, color, false, matrix, buffer, Font.DisplayMode.SEE_THROUGH, ICON_BACKGROUND, LightTexture.FULL_BRIGHT);
        font.drawInBatch(text, x, 0, color, false, matrix, buffer, Font.DisplayMode.NORMAL, 0, LightTexture.FULL_BRIGHT);
        poseStack.popPose();
    }
}
