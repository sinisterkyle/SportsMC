package com.sportsmc.client;

import com.sportsmc.network.BowlingStatePacket;
import net.minecraft.client.Minecraft;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Bowling games this client knows about: its own game (as a bowler) and any lane nearby it's watching.
 * Keeps the last two snapshots of each lane so the renderer can smooth the ball and pins between ticks.
 */
public final class ClientBowlingData {

    public static final class LaneView {
        public BowlingStatePacket now, prev;
        public long receivedAt, prevAt;
    }

    private static final Map<UUID, LaneView> lanes = new HashMap<>();
    @Nullable private static BowlingStatePacket mine;

    private ClientBowlingData() {}

    /** Your own game, if you're bowling. */
    @Nullable
    public static BowlingStatePacket mine() {
        return mine;
    }

    public static boolean myTurnToAim() {
        return mine != null && mine.phase() == BowlingStatePacket.AIM && mine.turn() == mine.viewer();
    }

    /** A lane's latest snapshots, or null if nobody's playing there (or we stopped hearing about it). */
    @Nullable
    public static LaneView lane(UUID fieldId) {
        LaneView v = lanes.get(fieldId);
        if (v == null) return null;
        if (System.currentTimeMillis() - v.receivedAt > 4000) { lanes.remove(fieldId); return null; }
        return v;
    }

    public static void apply(BowlingStatePacket p) {
        if (!p.active()) {
            if (p.fieldId() != null) lanes.remove(p.fieldId());
            if (p.fieldId() == null || (mine != null && p.fieldId().equals(mine.fieldId()))) {
                if (mine != null && mine.fieldId() != null) lanes.remove(mine.fieldId());
                mine = null;
                closeThrowScreen();
            }
            return;
        }
        LaneView v = lanes.computeIfAbsent(p.fieldId(), k -> new LaneView());
        long t = System.currentTimeMillis();
        v.prev = v.now;
        v.prevAt = v.receivedAt;
        v.now = p;
        v.receivedAt = t;
        if (p.viewer() < 0) return;
        boolean wasAiming = myTurnToAim();
        mine = p;
        if (myTurnToAim() && !wasAiming) openThrowScreen();
        else if (!myTurnToAim()) closeThrowScreen();
    }

    public static void openThrowScreen() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !myTurnToAim()) return;
        if (mc.screen == null || mc.screen instanceof com.sportsmc.client.screen.BowlingThrowScreen) {
            mc.setScreen(new com.sportsmc.client.screen.BowlingThrowScreen());
        }
    }

    private static void closeThrowScreen() {
        Minecraft mc = Minecraft.getInstance();
        // (Let a just-thrown ball finish flying off the screen; it closes itself.)
        if (mc.screen instanceof com.sportsmc.client.screen.BowlingThrowScreen s && !s.throwing()) mc.setScreen(null);
    }

    public static Map<UUID, LaneView> lanes() {
        return lanes;
    }

    public static void clear() {
        lanes.clear();
        mine = null;
    }
}
