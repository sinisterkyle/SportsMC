package com.sportsmc.client;

import com.sportsmc.bowling.BowlingPhysics;
import com.sportsmc.bowling.BowlingScore;
import com.sportsmc.network.BowlingStatePacket;
import com.sportsmc.network.LobbySyncPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.ForgeGui;

import java.util.ArrayList;
import java.util.List;

/**
 * Bowling HUD: a TV-style score sheet across the top (both bowlers, every frame's marks and running totals),
 * whose turn it is, big STRIKE! / SPARE! calls, and a "pin cam" of the pin deck in the corner during a roll.
 */
public final class BowlingHud {

    private static final int BG = 0xD0101820, HOME_BG = 0xE02A4FC0, AWAY_BG = 0xE0B8232D, CELL = 0xE0F4F4F4;
    private static final int TEXT = 0xFFFFFFFF, DARK = 0xFF202020, GOLD = 0xFFFFC83D, DIM = 0xFFB0B0B0;

    private BowlingHud() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        BowlingStatePacket s = ClientBowlingData.mine();
        Minecraft mc = Minecraft.getInstance();
        if (s == null || mc.options.hideGui) return;
        Font font = mc.font;
        int bottom = scoreSheet(g, font, s, width);
        status(g, font, s, width, bottom + 3, mc);
        callout(g, font, s, width, height);
        if (!(mc.screen instanceof com.sportsmc.client.screen.BowlingThrowScreen)
                && (s.phase() == BowlingStatePacket.ROLLING || s.phase() == BowlingStatePacket.RESULT)) {
            pinCam(g, font, s, height);
        }
    }

    // ------------------------------------------------------------------ score sheet

    private static int scoreSheet(GuiGraphics g, Font font, BowlingStatePacket s, int width) {
        int frames = Math.max(1, s.frames());
        int cw = frames >= 10 ? 20 : 26, lastW = cw + 10, nameW = 70, totalW = 32, rowH = 22;
        int total = nameW + cw * (frames - 1) + lastW + totalW;
        int x0 = width / 2 - total / 2, y0 = 4;
        for (int side = 0; side < 2; side++) {
            List<Integer> rolls = rolls(side == 0 ? s.homeRolls() : s.awayRolls());
            int y = y0 + side * (rowH + 1);
            boolean up = s.turn() == side && s.phase() != BowlingStatePacket.OVER;
            g.fill(x0, y, x0 + nameW, y + rowH, side == 0 ? HOME_BG : AWAY_BG);
            String name = side == 0 ? s.homeName() : s.awayName();
            boolean me = s.viewer() == side;
            g.drawString(font, font.plainSubstrByWidth(name, nameW - 10), x0 + 4, y + 3, me ? GOLD : TEXT);
            if (up) g.drawString(font, "▶", x0 + nameW - 9, y + 12, GOLD);
            List<String[]> marks = BowlingScore.marks(rolls, frames);
            int[] cum = BowlingScore.cumulative(rolls, frames);
            int current = BowlingScore.position(rolls, frames).frame();
            int fx = x0 + nameW;
            for (int f = 0; f < frames; f++) {
                int w = f == frames - 1 ? lastW : cw;
                g.fill(fx, y, fx + w - 1, y + rowH, CELL);
                if (up && f == current) g.renderOutline(fx, y, w - 1, rowH, 0xFFFFA000);
                String[] m = marks.get(f);
                int boxW = 9;
                for (int k = 0; k < m.length; k++) {
                    int bx = fx + w - 1 - (m.length - k) * boxW;
                    g.fill(bx, y, bx + 1, y + 10, 0xFFB0B0B0);
                    if (!m[k].isEmpty()) {
                        int col = m[k].equals("X") ? 0xFFD02020 : m[k].equals("/") ? 0xFF2050D0 : DARK;
                        g.drawCenteredString(font, m[k], bx + boxW / 2 + 1, y + 1, col);
                    }
                }
                g.fill(fx, y + 10, fx + w - 1, y + 11, 0xFFB0B0B0);
                if (cum[f] >= 0) g.drawCenteredString(font, String.valueOf(cum[f]), fx + w / 2, y + 12, DARK);
                fx += w;
            }
            g.fill(fx, y, fx + totalW, y + rowH, BG);
            g.drawCenteredString(font, String.valueOf(BowlingScore.total(rolls, frames)), fx + totalW / 2, y + 7, GOLD);
        }
        return y0 + 2 * rowH + 1;
    }

    private static List<Integer> rolls(byte[] b) {
        List<Integer> out = new ArrayList<>(b.length);
        for (byte v : b) out.add((int) v);
        return out;
    }

    // ------------------------------------------------------------------ whose turn

    private static void status(GuiGraphics g, Font font, BowlingStatePacket s, int width, int y, Minecraft mc) {
        String line;
        int color = DIM;
        String upName = s.turn() == 0 ? s.homeName() : s.awayName();
        boolean mine = s.turn() == s.viewer();
        switch (s.phase()) {
            case BowlingStatePacket.AIM -> {
                if (mine) {
                    boolean open = mc.screen instanceof com.sportsmc.client.screen.BowlingThrowScreen;
                    line = open ? "Your turn - grab the ball, flick UP to bowl" : "Your turn! Press M to bowl";
                    color = open || (System.currentTimeMillis() / 400) % 2 == 0 ? GOLD : TEXT;
                } else line = upName.startsWith("CPU") ? upName + " is lining up..." : upName + " is lining up";
            }
            case BowlingStatePacket.ROLLING -> line = upName + " bowls...";
            case BowlingStatePacket.OVER -> {
                line = s.winner() == 2 ? "Tie game!" : (s.winner() == 0 ? s.homeName() : s.awayName()) + " wins!";
                color = GOLD;
            }
            default -> line = "";
        }
        if (line.isEmpty()) return;
        int w = font.width(line) + 10;
        g.fill(width / 2 - w / 2, y, width / 2 + w / 2, y + 12, BG);
        g.drawCenteredString(font, line, width / 2, y + 2, color);
    }

    /** STRIKE! / SPARE! / GUTTER BALL in big letters. */
    private static void callout(GuiGraphics g, Font font, BowlingStatePacket s, int width, int height) {
        String m = s.message();
        if (m.isEmpty() || s.phase() == BowlingStatePacket.AIM) return;
        boolean big = m.startsWith("STRIKE") || m.startsWith("SPARE") || s.phase() == BowlingStatePacket.OVER;
        float scale = big ? 3f : 1.6f;
        int color = m.startsWith("STRIKE") ? 0xFFFF5040 : m.startsWith("SPARE") ? 0xFF50A0FF : big ? GOLD : TEXT;
        g.pose().pushPose();
        g.pose().translate(width / 2f, height * 0.3f, 0);
        g.pose().scale(scale, scale, 1);
        g.drawCenteredString(font, m, 0, 0, color);
        g.pose().popPose();
    }

    // ------------------------------------------------------------------ pin cam

    /** Looking straight down on the pin deck: standing pins white, falling orange, fallen grey; the ball in blue. */
    private static void pinCam(GuiGraphics g, Font font, BowlingStatePacket s, int height) {
        LobbySyncPacket data = ClientLobbyData.get();
        LobbySyncPacket.FieldView fv = data == null ? null : data.field(s.fieldId());
        if (fv == null) return;
        BowlingPhysics.Dims d = BowlingPhysics.Dims.of(fv.field().geometry().length(), fv.field().geometry().width());
        int size = 78, x0 = 8, y0 = height - size - 30;
        g.fill(x0 - 2, y0 - 12, x0 + size + 2, y0 + size + 2, BG);
        g.drawString(font, "PIN CAM", x0 + 2, y0 - 10, GOLD);
        g.fill(x0, y0, x0 + size, y0 + size, 0xFF2A2018);
        double hw = d.halfWidth(), u0 = d.headU() - d.rowGap() * 2, u1 = d.length() + d.pinR();
        double span = Math.max(hw * 2, u1 - u0);
        int laneL = (int) (x0 + size / 2.0 - d.laneHalf() / span * size), laneR = (int) (x0 + size / 2.0 + d.laneHalf() / span * size);
        g.fill(laneL, y0, laneR, y0 + size, 0xFFC8A060);
        java.util.function.DoubleUnaryOperator sx = x -> x0 + size / 2.0 + x / span * size;
        java.util.function.DoubleUnaryOperator su = u -> y0 + size - (u - u0) / span * size;
        for (int i = 0; i < 10; i++) {
            int st = (int) s.pins()[i * 5];
            if (st == BowlingPhysics.GONE) continue;
            double x = s.pins()[i * 5 + 1], u = s.pins()[i * 5 + 2], tilt = s.pins()[i * 5 + 3], dir = s.pins()[i * 5 + 4];
            int px = (int) sx.applyAsDouble(x), py = (int) su.applyAsDouble(u);
            if (st == BowlingPhysics.STANDING) {
                g.fill(px - 2, py - 2, px + 2, py + 2, 0xFFFFFFFF);
                g.fill(px - 1, py - 1, px + 1, py + 1, 0xFFE03030);
            } else {
                double len = d.pinH() * Math.sin(tilt);
                int col = st == BowlingPhysics.FALLING ? 0xFFFFA040 : 0xFF9A9A9A;
                for (int k = 0; k <= 6; k++) {
                    double t = k / 6.0;
                    int qx = (int) sx.applyAsDouble(x + Math.cos(dir) * len * t), qy = (int) su.applyAsDouble(u + Math.sin(dir) * len * t);
                    g.fill(qx - 1, qy - 1, qx + 1, qy + 1, col);
                }
            }
        }
        if (s.ballVisible() && s.ballU() > u0 - d.ballR()) {
            int bx = (int) sx.applyAsDouble(Math.abs(s.ballX()) > d.laneHalf() ? Math.signum(s.ballX()) * (d.laneHalf() + d.halfWidth()) / 2 : s.ballX());
            int by = (int) su.applyAsDouble(s.ballU());
            if (by >= y0 && by <= y0 + size) g.fill(bx - 3, by - 3, bx + 3, by + 3, 0xFF3050E0);
        }
    }
}
