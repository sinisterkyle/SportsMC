package com.sportsmc.client;

import com.sportsmc.SportsMC;
import com.sportsmc.network.ControlPacket;
import com.sportsmc.network.ModNetwork;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * During a match, keyboard and mouse drive the football player instead of your own body:
 *  WASD move (relative to the camera), CTRL sprint, SPACE snap / jump-hurdle,
 *  1-2-3 throw to the numbered receivers, G hand off, Z / C juke, left click dive-tackle,
 *  right click switch defender, R change play before the snap.
 * The keys are read here and sent to the server every tick; vanilla never sees them.
 */
@Mod.EventBusSubscriber(modid = SportsMC.MODID, value = Dist.CLIENT)
public final class MatchControls {

    private static int pending;
    private static float forward, strafe;
    private static boolean jumpWasDown;
    private static boolean sneakHeld;

    private MatchControls() {}

    private static boolean active() {
        return (ClientMatchData.get() != null || ClientTennisData.get() != null) && MatchCamera.isActive();
    }

    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent event) {
        if (!active()) return;
        Input in = event.getInput();
        forward = in.forwardImpulse;
        strafe = in.leftImpulse;
        if (in.jumping && !jumpWasDown) pending |= ControlPacket.HIKE_OR_JUMP;
        jumpWasDown = in.jumping;
        // Your real (spectator) body stays put.
        in.forwardImpulse = 0;
        in.leftImpulse = 0;
        in.up = in.down = in.left = in.right = false;
        in.jumping = false;
        if (in.shiftKeyDown) sneakHeld = true;
        in.shiftKeyDown = false;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (event.phase == TickEvent.Phase.START) {
            if (!active() || mc.screen != null) return;
            // Grab buttons before vanilla's key handling runs this tick.
            KeyMapping[] hotbar = mc.options.keyHotbarSlots;
            int[] throwBits = {ControlPacket.THROW_1, ControlPacket.THROW_2, ControlPacket.THROW_3};
            for (int i = 0; i < hotbar.length; i++) {
                while (hotbar[i].consumeClick()) if (i < 3) pending |= throwBits[i];
            }
            while (mc.options.keyAttack.consumeClick()) pending |= ControlPacket.TACKLE;
            while (mc.options.keyUse.consumeClick()) pending |= ControlPacket.SWITCH;
            while (mc.options.keyPickItem.consumeClick()) { /* swallowed */ }
            while (ClientEvents.JUKE_LEFT.consumeClick()) pending |= ControlPacket.JUKE_LEFT;
            while (ClientEvents.JUKE_RIGHT.consumeClick()) pending |= ControlPacket.JUKE_RIGHT;
            while (ClientEvents.HANDOFF.consumeClick()) pending |= ControlPacket.HANDOFF;
            while (ClientEvents.CYCLE_PLAY.consumeClick()) pending |= ControlPacket.CYCLE_PLAY;
            return;
        }

        MatchCamera.tick();
        if (!active() || mc.player == null) {
            pending = 0;
            return;
        }

        float yawRad = (float) Math.toRadians(MatchCamera.yaw());
        float sin = (float) Math.sin(yawRad), cos = (float) Math.cos(yawRad);
        float mx = strafe * cos - forward * sin;
        float mz = forward * cos + strafe * sin;
        boolean sprint = mc.options.keySprint.isDown();
        if (mc.screen != null) { mx = 0; mz = 0; sprint = false; }

        ModNetwork.sendToServer(new ControlPacket(mx, mz, sprint, pending | (sneakHeld ? ControlPacket.SNEAK_HELD : 0)));
        sneakHeld = false;
        pending = 0;
        forward = strafe = 0;
    }

    /** No crosshair while you're the broadcast camera. */
    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Pre event) {
        if (!active()) return;
        if (event.getOverlay().id().equals(VanillaGuiOverlay.CROSSHAIR.id())) event.setCanceled(true);
    }
}
