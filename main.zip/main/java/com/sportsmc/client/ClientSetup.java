package com.sportsmc.client;

import com.sportsmc.SportsMC;
import com.sportsmc.registry.ModEntities;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Client registration: entity renderers and the match HUD. */
@Mod.EventBusSubscriber(modid = SportsMC.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientSetup {

    private ClientSetup() {}

    /**
     * The Field Blueprint's icon follows its type: "sportsmc:field_type" is 0.0 for football, 0.1 for tennis, 0.2 for the next type...
     * (the item model picks the matching texture through its overrides).
     */
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> net.minecraft.client.renderer.item.ItemProperties.register(
                com.sportsmc.registry.ModItems.FIELD_BLUEPRINT.get(),
                new net.minecraft.resources.ResourceLocation(SportsMC.MODID, "field_type"),
                (stack, level, entity, seed) -> com.sportsmc.item.FieldBlueprintItem.getType(stack).ordinal() / 10f));
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.FOOTBALL_PLAYER.get(), FootballPlayerRenderer::new);
        event.registerEntityRenderer(ModEntities.FOOTBALL.get(), ThrownItemRenderer::new);
        event.registerEntityRenderer(ModEntities.TENNIS_PLAYER.get(), TennisPlayerRenderer::new);
        event.registerEntityRenderer(ModEntities.TENNIS_BALL.get(), TennisBallRenderer::new);
    }

    @SubscribeEvent
    public static void onRegisterOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("match_hud", MatchHud::render);
        event.registerAboveAll("tennis_hud", TennisHud::render);
        event.registerAboveAll("bowling_hud", BowlingHud::render);
    }
}
