package com.sportsmc.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.sportsmc.SportsMC;
import com.sportsmc.bowling.BowlingLane;
import com.sportsmc.bowling.BowlingPhysics;
import com.sportsmc.client.screen.BowlingThrowScreen;
import com.sportsmc.field.FieldData;
import com.sportsmc.field.FieldType;
import com.sportsmc.network.BowlingStatePacket;
import com.sportsmc.network.LobbySyncPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.util.ArrayList;
import java.util.List;

/**
 * Draws bowling pins and balls as real 3D models (lit by the world like any entity). Every bowling lane nearby
 * shows its pins: racked and waiting when nobody's playing, or exactly as the server's physics has them during
 * a game (smoothed between ticks), with the ball rolling and spinning down the lane.
 *
 * The pin is a surface of revolution traced from a real pin's profile (white with two red neck stripes);
 * the ball is a sphere with a swirl and finger holes.
 */
@Mod.EventBusSubscriber(modid = SportsMC.MODID, value = Dist.CLIENT)
public final class BowlingRenderer {

    private static final ResourceLocation WHITE = new ResourceLocation(SportsMC.MODID, "textures/entity/bowling_white.png");
    private static final double RANGE = 80;

    /** A pin's profile, from the base up: {radius, height} as fractions of its height (a 15-inch pin, 4.77 in wide). */
    private static final float[][] PROFILE = {
            {0.000f, 0.000f}, {0.067f, 0.000f}, {0.107f, 0.040f}, {0.140f, 0.133f}, {0.159f, 0.300f}, {0.150f, 0.400f},
            {0.117f, 0.517f}, {0.070f, 0.633f}, {0.060f, 0.700f}, {0.067f, 0.767f}, {0.083f, 0.853f}, {0.085f, 0.900f},
            {0.067f, 0.960f}, {0.033f, 0.993f}, {0.000f, 1.000f}};
    /** Two red rings around the neck: {from, to} heights. (Declared before PIN: static fields set up in order.) */
    private static final float[][] STRIPES = {{0.636f, 0.662f}, {0.688f, 0.714f}};
    private static final int SIDES = 14;
    /** Quads of a unit pin: each {x,y,z, nx,ny,nz} x 4 plus a color flag (1 = red stripe). */
    private static final List<float[]> PIN = buildPin();
    private static final List<float[]> BALL = buildBall(14, 10);

    private BowlingRenderer() {}

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        Minecraft mc = Minecraft.getInstance();
        LobbySyncPacket data = ClientLobbyData.get();
        if (mc.level == null || data == null) return;
        String dim = mc.level.dimension().location().toString();
        Vec3 cam = event.getCamera().getPosition();
        float partial = event.getPartialTick();
        PoseStack ps = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(WHITE));
        boolean any = false;
        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);
        for (LobbySyncPacket.FieldView fv : data.fields()) {
            FieldData f = fv.field();
            if (f.type() != FieldType.BOWLING || !f.dimension().toString().equals(dim)) continue;
            BowlingLane lane = new BowlingLane(f.geometry());
            if (lane.world(0, lane.dims.length() / 2, lane.floorY()).distanceTo(cam) > RANGE + lane.dims.length() / 2) continue;
            any = true;
            ClientBowlingData.LaneView view = ClientBowlingData.lane(f.id());
            drawLane(ps, vc, mc, lane, view);
        }
        ps.popPose();
        if (any) buffers.endBatch(RenderType.entityCutoutNoCull(WHITE));
    }

    private static void drawLane(PoseStack ps, VertexConsumer vc, Minecraft mc, BowlingLane lane, ClientBowlingData.LaneView view) {
        BowlingPhysics.Dims d = lane.dims;
        if (view == null || view.now == null) {
            // Nobody's bowling: a full rack waiting.
            for (int i = 0; i < 10; i++) drawPin(ps, vc, mc, lane, d.pinX(i), d.pinU(i), 0, 0);
            return;
        }
        BowlingStatePacket now = view.now, prev = view.prev;
        // How far we are between the last two snapshots (they arrive every tick or two).
        float k = 1f;
        if (prev != null && now.phase() == BowlingStatePacket.ROLLING && prev.phase() == BowlingStatePacket.ROLLING) {
            long span = Math.max(30, view.receivedAt - view.prevAt);
            k = Mth.clamp((System.currentTimeMillis() - view.receivedAt) / (float) span, 0f, 1f);
        } else prev = null;
        for (int i = 0; i < 10; i++) {
            int st = (int) now.pins()[i * 5];
            if (st == BowlingPhysics.GONE) continue;
            float x = now.pins()[i * 5 + 1], u = now.pins()[i * 5 + 2], tilt = now.pins()[i * 5 + 3], dir = now.pins()[i * 5 + 4];
            if (prev != null && (int) prev.pins()[i * 5] != BowlingPhysics.GONE) {
                x = Mth.lerp(k, prev.pins()[i * 5 + 1], x);
                u = Mth.lerp(k, prev.pins()[i * 5 + 2], u);
                tilt = Mth.lerp(k, prev.pins()[i * 5 + 3], tilt);
            }
            drawPin(ps, vc, mc, lane, x, u, tilt, dir);
        }
        // The ball: rolling during a throw; while you're lining up, waiting on your spot at the foul line.
        if (now.ballVisible()) {
            float bx = now.ballX(), bu = now.ballU(), roll = now.ballRoll();
            if (prev != null && prev.ballVisible()) {
                bx = Mth.lerp(k, prev.ballX(), bx);
                bu = Mth.lerp(k, prev.ballU(), bu);
                roll = Mth.lerp(k, prev.ballRoll(), roll);
            }
            boolean gutter = Math.abs(bx) > d.laneHalf();
            drawBall(ps, vc, mc, lane, bx, bu, roll, gutter);
        } else if (now.phase() == BowlingStatePacket.AIM && now.viewer() >= 0 && now.turn() == now.viewer()) {
            double sx = BowlingThrowScreen.start * (d.laneHalf() - d.ballR());
            drawBall(ps, vc, mc, lane, sx, -d.ballR() * 1.2, 0, false);
        }
    }

    // ------------------------------------------------------------------ pin

    private static void drawPin(PoseStack ps, VertexConsumer vc, Minecraft mc, BowlingLane lane, double x, double u, double tilt, double dir) {
        BowlingPhysics.Dims d = lane.dims;
        float h = (float) d.pinH();
        // Lying down, its widest part rests on the deck.
        double lift = Math.sin(tilt) * d.pinR();
        Vec3 base = lane.world(x, u, lane.floorY() + lift);
        int light = LevelRenderer.getLightColor(mc.level, BlockPos.containing(base.add(0, 0.3, 0)));
        ps.pushPose();
        ps.translate(base.x, base.y, base.z);
        if (tilt > 1e-3) {
            Vec3 fall = lane.worldDir(Math.cos(dir), Math.sin(dir));
            // Tip over toward the fall direction: rotate about (up x fall).
            ps.mulPose(new Quaternionf().rotationAxis((float) tilt, (float) fall.z, 0f, (float) -fall.x));
        }
        ps.scale(h, h, h);
        PoseStack.Pose pose = ps.last();
        for (float[] q : PIN) {
            boolean red = q[24] > 0.5f;
            float r = red ? 0.85f : 0.97f, g = red ? 0.12f : 0.96f, b = red ? 0.12f : 0.93f;
            quad(vc, pose.pose(), pose.normal(), q, r, g, b, light);
        }
        ps.popPose();
    }

    /** The profile's radius at a height (straight lines between the traced points). */
    private static float radiusAt(float y) {
        for (int i = 0; i < PROFILE.length - 1; i++) {
            float y0 = PROFILE[i][1], y1 = PROFILE[i + 1][1];
            if (y >= y0 && y <= y1 && y1 > y0) return PROFILE[i][0] + (PROFILE[i + 1][0] - PROFILE[i][0]) * (y - y0) / (y1 - y0);
        }
        return 0;
    }

    private static List<float[]> buildPin() {
        // The traced points plus the stripe edges, so the rings have crisp borders.
        java.util.TreeMap<Float, Float> pts = new java.util.TreeMap<>();
        for (float[] p : PROFILE) pts.merge(p[1], p[0], Math::max);
        for (float[] st : STRIPES) for (float y : st) pts.put(y, radiusAt(y));
        float[][] prof = new float[pts.size() + 1][];
        int idx = 1;
        prof[0] = new float[]{0, 0}; // the middle of the flat base
        for (java.util.Map.Entry<Float, Float> e : pts.entrySet()) prof[idx++] = new float[]{e.getValue(), e.getKey()};
        prof[prof.length - 1][0] = 0; // closed top
        List<float[]> out = new ArrayList<>();
        for (int s = 0; s < prof.length - 1; s++) {
            float r0 = prof[s][0], y0 = prof[s][1], r1 = prof[s + 1][0], y1 = prof[s + 1][1];
            // Outward normal of this band (in the r-y plane).
            float nr = y1 - y0, ny = -(r1 - r0);
            float nl = (float) Math.sqrt(nr * nr + ny * ny);
            if (nl < 1e-6f) continue;
            nr /= nl;
            ny /= nl;
            float mid = (y0 + y1) / 2;
            boolean red = false;
            for (float[] st : STRIPES) if (mid > st[0] && mid < st[1]) red = true;
            for (int a = 0; a < SIDES; a++) {
                double t0 = Math.PI * 2 * a / SIDES, t1 = Math.PI * 2 * (a + 1) / SIDES;
                float c0 = (float) Math.cos(t0), s0 = (float) Math.sin(t0), c1 = (float) Math.cos(t1), s1 = (float) Math.sin(t1);
                out.add(new float[]{
                        r0 * c0, y0, r0 * s0, nr * c0, ny, nr * s0,
                        r0 * c1, y0, r0 * s1, nr * c1, ny, nr * s1,
                        r1 * c1, y1, r1 * s1, nr * c1, ny, nr * s1,
                        r1 * c0, y1, r1 * s0, nr * c0, ny, nr * s0,
                        red ? 1 : 0});
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ ball

    private static void drawBall(PoseStack ps, VertexConsumer vc, Minecraft mc, BowlingLane lane, double x, double u, double roll, boolean gutter) {
        BowlingPhysics.Dims d = lane.dims;
        float r = (float) d.ballR();
        if (gutter) x = Math.signum(x) * (d.laneHalf() + d.halfWidth()) / 2;
        Vec3 c = lane.world(x, u, lane.floorY() + r - (gutter ? r * 0.45 : 0));
        int light = LevelRenderer.getLightColor(mc.level, BlockPos.containing(c.add(0, 0.3, 0)));
        Vec3 side = lane.worldDir(1, 0);
        ps.pushPose();
        ps.translate(c.x, c.y, c.z);
        // Rolling toward the pins: spin about the lane's side-to-side axis.
        ps.mulPose(new Quaternionf().rotationAxis((float) roll, (float) -side.x, 0f, (float) -side.z));
        ps.scale(r, r, r);
        PoseStack.Pose pose = ps.last();
        for (float[] q : BALL) quad(vc, pose.pose(), pose.normal(), q, q[24], q[25], q[26], light);
        ps.popPose();
    }

    private static List<float[]> buildBall(int lon, int lat) {
        List<float[]> out = new ArrayList<>();
        for (int j = 0; j < lat; j++) {
            double p0 = Math.PI * j / lat - Math.PI / 2, p1 = Math.PI * (j + 1) / lat - Math.PI / 2;
            for (int i = 0; i < lon; i++) {
                double t0 = Math.PI * 2 * i / lon, t1 = Math.PI * 2 * (i + 1) / lon;
                float[] a = sph(t0, p0), b = sph(t1, p0), c = sph(t1, p1), e = sph(t0, p1);
                double mt = (t0 + t1) / 2, mp = (p0 + p1) / 2;
                // Deep blue with a purple swirl; three dark finger holes near one pole.
                double swirl = 0.5 + 0.5 * Math.sin(mt * 2 + mp * 5);
                float rr = (float) (0.10 + 0.32 * swirl), gg = (float) (0.16 + 0.06 * swirl), bb = (float) (0.62 + 0.20 * swirl);
                boolean hole = j == lat - 2 && (i == 1 || i == 3) || j == lat - 3 && i == 2;
                if (hole) { rr = 0.03f; gg = 0.03f; bb = 0.05f; }
                out.add(new float[]{a[0], a[1], a[2], a[0], a[1], a[2], b[0], b[1], b[2], b[0], b[1], b[2],
                        c[0], c[1], c[2], c[0], c[1], c[2], e[0], e[1], e[2], e[0], e[1], e[2], rr, gg, bb});
            }
        }
        return out;
    }

    private static float[] sph(double t, double p) {
        return new float[]{(float) (Math.cos(p) * Math.cos(t)), (float) Math.sin(p), (float) (Math.cos(p) * Math.sin(t))};
    }

    // ------------------------------------------------------------------ helpers

    private static void quad(VertexConsumer vc, Matrix4f m, Matrix3f n, float[] q, float r, float g, float b, int light) {
        for (int v = 0; v < 4; v++) {
            int o = v * 6;
            vc.vertex(m, q[o], q[o + 1], q[o + 2]).color(r, g, b, 1f).uv(0.5f, 0.5f).overlayCoords(OverlayTexture.NO_OVERLAY)
                    .uv2(light).normal(n, q[o + 3], q[o + 4], q[o + 5]).endVertex();
        }
    }
}
