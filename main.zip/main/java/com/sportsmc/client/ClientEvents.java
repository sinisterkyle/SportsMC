package com.sportsmc.client;

import com.sportsmc.SportsMC;
import com.sportsmc.client.screen.FootballHubScreen;
import com.sportsmc.network.LobbyActionPacket;
import com.sportsmc.network.ModNetwork;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/** Client-only wiring: the hub keybind (default M). */
public final class ClientEvents {

    public static final KeyMapping OPEN_HUB = new KeyMapping(
            "key.sportsmc.open_hub",
            KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_M,
            "key.categories.sportsmc");

    public static final KeyMapping JUKE_LEFT = key("juke_left", GLFW.GLFW_KEY_Z);
    public static final KeyMapping JUKE_RIGHT = key("juke_right", GLFW.GLFW_KEY_C);
    public static final KeyMapping HANDOFF = key("handoff", GLFW.GLFW_KEY_G);
    public static final KeyMapping CYCLE_PLAY = key("cycle_play", GLFW.GLFW_KEY_R);

    private static KeyMapping key(String name, int code) {
        return new KeyMapping("key.sportsmc." + name, KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, code, "key.categories.sportsmc");
    }

    private ClientEvents() {}

    /** M key: the SportsMC menu (pick a sport). */
    public static void openHub() {
        // In an air hockey match, M brings the table back.
        if (ClientAirHockeyData.get() != null) {
            Minecraft.getInstance().setScreen(new com.sportsmc.client.screen.AirHockeyScreen());
            return;
        }
        // Bowling: M brings your throw panel back on your turn.
        if (ClientBowlingData.myTurnToAim()) {
            ClientBowlingData.openThrowScreen();
            return;
        }
        if (ClientCardData.get() != null) {
            Minecraft.getInstance().setScreen(new com.sportsmc.client.screen.CardDojoScreen());
            return;
        }
        com.sportsmc.client.screen.SportsMenuScreen.open();
    }

    @Mod.EventBusSubscriber(modid = SportsMC.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ModBus {
        @SubscribeEvent
        public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
            event.register(OPEN_HUB);
            event.register(JUKE_LEFT);
            event.register(JUKE_RIGHT);
            event.register(HANDOFF);
            event.register(CYCLE_PLAY);
        }
    }

    @Mod.EventBusSubscriber(modid = SportsMC.MODID, value = Dist.CLIENT)
    public static final class ForgeBus {
        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            while (OPEN_HUB.consumeClick()) {
                if (mc.player != null && mc.screen == null) openHub();
            }
        }

        @SubscribeEvent
        public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
            ClientLobbyData.clear();
            ClientMatchData.clear();
            ClientTennisData.clear();
            ClientAirHockeyData.clear();
            ClientCardData.clear();
            ClientBowlingData.clear();
            MatchCamera.deactivate();
        }
    }
}
