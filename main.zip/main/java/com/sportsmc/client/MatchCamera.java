package com.sportsmc.client;

import com.sportsmc.field.FieldGeometry;
import com.sportsmc.lobby.Lobby;
import com.sportsmc.network.LobbySyncPacket;
import com.sportsmc.network.MatchStatePacket;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Marker;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Broadcast-style camera for matches. Minecraft renders from a client-only "camera entity" that we
 * move every tick: behind and above the ball (carrier, ball in flight, or the line of scrimmage
 * between plays), always looking the way the team WITH the ball is going. When possession flips
 * (interception) the target heading flips, so the camera swings 180 degrees around the play.
 */
public final class MatchCamera {

    private static final float YAW_SMOOTH = 0.12f;   // ~1.5 s for a full 180
    private static final double POS_SMOOTH = 0.28;

    @Nullable private static Marker cam;
    @Nullable private static CameraType savedCameraType;
    private static float yaw;
    private static float pitch = 30f;
    private static Vec3 pos = Vec3.ZERO;
    private static Vec3 focus = Vec3.ZERO;

    private MatchCamera() {}

    public static boolean isActive() {
        return cam != null;
    }

    /** Heading the camera looks along (degrees); used to turn WASD into field directions. */
    public static float yaw() {
        return controlYaw != null ? controlYaw : yaw;
    }

    /**
     * Tennis: a high camera behind your own baseline looking down the court (like a TV / Wii Sports view),
     * sliding a little sideways with the ball. Each player sees the match from their own end.
     */
    private static void tennisTick(Minecraft mc, com.sportsmc.network.TennisStatePacket t) {
        LobbySyncPacket data = ClientLobbyData.get();
        LobbySyncPacket.FieldView fv = data == null ? null : data.field(t.fieldId());
        if (fv == null || mc.level == null || mc.player == null || !mc.level.dimension().location().equals(fv.field().dimension())) {
            deactivate();
            return;
        }
        com.sportsmc.tennis.TennisCourt court = new com.sportsmc.tennis.TennisCourt(fv.field().geometry());
        Lobby.Side side = t.viewerSide();
        int toward = court.toward(side);
        double ballZ = court.W / 2;
        Entity ballEntity = t.ballEntityId() >= 0 ? mc.level.getEntity(t.ballEntityId()) : null;
        if (ballEntity != null) ballZ = court.z(ballEntity.position());
        double follow = Math.max(-court.W * 0.4, Math.min(court.W * 0.4, ballZ - court.W / 2));

        double back = court.L * 0.3 + 3;
        double height = Math.max(7, court.L * 0.45);
        Vec3 wantedPos = court.world(court.baselineX(side) - toward * back, court.W / 2 + follow * 0.35, court.floorY + height);
        Vec3 look = court.world(court.baselineX(side) + toward * court.L * 0.55, court.W / 2 + follow * 0.5, court.floorY);

        if (cam == null) {
            cam = new Marker(EntityType.MARKER, mc.level);
            pos = wantedPos;
            savedCameraType = mc.options.getCameraType();
        }
        pos = pos.lerp(wantedPos, 0.15);
        double dx = look.x - pos.x, dz = look.z - pos.z;
        float wantedYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float wantedPitch = (float) Math.toDegrees(Math.atan2(pos.y - look.y, Math.max(0.1, Math.sqrt(dx * dx + dz * dz))));
        yaw += Mth.wrapDegrees(wantedYaw - yaw) * 0.25f;
        pitch += (wantedPitch - pitch) * 0.25f;
        controlYaw = court.netYaw(side);

        Marker c = cam;
        c.xo = c.getX();
        c.yo = c.getY();
        c.zo = c.getZ();
        c.yRotO = c.getYRot();
        c.xRotO = c.getXRot();
        c.setPos(pos.x, pos.y, pos.z);
        c.setYRot(yaw);
        c.setXRot(pitch);
        if (mc.getCameraEntity() != c) mc.setCameraEntity(c);
        if (mc.options.getCameraType() != CameraType.FIRST_PERSON) mc.options.setCameraType(CameraType.FIRST_PERSON);
    }

    @Nullable
    public static FieldGeometry activeField() {
        MatchStatePacket m = ClientMatchData.get();
        LobbySyncPacket data = ClientLobbyData.get();
        if (m == null || data == null) return null;
        LobbySyncPacket.FieldView fv = data.field(m.fieldId());
        return fv == null ? null : fv.field().geometry();
    }

    /** In tennis, W always means "toward the net", whatever small angle the camera is at. */
    @Nullable private static Float controlYaw;

    /**
     * Bowling "ball cam": while a ball is rolling in your game (yours or your opponent's), the camera rides along
     * behind it, then stops a few blocks short of the pins to watch them fly; back to your own eyes for the next ball.
     */
    private static boolean bowlingTick(Minecraft mc, com.sportsmc.network.BowlingStatePacket b) {
        LobbySyncPacket data = ClientLobbyData.get();
        LobbySyncPacket.FieldView fv = data == null ? null : data.field(b.fieldId());
        if (fv == null || mc.level == null || mc.player == null || !mc.level.dimension().location().equals(fv.field().dimension())) return false;
        com.sportsmc.bowling.BowlingLane lane = new com.sportsmc.bowling.BowlingLane(fv.field().geometry());
        com.sportsmc.bowling.BowlingPhysics.Dims d = lane.dims;
        double stop = d.headU() - Math.max(3.0, d.length() * 0.16);
        double ballU = b.ballVisible() ? b.ballU() : d.length();
        double camU = b.phase() == com.sportsmc.network.BowlingStatePacket.RESULT ? stop : Math.min(ballU - 2.6, stop);
        double ballX = b.ballVisible() && Math.abs(b.ballX()) <= d.laneHalf() ? b.ballX() : 0;
        Vec3 wantedPos = lane.world(ballX * 0.4, camU, lane.floorY() + 1.1 + d.scale() * 0.25);
        Vec3 look = lane.world(ballX * 0.25, Math.max(ballU + 1.5, d.headU() + d.rowGap()), lane.floorY() + d.pinH() * 0.4);
        if (cam == null) {
            cam = new Marker(EntityType.MARKER, mc.level);
            pos = mc.player.getEyePosition();
            yaw = mc.player.getYRot();
            pitch = mc.player.getXRot();
            savedCameraType = mc.options.getCameraType();
            cam.setPos(pos.x, pos.y, pos.z);
            cam.xo = pos.x;
            cam.yo = pos.y;
            cam.zo = pos.z;
        }
        pos = pos.lerp(wantedPos, 0.3);
        double dx = look.x - pos.x, dz = look.z - pos.z;
        float wantedYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float wantedPitch = (float) Math.toDegrees(Math.atan2(pos.y - look.y, Math.max(0.1, Math.sqrt(dx * dx + dz * dz))));
        yaw += Mth.wrapDegrees(wantedYaw - yaw) * 0.3f;
        pitch += (wantedPitch - pitch) * 0.3f;
        Marker c = cam;
        c.xo = c.getX();
        c.yo = c.getY();
        c.zo = c.getZ();
        c.yRotO = c.getYRot();
        c.xRotO = c.getXRot();
        c.setPos(pos.x, pos.y, pos.z);
        c.setYRot(yaw);
        c.setXRot(pitch);
        if (mc.getCameraEntity() != c) mc.setCameraEntity(c);
        if (mc.options.getCameraType() != CameraType.FIRST_PERSON) mc.options.setCameraType(CameraType.FIRST_PERSON);
        return true;
    }

    /** Called every client tick. */
    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        com.sportsmc.network.BowlingStatePacket bowling = ClientBowlingData.mine();
        if (bowling != null && (bowling.phase() == com.sportsmc.network.BowlingStatePacket.ROLLING
                || bowling.phase() == com.sportsmc.network.BowlingStatePacket.RESULT) && bowlingTick(mc, bowling)) {
            controlYaw = null;
            return;
        }
        com.sportsmc.network.TennisStatePacket tennis = ClientTennisData.get();
        if (tennis != null) {
            tennisTick(mc, tennis);
            return;
        }
        controlYaw = null;
        MatchStatePacket m = ClientMatchData.get();
        FieldGeometry g = activeField();
        if (m == null || g == null || mc.level == null || mc.player == null
                || !mc.level.dimension().location().equals(fieldDimension(m))) {
            deactivate();
            return;
        }

        // Where to look.
        Entity follow = m.followEntityId() >= 0 ? mc.level.getEntity(m.followEntityId()) : null;
        Vec3 target = follow != null ? follow.position() : g.at(m.ballYard(), 0, g.floorY);
        float targetYaw = g.yaw(m.possession() == Lobby.Side.HOME);

        double dist, height, lead;
        switch (m.phase()) {
            case PRE_SNAP, DEAD -> { dist = 15; height = 9.5; lead = 5; }
            case BALL_IN_AIR -> { dist = 12; height = 8; lead = 6; }
            default -> { dist = 10; height = 6.5; lead = 4; }
        }

        if (cam == null) activate(mc, target, targetYaw, dist, height);

        yaw += Mth.wrapDegrees(targetYaw - yaw) * YAW_SMOOTH;
        Vec3 fwd = Vec3.directionFromRotation(0, yaw);
        focus = focus.lerp(target, 0.35);
        Vec3 wanted = focus.subtract(fwd.scale(dist)).add(0, height, 0);
        pos = pos.lerp(wanted, POS_SMOOTH);

        Vec3 look = focus.add(fwd.scale(lead)).add(0, 1.0, 0);
        double horiz = Math.sqrt((look.x - pos.x) * (look.x - pos.x) + (look.z - pos.z) * (look.z - pos.z));
        float wantedPitch = (float) Math.toDegrees(Math.atan2(pos.y - look.y, Math.max(0.1, horiz)));
        pitch += (wantedPitch - pitch) * 0.3f;

        Marker c = cam;
        c.xo = c.getX();
        c.yo = c.getY();
        c.zo = c.getZ();
        c.yRotO = c.getYRot();
        c.xRotO = c.getXRot();
        c.setPos(pos.x, pos.y, pos.z);
        c.setYRot(yaw);
        c.setXRot(pitch);

        if (mc.getCameraEntity() != c) mc.setCameraEntity(c);
        if (mc.options.getCameraType() != CameraType.FIRST_PERSON) mc.options.setCameraType(CameraType.FIRST_PERSON);
    }

    private static void activate(Minecraft mc, Vec3 target, float targetYaw, double dist, double height) {
        cam = new Marker(EntityType.MARKER, mc.level);
        yaw = targetYaw;
        focus = target;
        pos = target.subtract(Vec3.directionFromRotation(0, yaw).scale(dist)).add(0, height, 0);
        cam.setPos(pos.x, pos.y, pos.z);
        cam.xo = pos.x;
        cam.yo = pos.y;
        cam.zo = pos.z;
        cam.setYRot(yaw);
        cam.yRotO = yaw;
        savedCameraType = mc.options.getCameraType();
        mc.setCameraEntity(cam);
    }

    public static void deactivate() {
        if (cam == null) return;
        Minecraft mc = Minecraft.getInstance();
        cam = null;
        if (mc.player != null) mc.setCameraEntity(mc.player);
        if (savedCameraType != null) mc.options.setCameraType(savedCameraType);
        savedCameraType = null;
    }

    private static net.minecraft.resources.ResourceLocation fieldDimension(MatchStatePacket m) {
        LobbySyncPacket data = ClientLobbyData.get();
        LobbySyncPacket.FieldView fv = data == null ? null : data.field(m.fieldId());
        return fv == null ? new net.minecraft.resources.ResourceLocation("minecraft", "overworld") : fv.field().dimension();
    }
}
