package com.sportsmc.client;

import com.sportsmc.lobby.Lobby;
import com.sportsmc.network.MatchStatePacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/**
 * Match HUD: a TV-style scorebug at the top (teams, score, possession, quarter, clock,
 * down & distance, play clock) and console-style button hints at the bottom that change with the situation.
 */
public final class MatchHud {

    private static final int KEY = 0xFFC83D;
    private static final int TEXT = 0xFFFFFF;
    private static final int DIM = 0xB0B0B0;
    private static final int HOME_BG = 0xE02A4FC0;
    private static final int AWAY_BG = 0xE0B8232D;
    private static final int BAR_BG = 0xD0101820;

    private MatchHud() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        MatchStatePacket m = ClientMatchData.get();
        Minecraft mc = Minecraft.getInstance();
        if (m == null || !MatchCamera.isActive() || mc.options.hideGui) return;
        Font font = mc.font;
        renderScorebug(g, font, m, width);
        renderBoost(g, font, m, width, height);
        renderHints(g, font, m, width, height);
    }

    // ------------------------------------------------------------------ scorebug

    private static void renderScorebug(GuiGraphics g, Font font, MatchStatePacket m, int width) {
        int teamW = 92, scoreW = 22, infoW = 132, h = 14;
        int total = teamW * 2 + scoreW * 2 + infoW;
        int x = width / 2 - total / 2, y = 4;

        // HOME
        g.fill(x, y, x + teamW + scoreW, y + h, HOME_BG);
        String home = (m.possession() == Lobby.Side.HOME ? "▶ " : "") + font.plainSubstrByWidth(m.homeName(), teamW - 14);
        g.drawString(font, home, x + 4, y + 3, TEXT);
        g.drawCenteredString(font, String.valueOf(m.homeScore()), x + teamW + scoreW / 2, y + 3, TEXT);
        x += teamW + scoreW;

        // AWAY
        g.fill(x, y, x + teamW + scoreW, y + h, AWAY_BG);
        g.drawCenteredString(font, String.valueOf(m.awayScore()), x + scoreW / 2, y + 3, TEXT);
        String away = (m.possession() == Lobby.Side.AWAY ? "▶ " : "") + font.plainSubstrByWidth(m.awayName(), teamW - 14);
        g.drawString(font, away, x + scoreW + 4, y + 3, TEXT);
        x += teamW + scoreW;

        // Quarter / clock / down
        g.fill(x, y, x + infoW, y + h, BAR_BG);
        String q = m.halftime() ? "HALF" : m.quarter() > 4 ? "OT" : "Q" + m.quarter();
        String clock = String.format("%d:%02d", m.clockSeconds() / 60, m.clockSeconds() % 60);
        g.drawString(font, q, x + 4, y + 3, KEY);
        g.drawString(font, clock, x + 26, y + 3, TEXT);
        g.drawString(font, m.downAndDistance(), x + 58, y + 3, TEXT);

        // Play clock under the bug when it matters
        if (m.playClock() >= 0 && m.phase() == MatchStatePacket.Phase.PRE_SNAP) {
            String pc = ":" + String.format("%02d", m.playClock());
            int color = m.playClock() <= 5 ? 0xFF5555 : TEXT;
            int px = width / 2 + total / 2 - 26;
            g.fill(px, y + h, px + 26, y + h + 11, BAR_BG);
            g.drawCenteredString(font, pc, px + 13, y + h + 2, color);
        }
    }

    // ------------------------------------------------------------------ boost bar

    private static void renderBoost(GuiGraphics g, Font font, MatchStatePacket m, int width, int height) {
        if (m.phase() != MatchStatePacket.Phase.LIVE && m.phase() != MatchStatePacket.Phase.BALL_IN_AIR) return;
        int w = 110, h = 5, x = width / 2 - w / 2, y = height - 66;
        float s = Math.max(0f, Math.min(1f, m.boost()));
        int color = m.boostExhausted() ? 0xFFE04040 : m.boostDefense() ? 0xFFFF8A2A : 0xFF4FD0FF;
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xC0000000);
        g.fill(x, y, x + (int) (w * s), y + h, color);
        String label = m.boostExhausted() ? "BOOST EMPTY" : m.boostDefense() ? "DEFENSE BOOST (CTRL)" : "BOOST (CTRL)";
        g.drawCenteredString(font, label, width / 2, y - 9, m.boostExhausted() ? 0xFF5555 : 0xB0B0B0);
    }

    // ------------------------------------------------------------------ button hints

    private static void renderHints(GuiGraphics g, Font font, MatchStatePacket m, int width, int height) {
        boolean offense = m.hint(MatchStatePacket.HINT_OFFENSE);
        boolean kickPlay = m.hint(MatchStatePacket.HINT_KICK_PLAY);
        String[][] hints;
        String title;

        if (m.halftime()) {
            title = "Halftime";
            hints = new String[0][];
        } else switch (m.phase()) {
            case PRE_SNAP -> {
                if (m.hint(MatchStatePacket.HINT_KICKOFF)) {
                    title = offense ? "Kickoff - you're kicking" : "Kickoff - get ready to return it";
                    hints = offense ? new String[][]{{"SPACE", "Kick off"}} : new String[][]{{"Right-click", "Switch player"}};
                } else if (offense) {
                    if (m.hint(MatchStatePacket.HINT_TRY)) {
                        boolean kickingIt = m.callName().equals("Extra Point");
                        title = kickingIt ? "Extra point attempt (1 pt)" : "Two-point try: " + m.callName();
                        hints = new String[][]{{"SPACE", "Snap"}, {"R", kickingIt ? "Go for two instead" : "Change play / kick"}};
                    } else if (m.down() == 4) {
                        title = "4th down - Play: " + m.callName();
                        hints = new String[][]{{"SPACE", "Snap"}, {"R", "Change play (Punt / Field Goal)"}};
                    } else {
                        title = "Play: " + m.callName();
                        hints = new String[][]{{"SPACE", "Snap"}, {"R", "Change play"}};
                    }
                } else {
                    title = "Defense: " + m.callName();
                    hints = new String[][]{{"R", "Change coverage"}, {"Right-click", "Switch player"}};
                }
            }
            case DEAD -> {
                title = "Whistle - next play coming up";
                hints = new String[0][];
            }
            default -> {
                if (m.hint(MatchStatePacket.HINT_CAN_THROW)) {
                    title = m.hint(MatchStatePacket.HINT_RUN_PLAY) ? "Run play - G to hand off, or throw" : "In the pocket - green = open";
                    hints = new String[][]{{"1 2 3", "Throw to receiver"}, {"G", "Hand off"}, {"WASD", "Scramble"}, {"CTRL", "Sprint"}};
                } else if (m.hint(MatchStatePacket.HINT_CARRIER)) {
                    title = kickPlay && m.phase() == MatchStatePacket.Phase.LIVE && offense ? "Kicking..." : "Ball carrier";
                    hints = new String[][]{{"Z / C", "Juke"}, {"SPACE", "Hurdle"}, {"CTRL", "Sprint"}};
                } else if (m.phase() == MatchStatePacket.Phase.BALL_IN_AIR && kickPlay) {
                    title = offense ? "Cover the kick!" : "Get under it!";
                    hints = new String[][]{{"WASD", "Move"}, {"CTRL", "Sprint"}};
                } else if (offense) {
                    title = m.phase() == MatchStatePacket.Phase.BALL_IN_AIR ? "Ball's in the air - get under it!" : "Block for your runner";
                    hints = new String[][]{{"WASD", "Move"}, {"SPACE", "Jump"}, {"CTRL", "Sprint"}};
                } else {
                    title = m.phase() == MatchStatePacket.Phase.BALL_IN_AIR ? "Ball's in the air - jump the route!" : "Bring him down";
                    hints = new String[][]{{"Left-click", "Dive tackle"}, {"Right-click", "Switch player"}, {"SPACE", "Jump"}, {"CTRL", "Sprint"}};
                }
            }
        }

        int y = height - 52;
        int tw = font.width(title);
        g.fill(width / 2 - tw / 2 - 6, y - 3, width / 2 + tw / 2 + 6, y + 10, 0x88000000);
        g.drawCenteredString(font, title, width / 2, y, TEXT);

        if (hints.length == 0) return;
        int total = 0;
        for (String[] h : hints) total += font.width("[" + h[0] + "] ") + font.width(h[1]) + 14;
        int x = width / 2 - total / 2;
        int hy = y + 15;
        g.fill(x - 6, hy - 3, x + total + 2, hy + 10, 0x88000000);
        for (String[] h : hints) {
            String k = "[" + h[0] + "] ";
            g.drawString(font, k, x, hy, KEY);
            x += font.width(k);
            g.drawString(font, h[1], x, hy, DIM);
            x += font.width(h[1]) + 14;
        }
    }
}
