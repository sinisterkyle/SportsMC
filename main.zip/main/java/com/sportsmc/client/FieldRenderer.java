package com.sportsmc.client;

import com.sportsmc.SportsMC;
import com.sportsmc.field.FieldData;
import com.sportsmc.field.FieldGeometry;
import com.sportsmc.field.FieldType;
import com.sportsmc.item.FieldBlueprintItem;
import com.sportsmc.lobby.Lobby;
import com.sportsmc.network.LobbySyncPacket;
import com.sportsmc.network.MatchStatePacket;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

/**
 * Broadcast-style "virtual" field lines. Nothing is placed in the world - these are thin neon lines drawn on the ground.
 *
 * In a match (only what matters, like a broadcast):
 *   - always: a thin neon outline around the whole field, goal lines, pylons; the end zone the offense is
 *     attacking glows, the other is dim;
 *   - between plays only: blue line of scrimmage (the offsides line) and yellow first-down line
 *     (no yellow line on "& Goal"); both hide while the ball is live and fade back in after the whistle.
 *
 * Holding a Field Blueprint: the field you're measuring (corner markers, end zones added past the goal lines,
 * faint 10-yard ticks to check the scale) and every saved field in this dimension, dimmed.
 */
@Mod.EventBusSubscriber(modid = SportsMC.MODID, value = Dist.CLIENT)
public final class FieldRenderer {

    // Neon palette (r, g, b)
    private static final float[] OUTLINE = {0.55f, 1.00f, 0.90f};   // mint
    private static final float[] SCRIMMAGE = {0.20f, 0.55f, 1.00f}; // blue
    private static final float[] FIRST_DOWN = {1.00f, 0.90f, 0.10f}; // yellow
    private static final float[] END_ZONE = {1.00f, 0.25f, 0.85f};  // magenta
    private static final float[] PYLON = {1.00f, 0.50f, 0.10f};     // orange
    private static final float[] HOME_COLOR = {0.35f, 0.60f, 1.00f};
    private static final float[] AWAY_COLOR = {1.00f, 0.35f, 0.35f};
    private static final float[] WHITE = {1f, 1f, 1f};
    private static final float[] TENNIS_LINE = {0.80f, 1.00f, 0.25f}; // tennis-ball lime

    private static final double LIFT = 0.03;   // keep lines just above the grass
    private static final double GLOW = 0.06;   // spacing of the faint "glow" lines beside each core line
    private static final long FADE_MS = 450;

    private FieldRenderer() {}

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        ItemStack blueprint = ClientHooks.heldBlueprint();
        MatchStatePacket match = ClientMatchData.get();
        LobbySyncPacket data = ClientLobbyData.get();
        FieldData matchField = null;
        if (match != null && data != null) {
            LobbySyncPacket.FieldView fv = data.field(match.fieldId());
            if (fv != null) matchField = fv.field();
        }
        com.sportsmc.network.TennisStatePacket tennis = ClientTennisData.get();
        FieldData tennisField = null;
        if (tennis != null && data != null) {
            LobbySyncPacket.FieldView fv = data.field(tennis.fieldId());
            if (fv != null) tennisField = fv.field();
        }
        // (No early exit: bowling lanes and the OPEN / OCCUPIED signs show whenever you're near a saved field.)

        String dim = mc.level.dimension().location().toString();
        PoseStack ps = event.getPoseStack();
        Vec3 cam = event.getCamera().getPosition();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer vc = buffers.getBuffer(RenderType.lines());

        long now = System.currentTimeMillis();
        float pulse = 0.85f + 0.15f * Mth.sin((now % 1_000_000L) / 320f);

        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);

        if (matchField != null && matchField.dimension().toString().equals(dim)) {
            drawMatch(ps, vc, matchField.geometry(), match, pulse, now);
            drawControlRing(ps, vc, mc, match, event.getPartialTick(), pulse);
        }
        if (tennisField != null && tennisField.dimension().toString().equals(dim)) {
            drawTennisCourt(ps, vc, tennisField.geometry(), 1f, 2); // singles uses the full court too
            drawHawkEye(ps, vc, tennis, tennisField.geometry().floorY, pulse);
            drawServeBox(ps, vc, tennis, tennisField.geometry(), pulse);
            drawRing(ps, vc, mc, tennis.controlledEntityId(), tennis.viewerSide(), event.getPartialTick(), pulse);
            drawRing(ps, vc, mc, tennis.partnerEntityId(), tennis.viewerSide(), event.getPartialTick(), pulse);
            drawBallMarker(ps, vc, mc, tennis.ballEntityId(), tennisField.geometry().floorY, event.getPartialTick());
        }

        // Bowling lanes: their markings are always shown (they're what makes a strip of floor a lane).
        if (data != null) {
            for (LobbySyncPacket.FieldView fv : data.fields()) {
                FieldData f = fv.field();
                if (f.type() != FieldType.BOWLING || !f.dimension().toString().equals(dim)) continue;
                if (f.geometry().center().distanceTo(cam) > 80 + f.geometry().length() / 2) continue;
                drawBowlingLane(ps, vc, f.geometry(), blueprint.isEmpty() ? 0.75f : 0.45f);
                drawAimLine(ps, vc, f, pulse);
            }
        }

        if (!blueprint.isEmpty()) {
            if (data != null) {
                for (LobbySyncPacket.FieldView fv : data.fields()) {
                    if (fv.field() != matchField && fv.field() != tennisField && fv.field().type() != FieldType.BOWLING
                            && fv.field().dimension().toString().equals(dim)) {
                        drawSavedField(ps, vc, fv.field().geometry(), fv.field().type());
                    }
                }
            }
            String bpDim = FieldBlueprintItem.getDimension(blueprint);
            if (bpDim == null || bpDim.equals(dim)) drawBlueprint(ps, vc, blueprint, pulse);
        }

        ps.popPose();
        buffers.endBatch(RenderType.lines());
        if (data != null) drawSigns(event, mc, data, dim, cam);
    }

    // ------------------------------------------------------------------ OPEN / OCCUPIED signs

    /**
     * A floating sign over every saved field, court and lane within 40 blocks: its name, and OPEN (green) or
     * OCCUPIED (red) while a game is being played on it.
     */
    private static void drawSigns(RenderLevelStageEvent event, Minecraft mc, LobbySyncPacket data, String dim, Vec3 cam) {
        PoseStack ps = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        net.minecraft.client.gui.Font font = mc.font;
        boolean any = false;
        for (LobbySyncPacket.FieldView fv : data.fields()) {
            FieldData f = fv.field();
            if (!f.dimension().toString().equals(dim)) continue;
            FieldGeometry g = f.geometry();
            Vec3 at;
            if (f.type() == FieldType.BOWLING) {
                // High over the pin end, like the lane numbers in a real alley (out of the bowler's way).
                com.sportsmc.bowling.BowlingLane lane = new com.sportsmc.bowling.BowlingLane(g);
                at = lane.world(0, lane.dims.length() + 0.3, g.floorY + 2.2);
            } else {
                at = g.center().add(0, f.type() == FieldType.TENNIS ? 3.5 : 5.0, 0);
            }
            double dist = at.distanceTo(cam);
            if (dist > (f.type() == FieldType.BOWLING ? 40 + g.length() : 40) || dist < 1.0) continue;
            any = true;
            ps.pushPose();
            ps.translate(at.x - cam.x, at.y - cam.y, at.z - cam.z);
            ps.mulPose(event.getCamera().rotation());
            float scale = 0.025f * (float) Math.max(1.0, dist / 12.0);
            ps.scale(-scale, -scale, scale);
            org.joml.Matrix4f m = ps.last().pose();
            String name = f.name();
            String status = fv.inUse() ? "OCCUPIED" : "OPEN";
            int statusColor = fv.inUse() ? 0xFFFF5050 : 0xFF55FF6A;
            int bg = 0x60000000;
            int light = 0xF000F0;
            font.drawInBatch(name, -font.width(name) / 2f, -10, 0xFFFFFFFF, false, m, buffers,
                    net.minecraft.client.gui.Font.DisplayMode.NORMAL, bg, light);
            font.drawInBatch(status, -font.width(status) / 2f, 0, statusColor, false, m, buffers,
                    net.minecraft.client.gui.Font.DisplayMode.NORMAL, bg, light);
            ps.popPose();
        }
        if (any) buffers.endBatch();
    }

    // ------------------------------------------------------------------ bowling

    private static final float[] LANE_WOOD = {1.00f, 0.80f, 0.45f};
    private static final float[] FOUL = {1.00f, 0.25f, 0.25f};

    /**
     * A bowling lane: gutters, the foul line, approach dots, the seven target arrows a third of the way down,
     * the pin spots and the edge of the pit. Sizes follow the real lane, scaled to the width you built.
     */
    private static void drawBowlingLane(PoseStack ps, VertexConsumer vc, FieldGeometry g, float a) {
        com.sportsmc.bowling.BowlingLane lane = new com.sportsmc.bowling.BowlingLane(g);
        com.sportsmc.bowling.BowlingPhysics.Dims d = lane.dims;
        double y = g.floorY + LIFT, L = d.length(), lh = d.laneHalf(), hw = d.halfWidth();
        // Lane edges (where the gutters start) and the outside of the gutters.
        for (double x : new double[]{-lh, lh}) seg(ps, vc, lane.world(x, 0, y), lane.world(x, L, y), LANE_WOOD, a);
        for (double x : new double[]{-hw, hw}) seg(ps, vc, lane.world(x, 0, y), lane.world(x, L, y), WHITE, a * 0.4f);
        // Foul line (glowing), and the end of the lane at the pit.
        seg(ps, vc, lane.world(-hw, 0, y + 0.002), lane.world(hw, 0, y + 0.002), FOUL, a);
        seg(ps, vc, lane.world(-hw, 0.04, y), lane.world(hw, 0.04, y), FOUL, a * 0.35f);
        seg(ps, vc, lane.world(-hw, L, y), lane.world(hw, L, y), WHITE, a * 0.5f);
        // Approach dots behind the foul line and range dots on the lane.
        for (int b = 1; b <= 7; b++) {
            double x = -lh + b * 5 / 39.0 * 2 * lh;
            cross(ps, vc, lane, x, -0.5, y, d.scale() * 0.03, WHITE, a * 0.6f);
            if (b != 4) cross(ps, vc, lane, x, d.headU() * 0.12, y, d.scale() * 0.025, WHITE, a * 0.5f);
        }
        // Target arrows: little chevrons pointing at the pins, the middle one furthest down the lane.
        double arrowU = d.headU() * 0.25, size = d.scale() * 0.06;
        for (int b = 1; b <= 7; b++) {
            double x = -lh + b * 5 / 39.0 * 2 * lh;
            double u = arrowU + (4 - Math.abs(b - 4)) * d.scale() * 0.09;
            seg(ps, vc, lane.world(x - size, u - size * 1.6, y), lane.world(x, u, y), LANE_WOOD, a);
            seg(ps, vc, lane.world(x + size, u - size * 1.6, y), lane.world(x, u, y), LANE_WOOD, a);
        }
        // Pin spots and the front of the pin deck.
        for (int i = 0; i < 10; i++) cross(ps, vc, lane, d.pinX(i), d.pinU(i), y, d.pinR() * 0.8, WHITE, a * 0.5f);
        double deck = d.headU() - d.rowGap();
        seg(ps, vc, lane.world(-lh, deck, y), lane.world(lh, deck, y), WHITE, a * 0.25f);
    }

    /** Your aim while you line up a ball: a dotted line from your spot (the hook will bend the real path). */
    private static void drawAimLine(PoseStack ps, VertexConsumer vc, FieldData f, float pulse) {
        com.sportsmc.network.BowlingStatePacket mine = ClientBowlingData.mine();
        if (mine == null || !f.id().equals(mine.fieldId()) || !ClientBowlingData.myTurnToAim()) return;
        com.sportsmc.bowling.BowlingLane lane = new com.sportsmc.bowling.BowlingLane(f.geometry());
        com.sportsmc.bowling.BowlingPhysics.Dims d = lane.dims;
        double sx = com.sportsmc.client.screen.BowlingThrowScreen.start * (d.laneHalf() - d.ballR());
        double tan = Math.tan(Math.toRadians(com.sportsmc.client.screen.BowlingThrowScreen.aim));
        double y = f.geometry().floorY + LIFT + 0.01;
        float[] cyan = {0.37f, 0.82f, 1f};
        double step = 0.5, end = d.headU() * 0.6;
        for (double u = 0; u < end; u += step * 2) {
            double x0 = sx + tan * u, x1 = sx + tan * (u + step);
            if (Math.abs(x1) > d.laneHalf()) break;
            seg(ps, vc, lane.world(x0, u, y), lane.world(x1, u + step, y), cyan, pulse);
        }
    }

    private static void cross(PoseStack ps, VertexConsumer vc, com.sportsmc.bowling.BowlingLane lane, double x, double u, double y,
                              double r, float[] c, float a) {
        seg(ps, vc, lane.world(x - r, u, y), lane.world(x + r, u, y), c, a);
        seg(ps, vc, lane.world(x, u - r, y), lane.world(x, u + r, y), c, a);
    }

    // ------------------------------------------------------------------ in a match

    private static void drawMatch(PoseStack ps, VertexConsumer vc, FieldGeometry g, MatchStatePacket m, float pulse, long now) {
        double y = g.floorY + LIFT;

        outline(ps, vc, g, y, OUTLINE, 0.9f * pulse);

        // Which end zone is the offense going for? HOME attacks AWAY's end (B), and vice versa.
        boolean attackingB = m.possession() == Lobby.Side.HOME;
        float bright = pulse, dim = 0.30f;
        endZone(ps, vc, g, true, y, END_ZONE, attackingB ? dim : bright);
        endZone(ps, vc, g, false, y, END_ZONE, attackingB ? bright : dim);
        pylons(ps, vc, g, 0.9f);

        goalPosts(ps, vc, g, 0.95f);

        if (m.betweenPlays() && !m.hint(MatchStatePacket.HINT_KICKOFF)) {
            float fade = Mth.clamp((now - ClientMatchData.phaseChangedAt()) / (float) FADE_MS, 0f, 1f);
            neonAcross(ps, vc, g, g.uAtYard(m.ballYard()), y + 0.005, SCRIMMAGE, fade * pulse);
            if (!m.goalToGo()) {
                neonAcross(ps, vc, g, g.uAtYard(m.firstDownYard()), y + 0.005, FIRST_DOWN, fade * pulse);
            }
        }
    }

    /** Neon ring under the player you're controlling (like a console football game's player icon). */
    private static void drawControlRing(PoseStack ps, VertexConsumer vc, Minecraft mc, MatchStatePacket m, float partial, float pulse) {
        drawRing(ps, vc, mc, m.controlledEntityId(), m.viewerSide(), partial, pulse);
    }

    private static void drawRing(PoseStack ps, VertexConsumer vc, Minecraft mc, int entityId, Lobby.Side side, float partial, float pulse) {
        if (entityId < 0 || mc.level == null) return;
        net.minecraft.world.entity.Entity e = mc.level.getEntity(entityId);
        if (e == null) return;
        double x = Mth.lerp(partial, e.xo, e.getX());
        double y = Mth.lerp(partial, e.yo, e.getY()) + 0.05;
        double z = Mth.lerp(partial, e.zo, e.getZ());
        float[] c = side == Lobby.Side.HOME ? HOME_COLOR : AWAY_COLOR;
        int n = 20;
        for (double r : new double[]{0.7, 0.78}) {
            for (int i = 0; i < n; i++) {
                double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
                seg(ps, vc, new Vec3(x + Math.cos(a0) * r, y, z + Math.sin(a0) * r),
                        new Vec3(x + Math.cos(a1) * r, y, z + Math.sin(a1) * r), c, r < 0.75 ? pulse : 0.4f * pulse);
            }
        }
        // Little marker above the head too, so you can find yourself in a crowd.
        seg(ps, vc, new Vec3(x, y + 2.3, z), new Vec3(x, y + 2.7, z), c, pulse);
    }

    /**
     * Tennis: a small ring on the court right under the ball and a faint line up to it, so you can judge
     * where and how high the ball is from the high camera.
     */
    private static void drawBallMarker(PoseStack ps, VertexConsumer vc, Minecraft mc, int ballId, int floorY, float partial) {
        if (ballId < 0 || mc.level == null) return;
        net.minecraft.world.entity.Entity b = mc.level.getEntity(ballId);
        if (b == null) return;
        double x = Mth.lerp(partial, b.xo, b.getX());
        double y = Mth.lerp(partial, b.yo, b.getY());
        double z = Mth.lerp(partial, b.zo, b.getZ());
        double fy = floorY + LIFT + 0.01;
        double height = Math.max(0, y - fy);
        double r = 0.18 + Math.min(0.35, height * 0.06); // grows a little the higher the ball is
        int n = 14;
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            seg(ps, vc, new Vec3(x + Math.cos(a0) * r, fy, z + Math.sin(a0) * r),
                    new Vec3(x + Math.cos(a1) * r, fy, z + Math.sin(a1) * r), TENNIS_LINE, 0.9f);
        }
        if (height > 0.3) seg(ps, vc, new Vec3(x, fy, z), new Vec3(x, y - 0.12, z), TENNIS_LINE, 0.25f);
    }

    /**
     * While serving, the service box the serve has to land in glows gold. It stops at the singles sideline
     * (the doubles alley next to it is a fault, even in doubles).
     */
    private static void drawServeBox(PoseStack ps, VertexConsumer vc, com.sportsmc.network.TennisStatePacket t, FieldGeometry g, float pulse) {
        if (t.serveBox() == 0) return;
        com.sportsmc.tennis.TennisCourt court = new com.sportsmc.tennis.TennisCourt(g);
        Lobby.Side recv = t.serving().opposite();
        double n = court.netX(), sd = court.serviceDist();
        double x0 = n, x1 = recv == Lobby.Side.HOME ? n - sd : n + sd;
        double half = court.W / 2 - court.singlesInset();
        double r0 = t.serveBox() == 1 ? 0 : -half, r1 = t.serveBox() == 1 ? half : 0;
        double z0 = court.zFromRight(recv, r0), z1 = court.zFromRight(recv, r1);
        float[] gold = {1f, 0.82f, 0.2f};
        double y = g.floorY + LIFT + 0.015;
        Vec3 a = court.world(x0, z0, y), b = court.world(x1, z0, y), c = court.world(x1, z1, y), d = court.world(x0, z1, y);
        seg(ps, vc, a, b, gold, pulse);
        seg(ps, vc, b, c, gold, pulse);
        seg(ps, vc, c, d, gold, pulse);
        seg(ps, vc, d, a, gold, pulse);
        // Faint hatching so the target area reads as a filled box from the high camera.
        for (int i = 1; i < 6; i++) {
            double f = i / 6.0;
            seg(ps, vc, court.world(x0 + (x1 - x0) * f, z0, y), court.world(x0 + (x1 - x0) * f, z1, y), gold, 0.25f * pulse);
        }
    }

    /** Hawk-Eye: a mark where the last shot landed - green if it was in, red if it was out. */
    private static void drawHawkEye(PoseStack ps, VertexConsumer vc, com.sportsmc.network.TennisStatePacket t, int floorY, float pulse) {
        if (t.mark() == 0) return;
        float[] c = t.mark() == 1 ? new float[]{0.3f, 1f, 0.35f} : new float[]{1f, 0.25f, 0.25f};
        double y = floorY + LIFT + 0.02, x = t.markX(), z = t.markZ();
        int n = 16;
        for (double r : new double[]{0.14, 0.24}) {
            for (int i = 0; i < n; i++) {
                double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
                seg(ps, vc, new Vec3(x + Math.cos(a0) * r, y, z + Math.sin(a0) * r),
                        new Vec3(x + Math.cos(a1) * r, y, z + Math.sin(a1) * r), c, pulse);
            }
        }
        if (t.mark() == 2) {
            seg(ps, vc, new Vec3(x - 0.2, y, z - 0.2), new Vec3(x + 0.2, y, z + 0.2), c, pulse);
            seg(ps, vc, new Vec3(x - 0.2, y, z + 0.2), new Vec3(x + 0.2, y, z - 0.2), c, pulse);
        }
    }

    // ------------------------------------------------------------------ blueprint / saved fields

    private static void drawBlueprint(PoseStack ps, VertexConsumer vc, ItemStack stack, float pulse) {
        List<BlockPos> points = FieldBlueprintItem.getPoints(stack);
        FieldType type = FieldBlueprintItem.getType(stack);
        for (int i = 0; i < Math.min(points.size(), 2); i++) {
            float[] c = type == FieldType.TENNIS ? TENNIS_LINE : i == 0 ? HOME_COLOR : AWAY_COLOR;
            BlockPos p = points.get(i);
            LevelRenderer.renderLineBox(ps, vc, new AABB(p).inflate(0.004), c[0], c[1], c[2], 1f);
            // A tall beacon so the corner can be found from across the field.
            seg(ps, vc, new Vec3(p.getX() + 0.5, p.getY() + 1, p.getZ() + 0.5),
                    new Vec3(p.getX() + 0.5, p.getY() + 6, p.getZ() + 0.5), c, pulse);
        }

        FieldGeometry.Result r = FieldBlueprintItem.layout(stack);
        if (r == null || !r.ok()) return;
        FieldGeometry g = r.geometry();
        double y = g.floorY + LIFT;
        if (type == FieldType.TENNIS) {
            drawTennisCourt(ps, vc, g, pulse);
            return;
        }
        if (type == FieldType.BOWLING) {
            drawBowlingLane(ps, vc, g, pulse);
            return;
        }

        outline(ps, vc, g, y, OUTLINE, pulse);
        endZone(ps, vc, g, true, y, HOME_COLOR, pulse);
        endZone(ps, vc, g, false, y, AWAY_COLOR, pulse);
        pylons(ps, vc, g, 1f);
        goalPosts(ps, vc, g, 0.8f);
        // Faint 10-yard ticks so the builder can check the scale; midfield a bit brighter.
        for (int yard = 10; yard <= 90; yard += 10) {
            line(ps, vc, g, g.uAtYard(yard), y, WHITE, yard == 50 ? 0.7f : 0.3f);
        }
    }

    private static void drawSavedField(PoseStack ps, VertexConsumer vc, FieldGeometry g, FieldType type) {
        if (type == FieldType.TENNIS) {
            drawTennisCourt(ps, vc, g, 0.35f);
            return;
        }
        double y = g.floorY + LIFT;
        outline(ps, vc, g, y, OUTLINE, 0.35f);
        line(ps, vc, g, g.goalA, y, END_ZONE, 0.35f);
        line(ps, vc, g, g.goalB, y, END_ZONE, 0.35f);
    }

    /**
     * Tennis court from its two clicked corners (baselines and doubles sidelines), using regulation
     * proportions: 78 ft long, 36 ft wide, singles sidelines 4.5 ft in, service lines 21 ft from the net,
     * center service line, center marks, and the net (3.5 ft at the posts, 3 ft outside the court).
     */
    private static void drawTennisCourt(PoseStack ps, VertexConsumer vc, FieldGeometry g, float a) {
        drawTennisCourt(ps, vc, g, a, 0);
    }

    /**
     * @param inPlay 0 = just showing the court (blueprint / saved), 1 = singles match, 2 = doubles match.
     *               During a match the boundary that counts glows bright and the unused alleys are dimmed.
     */
    private static void drawTennisCourt(PoseStack ps, VertexConsumer vc, FieldGeometry g, float a, int inPlay) {
        double y = g.floorY + LIFT;
        double single = 4.5 / 36.0;          // singles sideline, as a fraction of the width
        double service = 18.0 / 78.0;        // service line, fraction of the length from each baseline
        float outer = inPlay == 1 ? a * 0.25f : a;          // doubles alleys are out in singles
        float inner = inPlay == 1 ? a : a * 0.8f;
        float[] innerColor = inPlay == 1 ? TENNIS_LINE : WHITE;
        // Outer (doubles) court.
        rect(ps, vc, g, g.uAtFraction(0), g.uAtFraction(1), y, TENNIS_LINE, outer);
        if (inPlay == 1) {
            // Singles boundary: baselines between the singles sidelines, drawn bright.
            for (double fu : new double[]{0, 1}) {
                seg(ps, vc, g.world(g.uAtFraction(fu), g.vAtFraction(single), y + 0.002),
                        g.world(g.uAtFraction(fu), g.vAtFraction(1 - single), y + 0.002), TENNIS_LINE, a);
            }
        }
        // Singles sidelines (full length).
        for (double fv : new double[]{single, 1 - single}) {
            seg(ps, vc, g.world(g.uAtFraction(0), g.vAtFraction(fv), y + 0.002), g.world(g.uAtFraction(1), g.vAtFraction(fv), y + 0.002), innerColor, inner);
        }
        // Service lines (between the singles sidelines) and the center service line.
        for (double fu : new double[]{service, 1 - service}) {
            seg(ps, vc, g.world(g.uAtFraction(fu), g.vAtFraction(single), y), g.world(g.uAtFraction(fu), g.vAtFraction(1 - single), y), WHITE, a * 0.8f);
        }
        seg(ps, vc, g.world(g.uAtFraction(service), g.vAtFraction(0.5), y), g.world(g.uAtFraction(1 - service), g.vAtFraction(0.5), y), WHITE, a * 0.8f);
        // Center marks on both baselines.
        double mark = 0.6 / 78.0;
        seg(ps, vc, g.world(g.uAtFraction(0), g.vAtFraction(0.5), y), g.world(g.uAtFraction(mark), g.vAtFraction(0.5), y), WHITE, a * 0.8f);
        seg(ps, vc, g.world(g.uAtFraction(1), g.vAtFraction(0.5), y), g.world(g.uAtFraction(1 - mark), g.vAtFraction(0.5), y), WHITE, a * 0.8f);
        // Net: posts 3 ft outside the doubles sidelines, cord 3.5 ft high at the posts and 3 ft at the center.
        double blocksPerFoot = g.length() / 78.0;
        double postOut = 3.0 / 36.0;
        double postH = Math.max(0.9, 3.5 * blocksPerFoot), midH = Math.max(0.8, 3.0 * blocksPerFoot);
        double un = g.uAtFraction(0.5);
        Vec3 p0 = g.world(un, g.vAtFraction(-postOut), g.floorY), p1 = g.world(un, g.vAtFraction(1 + postOut), g.floorY);
        Vec3 mid = g.world(un, g.vAtFraction(0.5), g.floorY);
        seg(ps, vc, p0, p0.add(0, postH, 0), WHITE, a);
        seg(ps, vc, p1, p1.add(0, postH, 0), WHITE, a);
        seg(ps, vc, p0.add(0, postH, 0), mid.add(0, midH, 0), WHITE, a);
        seg(ps, vc, mid.add(0, midH, 0), p1.add(0, postH, 0), WHITE, a);
        seg(ps, vc, p0.add(0, 0.05, 0), p1.add(0, 0.05, 0), WHITE, a * 0.5f);
        // A few vertical mesh strands so the net reads as a net.
        for (int i = 1; i < 8; i++) {
            double fv = -postOut + (1 + 2 * postOut) * i / 8.0;
            double h = midH + (postH - midH) * Math.abs(fv - 0.5) / (0.5 + postOut);
            Vec3 b = g.world(un, g.vAtFraction(fv), g.floorY);
            seg(ps, vc, b, b.add(0, h, 0), WHITE, a * 0.35f);
        }
    }

    // ------------------------------------------------------------------ shapes

    /** Thin neon rectangle around the whole field, end zones included. */
    private static void outline(PoseStack ps, VertexConsumer vc, FieldGeometry g, double y, float[] c, float a) {
        rect(ps, vc, g, g.backA, g.backB, y, c, a);
        rect(ps, vc, g, g.backA + inward(g, true) * GLOW, g.backB + inward(g, false) * GLOW, y, c, a * 0.3f, GLOW);
    }

    /** End zone outline (the area between its end line and goal line) with a glowing goal line. */
    private static void endZone(PoseStack ps, VertexConsumer vc, FieldGeometry g, boolean home, double y, float[] c, float a) {
        double back = home ? g.backA : g.backB;
        double goal = home ? g.goalA : g.goalB;
        rect(ps, vc, g, back, goal, y + 0.002, c, a * 0.6f);
        neonAcross(ps, vc, g, goal, y + 0.004, c, a);
    }

    private static void pylons(PoseStack ps, VertexConsumer vc, FieldGeometry g, float a) {
        double size = Math.max(0.12, 0.25 * g.blocksPerYard());
        for (double u : new double[]{g.goalA, g.goalB}) {
            for (double v : new double[]{g.side0, g.side1}) {
                Vec3 p = g.world(u, v, g.floorY);
                LevelRenderer.renderLineBox(ps, vc,
                        new AABB(p.x - size, p.y, p.z - size, p.x + size, p.y + Math.max(0.8, 1.5 * g.blocksPerYard()), p.z + size),
                        PYLON[0], PYLON[1], PYLON[2], a);
            }
        }
    }

    /**
     * Neon goalposts centred on each end line: a post up to the crossbar, a crossbar 18.5 ft wide (6.17 yd)
     * at 10 ft (3.33 yd), and uprights. Sizes scale with the field's blocks-per-yard (with sensible minimums).
     */
    private static void goalPosts(PoseStack ps, VertexConsumer vc, FieldGeometry g, float a) {
        double bpy = g.blocksPerYard();
        double bar = Math.max(2.5, 3.33 * bpy);
        double half = Math.max(1.6, 3.08 * bpy);
        double upr = Math.max(4.0, 10.0 * bpy);
        float[] c = {1.0f, 0.95f, 0.2f};
        for (double u : new double[]{g.backA, g.backB}) {
            double y = g.floorY;
            Vec3 base = g.world(u, g.vCenter(), y);
            Vec3 barMid = g.world(u, g.vCenter(), y + bar);
            Vec3 left = g.world(u, g.vCenter() - half, y + bar);
            Vec3 right = g.world(u, g.vCenter() + half, y + bar);
            seg(ps, vc, base, barMid, c, a);
            seg(ps, vc, left, right, c, a);
            seg(ps, vc, left, left.add(0, upr, 0), c, a);
            seg(ps, vc, right, right.add(0, upr, 0), c, a);
        }
    }

    /** A core line across the field plus two faint parallel lines, which reads as a soft neon glow. */
    private static void neonAcross(PoseStack ps, VertexConsumer vc, FieldGeometry g, double u, double y, float[] c, float a) {
        if (a <= 0.01f) return;
        line(ps, vc, g, u, y, c, a);
        line(ps, vc, g, u - GLOW, y, c, a * 0.3f);
        line(ps, vc, g, u + GLOW, y, c, a * 0.3f);
    }

    private static void line(PoseStack ps, VertexConsumer vc, FieldGeometry g, double u, double y, float[] c, float a) {
        seg(ps, vc, g.world(u, g.side0, y), g.world(u, g.side1, y), c, a);
    }

    private static void rect(PoseStack ps, VertexConsumer vc, FieldGeometry g, double u0, double u1, double y, float[] c, float a) {
        rect(ps, vc, g, u0, u1, y, c, a, 0);
    }

    /** Rectangle from u0..u1 along the field, inset by `inset` from both sidelines. */
    private static void rect(PoseStack ps, VertexConsumer vc, FieldGeometry g, double u0, double u1, double y,
                             float[] c, float a, double inset) {
        double v0 = g.side0 + inset, v1 = g.side1 - inset;
        Vec3 p00 = g.world(u0, v0, y), p01 = g.world(u0, v1, y), p11 = g.world(u1, v1, y), p10 = g.world(u1, v0, y);
        seg(ps, vc, p00, p01, c, a);
        seg(ps, vc, p01, p11, c, a);
        seg(ps, vc, p11, p10, c, a);
        seg(ps, vc, p10, p00, c, a);
    }

    /** Direction (in u) pointing into the field from the HOME (true) or AWAY end line. */
    private static int inward(FieldGeometry g, boolean homeEnd) {
        return homeEnd ? g.dir : -g.dir;
    }

    private static void seg(PoseStack ps, VertexConsumer vc, Vec3 a, Vec3 b, float[] c, float alpha) {
        if (alpha <= 0.01f) return;
        PoseStack.Pose pose = ps.last();
        float nx = (float) (b.x - a.x), ny = (float) (b.y - a.y), nz = (float) (b.z - a.z);
        float len = Mth.sqrt(nx * nx + ny * ny + nz * nz);
        if (len < 1.0e-4f) return;
        nx /= len; ny /= len; nz /= len;
        float al = Mth.clamp(alpha, 0f, 1f);
        vc.vertex(pose.pose(), (float) a.x, (float) a.y, (float) a.z).color(c[0], c[1], c[2], al).normal(pose.normal(), nx, ny, nz).endVertex();
        vc.vertex(pose.pose(), (float) b.x, (float) b.y, (float) b.z).color(c[0], c[1], c[2], al).normal(pose.normal(), nx, ny, nz).endVertex();
    }
}
