package com.sportsmc.client;

import com.sportsmc.lobby.Lobby;
import com.sportsmc.network.LobbySyncPacket;
import com.sportsmc.network.TennisStatePacket;
import com.sportsmc.tennis.TennisCourt;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/**
 * Tennis HUD: TV-style scoreboard (top left), sprint stamina bar, a swing cue that tells you which side the
 * ball is coming to (LEFT click / RIGHT click), the current instruction, and a controls reminder.
 */
public final class TennisHud {

    private static final int BG = 0xD0101820;
    private static final int HOME_BG = 0xE02A4FC0;
    private static final int AWAY_BG = 0xE0B8232D;
    private static final int TEXT = 0xFFFFFF;
    private static final int DIM = 0xB0B0B0;
    private static final int GOLD = 0xFFC83D;
    private static final int LIME = 0xCCF03C;

    private TennisHud() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        TennisStatePacket t = ClientTennisData.get();
        Minecraft mc = Minecraft.getInstance();
        if (t == null || !MatchCamera.isActive() || mc.options.hideGui) return;
        Font font = mc.font;
        renderScoreboard(g, font, t);
        renderStamina(g, font, t, width, height);
        renderSwingCue(g, font, t, mc, width, height, partialTick);
        renderHint(g, font, t, width, height);
    }

    // ------------------------------------------------------------------ scoreboard

    private static void renderScoreboard(GuiGraphics g, Font font, TennisStatePacket t) {
        int x = 6, y = 6, nameW = 104, cell = 22, h = 13;
        row(g, font, x, y, nameW, cell, h, HOME_BG, t.homeName(), t.homeGames(), t.homePoints(), t.serving() == Lobby.Side.HOME);
        row(g, font, x, y + h + 1, nameW, cell, h, AWAY_BG, t.awayName(), t.awayGames(), t.awayPoints(), t.serving() == Lobby.Side.AWAY);
        String info = (t.doubles() ? "Doubles" : "Singles") + "  •  first to " + t.gamesToWin() + (t.gamesToWin() == 1 ? " game" : " games");
        g.fill(x, y + 2 * h + 2, x + nameW + 2 * cell, y + 2 * h + 13, BG);
        g.drawString(font, info, x + 4, y + 2 * h + 4, DIM);
    }

    private static void row(GuiGraphics g, Font font, int x, int y, int nameW, int cell, int h, int bg,
                            String name, int games, String points, boolean serving) {
        g.fill(x, y, x + nameW, y + h, bg);
        g.drawString(font, font.plainSubstrByWidth(name, nameW - 16), x + 4, y + 3, TEXT);
        if (serving) g.drawString(font, "●", x + nameW - 10, y + 3, LIME); // serve ball
        g.fill(x + nameW, y, x + nameW + cell, y + h, BG);
        g.drawCenteredString(font, String.valueOf(games), x + nameW + cell / 2, y + 3, GOLD);
        g.fill(x + nameW + cell, y, x + nameW + 2 * cell, y + h, 0xE0FFFFFF);
        g.drawCenteredString(font, points, x + nameW + cell + cell / 2, y + 3, 0x101820);
    }

    // ------------------------------------------------------------------ stamina

    private static void renderStamina(GuiGraphics g, Font font, TennisStatePacket t, int width, int height) {
        int w = 120, h = 6, x = width / 2 - w / 2, y = height - 40;
        float s = Mth.clamp(t.stamina(), 0f, 1f);
        int color = t.exhausted() ? 0xFFE04040 : s > 0.5f ? 0xFF5CE65C : s > 0.25f ? 0xFFF0C83C : 0xFFF07830;
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xC0000000);
        g.fill(x, y, x + (int) (w * s), y + h, color);
        String label = t.exhausted() ? "TIRED - catch your breath" : "SPRINT (CTRL)";
        boolean blink = t.exhausted() && (System.currentTimeMillis() / 300) % 2 == 0;
        g.drawCenteredString(font, label, width / 2, y - 10, t.exhausted() ? (blink ? 0xFF5555 : 0xAA3333) : DIM);
    }

    // ------------------------------------------------------------------ swing cue

    /** When the ball is coming at you, shows which side it's on: LEFT click or RIGHT click. */
    private static void renderSwingCue(GuiGraphics g, Font font, TennisStatePacket t, Minecraft mc, int width, int height, float partial) {
        if (t.phase() != TennisStatePacket.Phase.RALLY || mc.level == null) return;
        Entity me = t.controlledEntityId() >= 0 ? mc.level.getEntity(t.controlledEntityId()) : null;
        Entity ball = t.ballEntityId() >= 0 ? mc.level.getEntity(t.ballEntityId()) : null;
        // Doubles: the cue is for whichever of your two players is closer to the ball.
        Entity partner = t.partnerEntityId() >= 0 ? mc.level.getEntity(t.partnerEntityId()) : null;
        if (ball != null && partner != null && (me == null || partner.distanceToSqr(ball) < me.distanceToSqr(ball))) me = partner;
        LobbySyncPacket data = ClientLobbyData.get();
        LobbySyncPacket.FieldView fv = data == null ? null : data.field(t.fieldId());
        if (me == null || ball == null || fv == null) return;
        TennisCourt court = new TennisCourt(fv.field().geometry());
        Lobby.Side side = t.viewerSide();

        Vec3 bp = ball.getPosition(partial), mp = me.getPosition(partial);
        boolean onMyHalf = court.onHalf(side, court.x(bp));
        boolean comingAtMe = ball.getDeltaMovement().dot(court.facing(side)) < 0;
        if (!onMyHalf && !comingAtMe) return;
        double dist = Math.sqrt((bp.x - mp.x) * (bp.x - mp.x) + (bp.z - mp.z) * (bp.z - mp.z));
        if (dist > 9) return;

        double lateral = bp.subtract(mp).dot(court.rightVec(side));
        boolean right = lateral >= 0;
        boolean inReach = dist < 1.75 && onMyHalf && bp.y - court.floorY > 0.15 && bp.y - court.floorY < 2.9;
        int color = inReach ? 0xFF55FF55 : 0xFFFFFFFF;
        String text = right ? "RIGHT CLICK  ▶" : "◀  LEFT CLICK";
        int y = height / 2 + 28;
        int tw = font.width(text);
        int cx = width / 2 + (right ? 46 : -46);
        g.fill(cx - tw / 2 - 5, y - 4, cx + tw / 2 + 5, y + 11, inReach ? 0xC0105010 : 0x90000000);
        g.drawCenteredString(font, text, cx, y, color);
        if (inReach) g.drawCenteredString(font, "SWING!", width / 2, y + 16, 0x55FF55);
    }

    // ------------------------------------------------------------------ instruction + controls

    private static void renderHint(GuiGraphics g, Font font, TennisStatePacket t, int width, int height) {
        if (!t.hint().isEmpty()) {
            int tw = font.width(t.hint());
            int y = height - 64;
            g.fill(width / 2 - tw / 2 - 6, y - 3, width / 2 + tw / 2 + 6, y + 10, 0x90000000);
            g.drawCenteredString(font, t.hint(), width / 2, y, t.phase() == TennisStatePacket.Phase.POINT_OVER ? GOLD : TEXT);
        }
        String controls = "[WASD] move  [CTRL] sprint  [LMB] swing left  [RMB] swing right  [SHIFT+swing] lob  \u2022  early = cross-court, late = down the line";
        int cw = font.width(controls);
        int y = height - 26;
        g.fill(width / 2 - cw / 2 - 4, y - 2, width / 2 + cw / 2 + 4, y + 9, 0x70000000);
        g.drawCenteredString(font, controls, width / 2, y, DIM);
    }
}
