package com.sportsmc.client;

import com.sportsmc.client.screen.AirHockeyScreen;
import com.sportsmc.network.AirHockeyStatePacket;
import net.minecraft.client.Minecraft;

import javax.annotation.Nullable;

/** Latest air hockey table state. The table screen opens by itself when a match starts and closes when it ends. */
public final class ClientAirHockeyData {

    @Nullable private static AirHockeyStatePacket state;
    @Nullable private static AirHockeyStatePacket previous;
    private static long receivedAt;
    private static boolean fresh;

    private ClientAirHockeyData() {}

    @Nullable
    public static AirHockeyStatePacket get() {
        return state != null && state.active() ? state : null;
    }

    @Nullable
    public static AirHockeyStatePacket previous() {
        return previous;
    }

    /** Ticks (0..1.5) since the latest state arrived, for smooth drawing between server updates. */
    public static float ticksSinceUpdate() {
        return Math.min(1.5f, (System.nanoTime() - receivedAt) / 50_000_000f);
    }

    public static void apply(AirHockeyStatePacket packet) {
        Minecraft mc = Minecraft.getInstance();
        if (!packet.active()) {
            state = null;
            previous = null;
            if (mc.screen instanceof AirHockeyScreen) mc.setScreen(null);
            return;
        }
        boolean starting = state == null;
        previous = state;
        state = packet;
        receivedAt = System.nanoTime();
        fresh = true;
        if (starting && !(mc.screen instanceof AirHockeyScreen)) mc.setScreen(new AirHockeyScreen());
    }

    /** True once after each new state arrives (the table uses it to correct its puck). */
    public static boolean consumeFresh() {
        boolean f = fresh;
        fresh = false;
        return f;
    }

    public static void clear() {
        state = null;
        previous = null;
    }
}
