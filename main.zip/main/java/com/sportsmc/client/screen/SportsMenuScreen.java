package com.sportsmc.client.screen;

import com.sportsmc.client.ClientLobbyData;
import com.sportsmc.lobby.Lobby;
import com.sportsmc.network.LobbyActionPacket;
import com.sportsmc.network.LobbySyncPacket;
import com.sportsmc.network.ModNetwork;
import com.sportsmc.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.List;
import java.util.function.Supplier;

/**
 * The SportsMC main menu (press M): one tile per sport. Football opens its lobby / invite screen;
 * the other tiles are placeholders until those sports are added. To add a sport later, give it a
 * tile in {@link #SPORTS} with an `open` action.
 */
public class SportsMenuScreen extends Screen {

    private record Sport(String name, String tagline, Supplier<ItemStack> icon, boolean available) {}

    private static final List<Sport> SPORTS = List.of(
            new Sport("Football", "Play with friends or vs CPU", () -> new ItemStack(ModItems.FOOTBALL.get()), true),
            new Sport("Tennis", "1v1 or 2v2", () -> new ItemStack(com.sportsmc.registry.ModItems.TENNIS_BALL.get()), true),
            new Sport("Bowling", "Lanes \u2022 vs friend or CPU", () -> new ItemStack(Items.HEART_OF_THE_SEA), true),
            new Sport("Air Hockey", "Mouse vs friend", () -> new ItemStack(Items.HEAVY_WEIGHTED_PRESSURE_PLATE), true),
            new Sport("Card Dojo", "Fire • Water • Ice", () -> new ItemStack(Items.FIRE_CHARGE), true),
            new Sport("Arcade", com.sportsmc.arcade.ArcadeGame.values().length + " games", // counts itself as games are added
            () -> new ItemStack(Items.JUKEBOX), true)
    );

    private static final int COLS = 3;
    private static final int TILE_W = 120;
    private static final int TILE_H = 74;
    private static final int GAP = 8;

    private static final int COLOR_TILE = 0xC0101820;
    private static final int COLOR_TILE_OFF = 0x80101820;
    private static final int COLOR_BORDER = 0xFFFFC83D;
    private static final int COLOR_TEXT = 0xFFFFFF;
    private static final int COLOR_DIM = 0x8C8C8C;
    private static final int COLOR_GOLD = 0xFFC83D;

    public SportsMenuScreen() {
        super(Component.literal("SportsMC"));
    }

    /** Opens the menu and asks the server for fresh lobby / invite status. */
    public static void open() {
        Minecraft.getInstance().setScreen(new SportsMenuScreen());
        ModNetwork.sendToServer(LobbyActionPacket.of(LobbyActionPacket.Action.REQUEST_SYNC));
    }

    public void refresh() {
        rebuildWidgets();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private int gridLeft() { return width / 2 - (COLS * TILE_W + (COLS - 1) * GAP) / 2; }
    private int gridTop() { return 44; }

    @Override
    protected void init() {
        for (int i = 0; i < SPORTS.size(); i++) {
            Sport sport = SPORTS.get(i);
            int x = gridLeft() + (i % COLS) * (TILE_W + GAP);
            int y = gridTop() + (i / COLS) * (TILE_H + GAP);
            Button b = addRenderableWidget(Button.builder(
                            Component.literal(sport.available() ? "Play" : "Coming soon"),
                            btn -> openSport(sport))
                    .bounds(x + 8, y + TILE_H - 26, TILE_W - 16, 20)
                    .build());
            b.active = sport.available();
        }
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(width / 2 - 50, height - 26, 100, 20).build());
    }

    private void openSport(Sport sport) {
        if (sport.name().equals("Football")) FootballHubScreen.open(com.sportsmc.lobby.Sport.FOOTBALL);
        else if (sport.name().equals("Tennis")) FootballHubScreen.open(com.sportsmc.lobby.Sport.TENNIS);
        else if (sport.name().equals("Air Hockey")) FootballHubScreen.open(com.sportsmc.lobby.Sport.AIR_HOCKEY);
        else if (sport.name().equals("Card Dojo")) FootballHubScreen.open(com.sportsmc.lobby.Sport.CARD_DOJO);
        else if (sport.name().equals("Bowling")) FootballHubScreen.open(com.sportsmc.lobby.Sport.BOWLING);
        else if (sport.name().equals("Arcade")) com.sportsmc.client.arcade.ArcadeScreen.open();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.drawCenteredString(font, Component.literal("SPORTS").withStyle(s -> s.withBold(true))
                .append(Component.literal("MC").withStyle(s -> s.withBold(true).withColor(COLOR_GOLD))), width / 2, 14, COLOR_TEXT);
        g.drawCenteredString(font, "Pick a sport", width / 2, 27, COLOR_DIM);

        for (int i = 0; i < SPORTS.size(); i++) {
            Sport sport = SPORTS.get(i);
            int x = gridLeft() + (i % COLS) * (TILE_W + GAP);
            int y = gridTop() + (i / COLS) * (TILE_H + GAP);
            boolean hover = mouseX >= x && mouseX < x + TILE_W && mouseY >= y && mouseY < y + TILE_H;

            g.fill(x, y, x + TILE_W, y + TILE_H, sport.available() ? COLOR_TILE : COLOR_TILE_OFF);
            if (sport.available() && hover) g.renderOutline(x, y, TILE_W, TILE_H, COLOR_BORDER);

            // Icon at 2x.
            g.pose().pushPose();
            g.pose().translate(x + 8, y + 8, 0);
            g.pose().scale(1.5f, 1.5f, 1f);
            g.renderItem(sport.icon().get(), 0, 0);
            g.pose().popPose();

            g.drawString(font, sport.name(), x + 36, y + 10, sport.available() ? COLOR_TEXT : COLOR_DIM);
            String status = sport.available() ? lobbyStatus(sport) : sport.tagline();
            int statusColor = status.contains("invite") ? COLOR_GOLD : COLOR_DIM;
            g.drawString(font, font.plainSubstrByWidth(status, TILE_W - 40), x + 36, y + 22, statusColor);
        }

        super.render(g, mouseX, mouseY, partialTick);
    }

    /** One-line status for a playable sport's tile: invites waiting, in a lobby, in a match. */
    private static String lobbyStatus(Sport sport) {
        if (sport.name().equals("Arcade")) return sport.tagline(); // solo games, no lobby
        LobbySyncPacket data = ClientLobbyData.get();
        if (data == null) return sport.tagline();
        if (data.lobby() != null) {
            if (!data.lobby().sport().displayName.equals(sport.name())) return "You're in a " + data.lobby().sport().displayName + " lobby";
            if (data.lobby().state() == Lobby.State.IN_MATCH) return "Match in progress";
            return "In a lobby (" + data.lobby().members().size() + "/" + Lobby.MAX_HUMANS + ")";
        }
        int invites = data.invites().size();
        if (invites > 0) return invites + (invites == 1 ? " invite waiting!" : " invites waiting!");
        return sport.tagline();
    }
}
