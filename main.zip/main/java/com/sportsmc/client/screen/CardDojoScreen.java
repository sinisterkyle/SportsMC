package com.sportsmc.client.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.math.Axis;
import com.sportsmc.cards.CardRules;
import com.sportsmc.cards.CardRules.Card;
import com.sportsmc.cards.CardRules.Element;
import com.sportsmc.client.ClientCardData;
import com.sportsmc.network.CardPickPacket;
import com.sportsmc.network.CardStatePacket;
import com.sportsmc.network.LobbyActionPacket;
import com.sportsmc.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * The Card Dojo table. Your hand is at the bottom (click a card or press 1-5), the opponent's face-down hand at
 * the top, the mat in the middle, both banks on the left (sorted into Fire / Water / Ice columns) and the deck
 * on the right. The server decides everything; this screen animates it: dealing, playing a card onto the mat,
 * the opponent's card flipping over, the clash (with a fire, water or ice burst), and the winning card flying
 * into its owner's bank. ESC hides the dojo (the match keeps going), M brings it back.
 */
public class CardDojoScreen extends Screen {

    // Canonical card size; cards are drawn at this size and scaled.
    private static final float CW = 60, CH = 84;
    private static final int TEXT = 0xFFFFFFFF, DIM = 0xFFB8B0A0, GOLD = 0xFFFFC83D;

    // Reveal timeline (seconds after the reveal starts).
    private static final double FLIP_END = 0.35, CLASH = 0.45, FLY_START = 1.3, FLY_END = 1.9;

    private int seenVersion = -1;
    @Nullable private CardStatePacket prev;
    private final int[] shownHand = {-1, -1, -1, -1, -1};
    private final double[] dealAt = new double[5];
    private int localPick = -1;
    private double myPickAt = -1, oppPickAt = -1, revealAt = -1;
    private int revealMine = -1, revealTheirs = -1, revealResult;
    private boolean flipSound, clashDone, bankSound, winSound;
    private int hoverSlot = -1;
    private final List<Particle> particles = new ArrayList<>();
    private final Random rnd = new Random();
    private long lastFrame = System.nanoTime();

    private static final class Particle {
        double x, y, vx, vy, age, life, size, gravity;
        int color;
    }

    public CardDojoScreen() {
        super(Component.literal("Card Dojo"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    protected void init() {
        addRenderableWidget(Button.builder(Component.literal("Forfeit"), b -> {
            ModNetwork.sendToServer(LobbyActionPacket.of(LobbyActionPacket.Action.LEAVE));
            onClose();
        }).bounds(width - 70, height - 24, 64, 20).build());
    }

    private static double now() {
        return System.nanoTime() / 1e9;
    }

    // ------------------------------------------------------------------ layout

    private float handScale() { return Math.max(0.6f, Math.min(1.25f, (height - 130) / 3f / CH)); }
    private float matScale() { return handScale() * 1.15f; }
    private float oppScale() { return handScale() * 0.6f; }
    private int cx() { return width / 2 + 30; }

    /** Center of hand slot i (mine, bottom). */
    private float[] handPos(int i) {
        float s = handScale(), w = CW * s, gap = 6;
        float total = 5 * w + 4 * gap;
        float x = cx() - total / 2 + i * (w + gap) + w / 2;
        float y = height - 26 - CH * s / 2;
        return new float[]{x, y};
    }

    /** Center of the opponent's hand slot i (top). */
    private float[] oppPos(int i) {
        float s = oppScale(), w = CW * s, gap = 4;
        float total = 5 * w + 4 * gap;
        return new float[]{cx() - total / 2 + i * (w + gap) + w / 2, 10 + CH * s / 2};
    }

    private float matY() {
        float top = oppPos(0)[1] + CH * oppScale() / 2, bottom = handPos(0)[1] - CH * handScale() / 2;
        return (top + bottom) / 2;
    }

    private float[] myMat() { return new float[]{cx() - CW * matScale() * 0.62f, matY()}; }
    private float[] theirMat() { return new float[]{cx() + CW * matScale() * 0.62f, matY()}; }
    private float[] deckPos() { return new float[]{width - 40, matY()}; }

    // Banks (left side): three columns of mini cards.
    private static final float MINI = 0.3f; // mini card scale
    private int bankX() { return 8; }
    private int bankColW() { return (int) (CW * MINI) + 5; }

    private float[] bankSlot(boolean mine, Element e, int index) {
        int x = bankX() + 6 + e.ordinal() * bankColW();
        int top = mine ? height / 2 + 18 : 22;
        int span = height / 2 - 60;
        float step = Math.min(9, Math.max(3, span / 12f));
        return new float[]{x + CW * MINI / 2, top + 14 + index * step + CH * MINI / 2};
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (button == 0 && hoverSlot >= 0) return play(hoverSlot);
        return false;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key >= GLFW.GLFW_KEY_1 && key <= GLFW.GLFW_KEY_5) return play(key - GLFW.GLFW_KEY_1);
        return super.keyPressed(key, scan, mods);
    }

    private boolean play(int slot) {
        CardStatePacket s = ClientCardData.get();
        if (s == null || s.phase() != CardStatePacket.PICK || localPick >= 0 || s.myPick() >= 0) return false;
        if (slot < 0 || slot >= s.hand().size() || s.hand().get(slot) < 0) return false;
        localPick = slot;
        myPickAt = now();
        ModNetwork.sendToServer(new CardPickPacket(s.round(), slot));
        sound(SoundEvents.UI_BUTTON_CLICK.value(), 1.2f, 0.6f);
        return true;
    }

    // ------------------------------------------------------------------ state changes -> animations

    private void follow(CardStatePacket s) {
        if (ClientCardData.version() == seenVersion) return;
        seenVersion = ClientCardData.version();
        double t = now();
        boolean newGame = s.phase() == CardStatePacket.DEAL && (prev == null || prev.phase() != CardStatePacket.DEAL);
        int dealt = 0;
        for (int i = 0; i < 5; i++) {
            int id = i < s.hand().size() ? s.hand().get(i) : -1;
            if (newGame || (id >= 0 && id != shownHand[i])) {
                dealAt[i] = t + 0.09 * dealt++;
                if (id >= 0) sound(SoundEvents.BOOK_PAGE_TURN, 1.5f, 0.35f);
            }
            shownHand[i] = id;
        }
        if (newGame) { particles.clear(); revealAt = -1; }
        boolean newRound = s.phase() == CardStatePacket.PICK && (prev == null || prev.phase() != CardStatePacket.PICK || prev.round() != s.round());
        if (newRound) {
            localPick = -1;
            myPickAt = oppPickAt = revealAt = -1;
        }
        if (s.phase() == CardStatePacket.PICK && s.myPick() >= 0 && localPick < 0) { localPick = s.myPick(); myPickAt = t; }
        if (s.oppPicked() && oppPickAt < 0) { oppPickAt = t; sound(SoundEvents.BOOK_PAGE_TURN, 0.8f, 0.5f); }
        boolean revealing = s.phase() == CardStatePacket.REVEAL || s.phase() == CardStatePacket.GAME_OVER;
        if (revealing && s.revealMine() >= 0 && revealAt < 0) {
            revealAt = t;
            revealMine = s.revealMine();
            revealTheirs = s.revealTheirs();
            revealResult = s.roundResult();
            if (oppPickAt < 0) oppPickAt = t - 1;
            if (myPickAt < 0) myPickAt = t - 1;
            flipSound = clashDone = bankSound = winSound = false;
        }
        prev = s;
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        renderBackground(g);
        CardStatePacket s = ClientCardData.get();
        if (s == null) { super.render(g, mx, my, partialTick); return; }
        follow(s);
        long nowNs = System.nanoTime();
        double dt = Math.min(0.1, (nowNs - lastFrame) / 1e9);
        lastFrame = nowNs;
        double t = now();
        double rt = revealAt < 0 ? -1 : t - revealAt;
        timelineEvents(rt);

        g.drawManaged(() -> {
            drawMat(g);
            drawBanks(g, s, rt, t);
            drawDeck(g);
            drawOpponentHand(g, s, t);
            drawHand(g, s, mx, my, t);
            drawPlayed(g, s, rt, t);
        });
        tickParticles(dt);
        g.drawManaged(() -> drawParticles(g));
        drawHud(g, s, rt, t);
        super.render(g, mx, my, partialTick);
    }

    private void timelineEvents(double rt) {
        if (rt < 0) return;
        if (!flipSound && rt >= FLIP_END / 2) { flipSound = true; sound(SoundEvents.BOOK_PAGE_TURN, 1.1f, 0.8f); }
        if (!clashDone && rt >= CLASH) {
            clashDone = true;
            Card win = revealResult > 0 ? CardRules.card(revealMine) : revealResult < 0 ? CardRules.card(revealTheirs) : null;
            float[] at = revealResult > 0 ? myMat() : revealResult < 0 ? theirMat() : new float[]{cx(), matY()};
            if (win == null) {
                burst(at[0], at[1], 0xFF9A9A9A, 0xFFDDDDDD, 25, 60, 0);
                sound(SoundEvents.NOTE_BLOCK_BASS.value(), 0.8f, 0.7f);
            } else {
                switch (win.element()) {
                    case FIRE -> { burst(at[0], at[1], 0xFFFF6A1A, 0xFFFFD23C, 45, 90, -120); sound(SoundEvents.FIRECHARGE_USE, 1.0f, 0.7f); }
                    case WATER -> { burst(at[0], at[1], 0xFF2E8BFF, 0xFF9FE8FF, 45, 110, 260); sound(SoundEvents.BUCKET_EMPTY, 1.0f, 0.9f); }
                    case ICE -> { burst(at[0], at[1], 0xFFFFFFFF, 0xFF9FE8FF, 40, 80, 40); sound(SoundEvents.GLASS_BREAK, 1.2f, 0.7f); }
                }
            }
        }
        if (!bankSound && rt >= FLY_END) {
            bankSound = true;
            if (revealResult != 0) sound(SoundEvents.EXPERIENCE_ORB_PICKUP, revealResult > 0 ? 1.2f : 0.8f, 0.5f);
        }
        CardStatePacket s = ClientCardData.get();
        if (!winSound && rt >= FLY_END && s != null && s.phase() == CardStatePacket.GAME_OVER) {
            winSound = true;
            if (s.gameWinner() > 0) sound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1f, 0.7f);
            else sound(SoundEvents.NOTE_BLOCK_DIDGERIDOO.value(), 0.6f, 0.7f);
            for (int i = 0; i < 4; i++) {
                Element e = Element.values()[i % 3];
                burst(cx() + (rnd.nextFloat() - 0.5f) * 200, matY() + (rnd.nextFloat() - 0.5f) * 80, e.color, 0xFFFFFFFF, 30, 100, 80);
            }
        }
    }

    private void drawMat(GuiGraphics g) {
        int l = cx() - (int) (CW * matScale() * 1.6f), r = cx() + (int) (CW * matScale() * 1.6f);
        int tp = (int) (matY() - CH * matScale() * 0.7f), bt = (int) (matY() + CH * matScale() * 0.7f);
        g.fill(l - 3, tp - 3, r + 3, bt + 3, 0xFF2A1A0E);
        g.fillGradient(l, tp, r, bt, 0xFF7A5230, 0xFF4E321C);
        for (int y = tp + 6; y < bt; y += 8) g.fill(l, y, r, y + 1, 0x22000000); // floor boards
        g.fill(cx(), tp + 4, cx() + 1, bt - 4, 0x40FFE7B0);
        // Card spots.
        for (float[] p : new float[][]{myMat(), theirMat()}) {
            float w = CW * matScale() / 2 + 3, h = CH * matScale() / 2 + 3;
            outline(g, (int) (p[0] - w), (int) (p[1] - h), (int) (p[0] + w), (int) (p[1] + h), 0x60FFE7B0);
        }
    }

    private void drawDeck(GuiGraphics g) {
        float[] d = deckPos();
        float s = oppScale();
        for (int i = 3; i >= 0; i--) drawCardAt(g, -1, d[0] + i * 1.5f, d[1] - i * 1.5f, s, 0, false, 1f);
    }

    private void drawOpponentHand(GuiGraphics g, CardStatePacket s, double t) {
        int count = s.oppHandCount();
        boolean picked = oppPickAt >= 0 && s.phase() == CardStatePacket.PICK;
        int shown = picked ? count - 1 : count;
        for (int i = 0; i < Math.min(5, shown); i++) {
            float[] p = oppPos(i);
            drawCardAt(g, -1, p[0], p[1] + (float) Math.sin(t * 2 + i) * 1.2f, oppScale(), 180, false, 1f);
        }
        // Their chosen card slides from their hand to the mat, face down.
        if (picked) {
            float k = ease((t - oppPickAt) / 0.3);
            float[] a = oppPos(Math.min(4, Math.max(0, count - 1))), b = theirMat();
            float sc = lerp(oppScale(), matScale(), k);
            drawCardAt(g, -1, lerp(a[0], b[0], k), lerp(a[1], b[1], k), sc, 0, false, 1f);
        }
    }

    private void drawHand(GuiGraphics g, CardStatePacket s, int mx, int my, double t) {
        hoverSlot = -1;
        boolean canPick = s.phase() == CardStatePacket.PICK && localPick < 0 && s.myPick() < 0;
        float sc = handScale();
        for (int i = 0; i < 5; i++) {
            int id = i < s.hand().size() ? s.hand().get(i) : -1;
            if (id < 0 || i == localPick) continue;
            float[] p = handPos(i);
            boolean hover = canPick && Math.abs(mx - p[0]) <= CW * sc / 2 && Math.abs(my - p[1]) <= CH * sc / 2;
            if (hover) hoverSlot = i;
            // Dealt in from the deck: slides over and flips face up.
            double k = (t - dealAt[i]) / 0.35;
            if (k < 0) continue;
            float e = ease(k);
            float[] d = deckPos();
            float x = lerp(d[0], p[0], e), y = lerp(d[1], p[1], e) - (hover ? 8 : 0);
            float flip = (float) Math.min(1, Math.max(0, k * 1.6 - 0.6)); // back -> face during the slide
            drawFlipping(g, id, x, y, lerp(oppScale(), sc, e), flip, hover, canPick ? 1f : 0.85f);
            if (canPick && k >= 1) {
                g.pose().pushPose();
                g.pose().translate(x - CW * sc / 2 + 3, y + CH * sc / 2 + 2, 0);
                g.drawString(font, String.valueOf(i + 1), 0, 0, hover ? GOLD : DIM);
                g.pose().popPose();
            }
        }
    }

    /** The two cards on the mat: picking, the flip, the clash and the flight to the bank. */
    private void drawPlayed(GuiGraphics g, CardStatePacket s, double rt, double t) {
        // My card: slides from my hand to my spot (face up: I know what I played).
        int myId = rt >= 0 ? revealMine : localPick >= 0 && localPick < s.hand().size() ? s.hand().get(localPick) : -1;
        if (myId >= 0 && myPickAt >= 0) {
            float k = ease((t - myPickAt) / 0.3);
            float[] a = handPos(Math.max(0, localPick)), b = myMat();
            float x = lerp(a[0], b[0], k), y = lerp(a[1], b[1], k), sc = lerp(handScale(), matScale(), k);
            drawRevealCard(g, myId, x, y, sc, rt, revealResult > 0, revealResult < 0, true, s);
        }
        // Their card: face down until the reveal flips it.
        if (rt >= 0 && revealTheirs >= 0) {
            float[] b = theirMat();
            float flip = (float) Math.min(1, rt / FLIP_END);
            if (rt < FLIP_END) drawFlipping(g, revealTheirs, b[0], b[1], matScale(), flip, false, 1f);
            else drawRevealCard(g, revealTheirs, b[0], b[1], matScale(), rt, revealResult < 0, revealResult > 0, false, s);
        }
    }

    /** A revealed card through the clash: the winner pulses then flies to its bank; the loser shakes and fades. */
    private void drawRevealCard(GuiGraphics g, int id, float x, float y, float sc, double rt, boolean winner, boolean loser,
                                boolean mine, CardStatePacket s) {
        if (rt < CLASH) { drawCardAt(g, id, x, y, sc, 0, false, 1f); return; }
        boolean tie = !winner && !loser;
        if (winner) {
            if (rt < FLY_START) {
                float pulse = 1 + 0.08f * (float) Math.sin((rt - CLASH) * 14) * (float) Math.max(0, 1 - (rt - CLASH));
                drawCardAt(g, id, x, y, sc * pulse, 0, true, 1f);
            } else if (rt < FLY_END || s.phase() == CardStatePacket.GAME_OVER) {
                Card c = CardRules.card(id);
                if (c == null) return;
                List<Integer> bank = mine ? s.myBank() : s.theirBank();
                int idx = 0;
                for (int b : bank) { if (b == id) break; Card bc = CardRules.card(b); if (bc != null && bc.element() == c.element()) idx++; }
                float[] dst = bankSlot(mine, c.element(), idx);
                float k = ease((rt - FLY_START) / (FLY_END - FLY_START));
                if (k >= 1) return; // it's in the bank now
                float arc = (float) Math.sin(k * Math.PI) * -30;
                drawCardAt(g, id, lerp(x, dst[0], k), lerp(y, dst[1], k) + arc, lerp(sc, MINI, k), k * 360, true, 1f);
            }
            return;
        }
        // Loser (or both, on a tie): shake, then fade away.
        double fadeT = (rt - CLASH) / (tie ? 1.2 : 1.0);
        if (fadeT >= 1) return;
        float shake = (float) (Math.sin(rt * 60) * 3 * Math.max(0, 1 - (rt - CLASH) * 2.5));
        float alpha = (float) Math.max(0, 1 - Math.max(0, fadeT - 0.3) / 0.7);
        drawCardAt(g, id, x + shake, y + (float) (fadeT * 10), sc, 0, false, alpha);
        if (!tie) {
            // A dark wash over the beaten card.
            float w = CW * sc / 2, h = CH * sc / 2;
            g.fill((int) (x + shake - w), (int) (y - h + fadeT * 10), (int) (x + shake + w), (int) (y + h + fadeT * 10),
                    ((int) (alpha * 110) << 24));
        }
    }

    private void drawBanks(GuiGraphics g, CardStatePacket s, double rt, double t) {
        int x0 = bankX(), w = 3 * bankColW() + 8;
        for (int side = 0; side < 2; side++) {
            boolean mine = side == 1;
            int top = mine ? height / 2 + 4 : 8, bottom = mine ? height - 30 : height / 2 - 6;
            g.fill(x0, top, x0 + w, bottom, 0xB0101418);
            g.drawString(font, mine ? "YOUR BANK" : "THEIR BANK", x0 + 4, top + 3, mine ? 0xFF7CF07C : 0xFFF07C7C);
            List<Integer> bank = mine ? s.myBank() : s.theirBank();
            // The card flying in right now isn't shown in the bank until it lands.
            int flying = rt >= 0 && rt < FLY_END && ((mine && revealResult > 0) || (!mine && revealResult < 0))
                    ? (mine ? revealMine : revealTheirs) : -1;
            int[] perElement = new int[3];
            boolean showSet = (s.phase() == CardStatePacket.GAME_OVER || s.phase() == CardStatePacket.MATCH_OVER)
                    && ((mine && s.gameWinner() > 0) || (!mine && s.gameWinner() < 0)) && (rt < 0 || rt >= FLY_END);
            for (int id : bank) {
                Card c = CardRules.card(id);
                if (c == null) continue;
                int idx = perElement[c.element().ordinal()]++;
                if (id == flying) continue;
                float[] p = bankSlot(mine, c.element(), idx);
                boolean inSet = showSet && s.winningSet().contains(id);
                if (inSet) {
                    float glow = 0.5f + 0.5f * (float) Math.sin(t * 6);
                    int a = (int) (120 + 120 * glow);
                    g.fill((int) (p[0] - CW * MINI / 2 - 3), (int) (p[1] - CH * MINI / 2 - 3),
                            (int) (p[0] + CW * MINI / 2 + 3), (int) (p[1] + CH * MINI / 2 + 3), (a << 24) | 0xFFD23C);
                }
                drawCardAt(g, id, p[0], p[1], MINI * (inSet ? 1.15f : 1f), 0, false, 1f);
            }
            // Element column headers.
            for (Element e : Element.values()) {
                float[] p = bankSlot(mine, e, 0);
                drawEmblem(g, e, p[0], top + 15, 4.5f, t);
            }
        }
    }

    private void drawHud(GuiGraphics g, CardStatePacket s, double rt, double t) {
        int cx = cx();
        // Names and games.
        String header = s.theirName() + "   " + s.theirGames() + " - " + s.myGames() + "   YOU (" + s.myName() + ")";
        g.drawCenteredString(font, header, cx, (int) (oppPos(0)[1] + CH * oppScale() / 2 + 4), TEXT);
        if (s.gamesToWin() > 1) g.drawCenteredString(font, "First to " + s.gamesToWin() + " games", cx,
                (int) (oppPos(0)[1] + CH * oppScale() / 2 + 14), DIM);

        float matBottom = matY() + CH * matScale() * 0.7f;
        switch (s.phase()) {
            case CardStatePacket.DEAL -> g.drawCenteredString(font, "Dealing...", cx, (int) matBottom + 6, DIM);
            case CardStatePacket.PICK -> {
                float frac = s.pickTicksLeft() / 400f;
                int bw = (int) (CW * matScale() * 2.6f), bx = cx - bw / 2, by = (int) matBottom + 6;
                g.fill(bx, by, bx + bw, by + 4, 0x80000000);
                g.fill(bx, by, bx + (int) (bw * frac), by + 4, frac > 0.3f ? 0xFF7CF07C : 0xFFF0B03C);
                String hint = localPick >= 0 ? (s.oppPicked() ? "Revealing..." : "Waiting for " + s.theirName() + "...")
                        : "Pick a card!  (click or press 1-5)";
                g.drawCenteredString(font, hint, cx, by + 7, localPick >= 0 ? DIM : GOLD);
            }
            default -> {
                if (rt >= CLASH && !s.message().isEmpty()) {
                    int color = revealResult > 0 ? 0xFF7CF07C : revealResult < 0 ? 0xFFF07C7C : DIM;
                    g.drawCenteredString(font, s.message(), cx, (int) matBottom + 8, color);
                }
            }
        }
        // Game / match result banner.
        boolean over = s.phase() == CardStatePacket.GAME_OVER || s.phase() == CardStatePacket.MATCH_OVER;
        if (over && (rt < 0 || rt >= FLY_END)) {
            boolean won = s.gameWinner() > 0;
            String text = s.phase() == CardStatePacket.MATCH_OVER ? (won ? "YOU WIN THE MATCH!" : "MATCH LOST")
                    : (won ? "YOU WIN!" : s.theirName() + " WINS");
            float scale = 2.5f + 0.1f * (float) Math.sin(t * 5);
            g.pose().pushPose();
            g.pose().translate(cx, matY() - 10, 0);
            g.pose().scale(scale, scale, 1);
            int w = font.width(text);
            g.fill(-w / 2 - 6, -4, w / 2 + 6, 12, 0xC0000000);
            g.drawString(font, text, -w / 2, 0, won ? GOLD : 0xFFF07C7C);
            g.pose().popPose();
            g.drawCenteredString(font, "Winning set highlighted in the bank", cx, (int) (matY() + 26), DIM);
        }
        g.drawCenteredString(font, "Fire melts Ice  •  Ice freezes Water  •  Water puts out Fire  •  ESC hides (M to return)",
                width / 2, height - 12, 0xFF8A8270);
    }

    // ------------------------------------------------------------------ cards

    /** Draws a card (id < 0 = card back) centered at x, y. */
    private void drawCardAt(GuiGraphics g, int id, float x, float y, float scale, float rotDeg, boolean glow, float alpha) {
        if (alpha <= 0.01f) return;
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        if (rotDeg != 0) g.pose().mulPose(Axis.ZP.rotationDegrees(rotDeg));
        g.pose().scale(scale, scale, 1);
        g.pose().translate(-CW / 2, -CH / 2, 0);
        if (alpha < 1f) { g.flush(); RenderSystem.setShaderColor(1, 1, 1, alpha); }
        Card c = CardRules.card(id);
        if (c == null) drawBack(g); else drawFace(g, c, glow);
        if (alpha < 1f) { g.flush(); RenderSystem.setShaderColor(1, 1, 1, 1); }
        g.pose().popPose();
    }

    /** A card turning over: back for the first half (flip 0..0.5), face for the second; squashed sideways. */
    private void drawFlipping(GuiGraphics g, int id, float x, float y, float scale, float flip, boolean hover, float alpha) {
        if (flip >= 1) { drawCardAt(g, id, x, y, scale, 0, hover, alpha); return; }
        float squash = Math.abs((float) Math.cos(flip * Math.PI));
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(Math.max(0.02f, squash), 1, 1);
        drawCardAt(g, flip < 0.5f ? -1 : id, 0, 0, scale, 0, hover, alpha);
        g.pose().popPose();
    }

    private void drawFace(GuiGraphics g, Card c, boolean glow) {
        int col = c.color().rgb, el = c.element().color;
        if (glow) g.fill(-3, -3, 63, 87, 0x90FFE070);
        g.fill(2, 3, 62, 87, 0x50000000); // shadow
        // Colored frame with clipped corners.
        g.fill(1, 0, 59, 84, col);
        g.fill(0, 1, 60, 83, col);
        g.fillGradient(3, 3, 57, 81, 0xFFF6ECD6, 0xFFE4D0A8);
        // Top band in the element's color.
        g.fillGradient(3, 3, 57, 18, el, darker(el));
        // Number badge.
        fillCircle(g, 12, 12, 8.5, 0xFF000000);
        fillCircle(g, 12, 12, 7.5, col);
        String num = String.valueOf(c.value());
        g.drawString(font, num, 12 - font.width(num) / 2 + 1, 8, 0xFF000000, false);
        g.drawString(font, num, 12 - font.width(num) / 2, 7, 0xFFFFFFFF, false);
        drawEmblem(g, c.element(), 48, 10.5f, 4.5f, System.currentTimeMillis() / 1000.0);
        // Art: a soft halo and the big element emblem.
        fillCircle(g, 30, 43, 17, (0x40 << 24) | (el & 0xFFFFFF));
        drawEmblem(g, c.element(), 30, 44, 15, System.currentTimeMillis() / 1000.0 + c.id());
        // Name plate.
        g.fill(3, 68, 57, 81, 0xFF3A2614);
        g.pose().pushPose();
        g.pose().translate(30, 71.5f, 0);
        float ns = Math.min(0.6f, 50f / Math.max(1, font.width(c.name())));
        g.pose().scale(ns, ns, 1);
        g.drawString(font, c.name(), -font.width(c.name()) / 2, 0, 0xFFFFF2D0, false);
        g.pose().popPose();
    }

    private void drawBack(GuiGraphics g) {
        g.fill(2, 3, 62, 87, 0x50000000);
        g.fill(1, 0, 59, 84, 0xFFC9A227);
        g.fill(0, 1, 60, 83, 0xFFC9A227);
        g.fillGradient(3, 3, 57, 81, 0xFF7A1F1F, 0xFF4A1010);
        // Diamond lattice.
        for (int y = 6; y < 80; y += 6) for (int x = 6 + (y / 6 % 2) * 3; x < 55; x += 6) g.fill(x, y, x + 1, y + 1, 0x50FFD27A);
        outline(g, 6, 6, 54, 78, 0x80FFD27A);
        // Three elements around a circle.
        fillCircle(g, 30, 42, 14, 0xFF2A0A0A);
        double t = System.currentTimeMillis() / 1000.0;
        drawEmblem(g, Element.FIRE, 30, 35, 5, t);
        drawEmblem(g, Element.WATER, 24, 47, 5, t);
        drawEmblem(g, Element.ICE, 36, 47, 5, t);
    }

    /** Element symbols drawn from shapes: a flickering flame, a water drop, a snowflake. */
    private static void drawEmblem(GuiGraphics g, Element e, float cx, float cy, float s, double time) {
        switch (e) {
            case FIRE -> {
                float lean = (float) Math.sin(time * 5) * s * 0.12f;
                flame(g, cx, cy, s, lean, 0xFFE8401C);
                flame(g, cx, cy + s * 0.18f, s * 0.68f, lean * 1.4f, 0xFFFF9A1F);
                flame(g, cx, cy + s * 0.36f, s * 0.38f, lean * 1.8f, 0xFFFFE45C);
            }
            case WATER -> {
                drop(g, cx, cy, s, 0xFF1B5FC4);
                drop(g, cx, cy + s * 0.08f, s * 0.82f, 0xFF3F9BFF);
                fillCircle(g, cx - s * 0.22f, cy + s * 0.12f, Math.max(0.8, s * 0.13), 0xD0FFFFFF);
            }
            case ICE -> {
                snowflake(g, cx, cy, s, Math.max(1f, s * 0.2f), 0xFF2D6E8E);
                snowflake(g, cx, cy, s * 0.92f, Math.max(0.6f, s * 0.1f), 0xFFE8FBFF);
            }
        }
    }

    /** Flame: a teardrop pointing up, its tip leaning sideways. */
    private static void flame(GuiGraphics g, float cx, float cy, float s, float lean, int color) {
        int top = (int) (cy - s), bottom = (int) (cy + s * 0.75f);
        for (int y = top; y <= bottom; y++) {
            float t = (y - (cy - s)) / (s * 1.75f); // 0 at tip, 1 at base
            double half;
            if (t < 0.7) half = s * 0.62 * Math.pow(t / 0.7, 0.9);
            else { double u = (t - 0.7) / 0.3; half = s * 0.62 * Math.sqrt(Math.max(0, 1 - u * u)); }
            float x = cx + lean * (1 - t);
            g.fill((int) Math.round(x - half), y, (int) Math.round(x + half), y + 1, color);
        }
    }

    /** Water drop: a point on top widening into a round bottom. */
    private static void drop(GuiGraphics g, float cx, float cy, float s, int color) {
        float r = s * 0.58f, ccy = cy + s * 0.32f;
        int top = (int) (cy - s), bottom = (int) (ccy + r);
        for (int y = top; y <= bottom; y++) {
            double half;
            if (y < ccy) {
                double k = (y - (cy - s)) / (ccy - (cy - s));
                half = r * Math.pow(Math.max(0, k), 1.3);
            } else {
                double dy = y - ccy;
                half = Math.sqrt(Math.max(0, r * r - dy * dy));
            }
            g.fill((int) Math.round(cx - half), y, (int) Math.round(cx + half), y + 1, color);
        }
    }

    /** Snowflake: six arms with little branches. */
    private static void snowflake(GuiGraphics g, float cx, float cy, float s, float thick, int color) {
        for (int k = 0; k < 6; k++) {
            g.pose().pushPose();
            g.pose().translate(cx, cy, 0);
            g.pose().mulPose(Axis.ZP.rotationDegrees(k * 60));
            float hw = thick / 2;
            fillF(g, -hw, -s, hw, 0, color);
            for (float f : new float[]{0.45f, 0.72f}) {
                g.pose().pushPose();
                g.pose().translate(0, -s * f, 0);
                g.pose().mulPose(Axis.ZP.rotationDegrees(40));
                fillF(g, -hw, -s * 0.28f, hw, 0, color);
                g.pose().mulPose(Axis.ZP.rotationDegrees(-80));
                fillF(g, -hw, -s * 0.28f, hw, 0, color);
                g.pose().popPose();
            }
            g.pose().popPose();
        }
        fillCircle(g, cx, cy, Math.max(1, s * 0.16), color);
    }

    /** fill() with fractional coordinates (scaled up so thin lines survive, then scaled back). */
    private static void fillF(GuiGraphics g, float x0, float y0, float x1, float y1, int color) {
        g.pose().pushPose();
        g.pose().scale(0.1f, 0.1f, 1);
        g.fill(Math.round(x0 * 10), Math.round(y0 * 10), Math.round(x1 * 10), Math.round(y1 * 10), color);
        g.pose().popPose();
    }

    // ------------------------------------------------------------------ particles

    private void burst(float x, float y, int c1, int c2, int count, double speed, double gravity) {
        for (int i = 0; i < count; i++) {
            Particle p = new Particle();
            double a = rnd.nextDouble() * Math.PI * 2, v = speed * (0.3 + rnd.nextDouble() * 0.7);
            p.x = x + (rnd.nextDouble() - 0.5) * 20;
            p.y = y + (rnd.nextDouble() - 0.5) * 20;
            p.vx = Math.cos(a) * v;
            p.vy = Math.sin(a) * v - (gravity < 0 ? speed * 0.6 : 0);
            p.gravity = gravity;
            p.life = 0.6 + rnd.nextDouble() * 0.6;
            p.size = 1.5 + rnd.nextDouble() * 2.5;
            p.color = rnd.nextBoolean() ? c1 : c2;
            particles.add(p);
        }
    }

    private void tickParticles(double dt) {
        for (Iterator<Particle> it = particles.iterator(); it.hasNext(); ) {
            Particle p = it.next();
            p.age += dt;
            if (p.age >= p.life) { it.remove(); continue; }
            p.vy += p.gravity * dt;
            p.vx *= Math.pow(0.4, dt);
            p.vy *= Math.pow(0.6, dt);
            p.x += p.vx * dt;
            p.y += p.vy * dt;
        }
    }

    private void drawParticles(GuiGraphics g) {
        for (Particle p : particles) {
            float k = (float) (1 - p.age / p.life);
            int a = (int) (255 * k);
            float s = (float) p.size * (0.5f + 0.5f * k);
            fillF(g, (float) p.x - s / 2, (float) p.y - s / 2, (float) p.x + s / 2, (float) p.y + s / 2, (a << 24) | (p.color & 0xFFFFFF));
        }
    }

    // ------------------------------------------------------------------ helpers

    private static void fillCircle(GuiGraphics g, double cx, double cy, double r, int color) {
        int r0 = (int) Math.ceil(r);
        for (int dy = -r0; dy <= r0; dy++) {
            double half = Math.sqrt(Math.max(0, r * r - dy * dy));
            if (half <= 0) continue;
            g.fill((int) Math.round(cx - half), (int) Math.round(cy + dy), (int) Math.round(cx + half), (int) Math.round(cy + dy) + 1, color);
        }
    }

    private static void outline(GuiGraphics g, int x0, int y0, int x1, int y1, int color) {
        g.fill(x0, y0, x1, y0 + 1, color);
        g.fill(x0, y1 - 1, x1, y1, color);
        g.fill(x0, y0, x0 + 1, y1, color);
        g.fill(x1 - 1, y0, x1, y1, color);
    }

    private static int darker(int c) {
        int r = (c >> 16 & 255) * 6 / 10, gr = (c >> 8 & 255) * 6 / 10, b = (c & 255) * 6 / 10;
        return 0xFF000000 | r << 16 | gr << 8 | b;
    }

    private static float lerp(float a, float b, float k) {
        return a + (b - a) * k;
    }

    /** Smooth 0..1 (clamped) ease-out. */
    private static float ease(double k) {
        double c = Math.max(0, Math.min(1, k));
        return (float) (1 - Math.pow(1 - c, 3));
    }

    private static void sound(SoundEvent sound, float pitch, float volume) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(sound, pitch, volume));
    }
}
