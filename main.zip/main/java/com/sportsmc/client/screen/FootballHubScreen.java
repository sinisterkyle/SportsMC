package com.sportsmc.client.screen;

import com.sportsmc.client.ClientLobbyData;
import com.sportsmc.lobby.Difficulty;
import com.sportsmc.lobby.Lobby;
import com.sportsmc.lobby.Sport;
import com.sportsmc.network.LobbyActionPacket;
import com.sportsmc.network.LobbyActionPacket.Action;
import com.sportsmc.network.LobbySyncPacket;
import com.sportsmc.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import javax.annotation.Nullable;
import java.util.List;
import java.util.UUID;

/**
 * The SportsMC hub (press M). Three layouts, chosen from the latest server snapshot:
 *  - no lobby:   Play panel (create lobby / play CPU) + pending invites
 *  - in lobby:   team cards, ready / swap / kick off / CPU / leave + invite list
 *  - in match:   status + forfeit
 */
public class FootballHubScreen extends Screen {

    private static final int PANEL_W = 200;
    private static final int ROWS_PER_PAGE = 5;
    private static final int ROW_H = 24;

    private static final int COLOR_PANEL = 0xAA101820;
    private static final int COLOR_HOME = 0xCC1D3B8A;
    private static final int COLOR_AWAY = 0xCC8A1D1D;
    private static final int COLOR_TEXT = 0xFFFFFF;
    private static final int COLOR_DIM = 0xA0A0A0;
    private static final int COLOR_GOLD = 0xFFC83D;

    /** Remembered between openings for the "Play vs CPU" button outside a lobby. */
    private static Difficulty localDifficulty = Difficulty.PRO;
    /** Field picked for a CPU match started outside a lobby (null = automatic). */
    @Nullable private static UUID localField = null;

    private int invitePage = 0;

    /** Sport this screen was opened for (used when you're not in a lobby yet). */
    private final Sport screenSport;

    public FootballHubScreen() {
        this(Sport.FOOTBALL);
    }

    public FootballHubScreen(Sport sport) {
        super(Component.translatable("screen.sportsmc.hub"));
        this.screenSport = sport;
    }

    /** The lobby's sport if you're in one, else the sport this screen was opened for. */
    private Sport sport() {
        LobbySyncPacket data = ClientLobbyData.get();
        return data != null && data.lobby() != null ? data.lobby().sport() : screenSport;
    }

    private com.sportsmc.field.FieldType fieldType() {
        return sport().fieldType;
    }

    /** Called by ClientLobbyData whenever a new snapshot arrives. */
    public void refresh() {
        rebuildWidgets();
    }

    @Override
    public boolean isPauseScreen() {
        return false; // keep the integrated server (and any match clock) running in singleplayer
    }

    // ------------------------------------------------------------------ layout

    private int leftX() { return width / 2 - PANEL_W - 10; }
    private int rightX() { return width / 2 + 10; }
    private int top() { return 40; }

    @Override
    protected void init() {
        LobbySyncPacket data = ClientLobbyData.get();
        if (data != null) {
            if (data.lobby() == null) initNoLobby(data);
            else if (data.lobby().state() == Lobby.State.IN_MATCH) initInMatch();
            else initLobby(data);
        }

        addRenderableWidget(Button.builder(Component.literal("< Sports"), b -> SportsMenuScreen.open())
                .bounds(width / 2 - 104, height - 24, 100, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.sportsmc.close"), b -> onClose())
                .bounds(width / 2 + 4, height - 24, 100, 20).build());
    }

    /** Opens the football lobby / invite screen and asks the server for fresh status. */
    public static void open() {
        open(Sport.FOOTBALL);
    }

    /** Opens the lobby / invite screen for a sport and asks the server for fresh status. */
    public static void open(Sport sport) {
        net.minecraft.client.Minecraft.getInstance().setScreen(new FootballHubScreen(sport));
        ModNetwork.sendToServer(LobbyActionPacket.of(LobbyActionPacket.Action.REQUEST_SYNC));
    }

    private void initNoLobby(LobbySyncPacket data) {
        int x = leftX(), y = top() + 20;

        addRenderableWidget(Button.builder(Component.translatable("screen.sportsmc.create_lobby"),
                b -> send(LobbyActionPacket.of(Action.CREATE_LOBBY, sport().ordinal()))).bounds(x, y, PANEL_W, 20).build());

        Button playCpu = addRenderableWidget(Button.builder(Component.translatable("screen.sportsmc.play_cpu"),
                b -> send(LobbyActionPacket.of(Action.START_CPU_MATCH, localField, localDifficulty.ordinal() | (sport().ordinal() << 8))))
                .bounds(x, y + 25, PANEL_W, 20).build());
        busyCheck(playCpu, data, localField);

        addRenderableWidget(Button.builder(difficultyLabel(localDifficulty), b -> {
            localDifficulty = localDifficulty.next();
            b.setMessage(difficultyLabel(localDifficulty));
        }).bounds(x, y + 50, PANEL_W, 20).build());

        if (data.field(localField) == null || data.field(localField).field().type() != fieldType()) localField = null;
        if (fieldType() != null) {
            Button field = addRenderableWidget(Button.builder(fieldLabel(data, localField), b -> {
                localField = nextField(data, localField);
                b.setMessage(fieldLabel(data, localField));
            }).bounds(x, y + 75, PANEL_W, 20).tooltip(fieldTooltip(data)).build());
            field.active = !data.fieldsOf(fieldType()).isEmpty();
        }

        // Pending invites on the right.
        List<LobbySyncPacket.InviteView> invites = data.invites();
        int rx = rightX(), ry = top() + 20;
        for (int i = 0; i < Math.min(invites.size(), ROWS_PER_PAGE); i++) {
            LobbySyncPacket.InviteView inv = invites.get(i);
            int rowY = ry + i * ROW_H;
            addRenderableWidget(Button.builder(Component.translatable("screen.sportsmc.accept"),
                    b -> send(LobbyActionPacket.of(Action.ACCEPT_INVITE, inv.lobbyId())))
                    .bounds(rx + PANEL_W - 104, rowY, 50, 20).build());
            addRenderableWidget(Button.builder(Component.translatable("screen.sportsmc.decline"),
                    b -> send(LobbyActionPacket.of(Action.DECLINE_INVITE, inv.lobbyId())))
                    .bounds(rx + PANEL_W - 52, rowY, 52, 20).build());
        }
    }

    private void initLobby(LobbySyncPacket data) {
        LobbySyncPacket.LobbyView lobby = data.lobby();
        UUID me = myUuid();
        boolean host = lobby.host().equals(me);
        boolean full = lobby.members().size() >= Lobby.MAX_HUMANS;
        boolean allReady = full && lobby.members().stream().allMatch(LobbySyncPacket.MemberView::ready);
        LobbySyncPacket.MemberView self = member(lobby, me);

        int x = leftX(), half = (PANEL_W - 4) / 2;

        // Kick button beside the opponent's card (host only).
        if (host) {
            for (LobbySyncPacket.MemberView m : lobby.members()) {
                if (m.uuid().equals(me)) continue;
                int cardY = cardY(m.side());
                addRenderableWidget(Button.builder(Component.literal("Kick"),
                        b -> send(LobbyActionPacket.of(Action.KICK, m.uuid())))
                        .bounds(x + PANEL_W - 40, cardY + 10, 36, 20).build());
            }
        }

        int y = top() + 106;
        Button ready = addRenderableWidget(Button.builder(
                Component.translatable(self != null && self.ready() ? "screen.sportsmc.unready" : "screen.sportsmc.ready"),
                b -> send(LobbyActionPacket.of(Action.TOGGLE_READY))).bounds(x, y, half, 20).build());
        ready.active = full;

        Button swap = addRenderableWidget(Button.builder(Component.translatable("screen.sportsmc.swap"),
                b -> send(LobbyActionPacket.of(Action.SWAP_SIDES))).bounds(x + half + 4, y, half, 20).build());
        swap.active = host;

        Button kickoff = addRenderableWidget(Button.builder(lobby.sport() != Sport.FOOTBALL
                        ? Component.literal("Start Match") : Component.translatable("screen.sportsmc.start"),
                b -> send(LobbyActionPacket.of(Action.START_MATCH))).bounds(x, y + 22, half, 20).build());
        kickoff.active = host && allReady;
        busyCheck(kickoff, data, lobby.selectedField());

        Button cpu = addRenderableWidget(Button.builder(Component.translatable("screen.sportsmc.play_cpu"),
                b -> send(LobbyActionPacket.of(Action.START_CPU_MATCH, lobby.difficulty().ordinal())))
                .bounds(x + half + 4, y + 22, half, 20).build());
        cpu.active = host && !full;
        busyCheck(cpu, data, lobby.selectedField());

        Button diff = addRenderableWidget(Button.builder(Component.literal("CPU: ").append(lobby.difficulty().displayName()),
                b -> send(LobbyActionPacket.of(Action.SET_DIFFICULTY, lobby.difficulty().next().ordinal())))
                .bounds(x, y + 44, half, 20).tooltip(Tooltip.create(Component.literal("CPU difficulty"))).build());
        diff.active = host;

        if (fieldType() != null) {
            Button field = addRenderableWidget(Button.builder(fieldLabel(data, lobby.selectedField()),
                    b -> send(LobbyActionPacket.of(Action.SELECT_FIELD, nextField(data, lobby.selectedField()))))
                    .bounds(x + half + 4, y + 44, half, 20).tooltip(fieldTooltip(data)).build());
            field.active = host && !data.fieldsOf(fieldType()).isEmpty();
        } else {
            boolean cards = lobby.sport() == Sport.CARD_DOJO;
            Button goals = addRenderableWidget(Button.builder(Component.literal(cards
                            ? "First to " + lobby.airGoals() + (lobby.airGoals() == 1 ? " game" : " games")
                            : "First to " + lobby.airGoals()),
                    b -> send(LobbyActionPacket.of(Action.SET_AIR_GOALS, null, cards
                            ? nextOption(Lobby.CARD_GAME_OPTIONS, lobby.airGoals()) : nextAirGoals(lobby.airGoals()))))
                    .bounds(x + half + 4, y + 44, half, 20)
                    .tooltip(Tooltip.create(Component.literal(cards ? "Games needed to win the match" : "Goals needed to win the match"))).build());
            goals.active = host;
        }

        if (lobby.sport().fieldType == null) {
            addRenderableWidget(Button.builder(Component.translatable("screen.sportsmc.leave"),
                    b -> send(LobbyActionPacket.of(Action.LEAVE))).bounds(x, y + 66, PANEL_W, 20).build());
        } else if (lobby.sport() == Sport.BOWLING) {
            Button framesButton = addRenderableWidget(Button.builder(Component.literal(lobby.airGoals() + " frames"),
                    b -> send(LobbyActionPacket.of(Action.SET_AIR_GOALS, null, nextOption(Lobby.BOWLING_FRAME_OPTIONS, lobby.airGoals()))))
                    .bounds(x, y + 66, half, 20)
                    .tooltip(Tooltip.create(Component.literal("Game length: 3, 5 or a full 10 frames. The last frame gets the bonus balls.")))
                    .build());
            framesButton.active = host;
            addRenderableWidget(Button.builder(Component.translatable("screen.sportsmc.leave"),
                    b -> send(LobbyActionPacket.of(Action.LEAVE))).bounds(x + half + 4, y + 66, half, 20).build());
        } else if (lobby.sport() == Sport.TENNIS) {
            Button games = addRenderableWidget(Button.builder(Component.literal("Best of " + lobby.tennisGames() + " games"),
                    b -> send(LobbyActionPacket.of(Action.SET_TENNIS_GAMES, null, nextTennisGames(lobby.tennisGames()))))
                    .bounds(x, y + 66, half, 20)
                    .tooltip(Tooltip.create(Component.literal("Match length: first to win " + (lobby.tennisGames() / 2 + 1)
                            + " game" + (lobby.tennisGames() / 2 + 1 == 1 ? "" : "s") + " wins the match.")))
                    .build());
            games.active = host;
            Button format = addRenderableWidget(Button.builder(Component.literal(lobby.doubles() ? "Doubles (2v2)" : "Singles (1v1)"),
                    b -> send(LobbyActionPacket.of(Action.SET_DOUBLES, null, lobby.doubles() ? 0 : 1)))
                    .bounds(x + half + 4, y + 66, half, 20)
                    .tooltip(Tooltip.create(Component.literal("Doubles: each side has two players. You control whichever "
                            + "of yours the ball is coming to, and your partner covers the other half.")))
                    .build());
            format.active = host;
            addRenderableWidget(Button.builder(Component.translatable("screen.sportsmc.leave"),
                    b -> send(LobbyActionPacket.of(Action.LEAVE))).bounds(x, y + 88, PANEL_W, 20).build());
        } else {
            Button quarters = addRenderableWidget(Button.builder(Component.literal(lobby.quarterMinutes() + "-min quarters"),
                    b -> send(LobbyActionPacket.of(Action.SET_QUARTER_LENGTH, null, nextQuarterLength(lobby.quarterMinutes()))))
                    .bounds(x, y + 66, half, 20)
                    .tooltip(Tooltip.create(Component.literal("Game length. The clock stops on incompletions, out of bounds and scores.")))
                    .build());
            quarters.active = host;

            addRenderableWidget(Button.builder(Component.translatable("screen.sportsmc.leave"),
                    b -> send(LobbyActionPacket.of(Action.LEAVE))).bounds(x + half + 4, y + 66, half, 20).build());
        }

        // Invite list on the right (paged).
        List<LobbySyncPacket.PlayerView> players = data.invitable();
        int pages = Math.max(1, (players.size() + ROWS_PER_PAGE - 1) / ROWS_PER_PAGE);
        invitePage = Math.min(invitePage, pages - 1);
        int rx = rightX(), ry = top() + 20;
        int start = invitePage * ROWS_PER_PAGE;
        for (int i = start; i < Math.min(players.size(), start + ROWS_PER_PAGE); i++) {
            LobbySyncPacket.PlayerView p = players.get(i);
            Button inv = addRenderableWidget(Button.builder(Component.literal("Invite " + p.name()),
                    b -> send(LobbyActionPacket.of(Action.INVITE, p.uuid())))
                    .bounds(rx, ry + (i - start) * ROW_H, PANEL_W, 20).build());
            inv.active = host && !full;
        }
        if (pages > 1) {
            int py = ry + ROWS_PER_PAGE * ROW_H;
            Button prev = addRenderableWidget(Button.builder(Component.literal("<"), b -> { invitePage--; rebuildWidgets(); })
                    .bounds(rx, py, 20, 20).build());
            prev.active = invitePage > 0;
            Button next = addRenderableWidget(Button.builder(Component.literal(">"), b -> { invitePage++; rebuildWidgets(); })
                    .bounds(rx + PANEL_W - 20, py, 20, 20).build());
            next.active = invitePage < pages - 1;
        }
    }

    private void initInMatch() {
        if (com.sportsmc.client.ClientAirHockeyData.get() != null) {
            addRenderableWidget(Button.builder(Component.literal("Back to the table"),
                    b -> net.minecraft.client.Minecraft.getInstance().setScreen(new AirHockeyScreen()))
                    .bounds(width / 2 - 60, height / 2 - 14, 120, 20).build());
        }
        addRenderableWidget(Button.builder(Component.translatable("screen.sportsmc.forfeit"),
                b -> send(LobbyActionPacket.of(Action.LEAVE))).bounds(width / 2 - 60, height / 2 + 10, 120, 20).build());
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        LobbySyncPacket data = ClientLobbyData.get();

        g.drawCenteredString(font, Component.literal(sport().displayName.toUpperCase()).withStyle(s -> s.withBold(true))
                .append(Component.literal(" LOBBY").withStyle(s -> s.withColor(COLOR_GOLD))), width / 2, 14, COLOR_TEXT);

        if (data == null) {
            super.render(g, mouseX, mouseY, partialTick);
            g.drawCenteredString(font, Component.translatable("screen.sportsmc.loading"), width / 2, height / 2, COLOR_DIM);
            return;
        }

        if (data.lobby() == null) renderNoLobbyBackdrop(g, data);
        else if (data.lobby().state() == Lobby.State.IN_MATCH) renderInMatch(g);
        else renderLobbyBackdrop(g, data);

        super.render(g, mouseX, mouseY, partialTick);

        // Bottom hint line.
        Component hint = null;
        if (!data.multiplayerContext()) hint = Component.translatable("screen.sportsmc.hint_singleplayer");
        else if (data.aloneOnServer()) hint = Component.translatable("screen.sportsmc.hint_alone");
        if (hint != null) g.drawCenteredString(font, hint, width / 2, height - 36, COLOR_DIM);
    }

    private void renderNoLobbyBackdrop(GuiGraphics g, LobbySyncPacket data) {
        int lx = leftX(), rx = rightX(), y = top();
        panel(g, lx, y, PANEL_W, 125);
        panel(g, rx, y, PANEL_W, 20 + ROWS_PER_PAGE * ROW_H);
        g.drawString(font, Component.translatable("screen.sportsmc.play"), lx + 6, y + 6, COLOR_GOLD);
        g.drawString(font, Component.translatable("screen.sportsmc.invites"), rx + 6, y + 6, COLOR_GOLD);

        List<LobbySyncPacket.InviteView> invites = data.invites();
        if (invites.isEmpty()) {
            g.drawString(font, Component.translatable("screen.sportsmc.no_invites"), rx + 6, y + 26, COLOR_DIM);
        }
        for (int i = 0; i < Math.min(invites.size(), ROWS_PER_PAGE); i++) {
            g.drawString(font, font.plainSubstrByWidth(invites.get(i).hostName(), PANEL_W - 112),
                    rx + 4, y + 26 + i * ROW_H, COLOR_TEXT);
        }
    }

    private void renderLobbyBackdrop(GuiGraphics g, LobbySyncPacket data) {
        LobbySyncPacket.LobbyView lobby = data.lobby();
        int lx = leftX(), rx = rightX(), y = top();

        LobbySyncPacket.FieldView fv = data.field(lobby.selectedField());
        String where = fieldType() == null ? (lobby.sport() == Sport.CARD_DOJO ? "  (on-screen dojo)" : "  (on-screen table)") : fv != null ? "  @ " + fv.field().name() : data.fieldsOf(fieldType()).isEmpty() ? "  (no " + fieldType().noun.toLowerCase() + " built)" : "  @ first free " + fieldType().noun.toLowerCase();
        g.drawString(font, font.plainSubstrByWidth("Lobby - Head-to-Head" + where, PANEL_W * 2 + 20), lx, y - 12, COLOR_GOLD);

        teamCard(g, lobby, Lobby.Side.HOME);
        teamCard(g, lobby, Lobby.Side.AWAY);

        panel(g, rx, y, PANEL_W, 20 + (ROWS_PER_PAGE + 1) * ROW_H);
        g.drawString(font, Component.translatable("screen.sportsmc.invite_players"), rx + 6, y + 6, COLOR_GOLD);
        if (data.invitable().isEmpty()) {
            g.drawString(font, Component.translatable("screen.sportsmc.no_players"), rx + 6, y + 26, COLOR_DIM);
        }
    }

    private void teamCard(GuiGraphics g, LobbySyncPacket.LobbyView lobby, Lobby.Side side) {
        int x = leftX(), y = cardY(side);
        g.fill(x, y, x + PANEL_W, y + 40, side == Lobby.Side.HOME ? COLOR_HOME : COLOR_AWAY);
        g.drawString(font, Component.translatable(side == Lobby.Side.HOME ? "screen.sportsmc.home" : "screen.sportsmc.away"),
                x + 6, y + 5, COLOR_GOLD);

        LobbySyncPacket.MemberView m = null;
        for (LobbySyncPacket.MemberView mv : lobby.members()) if (mv.side() == side) m = mv;

        if (m != null) {
            String name = m.name() + (m.uuid().equals(lobby.host()) ? " (host)" : "");
            g.drawString(font, name, x + 6, y + 20, COLOR_TEXT);
            if (lobby.members().size() >= Lobby.MAX_HUMANS) {
                g.drawString(font, m.ready() ? "READY" : "not ready", x + PANEL_W - 90, y + 5,
                        m.ready() ? 0x55FF55 : COLOR_DIM);
            }
        } else {
            g.drawString(font, Component.translatable("screen.sportsmc.waiting"), x + 6, y + 20, COLOR_DIM);
            g.drawString(font, "or CPU: " + lobby.difficulty().displayName().getString(), x + 6, y + 30, COLOR_DIM);
        }
    }

    private void renderInMatch(GuiGraphics g) {
        int w = 220, h = 70, x = width / 2 - w / 2, y = height / 2 - 45;
        panel(g, x, y, w, h);
        g.drawCenteredString(font, Component.translatable("screen.sportsmc.in_match"), width / 2, y + 10, COLOR_GOLD);
        g.drawCenteredString(font, "Your match is running. Forfeit to leave it.", width / 2, y + 26, COLOR_DIM);
    }

    // ------------------------------------------------------------------ helpers

    private int cardY(Lobby.Side side) {
        return top() + (side == Lobby.Side.HOME ? 10 : 60);
    }

    private void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, COLOR_PANEL);
    }

    private static int nextQuarterLength(int current) {
        int[] opts = Lobby.QUARTER_OPTIONS;
        for (int i = 0; i < opts.length; i++) if (opts[i] == current) return opts[(i + 1) % opts.length];
        return 3;
    }

    private static int nextOption(int[] opts, int current) {
        for (int i = 0; i < opts.length; i++) if (opts[i] == current) return opts[(i + 1) % opts.length];
        return opts[0];
    }

    private static int nextAirGoals(int current) {
        int[] opts = Lobby.AIR_GOAL_OPTIONS;
        for (int i = 0; i < opts.length; i++) if (opts[i] == current) return opts[(i + 1) % opts.length];
        return 7;
    }

    private static int nextTennisGames(int current) {
        int[] opts = Lobby.TENNIS_GAME_OPTIONS;
        for (int i = 0; i < opts.length; i++) if (opts[i] == current) return opts[(i + 1) % opts.length];
        return 3;
    }

    /** Cycles to the next saved field of this sport (wrapping), or null if none exist. */
    @Nullable
    private UUID nextField(LobbySyncPacket data, @Nullable UUID current) {
        List<LobbySyncPacket.FieldView> fields = data.fieldsOf(fieldType());
        if (fields.isEmpty()) return null;
        for (int i = 0; i < fields.size(); i++) {
            if (fields.get(i).field().id().equals(current)) return fields.get((i + 1) % fields.size()).field().id();
        }
        return fields.get(0).field().id();
    }

    private Component fieldLabel(LobbySyncPacket data, @Nullable UUID id) {
        LobbySyncPacket.FieldView fv = data.field(id);
        List<LobbySyncPacket.FieldView> all = data.fieldsOf(fieldType());
        String noun = fieldType().noun;
        if (all.isEmpty()) return Component.literal(noun + ": none built");
        if (fv == null) {
            long open = all.stream().filter(f -> !f.inUse()).count();
            return Component.literal(noun + ": Auto (" + open + "/" + all.size() + " open)")
                    .withStyle(s -> s.withColor(open == 0 ? 0xFF5555 : 0xFFFFFF));
        }
        String name = font.plainSubstrByWidth(fv.field().name(), PANEL_W - 110);
        Component label = Component.literal(noun + ": " + name);
        return fv.inUse()
                ? label.copy().append(Component.literal(" OCCUPIED").withStyle(s -> s.withColor(0xFF5555).withBold(true)))
                : label.copy().append(Component.literal(" OPEN").withStyle(s -> s.withColor(0x55FF55)));
    }

    /**
     * Greys out a start button while the picked field / court / lane is occupied by another game
     * (with "Auto" the server just takes the first open one).
     */
    private void busyCheck(Button b, LobbySyncPacket data, @Nullable UUID fieldId) {
        if (fieldType() == null) return;
        LobbySyncPacket.FieldView fv = data.field(fieldId);
        List<LobbySyncPacket.FieldView> all = data.fieldsOf(fieldType());
        boolean busy = fv != null ? fv.inUse() : !all.isEmpty() && all.stream().allMatch(LobbySyncPacket.FieldView::inUse);
        if (!busy) return;
        b.active = false;
        b.setTooltip(Tooltip.create(Component.literal(fv != null
                ? "\"" + fv.field().name() + "\" is OCCUPIED - someone's playing there. Pick another " + fieldType().noun.toLowerCase()
                  + " or wait for them to finish."
                : "Every " + fieldType().noun.toLowerCase() + " is OCCUPIED right now. Wait for a game to end or build another.")));
    }

    private Tooltip fieldTooltip(LobbySyncPacket data) {
        com.sportsmc.field.FieldType t = fieldType();
        String noun = t.noun.toLowerCase();
        return Tooltip.create(Component.literal(data.fieldsOf(t).isEmpty()
                ? "No " + t.displayName.toLowerCase() + "s yet. Craft a Field Blueprint (paper + green dye + white dye), set it to "
                  + t.displayName + " and mark one."
                : "Click to cycle through saved " + noun + "s. Auto = first free " + noun + "."));
    }

    private static Component difficultyLabel(Difficulty d) {
        return Component.translatable("screen.sportsmc.difficulty", d.displayName());
    }

    @Nullable
    private static LobbySyncPacket.MemberView member(LobbySyncPacket.LobbyView lobby, UUID uuid) {
        for (LobbySyncPacket.MemberView m : lobby.members()) if (m.uuid().equals(uuid)) return m;
        return null;
    }

    @Nullable
    private static UUID myUuid() {
        Minecraft mc = Minecraft.getInstance();
        return mc.player == null ? null : mc.player.getUUID();
    }

    private static void send(LobbyActionPacket packet) {
        ModNetwork.sendToServer(packet);
    }
}
