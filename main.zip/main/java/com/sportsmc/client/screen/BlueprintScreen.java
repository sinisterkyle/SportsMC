package com.sportsmc.client.screen;

import com.sportsmc.client.ClientHooks;
import com.sportsmc.client.ClientLobbyData;
import com.sportsmc.field.FieldData;
import com.sportsmc.field.FieldGeometry;
import javax.annotation.Nullable;
import com.sportsmc.field.FieldType;
import com.sportsmc.field.FieldService;
import com.sportsmc.item.FieldBlueprintItem;
import com.sportsmc.network.BlueprintPacket;
import com.sportsmc.network.LobbySyncPacket;
import com.sportsmc.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemStack;

import java.util.Collections;
import java.util.List;

/**
 * Field Blueprint screen (shift + right-click with the blueprint).
 * Left: the 4-corner checklist, live measurements, name box, Save / Undo / Clear.
 * Right: every saved field, with Visit and Delete for its creator or operators.
 * Everything on the left is read live from the held item, so it updates the moment a corner is set.
 */
public class BlueprintScreen extends Screen {

    private static final int PANEL_W = 200;
    private static final int ROWS_PER_PAGE = 5;
    private static final int ROW_H = 24;

    private static final int COLOR_PANEL = 0xAA101820;
    private static final int COLOR_TEXT = 0xFFFFFF;
    private static final int COLOR_DIM = 0x8C8C8C;
    private static final int COLOR_GOLD = 0xFFC83D;
    private static final int COLOR_A = 0x6FA0FF;
    private static final int COLOR_B = 0xFF7070;
    private static final int COLOR_OK = 0x6CFF6C;
    private static final int COLOR_ERR = 0xFF5555;

    private static String nameDraft = "";
    private int fieldPage = 0;

    private EditBox nameBox;
    private Button saveButton;
    private Button undoButton;
    private Button clearButton;
    private Button typeButton;

    public BlueprintScreen() {
        super(Component.literal("Field Blueprint"));
    }

    public void refresh() {
        // A just-saved field shows up in the list: clear the name box for the next one.
        String name = FieldService.cleanName(nameDraft);
        if (!name.isEmpty() && fields().stream().anyMatch(f -> f.field().name().equalsIgnoreCase(name))
                && FieldBlueprintItem.getPoints(ClientHooks.heldBlueprint()).isEmpty()) {
            nameDraft = "";
        }
        rebuildWidgets();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private int leftX() { return width / 2 - PANEL_W - 10; }
    private int rightX() { return width / 2 + 10; }
    private int top() { return 36; }

    // ------------------------------------------------------------------ widgets

    @Override
    protected void init() {
        int x = leftX(), y = top() + 128;

        nameBox = new EditBox(font, x + 4, y, PANEL_W - 8, 18, Component.literal("Field name"));
        nameBox.setMaxLength(FieldData.MAX_NAME_LENGTH);
        nameBox.setValue(nameDraft);
        nameBox.setHint(Component.literal("Name your " + currentType().noun.toLowerCase() + "...").withStyle(s -> s.withColor(COLOR_DIM)));
        nameBox.setResponder(v -> nameDraft = v);
        addRenderableWidget(nameBox);

        saveButton = addRenderableWidget(Button.builder(Component.literal("Save Field"),
                b -> ModNetwork.sendToServer(BlueprintPacket.save(nameBox.getValue())))
                .bounds(x + 4, y + 24, 96, 20).build());
        undoButton = addRenderableWidget(Button.builder(Component.literal("Undo"),
                b -> ModNetwork.sendToServer(BlueprintPacket.of(BlueprintPacket.Action.UNDO)))
                .bounds(x + 104, y + 24, 44, 20).build());
        clearButton = addRenderableWidget(Button.builder(Component.literal("Clear"),
                b -> ModNetwork.sendToServer(BlueprintPacket.of(BlueprintPacket.Action.CLEAR)))
                .bounds(x + 152, y + 24, 44, 20).build());

        // What this blueprint marks: click to switch (Football Field -> Tennis Court -> ...).
        typeButton = addRenderableWidget(Button.builder(typeLabel(currentType()),
                        b -> ModNetwork.sendToServer(BlueprintPacket.of(BlueprintPacket.Action.CYCLE_TYPE)))
                .bounds(x + 4, top() + 3, PANEL_W - 8, 15)
                .tooltip(Tooltip.create(Component.literal("Switch what this blueprint marks: "
                        + java.util.Arrays.stream(FieldType.values()).map(t -> t.displayName).collect(java.util.stream.Collectors.joining(", "))
                        + ". Corners you've already set are kept.")))
                .build());

        initFieldList();

        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(width / 2 - 50, height - 26, 100, 20).build());

        updateButtons();
    }

    private void initFieldList() {
        List<LobbySyncPacket.FieldView> fields = fields();
        int pages = Math.max(1, (fields.size() + ROWS_PER_PAGE - 1) / ROWS_PER_PAGE);
        fieldPage = Math.min(fieldPage, pages - 1);
        int rx = rightX(), ry = top() + 20;
        int start = fieldPage * ROWS_PER_PAGE;

        for (int i = start; i < Math.min(fields.size(), start + ROWS_PER_PAGE); i++) {
            LobbySyncPacket.FieldView fv = fields.get(i);
            FieldData f = fv.field();
            int rowY = ry + (i - start) * ROW_H;
            boolean manage = canManage(f);

            Button visit = addRenderableWidget(Button.builder(Component.literal("Go"),
                    b -> { ModNetwork.sendToServer(BlueprintPacket.field(BlueprintPacket.Action.TELEPORT, f.id())); onClose(); })
                    .bounds(rx + PANEL_W - 64, rowY, 28, 20)
                    .tooltip(Tooltip.create(Component.literal("Teleport to midfield")))
                    .build());
            visit.active = manage;

            Button del = addRenderableWidget(Button.builder(Component.literal("Del"),
                    b -> ModNetwork.sendToServer(BlueprintPacket.field(BlueprintPacket.Action.DELETE_FIELD, f.id())))
                    .bounds(rx + PANEL_W - 33, rowY, 30, 20)
                    .tooltip(Tooltip.create(Component.literal(fv.inUse() ? "A match is being played here"
                            : manage ? "Delete this field" : "Only " + f.creatorName() + " or an operator can delete")))
                    .build());
            del.active = manage && !fv.inUse();
        }

        if (pages > 1) {
            int py = ry + ROWS_PER_PAGE * ROW_H;
            Button prev = addRenderableWidget(Button.builder(Component.literal("<"), b -> { fieldPage--; rebuildWidgets(); })
                    .bounds(rx + 2, py, 20, 20).build());
            prev.active = fieldPage > 0;
            Button next = addRenderableWidget(Button.builder(Component.literal(">"), b -> { fieldPage++; rebuildWidgets(); })
                    .bounds(rx + PANEL_W - 22, py, 20, 20).build());
            next.active = fieldPage < pages - 1;
        }
    }

    @Override
    public void tick() {
        nameBox.tick();
        updateButtons();
    }

    private void updateButtons() {
        ItemStack stack = ClientHooks.heldBlueprint();
        FieldType type = currentType();
        typeButton.active = !stack.isEmpty();
        typeButton.setMessage(typeLabel(type));
        saveButton.setMessage(Component.literal("Save " + type.noun));
        nameBox.setHint(Component.literal("Name your " + type.noun.toLowerCase() + "...").withStyle(s -> s.withColor(COLOR_DIM)));
        List<BlockPos> points = stack.isEmpty() ? Collections.emptyList() : FieldBlueprintItem.getPoints(stack);
        FieldGeometry.Result r = stack.isEmpty() ? null : FieldBlueprintItem.layout(stack);
        String name = FieldService.cleanName(nameBox.getValue());
        boolean duplicate = fields().stream().anyMatch(f -> f.field().name().equalsIgnoreCase(name));

        saveButton.active = r != null && r.ok() && !name.isEmpty() && !duplicate;
        saveButton.setTooltip(Tooltip.create(Component.literal(
                r == null ? "Mark both corners of the " + type.noun.toLowerCase() + " first"
                        : !r.ok() ? "Fix the layout first"
                        : name.isEmpty() ? "Type a name for the " + type.noun.toLowerCase()
                        : duplicate ? "That name is already taken"
                        : "Save \"" + name + "\" as a " + type.displayName)));
        undoButton.active = !points.isEmpty();
        clearButton.active = !points.isEmpty();
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        int lx = leftX(), rx = rightX(), y = top();

        g.drawCenteredString(font, Component.literal("FIELD BLUEPRINT").withStyle(s -> s.withBold(true).withColor(COLOR_GOLD)),
                width / 2, 14, COLOR_TEXT);

        g.fill(lx, y, lx + PANEL_W, y + 176, COLOR_PANEL);
        g.fill(rx, y, rx + PANEL_W, y + 20 + (ROWS_PER_PAGE + 1) * ROW_H, COLOR_PANEL);

        renderLayout(g, lx, y);
        renderFieldList(g, rx, y);

        super.render(g, mouseX, mouseY, partialTick);

        FieldType type = currentType();
        String hint = type == FieldType.TENNIS
                ? "Corner 1 = a baseline corner  \u2022  Corner 2 = opposite corner on the other baseline"
                : type == FieldType.BOWLING
                ? "Corner 1 = foul line corner  \u2022  Corner 2 = far corner past the pins  \u2022  one lane per save"
                : "Corner 1 = HOME goal line  \u2022  Corner 2 = AWAY goal line  \u2022  leave room for end zones";
        g.drawCenteredString(font, Component.literal(hint), width / 2, height - 38, COLOR_DIM);
    }

    private void renderLayout(GuiGraphics g, int x, int y) {
        ItemStack stack = ClientHooks.heldBlueprint();
        FieldType type = currentType();
        if (stack.isEmpty()) {
            g.drawString(font, "Hold a Field Blueprint to mark corners.", x + 6, y + 22, COLOR_DIM);
            return;
        }

        List<BlockPos> points = FieldBlueprintItem.getPoints(stack);
        String[] labels = {"Corner 1", "Corner 2"};
        for (int i = 0; i < 2; i++) {
            int rowY = y + 20 + i * 12;
            int color = i == 0 ? COLOR_A : COLOR_B;
            if (i < points.size()) {
                BlockPos p = points.get(i);
                g.drawString(font, "\u2714 " + labels[i], x + 6, rowY, color);
                g.drawString(font, p.getX() + ", " + p.getY() + ", " + p.getZ(), x + 70, rowY, COLOR_TEXT);
            } else if (i == points.size()) {
                g.drawString(font, "\u27A4 " + labels[i], x + 6, rowY, COLOR_GOLD);
                String where = type == FieldType.TENNIS ? (i == 0 ? "a baseline corner" : "opposite corner")
                        : type == FieldType.BOWLING ? (i == 0 ? "foul line corner" : "far corner (pit)")
                        : (i == 0 ? "HOME goal line" : "opposite goal line");
                g.drawString(font, where, x + 70, rowY, COLOR_GOLD);
            } else {
                g.drawString(font, "   " + labels[i], x + 6, rowY, COLOR_DIM);
            }
        }

        int my = y + 48;
        FieldGeometry.Result r = FieldBlueprintItem.layout(stack);
        if (type == FieldType.TENNIS) {
            renderTennisLayout(g, x, my, r);
            return;
        }
        if (type == FieldType.BOWLING) {
            renderBowlingLayout(g, x, my, r);
            return;
        }
        if (r != null && r.ok()) {
            FieldGeometry geo = r.geometry();
            line(g, x, my, "100 yds", FieldGeometry.fmt(geo.length()) + " blocks goal to goal", COLOR_OK);
            line(g, x, my + 11, "1 yard", FieldGeometry.fmt(geo.blocksPerYard()) + " blocks", COLOR_TEXT);
            line(g, x, my + 22, "End zones", "+" + FieldGeometry.fmt(geo.endZoneDepth()) + " blocks past each goal", COLOR_TEXT);
            line(g, x, my + 33, "With EZs", FieldGeometry.fmt(geo.totalLength()) + " blocks (120 yds)", COLOR_TEXT);
            int wy = (int) Math.round(geo.widthYards());
            line(g, x, my + 44, "Width", FieldGeometry.fmt(geo.width()) + " blocks = " + wy + " yds", COLOR_TEXT);
            line(g, x, my + 55, "Runs", geo.axis.label, COLOR_TEXT);
            if (wy < 40 || wy > 70) {
                g.drawString(font, "(NFL width is 53 yds - yours plays " + (wy < 40 ? "narrow" : "wide") + ")", x + 6, my + 66, COLOR_GOLD);
            }
        } else if (r != null) {
            List<FormattedCharSequence> lines = font.split(Component.literal(r.error()), PANEL_W - 12);
            for (int i = 0; i < Math.min(lines.size(), 5); i++) g.drawString(font, lines.get(i), x + 6, my + i * 11, COLOR_ERR);
        } else {
            g.drawString(font, "Click two OPPOSITE corners of the", x + 6, my, COLOR_DIM);
            g.drawString(font, "playing field, goal line to goal line.", x + 6, my + 11, COLOR_DIM);
            g.drawString(font, "That length = 100 yards. 10-yard end", x + 6, my + 27, COLOR_DIM);
            g.drawString(font, "zones are added past each goal line.", x + 6, my + 38, COLOR_DIM);
            g.drawString(font, "Full scale: 100 x 53 blocks.", x + 6, my + 54, COLOR_DIM);
        }
    }

    /** Tennis court: 78 ft baseline to baseline, 36 ft between the doubles sidelines (27 ft singles). */
    private void renderTennisLayout(GuiGraphics g, int x, int my, @Nullable FieldGeometry.Result r) {
        if (r != null && r.ok()) {
            FieldGeometry geo = r.geometry();
            double ftPerBlock = 78.0 / geo.length();
            line(g, x, my, "Length", FieldGeometry.fmt(geo.length()) + " blocks baseline to baseline", COLOR_OK);
            line(g, x, my + 11, "Width", FieldGeometry.fmt(geo.width()) + " blocks (doubles)", COLOR_TEXT);
            line(g, x, my + 22, "Singles", FieldGeometry.fmt(geo.width() * 27.0 / 36.0) + " blocks wide", COLOR_TEXT);
            line(g, x, my + 33, "Service", FieldGeometry.fmt(geo.length() * 21.0 / 78.0) + " blocks from the net", COLOR_TEXT);
            line(g, x, my + 44, "Scale", "1 block = " + FieldGeometry.fmt(ftPerBlock) + " ft", COLOR_TEXT);
            line(g, x, my + 55, "Runs", geo.axis.label, COLOR_TEXT);
            double ratio = geo.length() / geo.width();
            if (ratio < 1.6 || ratio > 2.8) {
                g.drawString(font, "(A real court is ~2.2x longer than wide)", x + 6, my + 66, COLOR_GOLD);
            }
        } else if (r != null) {
            List<FormattedCharSequence> lines = font.split(Component.literal(r.error()), PANEL_W - 12);
            for (int i = 0; i < Math.min(lines.size(), 5); i++) g.drawString(font, lines.get(i), x + 6, my + i * 11, COLOR_ERR);
        } else {
            g.drawString(font, "Click two OPPOSITE corners of the", x + 6, my, COLOR_DIM);
            g.drawString(font, "court, baseline to baseline, on the", x + 6, my + 11, COLOR_DIM);
            g.drawString(font, "outer (doubles) sidelines. The net,", x + 6, my + 22, COLOR_DIM);
            g.drawString(font, "service boxes and singles lines are", x + 6, my + 33, COLOR_DIM);
            g.drawString(font, "drawn for you.", x + 6, my + 44, COLOR_DIM);
            g.drawString(font, "Regulation: 24 x 11 blocks.", x + 6, my + 60, COLOR_DIM);
        }
    }

    /** Bowling lane: the marked width includes the gutters; pins and ball are sized to the lane. */
    private void renderBowlingLayout(GuiGraphics g, int x, int my, @Nullable FieldGeometry.Result r) {
        if (r != null && r.ok()) {
            FieldGeometry geo = r.geometry();
            com.sportsmc.bowling.BowlingPhysics.Dims d = com.sportsmc.bowling.BowlingPhysics.Dims.of(geo.length(), geo.width());
            line(g, x, my, "Length", FieldGeometry.fmt(geo.length()) + " blocks foul line to pit", COLOR_OK);
            line(g, x, my + 11, "Width", FieldGeometry.fmt(geo.width()) + " blocks with gutters", COLOR_TEXT);
            line(g, x, my + 22, "Lane", String.format("%.1f", d.laneHalf() * 2) + " blocks between gutters", COLOR_TEXT);
            line(g, x, my + 33, "Pins", String.format("%.2f", d.pinH()) + " blocks tall", COLOR_TEXT);
            line(g, x, my + 44, "Head pin", String.format("%.1f", d.headU()) + " blocks from the foul line", COLOR_TEXT);
            line(g, x, my + 55, "Runs", geo.axis.label, COLOR_TEXT);
            if (geo.width() < 2.5) g.drawString(font, "(3 blocks wide makes bigger pins)", x + 6, my + 66, COLOR_GOLD);
        } else if (r != null) {
            List<FormattedCharSequence> lines = font.split(Component.literal(r.error()), PANEL_W - 12);
            for (int i = 0; i < Math.min(lines.size(), 5); i++) g.drawString(font, lines.get(i), x + 6, my + i * 11, COLOR_ERR);
        } else {
            g.drawString(font, "Click two OPPOSITE corners of one", x + 6, my, COLOR_DIM);
            g.drawString(font, "lane: the foul line end, then the", x + 6, my + 11, COLOR_DIM);
            g.drawString(font, "far end past the pins. Include the", x + 6, my + 22, COLOR_DIM);
            g.drawString(font, "gutters in the width. Gutters, arrows", x + 6, my + 33, COLOR_DIM);
            g.drawString(font, "and pin spots are drawn for you.", x + 6, my + 44, COLOR_DIM);
            g.drawString(font, "Good size: 20-24 x 3 blocks.", x + 6, my + 60, COLOR_DIM);
        }
    }

    private void line(GuiGraphics g, int x, int y, String label, String value, int valueColor) {
        g.drawString(font, label, x + 6, y, COLOR_DIM);
        g.drawString(font, value, x + 62, y, valueColor);
    }

    private void renderFieldList(GuiGraphics g, int x, int y) {
        List<LobbySyncPacket.FieldView> fields = fields();
        g.drawString(font, "Saved Fields (" + fields.size() + ")", x + 6, y + 6, COLOR_GOLD);
        if (fields.isEmpty()) {
            g.drawString(font, "None yet - build your first!", x + 6, y + 26, COLOR_DIM);
            return;
        }
        int start = fieldPage * ROWS_PER_PAGE;
        for (int i = start; i < Math.min(fields.size(), start + ROWS_PER_PAGE); i++) {
            LobbySyncPacket.FieldView fv = fields.get(i);
            int rowY = y + 20 + (i - start) * ROW_H;
            String name = font.plainSubstrByWidth(fv.field().name(), PANEL_W - 76);
            g.drawString(font, name, x + 6, rowY + 1, fv.inUse() ? COLOR_GOLD : COLOR_TEXT);
            String sub = fv.inUse() ? "OCCUPIED - game in progress"
                    : fv.field().type().sport + " \u2022 " + fv.field().geometry().summary();
            g.drawString(font, font.plainSubstrByWidth(sub, PANEL_W - 70), x + 6, rowY + 11, fv.inUse() ? COLOR_ERR : COLOR_DIM);
        }
    }

    // ------------------------------------------------------------------ helpers

    private static List<LobbySyncPacket.FieldView> fields() {
        LobbySyncPacket data = ClientLobbyData.get();
        return data == null ? Collections.emptyList() : data.fields();
    }

    private static FieldType currentType() {
        ItemStack stack = ClientHooks.heldBlueprint();
        return stack.isEmpty() ? FieldType.FOOTBALL : FieldBlueprintItem.getType(stack);
    }

    private static Component typeLabel(FieldType type) {
        return Component.literal("Marking: ").append(Component.literal(type.displayName).withStyle(s -> s.withColor(COLOR_GOLD)))
                .append(Component.literal("   \u21C4 switch").withStyle(s -> s.withColor(COLOR_DIM)));
    }

    private static boolean canManage(FieldData f) {
        Minecraft mc = Minecraft.getInstance();
        return mc.player != null && (f.creator().equals(mc.player.getUUID()) || mc.player.hasPermissions(2));
    }
}
