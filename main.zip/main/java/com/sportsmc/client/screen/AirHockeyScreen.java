package com.sportsmc.client.screen;

import com.sportsmc.airhockey.AirHockeyPhysics;
import com.sportsmc.airhockey.AirHockeyPhysics.Puck;
import com.sportsmc.network.AirHockeyInputPacket;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import com.sportsmc.client.AirHockeyTheme;
import com.sportsmc.client.ClientAirHockeyData;
import com.sportsmc.lobby.Lobby;
import com.sportsmc.network.AirHockeyStatePacket;
import com.sportsmc.network.LobbyActionPacket;
import com.sportsmc.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * The air hockey table. Your goal is always at the bottom; move the mouse and your mallet follows it
 * (it can't cross the center line). ESC hides the table (the match keeps going) and M brings it back.
 *
 * Netcode: while the puck is on your half, this screen runs it (AirHockeyPhysics) with your mallet, so your
 * hits are instant and exact, and reports it to the server. While it's on your opponent's half, the server's
 * puck is run forward by the network delay ("lead") to show where it really is now, and small corrections
 * are blended in over a few frames instead of snapping. Everything is drawn in one batch.
 * The arrows on the right (or the left / right arrow keys) cycle through table themes; the choice is
 * personal and remembered.
 */
public class AirHockeyScreen extends Screen {

    private static final int TEXT = 0xFFFFFFFF, DIM = 0xFFA8B0C0, GOLD = 0xFFFFC83D;

    private double mouseX, mouseY;
    private boolean cursorHidden;
    private final Deque<double[]> trail = new ArrayDeque<>();

    // ---- local simulation (table frame) ----
    private final Puck puck = new Puck();
    @javax.annotation.Nullable private double[] myMallet;
    @javax.annotation.Nullable private double[] oppLast;
    @javax.annotation.Nullable private double[] oppShown;
    private boolean owning;
    private int seq;
    /** Seq of my newest input that carried the puck; server states older than it don't know about my last hit. */
    private int lastPuckSeq;
    private int goalHold;
    private int ignoredServer;
    private int hitCooldown, wallCooldown;
    /** Visual offset left over from a correction; fades out over a few frames so the puck never jumps. */
    private double offX, offY;
    private long lastTickNanos = System.nanoTime(), lastFrameNanos = System.nanoTime();

    public AirHockeyScreen() {
        super(Component.literal("Air Hockey"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    protected void init() {
        addRenderableWidget(Button.builder(Component.literal("Forfeit"), b -> {
            ModNetwork.sendToServer(LobbyActionPacket.of(LobbyActionPacket.Action.LEAVE));
            onClose();
        }).bounds(width - 70, height - 24, 64, 20).build());
        int x0 = themeX(), pw = themeW();
        if (pw >= 60) {
            addRenderableWidget(Button.builder(Component.literal("◀"), b -> AirHockeyTheme.cycle(-1))
                    .bounds(x0, top() + 18, 20, 20).build());
            addRenderableWidget(Button.builder(Component.literal("▶"), b -> AirHockeyTheme.cycle(1))
                    .bounds(x0 + pw - 20, top() + 18, 20, 20).build());
        }
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_LEFT) { AirHockeyTheme.cycle(-1); return true; }
        if (key == GLFW.GLFW_KEY_RIGHT) { AirHockeyTheme.cycle(1); return true; }
        return super.keyPressed(key, scan, mods);
    }

    // ------------------------------------------------------------------ layout

    private int tableH() { return Math.max(120, Math.min(height - 46, (width - 230) * 2)); }
    private int tableW() { return tableH() / 2; }
    private int left() { return width / 2 - tableW() / 2; }
    private int top() { return 20; }
    private int themeX() { return left() + tableW() + 24; }
    private int themeW() { return Math.min(130, width - themeX() - 8); }

    /** View frame (own goal at the bottom) to screen. */
    private double sx(double vx) { return left() + (vx + 0.5) * tableW(); }
    private double sy(double vy) { return top() + (1 - vy) / 2 * tableH(); }

    private static boolean flipped(AirHockeyStatePacket s) { return s.viewerSide() == Lobby.Side.AWAY; }

    // ------------------------------------------------------------------ input

    @Override
    public void mouseMoved(double x, double y) {
        mouseX = x;
        mouseY = y;
    }

    /** Where your mallet wants to be, in the view frame, kept in your half. */
    private double[] ownMalletView() {
        double r = AirHockeyPhysics.MALLET_R;
        double vx = (mouseX - left()) / tableW() - 0.5;
        double vy = 1 - 2 * (mouseY - top()) / tableH();
        vx = Math.max(-0.5 + r, Math.min(0.5 - r, vx));
        vy = Math.max(-1 + r, Math.min(-r, vy));
        return new double[]{vx, vy};
    }

    @Override
    public void tick() {
        AirHockeyStatePacket s = ClientAirHockeyData.get();
        if (s == null) { onClose(); return; }
        lastTickNanos = System.nanoTime();
        boolean home = s.viewerSide() == Lobby.Side.HOME;
        boolean fresh = ClientAirHockeyData.consumeFresh();
        if (hitCooldown > 0) hitCooldown--;
        if (wallCooldown > 0) wallCooldown--;

        // My mallet: toward the mouse at the table's mallet speed (the same rule the server uses).
        double[] v = ownMalletView();
        double[] want = AirHockeyPhysics.clampToHalf(home, flipped(s) ? -v[0] : v[0], flipped(s) ? -v[1] : v[1]);
        if (myMallet == null) myMallet = want;
        double[] mFrom = myMallet;
        double[] mTo = AirHockeyPhysics.stepToward(myMallet, want, AirHockeyPhysics.MAX_MALLET_STEP);
        myMallet = mTo;
        // Opponent's mallet as last reported.
        double[] oNow = home ? new double[]{s.awayX(), s.awayY()} : new double[]{s.homeX(), s.homeY()};
        double[] oFrom = oppLast == null ? oNow : oppLast;
        oppLast = oNow;

        int seqNow = ++seq;
        if (s.phase() != AirHockeyStatePacket.Phase.PLAY) {
            // Countdown / goal / game over: the server's puck, as is.
            owning = false;
            goalHold = 0;
            puck.set(new Puck(s.puckX(), s.puckY(), 0, 0));
            offX = offY = 0;
            send(AirHockeyInputPacket.malletOnly(seqNow, (float) mTo[0], (float) mTo[1]));
            return;
        }
        if (goalHold > 0) {
            // I reported a goal against me; wait for the server to confirm (or resume from its puck if it doesn't).
            if (--goalHold == 0) correctFromServer(s);
            send(AirHockeyInputPacket.malletOnly(seqNow, (float) mTo[0], (float) mTo[1]));
            return;
        }

        if (fresh) {
            int opp = home ? 2 : 1;
            if (!owning) {
                // Just shot it across: until the server has my last report, my own game knows better than it does.
                if (s.ackSeq() >= lastPuckSeq) correctFromServer(s);
                ignoredServer = 0;
            } else if (s.owner() == opp && ++ignoredServer > 6) {
                // The server has had the puck on the other side for a third of a second: we're out of sync, follow it.
                owning = false;
                correctFromServer(s);
                ignoredServer = 0;
            } else if (s.owner() != opp) {
                ignoredServer = 0;
            }
        }

        boolean wasOwning = owning;
        int ev = home ? AirHockeyPhysics.step(puck, mFrom, mTo, oFrom, oNow)
                      : AirHockeyPhysics.step(puck, oFrom, oNow, mFrom, mTo);
        boolean onMine = AirHockeyPhysics.onHalf(home, puck.y);
        boolean goalAgainst = (ev & (home ? AirHockeyPhysics.GOAL_FOR_AWAY : AirHockeyPhysics.GOAL_FOR_HOME)) != 0;
        boolean goalFor = (ev & (home ? AirHockeyPhysics.GOAL_FOR_HOME : AirHockeyPhysics.GOAL_FOR_AWAY)) != 0;
        owning = onMine || goalAgainst;

        if (wasOwning || owning) {
            // My game is running the puck: report it (including the tick it leaves my half).
            int events = 0;
            boolean myHit = (ev & (home ? AirHockeyPhysics.HIT_HOME : AirHockeyPhysics.HIT_AWAY)) != 0;
            if (myHit) {
                events |= AirHockeyInputPacket.EV_HIT;
                if (hitCooldown == 0) {
                    float st = (float) puck.lastHitStrength;
                    play(0.6f + 0.5f * st, 1.4f + 0.5f * st);
                    hitCooldown = 3;
                }
            }
            if ((ev & AirHockeyPhysics.WALL) != 0) {
                events |= AirHockeyInputPacket.EV_WALL;
                if (wallCooldown == 0) { play(0.4f, 1.0f); wallCooldown = 3; }
            }
            if (goalAgainst) {
                events |= AirHockeyInputPacket.EV_GOAL_AGAINST;
                goalHold = 20;
                owning = false;
            }
            lastPuckSeq = seqNow;
            send(new AirHockeyInputPacket(seqNow, (float) mTo[0], (float) mTo[1], true, (float) puck.x, (float) puck.y,
                    (float) puck.vx, (float) puck.vy, events, (float) puck.lastHitStrength));
            if (goalAgainst) { puck.vx = puck.vy = 0; }
        } else {
            if (goalFor) { puck.vx = puck.vy = 0; } // their game / the server decides; just wait at the line
            send(AirHockeyInputPacket.malletOnly(seqNow, (float) mTo[0], (float) mTo[1]));
        }
    }

    /** Takes the server's puck, runs it forward by the delay so it shows where it is now, and blends the jump. */
    private void correctFromServer(AirHockeyStatePacket s) {
        Puck target = new Puck(s.puckX(), s.puckY(), s.puckVX(), s.puckVY());
        for (int i = 0; i < s.lead(); i++) {
            int ev = AirHockeyPhysics.step(target, null, null, null, null);
            if ((ev & (AirHockeyPhysics.GOAL_FOR_HOME | AirHockeyPhysics.GOAL_FOR_AWAY)) != 0) { target.vx = target.vy = 0; break; }
        }
        double dx = puck.x - target.x, dy = puck.y - target.y;
        if (dx * dx + dy * dy < 0.5 * 0.5) { offX += dx; offY += dy; } // glide to it (big jumps only on a real desync)
        else { offX = 0; offY = 0; }
        puck.set(target);
    }

    private static void send(AirHockeyInputPacket p) {
        ModNetwork.sendToServer(p);
    }

    private static void play(float volume, float pitch) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_HAT.value(), pitch, volume));
    }

    @Override
    public void removed() {
        setCursorHidden(false);
        super.removed();
    }

    private void setCursorHidden(boolean hide) {
        if (hide == cursorHidden) return;
        cursorHidden = hide;
        GLFW.glfwSetInputMode(Minecraft.getInstance().getWindow().getWindow(), GLFW.GLFW_CURSOR,
                hide ? GLFW.GLFW_CURSOR_HIDDEN : GLFW.GLFW_CURSOR_NORMAL);
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        renderBackground(g);
        AirHockeyStatePacket s = ClientAirHockeyData.get();
        if (s == null) { super.render(g, mx, my, partialTick); return; }
        mouseX = mx;
        mouseY = my;
        boolean overTable = mx >= left() - 10 && mx <= left() + tableW() + 10 && my >= top() - 10 && my <= top() + tableH() + 10;
        setCursorHidden(overTable);

        AirHockeyTheme th = AirHockeyTheme.current();
        boolean flip = flipped(s);
        long now = System.nanoTime();
        double dt = Math.min(0.1, (now - lastFrameNanos) / 1e9);
        lastFrameNanos = now;
        double fade = Math.exp(-dt * 12);
        offX *= fade;
        offY *= fade;

        // Puck: the local simulation, moved on by the time since the last tick so it glides at any frame rate.
        double sinceTick = Math.min(1.5, (now - lastTickNanos) / 50_000_000.0);
        boolean moving = s.phase() == AirHockeyStatePacket.Phase.PLAY && goalHold == 0;
        double px = puck.x + (moving ? puck.vx * sinceTick : 0) + offX;
        double py = puck.y + (moving ? puck.vy * sinceTick : 0) + offY;
        double pvx = flip ? -px : px, pvy = flip ? -py : py;
        trail.addFirst(new double[]{pvx, pvy});
        while (trail.size() > 6) trail.removeLast();

        // Opponent mallet: glides toward its latest reported spot.
        double[] oTarget = flip ? new double[]{s.homeX(), s.homeY()} : new double[]{s.awayX(), s.awayY()};
        if (oppShown == null) oppShown = oTarget.clone();
        double k = 1 - Math.exp(-dt * 25);
        oppShown[0] += (oTarget[0] - oppShown[0]) * k;
        oppShown[1] += (oTarget[1] - oppShown[1]) * k;
        double ox = flip ? -oppShown[0] : oppShown[0], oy = flip ? -oppShown[1] : oppShown[1];
        double[] own = ownMalletView(); // drawn right at your mouse: no lag

        // One batched draw for the whole table instead of a draw call per shape.
        g.drawManaged(() -> {
            drawTable(g, th);
            drawMallet(g, ox, oy, th.theirMallet(), th.glow());
            int i = 0;
            for (double[] t : trail) {
                if (i++ == 0) continue;
                int alpha = Math.max(0, 70 - i * 12);
                fillCircle(g, sx(t[0]), sy(t[1]), AirHockeyPhysics.PUCK_R * tableW(), (alpha << 24) | (th.trail() & 0xFFFFFF));
            }
            drawPuck(g, pvx, pvy, th);
            drawMallet(g, own[0], own[1], th.myMallet(), th.glow());
        });
        // Panels and text after the batch (text is queued separately and must land on top of its panel).
        drawScoreboard(g, s, th);
        drawThemePanel(g, th);
        drawMessage(g, s, th);
        g.drawCenteredString(font, "Move the mouse to play  •  ◀ ▶ change theme  •  ESC hides the table (M to return)", width / 2, height - 14, DIM);
        super.render(g, mx, my, partialTick);
    }

    private void drawTable(GuiGraphics g, AirHockeyTheme th) {
        int l = left(), t = top(), w = tableW(), h = tableH();
        // Rails.
        g.fill(l - 8, t - 8, l + w + 8, t + h + 8, th.rail());
        g.fill(l - 3, t - 3, l + w + 3, t + h + 3, th.railLight());
        // Surface + the theme's animated decoration, clipped to the table.
        g.fillGradient(l, t, l + w, t + h, th.surfaceTop(), th.surfaceBottom());
        g.flush(); // batched drawing: finish what's queued before clipping
        g.enableScissor(l, t, l + w, t + h);
        th.drawPattern(g, l, t, w, h, System.currentTimeMillis());
        g.flush();
        g.disableScissor();
        // Center line, center circle, goal creases (with a soft halo for glowing themes).
        int cy = t + h / 2;
        if (th.glow()) {
            int halo = 0x40000000 | (th.centerLine() & 0xFFFFFF);
            g.fill(l, cy - 3, l + w, cy + 3, halo);
            ring(g, l + w / 2.0, cy, w * 0.16 + 1, halo, 0, Math.PI * 2);
            ring(g, l + w / 2.0, cy, w * 0.16 - 1, halo, 0, Math.PI * 2);
            int creaseHalo = 0x40000000 | (th.creaseLine() & 0xFFFFFF);
            ring(g, l + w / 2.0, t + h, w * 0.26 + 1, creaseHalo, Math.PI, Math.PI * 2);
            ring(g, l + w / 2.0, t, w * 0.26 + 1, creaseHalo, 0, Math.PI);
        }
        g.fill(l, cy - 1, l + w, cy + 1, th.centerLine());
        ring(g, l + w / 2.0, cy, w * 0.16, th.centerLine(), 0, Math.PI * 2);
        ring(g, l + w / 2.0, t + h, w * 0.26, th.creaseLine(), Math.PI, Math.PI * 2);   // your crease (bottom)
        ring(g, l + w / 2.0, t, w * 0.26, th.creaseLine(), 0, Math.PI);                 // their crease (top)
        // Goal slots in the end rails.
        int gw = (int) (AirHockeyPhysics.GOAL_HALF * w);
        g.fill(l + w / 2 - gw, t - 8, l + w / 2 + gw, t, th.slot());
        g.fill(l + w / 2 - gw, t + h, l + w / 2 + gw, t + h + 8, th.slot());
    }

    private void drawMallet(GuiGraphics g, double vx, double vy, int color, boolean glow) {
        double r = AirHockeyPhysics.MALLET_R * tableW();
        double x = sx(vx), y = sy(vy);
        if (glow) fillCircle(g, x, y, r + 3, 0x40000000 | (color & 0xFFFFFF));
        fillCircle(g, x + 1.5, y + 2, r, 0x50000000);           // shadow
        fillCircle(g, x, y, r, color);
        fillCircle(g, x, y, r * 0.72, darker(color));
        fillCircle(g, x, y, r * 0.38, lighter(color));          // the handle knob
    }

    private void drawPuck(GuiGraphics g, double vx, double vy, AirHockeyTheme th) {
        double r = AirHockeyPhysics.PUCK_R * tableW();
        double x = sx(vx), y = sy(vy);
        if (th.glow()) fillCircle(g, x, y, r + 3, 0x50000000 | (th.puckRim() & 0xFFFFFF));
        fillCircle(g, x + 1, y + 1.5, r, 0x50000000);
        fillCircle(g, x, y, r, th.puckRim());
        fillCircle(g, x, y, r * 0.78, th.puck());
    }

    /** Theme picker on the right of the table: name between the arrow buttons, plus a small preview. */
    private void drawThemePanel(GuiGraphics g, AirHockeyTheme th) {
        int x0 = themeX(), pw = themeW();
        if (pw < 60) return;
        g.fill(x0 - 4, top(), x0 + pw + 4, top() + 92, 0xC0101820);
        g.drawCenteredString(font, "THEME", x0 + pw / 2, top() + 6, DIM);
        String name = font.plainSubstrByWidth(th.name(), pw - 46);
        g.drawCenteredString(font, name, x0 + pw / 2, top() + 24, th.accent() | 0xFF000000);
        // Mini table preview.
        int pwid = 28, ph = 40, px = x0 + pw / 2 - pwid / 2, py = top() + 44;
        g.fill(px - 2, py - 2, px + pwid + 2, py + ph + 2, th.rail());
        g.fillGradient(px, py, px + pwid, py + ph, th.surfaceTop(), th.surfaceBottom());
        g.fill(px, py + ph / 2, px + pwid, py + ph / 2 + 1, th.centerLine());
        fillCircle(g, px + pwid / 2.0, py + 8, 3.5, th.theirMallet());
        fillCircle(g, px + pwid * 0.65, py + ph * 0.42, 2, th.puckRim());
        fillCircle(g, px + pwid / 2.0, py + ph - 8, 3.5, th.myMallet());
        String idx = (AirHockeyTheme.THEMES.indexOf(th) + 1) + "/" + AirHockeyTheme.THEMES.size();
        g.drawString(font, idx, x0 + pw - font.width(idx), top() + 80, DIM);
    }

    private void drawScoreboard(GuiGraphics g, AirHockeyStatePacket s, AirHockeyTheme th) {
        boolean flip = flipped(s);
        String me = flip ? s.awayName() : s.homeName(), them = flip ? s.homeName() : s.awayName();
        int myScore = flip ? s.awayScore() : s.homeScore(), theirScore = flip ? s.homeScore() : s.awayScore();
        int x = left() - 24;
        int panelW = Math.min(150, left() - 40);
        if (panelW < 60) return;
        int px0 = x - panelW;
        g.fill(px0, top(), x, top() + 70, 0xC0101820);
        g.drawString(font, font.plainSubstrByWidth(them, panelW - 10), px0 + 6, top() + 6, th.theirMallet());
        bigNumber(g, theirScore, px0 + 6, top() + 18);
        g.fill(px0, top() + tableH() - 70, x, top() + tableH(), 0xC0101820);
        g.drawString(font, "YOU (" + font.plainSubstrByWidth(me, panelW - 50) + ")", px0 + 6, top() + tableH() - 64, th.myMallet());
        bigNumber(g, myScore, px0 + 6, top() + tableH() - 52);
        g.drawString(font, "First to " + s.goalsToWin(), px0 + 6, top() + tableH() / 2 - 4, DIM);
    }

    private void bigNumber(GuiGraphics g, int n, int x, int y) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(4f, 4f, 1f);
        g.drawString(font, String.valueOf(n), 0, 0, TEXT);
        g.pose().popPose();
    }

    private void drawMessage(GuiGraphics g, AirHockeyStatePacket s, AirHockeyTheme th) {
        if (s.message().isEmpty()) return;
        int color = s.phase() == AirHockeyStatePacket.Phase.GOAL || s.phase() == AirHockeyStatePacket.Phase.OVER ? (th.accent() | 0xFF000000) : TEXT;
        float scale = s.message().length() <= 3 ? 4f : 2f;
        int w = font.width(s.message());
        g.pose().pushPose();
        g.pose().translate(width / 2f, top() + tableH() / 2f - 30, 0);
        g.pose().scale(scale, scale, 1f);
        g.fill(-w / 2 - 4, -3, w / 2 + 4, 11, 0xA0000000);
        g.drawString(font, s.message(), -w / 2, 0, color);
        g.pose().popPose();
    }

    // ------------------------------------------------------------------ shapes

    private static void fillCircle(GuiGraphics g, double cx, double cy, double r, int color) {
        AirHockeyTheme.fillCircle(g, cx, cy, r, color);
    }

    private static void ring(GuiGraphics g, double cx, double cy, double r, int color, double a0, double a1) {
        AirHockeyTheme.ring(g, cx, cy, r, color, a0, a1);
    }

    private static int darker(int c) {
        int r = (c >> 16 & 255) * 7 / 10, gr = (c >> 8 & 255) * 7 / 10, b = (c & 255) * 7 / 10;
        return 0xFF000000 | r << 16 | gr << 8 | b;
    }

    private static int lighter(int c) {
        int r = Math.min(255, (c >> 16 & 255) + 70), gr = Math.min(255, (c >> 8 & 255) + 70), b = Math.min(255, (c & 255) + 70);
        return 0xFF000000 | r << 16 | gr << 8 | b;
    }
}
