package com.sportsmc.client.screen;

import com.sportsmc.bowling.BowlingPhysics;
import com.sportsmc.bowling.BowlingScore;
import com.sportsmc.client.ClientBowlingData;
import com.sportsmc.client.ClientLobbyData;
import com.sportsmc.network.BowlingStatePacket;
import com.sportsmc.network.BowlingThrowPacket;
import com.sportsmc.network.LobbySyncPacket;
import com.sportsmc.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 * Your turn to bowl, Pokemon GO style. The ball sits at the bottom of the screen (the lane stays visible behind):
 *   1. GRAB it: press and hold the left mouse button.
 *   2. (Optional) SPIN it: move the mouse in little circles while holding - the ball spins up, and that spin
 *      becomes a curve ball: clockwise curves right, counter-clockwise left, faster circles curve more.
 *   3. FLICK it: swipe the mouse UP and let go. How fast you flick = how hard it's rolled; flicking a little left
 *      or right aims it that way.
 * A / D (or the arrow keys) move where you stand on the foul line first. Any upward flick bowls.
 */
public class BowlingThrowScreen extends Screen {

    /** Where you stand (-1 left edge .. 1 right edge), kept between balls. Aim is always 0 here (the flick aims). */
    public static float start = 0f, aim = 0f;

    private static final int BALL_R = 22;
    /** Upward flick speed (GUI pixels per second) for full power; anything above MIN_FLICK bowls. */
    private static final double FULL_FLICK = 1100, MIN_FLICK = 90;

    private boolean holding;
    private int heldX, heldY;
    /** Mouse samples while holding: {time ns, x, y}. */
    private final ArrayDeque<double[]> samples = new ArrayDeque<>();
    /** Spin: how fast the mouse's direction of travel is turning (rad/s, + = clockwise), smoothed. */
    private double spinRate, spinAngle, lastHeading;
    private boolean haveHeading;
    private final ArrayDeque<double[]> spinHistory = new ArrayDeque<>(); // {time ns, spinRate}
    private long lastNanos;
    /** After letting go: the ball flies up the screen. */
    private long thrownAt = -1;
    private double throwDx;
    private String note = "";
    private long noteUntil;

    public BowlingThrowScreen() {
        super(Component.literal("Bowl"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    protected void init() {
        addRenderableWidget(Button.builder(Component.literal("Leave game"),
                        b -> { ModNetwork.sendToServer(com.sportsmc.network.LobbyActionPacket.of(com.sportsmc.network.LobbyActionPacket.Action.LEAVE)); onClose(); })
                .bounds(width - 74, 4, 70, 16).build());
    }

    /** True for the moment after you let go, while the ball flies off (the screen closes itself after). */
    public boolean throwing() {
        return thrownAt >= 0;
    }

    private int ballX() { return width / 2; }
    private int ballY() { return height - 52; }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_A || key == GLFW.GLFW_KEY_LEFT) { start = Mth.clamp(start - 0.05f, -1f, 1f); return true; }
        if (key == GLFW.GLFW_KEY_D || key == GLFW.GLFW_KEY_RIGHT) { start = Mth.clamp(start + 0.05f, -1f, 1f); return true; }
        if (key == GLFW.GLFW_KEY_R) { start = 0; return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true; // the Leave button
        if (button != 0 || thrownAt >= 0) return false;
        holding = true;
        heldX = (int) mx;
        heldY = (int) my;
        samples.clear();
        spinHistory.clear();
        spinRate = 0;
        haveHeading = false;
        lastNanos = System.nanoTime();
        samples.addLast(new double[]{lastNanos, mx, my});
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (button != 0 || !holding) return super.mouseReleased(mx, my, button);
        holding = false;
        long now = System.nanoTime();
        addSample(now, mx, my);
        // Flick velocity over the last ~90 ms.
        double[] last = samples.peekLast(), first = last;
        for (double[] s : samples) if (now - s[0] <= 90_000_000L) { first = s; break; }
        double dt = Math.max(0.016, (last[0] - first[0]) / 1e9);
        double vx = (last[1] - first[1]) / dt, up = -(last[2] - first[2]) / dt;
        if (up < MIN_FLICK) {
            note("Flick the mouse UP and let go to bowl!");
            return true;
        }
        float power = (float) Mth.clamp(0.2 + 0.8 * (up - MIN_FLICK) / (FULL_FLICK - MIN_FLICK), 0.2, 1.0);
        // Flick direction aims: 30 degrees off straight up = the full 3 degrees on the lane.
        double flickDeg = Math.toDegrees(Math.atan2(vx, up));
        float aimDeg = (float) Mth.clamp(flickDeg / 10.0, -3, 3);
        float hook = (float) curveAt(now);
        if (ClientBowlingData.myTurnToAim()) {
            ModNetwork.sendToServer(new BowlingThrowPacket(start, aimDeg, power, hook));
            thrownAt = System.currentTimeMillis();
            throwDx = vx;
        }
        return true;
    }

    /** The curve from your spin, as it was just before the flick (the flick itself is a straight line). */
    private double curveAt(long now) {
        double rate = 0;
        for (double[] h : spinHistory) {
            if (now - h[0] >= 150_000_000L) rate = h[1];
            else break;
        }
        if (spinHistory.isEmpty()) rate = spinRate;
        return curveOf(rate);
    }

    /** Spin rate -> curve: under half a circle per second is no curve; two circles per second is full. */
    private static double curveOf(double rate) {
        double rps = Math.abs(rate) / (Math.PI * 2);
        return Math.signum(rate) * Mth.clamp((rps - 0.5) / 1.5, 0, 1);
    }

    private void addSample(long now, double mx, double my) {
        double[] prev = samples.peekLast();
        samples.addLast(new double[]{now, mx, my});
        while (samples.size() > 2 && now - samples.peekFirst()[0] > 400_000_000L) samples.removeFirst();
        if (prev == null) return;
        double dx = mx - prev[1], dy = my - prev[2];
        double dt = Math.max(1e-4, (now - prev[0]) / 1e9);
        if (dx * dx + dy * dy >= 9) {
            // Spin = how fast the direction you're moving the mouse turns (circling = steady turning).
            double heading = Math.atan2(dy, dx);
            if (haveHeading) {
                double d = heading - lastHeading;
                while (d > Math.PI) d -= Math.PI * 2;
                while (d < -Math.PI) d += Math.PI * 2;
                spinRate += (d / dt - spinRate) * Math.min(1, dt / 0.3);
            }
            lastHeading = heading;
            haveHeading = true;
        } else {
            spinRate *= Math.exp(-dt / 0.6);
        }
        spinHistory.addLast(new double[]{now, spinRate});
        while (spinHistory.size() > 2 && now - spinHistory.peekFirst()[0] > 500_000_000L) spinHistory.removeFirst();
    }

    private void note(String s) {
        note = s;
        noteUntil = System.currentTimeMillis() + 2500;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        long now = System.nanoTime();
        double frameDt = lastNanos == 0 ? 0.016 : Math.min(0.1, (now - lastNanos) / 1e9);
        lastNanos = now;
        if (holding) addSample(now, mx, my);
        else spinRate *= Math.exp(-frameDt / 0.6);
        spinAngle += spinRate * frameDt;
        if (thrownAt >= 0 && System.currentTimeMillis() - thrownAt > 450) { onClose(); return; }
        if (!ClientBowlingData.myTurnToAim() && thrownAt < 0) { onClose(); return; }

        // ---- the ball: in your hand while held, flying up the screen once thrown
        int bx = ballX(), by = ballY();
        float scale = 1f;
        if (holding) {
            bx = mx;
            by = my;
        } else if (thrownAt >= 0) {
            float k = (System.currentTimeMillis() - thrownAt) / 450f;
            by = (int) (ballY() - k * height * 0.55);
            bx = (int) (ballX() + Mth.clamp(throwDx * 0.15, -120, 120) * k);
            scale = 1f - 0.7f * k;
        }
        double curve = curveOf(spinRate);
        if (Math.abs(curve) > 0.05) spinRing(g, bx, by, (int) (BALL_R * scale) + 6, curve);
        drawBall(g, bx, by, Math.max(4, (int) (BALL_R * scale)), spinAngle);

        // ---- hints
        BowlingStatePacket st = ClientBowlingData.mine();
        if (st != null) {
            List<Integer> mine = new ArrayList<>();
            for (byte v : st.viewer() == 0 ? st.homeRolls() : st.awayRolls()) mine.add((int) v);
            BowlingScore.Position pos = BowlingScore.position(mine, Math.max(1, st.frames()));
            String info = "Frame " + (pos.frame() + 1) + "  •  ball " + (pos.ball() + 1) + "  •  " + pos.pinsUp()
                    + (pos.pinsUp() == 1 ? " pin up" : " pins up");
            g.drawCenteredString(font, info, width / 2, height - 98, 0xFFFFFFFF);
        }
        String how = thrownAt >= 0 ? "" : holding
                ? (Math.abs(curve) > 0.05 ? (curve > 0 ? "Curve ball ↷ right!  " : "↶ Curve ball left!  ") : "Circle to spin it, ")
                  + "flick UP to bowl"
                : "GRAB the ball (hold left mouse), flick UP to bowl";
        if (!how.isEmpty()) g.drawCenteredString(font, how, width / 2, height - 86, holding ? 0xFFFFC83D : 0xFFFFFFFF);
        drawMiniLane(g);
        int secs = st == null ? 0 : (st.ticksLeft() + 19) / 20;
        g.drawString(font, "A/D move your spot  R reset", 10, height - 22, 0xFFB0C8E8);
        g.drawString(font, secs + "s to bowl", 10, height - 12, secs <= 10 ? 0xFFFF5555 : 0xFF8A9AB8);
        if (System.currentTimeMillis() < noteUntil) g.drawCenteredString(font, note, width / 2, height - 112, 0xFFFF7070);
        super.render(g, mx, my, partialTick);
    }

    /** A shaded bowling ball (drawn as rows) with three finger holes that turn as it spins. */
    private static void drawBall(GuiGraphics g, int cx, int cy, int r, double angle) {
        for (int dy = -r; dy <= r; dy++) {
            int w = (int) Math.round(Math.sqrt(r * r - dy * dy));
            for (int dx = -w; dx < w; dx += 2) {
                double lx = (dx + 0.5 * r) / r, ly = (dy + 0.6 * r) / r;
                double light = Math.max(0, 1 - Math.sqrt(lx * lx + ly * ly) * 0.75);
                double swirl = 0.5 + 0.5 * Math.sin(angle * 0.7 + dx * 0.25 + dy * 0.18);
                int rr = (int) (30 + 60 * swirl + 140 * light * light), gg = (int) (40 + 20 * swirl + 120 * light * light),
                        bb = (int) (150 + 60 * swirl + 90 * light * light);
                g.fill(cx + dx, cy + dy, cx + Math.min(w, dx + 2), cy + dy + 1,
                        0xFF000000 | Math.min(255, rr) << 16 | Math.min(255, gg) << 8 | Math.min(255, bb));
            }
        }
        // Finger holes: two together and the thumb hole, turning with the spin.
        double[][] holes = {{-0.28, -0.35}, {0.12, -0.42}, {-0.05, 0.25}};
        double ca = Math.cos(angle), sa = Math.sin(angle);
        for (double[] h : holes) {
            int hx = cx + (int) Math.round((h[0] * ca - h[1] * sa) * r), hy = cy + (int) Math.round((h[0] * sa + h[1] * ca) * r);
            int hr = Math.max(1, r / 8);
            g.fill(hx - hr, hy - hr, hx + hr, hy + hr, 0xFF0A0A14);
        }
    }

    /** Sparkles circling the ball while it has spin on it (gold = it'll curve). */
    private void spinRing(GuiGraphics g, int cx, int cy, int r, double curve) {
        int n = 10;
        for (int i = 0; i < n; i++) {
            double a = spinAngle * 1.5 + i * Math.PI * 2 / n;
            int x = cx + (int) (Math.cos(a) * r), y = cy + (int) (Math.sin(a) * r);
            int alpha = (int) (80 + 175 * Math.abs(curve));
            g.fill(x - 1, y - 1, x + 2, y + 2, alpha << 24 | 0xFFC83D);
        }
    }

    private void drawMiniLane(GuiGraphics g) {
        BowlingStatePacket s = ClientBowlingData.mine();
        LobbySyncPacket data = ClientLobbyData.get();
        LobbySyncPacket.FieldView fv = s == null || data == null ? null : data.field(s.fieldId());
        int x0 = 14, w = 46, top = height - 196, bottom = height - 30;
        g.fill(x0 - 4, top - 14, x0 + w + 4, bottom + 4, 0x80101820);
        g.drawCenteredString(font, "LANE", x0 + w / 2, top - 11, 0xFFFFC83D);
        // Gutters, lane, foul line.
        int gut = Math.round(w * 9.25f / 60f);
        g.fill(x0, top, x0 + gut, bottom, 0xFF2A2A34);
        g.fill(x0 + w - gut, top, x0 + w, bottom, 0xFF2A2A34);
        g.fill(x0 + gut, top, x0 + w - gut, bottom, 0xFFC8A060);
        g.fill(x0, bottom - 1, x0 + w, bottom, 0xFFFF4040);
        if (fv == null) return;
        BowlingPhysics.Dims d = BowlingPhysics.Dims.of(fv.field().geometry().length(), fv.field().geometry().width());
        double laneW = w - 2 * gut, len = bottom - top;
        java.util.function.DoubleUnaryOperator sx = x -> x0 + gut + (x / d.laneHalf() * 0.5 + 0.5) * laneW;
        java.util.function.DoubleUnaryOperator su = u -> bottom - u / d.length() * len;
        // Target arrows.
        for (int b = 1; b <= 7; b++) {
            double x = -d.laneHalf() + b * 5 / 39.0 * 2 * d.laneHalf();
            int ax = (int) sx.applyAsDouble(x), ay = (int) su.applyAsDouble(d.headU() * 0.25);
            g.fill(ax - 1, ay - 2, ax + 1, ay + 1, 0xFF6A4A20);
        }
        // Pins still standing.
        for (int p = 0; p < 10; p++) {
            if ((int) s.pins()[p * 5] != BowlingPhysics.STANDING) continue;
            int pxp = (int) sx.applyAsDouble(s.pins()[p * 5 + 1]), pyp = (int) su.applyAsDouble(s.pins()[p * 5 + 2]);
            g.fill(pxp - 1, pyp - 1, pxp + 2, pyp + 2, 0xFFFFFFFF);
        }
        // Your spot and aim (straight line; the hook bends it on the real lane).
        double startX = start * (d.laneHalf() - d.ballR());
        int sxp = (int) sx.applyAsDouble(startX);
        g.fill(sxp - 2, bottom - 4, sxp + 3, bottom + 1, 0xFF5FD0FF);
        double tan = 0; // straight down from your spot (you aim with the flick)
        for (int k = 1; k <= 24; k++) {
            double u = d.headU() * k / 24.0, x = startX + tan * u;
            if (Math.abs(x) > d.laneHalf()) break;
            int ax = (int) sx.applyAsDouble(x), ay = (int) su.applyAsDouble(u);
            if (k % 2 == 0) g.fill(ax, ay, ax + 1, ay + 2, 0xFF5FD0FF);
        }
    }

    @Override
    public void renderBackground(GuiGraphics g) {
        // No dark backdrop: you need to see the lane.
    }
}
