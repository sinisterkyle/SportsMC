package com.sportsmc.client;

import com.sportsmc.client.screen.CardDojoScreen;
import com.sportsmc.network.CardStatePacket;
import net.minecraft.client.Minecraft;

import javax.annotation.Nullable;

/** Latest Card Dojo state. The dojo screen opens by itself when a match starts and closes when it ends. */
public final class ClientCardData {

    @Nullable private static CardStatePacket state;
    private static int version;

    private ClientCardData() {}

    @Nullable
    public static CardStatePacket get() {
        return state != null && state.active() ? state : null;
    }

    /** Increases with every state received, so the screen can spot changes. */
    public static int version() {
        return version;
    }

    public static void apply(CardStatePacket packet) {
        Minecraft mc = Minecraft.getInstance();
        if (!packet.active()) {
            state = null;
            version++;
            if (mc.screen instanceof CardDojoScreen) mc.setScreen(null);
            return;
        }
        boolean starting = state == null;
        state = packet;
        version++;
        if (starting && !(mc.screen instanceof CardDojoScreen)) mc.setScreen(new CardDojoScreen());
    }

    public static void clear() {
        state = null;
        version++;
    }
}
