package com.sportsmc.client.arcade;

import com.sportsmc.arcade.ArcadeGame;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

/**
 * Maze Muncher: eat every pellet in the maze while four ghosts hunt you. Power pellets turn the ghosts blue so
 * you can eat them (200, 400, 800, 1600 in a row); eaten ghosts race home as eyes and come back. Ghosts take
 * turns scattering to their corners and chasing, each in its own way: Ember (red) heads straight for you,
 * Bloom (pink) cuts you off four tiles ahead, Tide (cyan) flanks using Ember's position, and Sunny (orange)
 * chases from far away but wanders off when close. Fruit appears twice a level. The side tunnel wraps around.
 *
 * Positions are in tiles: an entity sits on tile (tx, ty) and has moved `prog` (0..1) toward the next tile in
 * its direction. The maze is 28 x 28 tiles of 8 units, with a 16-unit strip above and below for the score.
 */
public class MazeMuncherScreen extends ArcadeGameScreen {

    static final String[] MAZE = {
            "############################",
            "#.....#......##......#.....#",
            "#.###.#.####.##.####.#.###.#",
            "#o###.#.####.##.####.#.###o#",
            "#..........................#",
            "#.###.###.########.###.###.#",
            "#.###.###.########.###.###.#",
            "#.....#......##......#.....#",
            "#####.#.####.##.####.#.#####",
            "#####.#.####.##.####.#.#####",
            "#####.#..............#.#####",
            "#####.#.#####--#####.#.#####",
            "#####...#HHHHHHHHHH#...#####",
            "T    .#.#HHHHHHHHHH#.#.    T",
            "#####.#.############.#.#####",
            "#####.#..............#.#####",
            "#####.###.########.###.#####",
            "#.........########.........#",
            "#.###.###....##....###.###.#",
            "#o..#.#...##.##.##...#.#..o#",
            "###.#.#.#.##.##.##.#.#.#.###",
            "###.....#..........#.....###",
            "#...###.############.###...#",
            "#.#.###..............###.#.#",
            "#.#.....############.....#.#",
            "#.#####.############.#####.#",
            "#............PP............#",
            "############################",
    };
    static final int MW = 28, MH = 28, TILE = 8, TOP = 16;
    static final float FW = MW * TILE, FH = MH * TILE + 32;
    private static final int TUNNEL_ROW = 13;
    // Directions: 0 up, 1 left, 2 down, 3 right (this order also breaks ties, like the classic).
    private static final int[] DX = {0, -1, 0, 1}, DY = {-1, 0, 1, 0};
    private static final int[] GHOST_COLORS = {0xFFFF3030, 0xFFFFA0E0, 0xFF30E0FF, 0xFFFFB040};
    private static final String[] GHOST_NAMES = {"Ember", "Bloom", "Tide", "Sunny"};
    private static final int[][] SCATTER = {{25, -3}, {2, -3}, {27, 30}, {0, 30}};
    private static final double[] MODE_TIMES = {7, 20, 7, 20, 5, 20, 5};
    private static final int[] FRUIT_POINTS = {100, 300, 500, 700, 1000, 2000, 3000, 5000};

    private enum Phase { READY, PLAY, DYING, CLEARED, GHOST_EATEN_PAUSE }
    private enum GState { HOUSE, LEAVING, ACTIVE, EYES, ENTERING }

    private static final class Mover {
        int tx, ty, dir;
        double prog;
        boolean moving = true;

        double x() { return tx + DX[dir] * prog + 0.5; }
        double y() { return ty + DY[dir] * prog + 0.5; }
    }

    private static final class Ghost {
        final int id;
        final Mover m = new Mover();
        GState state;
        boolean frightened;
        double hx, hy;        // free position while in / leaving / entering the house (tile-center units)
        double releaseAt;

        Ghost(int id) { this.id = id; }
    }

    private final boolean[][] pellet = new boolean[MH][MW];
    private final boolean[][] power = new boolean[MH][MW];
    private int pelletsLeft, eatenThisLevel;
    private final Mover pac = new Mover();
    private int wantDir = 1;
    private final Ghost[] ghosts = {new Ghost(0), new Ghost(1), new Ghost(2), new Ghost(3)};
    private final Random random = new Random();
    private Phase phase = Phase.READY;
    private double phaseStart;
    private int level, lives, nextExtra;
    private int modeIndex;
    private double modeTime;      // time spent in the current scatter/chase mode
    private double frightUntil = -1;
    private int ghostChain;
    private double lifeStart;
    private boolean fruitOut;
    private double fruitUntil;
    private boolean fruit1, fruit2;
    private String popText = "";
    private double popX, popY, popUntil;
    private double chompSound;

    public MazeMuncherScreen() {
        super(ArcadeGame.MAZE_MUNCHER);
    }

    // ================================================================== setup

    @Override
    protected void reset() {
        level = 1;
        lives = 3;
        nextExtra = 10_000;
        startLevel();
    }

    private void startLevel() {
        pelletsLeft = 0;
        eatenThisLevel = 0;
        for (int y = 0; y < MH; y++) {
            for (int x = 0; x < MW; x++) {
                char c = MAZE[y].charAt(x);
                pellet[y][x] = c == '.';
                power[y][x] = c == 'o';
                if (c == '.' || c == 'o') pelletsLeft++;
            }
        }
        fruit1 = fruit2 = false;
        startLife();
    }

    private void startLife() {
        pac.tx = 14; pac.ty = 26; pac.dir = 1; pac.prog = 0.5; pac.moving = true;
        wantDir = 1;
        for (Ghost g : ghosts) {
            g.frightened = false;
            if (g.id == 0) {
                g.state = GState.ACTIVE;
                g.m.tx = 14; g.m.ty = 10; g.m.dir = 1; g.m.prog = 0.5;
            } else {
                g.state = GState.HOUSE;
                g.hx = g.id == 1 ? 14.0 : g.id == 2 ? 12.0 : 16.0;
                g.hy = 13.0;
                double[] base = {0, 0.5, 4, 8};
                g.releaseAt = Math.max(0, base[g.id] - (level - 1) * 1.0);
            }
        }
        modeIndex = 0;
        modeTime = 0;
        frightUntil = -1;
        fruitOut = false;
        phase = Phase.READY;
        phaseStart = time;
        lifeStart = time + 2.0;
    }

    private double levelSpeed() {
        return 1 + Math.min(0.25, (level - 1) * 0.05);
    }

    private double frightTime() {
        return Math.max(1.5, 7 - level);
    }

    // ================================================================== maze helpers

    private static char at(int x, int y) {
        if (y < 0 || y >= MH) return '#';
        if (x < 0 || x >= MW) return y == TUNNEL_ROW ? ' ' : '#';
        return MAZE[y].charAt(x);
    }

    private static boolean open(int x, int y) {
        char c = at(x, y);
        return c != '#' && c != '-' && c != 'H';
    }

    private static int wrap(int x) {
        return (x + MW) % MW;
    }

    private static boolean inTunnel(Mover m) {
        return m.ty == TUNNEL_ROW && (m.tx <= 5 || m.tx >= 22);
    }

    // ================================================================== update

    @Override
    protected void update() {
        double dt = STEP;
        switch (phase) {
            case READY -> {
                if (time - phaseStart > 2.0) { phase = Phase.PLAY; phaseStart = time; }
                return;
            }
            case DYING -> {
                if (time - phaseStart > 1.8) {
                    if (lives > 0) startLife();
                    else gameOver();
                }
                return;
            }
            case CLEARED -> {
                if (time - phaseStart > 2.2) { level++; startLevel(); }
                return;
            }
            case GHOST_EATEN_PAUSE -> {
                if (time - phaseStart > 0.5) phase = Phase.PLAY;
                return;
            }
            default -> {}
        }

        // Input: the newest direction key held wins (and is remembered until it can be taken).
        if (isHeld(GLFW.GLFW_KEY_UP, GLFW.GLFW_KEY_W)) wantDir = 0;
        else if (isHeld(GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_A)) wantDir = 1;
        else if (isHeld(GLFW.GLFW_KEY_DOWN, GLFW.GLFW_KEY_S)) wantDir = 2;
        else if (isHeld(GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_D)) wantDir = 3;

        boolean frightened = time < frightUntil;
        if (!frightened) {
            for (Ghost g : ghosts) g.frightened = false;
            modeTime += dt;
            if (modeIndex < MODE_TIMES.length && modeTime >= MODE_TIMES[modeIndex]) {
                modeIndex++;
                modeTime = 0;
                for (Ghost g : ghosts) if (g.state == GState.ACTIVE) reverse(g.m);
            }
        }

        movePac(7.6 * levelSpeed() * dt);
        for (Ghost g : ghosts) moveGhost(g, dt);
        collide();

        if (fruitOut && time > fruitUntil) fruitOut = false;
    }

    @Override
    protected void onPress(int key) {
        switch (key) {
            case GLFW.GLFW_KEY_UP, GLFW.GLFW_KEY_W -> wantDir = 0;
            case GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_A -> wantDir = 1;
            case GLFW.GLFW_KEY_DOWN, GLFW.GLFW_KEY_S -> wantDir = 2;
            case GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_D -> wantDir = 3;
            default -> {}
        }
    }

    private static void reverse(Mover m) {
        if (!m.moving) return;
        m.tx = wrap(m.tx + DX[m.dir]);
        m.ty += DY[m.dir];
        m.dir = (m.dir + 2) % 4;
        m.prog = 1 - m.prog;
    }

    private void movePac(double dist) {
        // Turning around never has to wait for the next tile.
        if (pac.moving && wantDir == (pac.dir + 2) % 4) reverse(pac);
        if (!pac.moving) {
            if (open(wrap(pac.tx + DX[wantDir]), pac.ty + DY[wantDir])) { pac.dir = wantDir; pac.moving = true; }
            else return;
        }
        while (dist > 0) {
            double left = 1 - pac.prog;
            if (dist < left) { pac.prog += dist; break; }
            dist -= left;
            pac.tx = wrap(pac.tx + DX[pac.dir]);
            pac.ty += DY[pac.dir];
            pac.prog = 0;
            eat(pac.tx, pac.ty);
            if (phase != Phase.PLAY) return;
            if (open(wrap(pac.tx + DX[wantDir]), pac.ty + DY[wantDir])) pac.dir = wantDir;
            else if (!open(wrap(pac.tx + DX[pac.dir]), pac.ty + DY[pac.dir])) { pac.moving = false; break; }
        }
    }

    private void eat(int x, int y) {
        if (y < 0 || y >= MH || x < 0 || x >= MW) return;
        if (pellet[y][x]) {
            pellet[y][x] = false;
            addScore(10);
            ate();
            if (time - chompSound > 0.12) { chompSound = time; sound(SoundEvents.NOTE_BLOCK_HAT.value(), 1.6f, 0.15f); }
        } else if (power[y][x]) {
            power[y][x] = false;
            addScore(50);
            ate();
            frightUntil = time + frightTime();
            ghostChain = 0;
            for (Ghost g : ghosts) {
                if (g.state == GState.EYES || g.state == GState.ENTERING) continue;
                g.frightened = true;
                if (g.state == GState.ACTIVE) reverse(g.m);
            }
            sound(SoundEvents.NOTE_BLOCK_CHIME.value(), 0.8f, 0.5f);
        }
    }

    private void ate() {
        pelletsLeft--;
        eatenThisLevel++;
        if ((eatenThisLevel == 70 && !fruit1) || (eatenThisLevel == 170 && !fruit2)) {
            if (eatenThisLevel == 70) fruit1 = true; else fruit2 = true;
            fruitOut = true;
            fruitUntil = time + 9.5;
        }
        if (pelletsLeft <= 0) {
            phase = Phase.CLEARED;
            phaseStart = time;
            sound(SoundEvents.PLAYER_LEVELUP, 1.4f, 0.6f);
        }
    }

    private void addScore(int pts) {
        score += pts;
        if (score >= nextExtra) {
            lives++;
            nextExtra += 10_000 * 4;
            sound(SoundEvents.PLAYER_LEVELUP, 1.8f, 0.5f);
        }
    }

    // ---- ghosts ---------------------------------------------------------------------------------------------

    private void moveGhost(Ghost g, double dt) {
        double ls = levelSpeed();
        switch (g.state) {
            case HOUSE -> {
                g.hy = 13.0 + Math.sin(time * 6 + g.id) * 0.35; // bob up and down
                if (time - lifeStart >= g.releaseAt) g.state = GState.LEAVING;
            }
            case LEAVING -> {
                // Slide to the middle, then up through the door, then join the maze.
                double sp = 4 * dt;
                if (Math.abs(g.hx - 14.0) > 0.01) g.hx += Math.max(-sp, Math.min(sp, 14.0 - g.hx));
                else if (g.hy > 10.5) g.hy = Math.max(10.5, g.hy - sp);
                else {
                    g.state = GState.ACTIVE;
                    g.m.tx = 14; g.m.ty = 10; g.m.prog = 0.5; g.m.moving = true;
                    g.m.dir = random.nextBoolean() ? 1 : 3;
                    if (g.m.dir == 3) { g.m.tx = 13; }
                }
            }
            case ENTERING -> {
                double sp = 8 * dt;
                if (Math.abs(g.hx - 14.0) > 0.01) g.hx += Math.max(-sp, Math.min(sp, 14.0 - g.hx));
                else if (g.hy < 13.0) g.hy = Math.min(13.0, g.hy + sp);
                else { g.frightened = false; g.state = GState.LEAVING; }
            }
            case ACTIVE, EYES -> {
                double speed;
                if (g.state == GState.EYES) speed = 15;
                else if (inTunnel(g.m)) speed = 3.8;
                else if (g.frightened) speed = 4.5;
                else speed = 7.1 * ls;
                stepGhost(g, speed * dt);
            }
        }
    }

    private void stepGhost(Ghost g, double dist) {
        Mover m = g.m;
        while (dist > 0) {
            double left = 1 - m.prog;
            if (dist < left) { m.prog += dist; return; }
            dist -= left;
            m.tx = wrap(m.tx + DX[m.dir]);
            m.ty += DY[m.dir];
            m.prog = 0;
            if (g.state == GState.EYES && m.ty == 10 && (m.tx == 13 || m.tx == 14)) {
                // Home: drop in through the door.
                g.state = GState.ENTERING;
                g.hx = m.tx + 0.5;
                g.hy = 10.5;
                return;
            }
            m.dir = chooseDir(g);
        }
    }

    /** At a tile center: pick the turn that gets closest to the target (or a random one when frightened). */
    private int chooseDir(Ghost g) {
        Mover m = g.m;
        int back = (m.dir + 2) % 4;
        int[] target = target(g);
        int best = -1;
        double bestD = Double.MAX_VALUE;
        int options = 0;
        int[] cand = new int[4];
        for (int d = 0; d < 4; d++) {
            if (d == back) continue;
            int nx = wrap(m.tx + DX[d]), ny = m.ty + DY[d];
            if (!open(nx, ny)) continue;
            cand[options++] = d;
            double dx = nx - target[0], dy = ny - target[1];
            double dd = dx * dx + dy * dy;
            if (dd < bestD) { bestD = dd; best = d; }
        }
        if (options == 0) return back; // shouldn't happen (no dead ends), but never get stuck
        if (g.frightened && g.state == GState.ACTIVE) return cand[random.nextInt(options)];
        return best;
    }

    private int[] target(Ghost g) {
        if (g.state == GState.EYES) return new int[]{13, 10};
        boolean scatter = modeIndex < MODE_TIMES.length && modeIndex % 2 == 0;
        if (scatter) return SCATTER[g.id];
        int px = pac.tx, py = pac.ty, pd = pac.dir;
        return switch (g.id) {
            case 0 -> new int[]{px, py};
            case 1 -> new int[]{px + DX[pd] * 4, py + DY[pd] * 4};
            case 2 -> {
                int ax = px + DX[pd] * 2, ay = py + DY[pd] * 2;
                Mover r = ghosts[0].m;
                yield new int[]{ax * 2 - r.tx, ay * 2 - r.ty};
            }
            default -> {
                double dx = g.m.tx - px, dy = g.m.ty - py;
                yield dx * dx + dy * dy > 64 ? new int[]{px, py} : SCATTER[3];
            }
        };
    }

    private void collide() {
        double px = pac.x(), py = pac.y();
        for (Ghost g : ghosts) {
            if (g.state != GState.ACTIVE) continue;
            double dx = g.m.x() - px, dy = g.m.y() - py;
            if (Math.abs(dx) > MW / 2.0) dx = MW - Math.abs(dx); // across the tunnel
            if (dx * dx + dy * dy > 0.55 * 0.55) continue;
            if (g.frightened) {
                g.frightened = false;
                g.state = GState.EYES;
                int pts = 200 << Math.min(3, ghostChain++);
                addScore(pts);
                pop(String.valueOf(pts), g.m.x(), g.m.y());
                sound(SoundEvents.NOTE_BLOCK_BELL.value(), 1.0f + ghostChain * 0.15f, 0.6f);
                phase = Phase.GHOST_EATEN_PAUSE;
                phaseStart = time;
                return;
            }
            lives--;
            phase = Phase.DYING;
            phaseStart = time;
            sound(SoundEvents.NOTE_BLOCK_DIDGERIDOO.value(), 0.6f, 0.8f);
            return;
        }
        if (fruitOut && Math.abs(px - 14.0) < 0.8 && Math.abs(py - 15.5) < 0.6) {
            int pts = FRUIT_POINTS[Math.min(FRUIT_POINTS.length - 1, level - 1)];
            addScore(pts);
            pop(String.valueOf(pts), 14.0, 15.5);
            fruitOut = false;
            sound(SoundEvents.PLAYER_BURP, 1.2f, 0.6f);
        }
    }

    private void pop(String text, double x, double y) {
        popText = text;
        popX = x;
        popY = y;
        popUntil = time + 1.2;
    }

    // ================================================================== drawing

    private float scale() {
        return Math.min((height - 24) / FH, (width - 20) / FW);
    }

    @Override
    protected void draw(GuiGraphics g) {
        float s = scale();
        float ox = width / 2f - FW * s / 2, oy = (height - FH * s) / 2f - 4;
        g.fill((int) ox - 2, (int) oy - 2, (int) (ox + FW * s) + 2, (int) (oy + FH * s) + 2, 0xFF1A1A3A);
        g.fill((int) ox, (int) oy, (int) (ox + FW * s), (int) (oy + FH * s), 0xFF000000);
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(s, s, 1);

        boolean flashWalls = phase == Phase.CLEARED && ((int) ((time - phaseStart) * 5)) % 2 == 1;
        drawMaze(g, flashWalls ? 0xFFFFFFFF : 0xFF2D5BFF, TOP);
        // Pellets.
        boolean blink = ((int) (time * 4)) % 2 == 0;
        for (int y = 0; y < MH; y++) {
            for (int x = 0; x < MW; x++) {
                float cx = x * TILE + 4, cy = TOP + y * TILE + 4;
                if (pellet[y][x]) fillF(g, cx - 1, cy - 1, cx + 1, cy + 1, 0xFFFFD8B0);
                if (power[y][x] && (blink || phase != Phase.PLAY)) disc(g, cx, cy, 3.2f, 0xFFFFD8B0);
            }
        }
        if (fruitOut) drawFruit(g, 14.0f * TILE, TOP + 15.5f * TILE);

        // Ghosts (hidden while dying, after the first moment).
        boolean dying = phase == Phase.DYING;
        if (!(dying && time - phaseStart > 0.5) && phase != Phase.CLEARED) {
            for (Ghost gh : ghosts) {
                if (phase == Phase.GHOST_EATEN_PAUSE && gh.state == GState.EYES && gh.m.tx == (int) Math.floor(popX)) continue;
                double gx, gy;
                if (gh.state == GState.HOUSE || gh.state == GState.LEAVING || gh.state == GState.ENTERING) { gx = gh.hx; gy = gh.hy; }
                else { gx = gh.m.x(); gy = gh.m.y(); }
                int dir = gh.state == GState.HOUSE ? 0 : gh.m.dir;
                boolean eyesOnly = gh.state == GState.EYES || gh.state == GState.ENTERING;
                boolean flash = gh.frightened && frightUntil - time < 2 && ((int) (time * 6)) % 2 == 0;
                drawGhost(g, (float) gx * TILE, TOP + (float) gy * TILE, GHOST_COLORS[gh.id], dir, gh.frightened, flash, eyesOnly, time);
            }
        }
        // Muncher.
        if (phase != Phase.GHOST_EATEN_PAUSE) {
            float mouth;
            if (dying) mouth = (float) Math.min(180, (time - phaseStart) / 1.2 * 180);
            else mouth = pac.moving && phase == Phase.PLAY ? (float) (Math.abs(Math.sin(time * 14)) * 42) : 25;
            if (!(dying && time - phaseStart > 1.25)) drawMuncher(g, (float) pac.x() * TILE, TOP + (float) pac.y() * TILE, pac.dir, mouth);
        }
        g.pose().popPose();

        // Text: score, best, level, lives, READY / points pop-ups.
        int left = (int) ox, right = (int) (ox + FW * s), top = (int) oy;
        g.drawString(font, "SCORE " + String.format("%,d", score), left + 4, top + 4, TEXT);
        String best = "BEST " + String.format("%,d", Math.max(score, ClientArcadeData.personalBest(game)));
        g.drawString(font, best, right - font.width(best) - 4, top + 4, DIM);
        int bottom = (int) (oy + FH * s);
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(s, s, 1);
        for (int i = 0; i < Math.min(6, lives); i++) drawMuncher(g, 10 + i * 12, FH - 8, 1, 30);
        g.pose().popPose();
        String lv = "LEVEL " + level;
        g.drawString(font, lv, right - font.width(lv) - 4, bottom - 12, 0xFFFFB040);
        if (phase == Phase.READY) {
            g.drawCenteredString(font, "READY!", (left + right) / 2, (int) (oy + (TOP + 15.1f * TILE) * s), 0xFFFFE030);
        }
        if (time < popUntil) {
            g.drawCenteredString(font, popText, (int) (ox + popX * TILE * s), (int) (oy + (TOP + popY * TILE - 4) * s), 0xFF30E0FF);
        }
        g.drawCenteredString(font, "ARROWS / WASD move   P pause   ESC menu", width / 2, height - 11, 0xFF6A6A88);
    }

    /** Walls: a dark fill with a neon edge wherever the wall meets a corridor. */
    static void drawMaze(GuiGraphics g, int line, float top) {
        for (int y = 0; y < MH; y++) {
            for (int x = 0; x < MW; x++) {
                char c = MAZE[y].charAt(x);
                float x0 = x * TILE, y0 = top + y * TILE;
                if (c == '-') { fillF(g, x0, y0 + 3, x0 + TILE, y0 + 5, 0xFFFFB0E0); continue; }
                if (c != '#') continue;
                fillF(g, x0, y0, x0 + TILE, y0 + TILE, 0xFF070720);
                if (!isWall(x, y - 1)) fillF(g, x0, y0 + 1.5f, x0 + TILE, y0 + 2.5f, line);
                if (!isWall(x, y + 1)) fillF(g, x0, y0 + TILE - 2.5f, x0 + TILE, y0 + TILE - 1.5f, line);
                if (!isWall(x - 1, y)) fillF(g, x0 + 1.5f, y0, x0 + 2.5f, y0 + TILE, line);
                if (!isWall(x + 1, y)) fillF(g, x0 + TILE - 2.5f, y0, x0 + TILE - 1.5f, y0 + TILE, line);
            }
        }
    }

    private static boolean isWall(int x, int y) {
        if (y < 0 || y >= MH || x < 0 || x >= MW) return true;
        char c = MAZE[y].charAt(x);
        return c == '#';
    }

    static void drawMuncher(GuiGraphics g, float cx, float cy, int dir, float mouthDeg) {
        float r = 6.5f;
        double facing = Math.atan2(DY[dir], DX[dir]);
        double half = Math.toRadians(mouthDeg);
        for (int j = -7; j < 7; j++) {
            for (int i = -7; i < 7; i++) {
                double px = i + 0.5, py = j + 0.5;
                if (px * px + py * py > r * r) continue;
                double a = Math.atan2(py, px) - facing;
                a = Math.atan2(Math.sin(a), Math.cos(a));
                if (Math.abs(a) < half) continue;
                fillF(g, cx + i, cy + j, cx + i + 1, cy + j + 1, 0xFFFFE030);
            }
        }
    }

    static void drawGhost(GuiGraphics g, float cx, float cy, int color, int dir, boolean frightened, boolean flash,
                          boolean eyesOnly, double t) {
        int body = frightened ? (flash ? 0xFFF0F0FF : 0xFF2121DE) : color;
        int frame = ((int) (t * 8)) % 2;
        if (!eyesOnly) {
            for (int j = -7; j < 7; j++) {
                for (int i = -7; i < 7; i++) {
                    double px = i + 0.5, py = j + 0.5;
                    boolean in;
                    if (py < -0.5) in = px * px + (py + 0.5) * (py + 0.5) <= 6.8 * 6.8;
                    else if (py < 5) in = true;
                    else in = ((i + 7) / 2 + frame) % 2 == 0; // wavy skirt
                    if (in) fillF(g, cx + i, cy + j, cx + i + 1, cy + j + 1, body);
                }
            }
        }
        if (frightened && !eyesOnly) {
            int face = flash ? 0xFFFF3030 : 0xFFFFD8B0;
            fillF(g, cx - 3, cy - 2, cx - 1, cy, face);
            fillF(g, cx + 1, cy - 2, cx + 3, cy, face);
            for (int i = -5; i < 5; i++) fillF(g, cx + i, cy + 2 + (i % 2 == 0 ? 0 : 1), cx + i + 1, cy + 3 + (i % 2 == 0 ? 0 : 1), face);
            return;
        }
        float ex = DX[dir] * 1.2f, ey = DY[dir] * 1.2f;
        for (int side = -1; side <= 1; side += 2) {
            float x = cx + side * 3;
            fillF(g, x - 2, cy - 4, x + 2, cy + 1, 0xFFFFFFFF);
            fillF(g, x - 1 + ex, cy - 2.5f + ey, x + 1 + ex, cy - 0.5f + ey, 0xFF2121DE);
        }
    }

    private static void drawFruit(GuiGraphics g, float cx, float cy) {
        disc(g, cx - 2.5f, cy + 2, 2.6f, 0xFFE02020);
        disc(g, cx + 2.5f, cy + 2.5f, 2.6f, 0xFFE02020);
        fillF(g, cx - 2.5f, cy - 4, cx - 1.5f, cy, 0xFF30A030);
        fillF(g, cx + 1.5f, cy - 4, cx + 2.5f, cy, 0xFF30A030);
        fillF(g, cx - 2.5f, cy - 5, cx + 2.5f, cy - 4, 0xFF30A030);
        fillF(g, cx - 3.5f, cy + 1, cx - 2.5f, cy + 2, 0xFFFFFFFF);
    }

    static void disc(GuiGraphics g, float cx, float cy, float r, int color) {
        for (float dy = -r; dy < r; dy += 0.5f) {
            float half = (float) Math.sqrt(Math.max(0, r * r - (dy + 0.25f) * (dy + 0.25f)));
            fillF(g, cx - half, cy + dy, cx + half, cy + dy + 0.5f, color);
        }
    }

    // ================================================================== menu preview

    public static void drawPreview(GuiGraphics g, int x, int y, int w, int h, double t) {
        float s = Math.min(h / FH, w / FW);
        g.pose().pushPose();
        g.pose().translate(x + w / 2f - FW * s / 2, y + h / 2f - FH * s / 2, 0);
        g.pose().scale(s, s, 1);
        drawMaze(g, 0xFF2D5BFF, TOP);
        // The bottom corridor: pellets being eaten by a muncher chased by a ghost.
        double p = (t * 6) % 30 - 1;
        for (int i = 1; i < 27; i++) if (i > p) fillF(g, i * TILE + 3, TOP + 26 * TILE + 3, i * TILE + 5, TOP + 26 * TILE + 5, 0xFFFFD8B0);
        float mx = (float) (p * TILE + 4);
        drawMuncher(g, mx, TOP + 26 * TILE + 4, 3, (float) (Math.abs(Math.sin(t * 14)) * 42));
        drawGhost(g, mx - 22, TOP + 26 * TILE + 4, GHOST_COLORS[0], 3, false, false, false, t);
        drawGhost(g, mx - 40, TOP + 26 * TILE + 4, GHOST_COLORS[1], 3, false, false, false, t);
        for (int i = 0; i < 4; i++) drawGhost(g, (11.5f + i * 1.7f) * TILE, TOP + 13 * TILE, GHOST_COLORS[i], 0, false, false, false, t + i);
        g.pose().popPose();
    }
}
