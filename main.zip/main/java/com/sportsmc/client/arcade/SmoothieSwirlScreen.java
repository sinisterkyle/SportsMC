package com.sportsmc.client.arcade;

import com.mojang.math.Axis;
import com.sportsmc.arcade.ArcadeGame;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Smoothie Swirl: a chain of fruit flavors rolls along a winding conveyor toward the blender. Aim the shooter
 * in the middle (mouse, or ← →) and fire flavors into the chain (click or SPACE): 3 or more of a flavor
 * together pop. When a gap closes and the flavors on both sides match, that end of the chain is pulled back
 * in and can pop again: chain reactions score more. Right-click (or X) swaps your flavor with the next one.
 * Clear the whole order (the cup fills as you go) before the chain reaches the blender. Field 320 x 240.
 */
public class SmoothieSwirlScreen extends ArcadeGameScreen {

    static final float FW = 320, FH = 240, CX = 160, CY = 124, D = 14, BR = 7;
    static final int[] FLAVORS = {0xFFFF4D6A, 0xFFFFD84A, 0xFF4C8DFF, 0xFF6BDB4C, 0xFFFF9A3C, 0xFFB46BFF};
    static final String[] FLAVOR_NAMES = {"Strawberry", "Banana", "Blueberry", "Kiwi", "Orange", "Grape"};
    private static final float SHOT_SPEED = 400, RETRACT_SPEED = 220, RUSH_SPEED = 120;

    // ---- the conveyor path: a spiral, stored as points every 1 unit of length --------------------------------
    static final float[] PX, PY;
    static final float PATH_LEN;

    static {
        List<float[]> raw = new ArrayList<>();
        for (int i = 0; i <= 4000; i++) {
            double t = i / 4000.0;
            double th = Math.PI + t * 2.6 * Math.PI;
            double rx = 150 - 85 * t, ry = 108 - 62 * t;
            raw.add(new float[]{(float) (CX + Math.cos(th) * rx), (float) (CY + Math.sin(th) * ry)});
        }
        List<float[]> even = new ArrayList<>();
        even.add(raw.get(0));
        float carry = 0;
        for (int i = 1; i < raw.size(); i++) {
            float[] a = raw.get(i - 1), b = raw.get(i);
            float seg = (float) Math.hypot(b[0] - a[0], b[1] - a[1]);
            float d = 1 - carry;
            while (d <= seg) {
                float k = d / seg;
                even.add(new float[]{a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k});
                d += 1;
            }
            carry = seg - (d - 1);
        }
        PX = new float[even.size()];
        PY = new float[even.size()];
        for (int i = 0; i < even.size(); i++) { PX[i] = even.get(i)[0]; PY[i] = even.get(i)[1]; }
        PATH_LEN = even.size() - 1;
    }

    static float[] at(float s) {
        float c = Math.max(0, Math.min(PATH_LEN, s));
        int i = (int) c;
        if (i >= PATH_LEN) return new float[]{PX[PX.length - 1], PY[PY.length - 1]};
        float k = c - i;
        return new float[]{PX[i] + (PX[i + 1] - PX[i]) * k, PY[i] + (PY[i + 1] - PY[i]) * k};
    }

    // ---- state ----------------------------------------------------------------------------------------------
    static final class Ball { int color; float s, shown; }
    private static final class Shot { float x, y, vx, vy; int color; }
    private static final class Fx { float x, y, vx, vy, age, life; int color; }

    /** The chain, front (closest to the blender) first. */
    final List<Ball> chain = new ArrayList<>();
    private final List<Shot> shots = new ArrayList<>();
    private final List<Fx> fx = new ArrayList<>();
    final Random random = new Random();
    private float aim = -90; // degrees, screen angle (-90 = up)
    private int current, next;
    int level, lives, colors, quota, spawned, cleared;
    private float speed;
    boolean rushing;
    private int combo;
    private double lostAt = -1, levelClearAt = -1, levelStart;
    private String popText = "";
    private float popX, popY;
    private double popUntil;
    private float lastScale = 1, lastOx, lastOy;

    public SmoothieSwirlScreen() {
        super(ArcadeGame.SMOOTHIE_SWIRL);
    }

    // ================================================================== setup

    @Override
    protected void reset() {
        level = 0;
        lives = 3;
        nextLevel();
    }

    private void nextLevel() {
        level++;
        startLevel();
    }

    void startLevel() {
        chain.clear();
        shots.clear();
        colors = Math.min(FLAVORS.length, 4 + (level - 1) / 2);
        quota = 45 + level * 12;
        spawned = cleared = 0;
        speed = 16 + level * 2.5f;
        rushing = true;
        lostAt = levelClearAt = -1;
        levelStart = time;
        current = random.nextInt(colors);
        next = random.nextInt(colors);
    }

    int pickColor() {
        Set<Integer> present = new HashSet<>();
        for (Ball b : chain) present.add(b.color);
        if (present.isEmpty()) return random.nextInt(colors);
        List<Integer> l = new ArrayList<>(present);
        return l.get(random.nextInt(l.size()));
    }

    // ================================================================== input

    @Override
    public void mouseMoved(double mx, double my) {
        float fx = (float) ((mx - lastOx) / lastScale), fy = (float) ((my - lastOy) / lastScale);
        aim = (float) Math.toDegrees(Math.atan2(fy - CY, fx - CX));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (!playing()) return false;
        if (button == 1) swap(); else fire();
        return true;
    }

    @Override
    protected void onPress(int key) {
        if (key == GLFW.GLFW_KEY_SPACE || key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_W) fire();
        if (key == GLFW.GLFW_KEY_X || key == GLFW.GLFW_KEY_C || key == GLFW.GLFW_KEY_DOWN || key == GLFW.GLFW_KEY_S) swap();
    }

    private void swap() {
        int t = current;
        current = next;
        next = t;
        sound(SoundEvents.BOOK_PAGE_TURN, 1.6f, 0.4f);
    }

    void fire() {
        if (shots.size() >= 2 || lostAt >= 0 || levelClearAt >= 0) return;
        Shot s = new Shot();
        double a = Math.toRadians(aim);
        s.x = CX + (float) Math.cos(a) * 14;
        s.y = CY + (float) Math.sin(a) * 14;
        s.vx = (float) Math.cos(a) * SHOT_SPEED;
        s.vy = (float) Math.sin(a) * SHOT_SPEED;
        s.color = current;
        shots.add(s);
        current = next;
        next = pickColor();
        combo = 0;
        sound(SoundEvents.NOTE_BLOCK_HAT.value(), 1.4f, 0.35f);
    }

    // ================================================================== update

    @Override
    protected void update() {
        float dt = (float) STEP;
        boolean left = isHeld(GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_A), right = isHeld(GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_D);
        if (left != right) aim += (left ? -140 : 140) * dt;
        tickFx(dt);

        if (lostAt >= 0) {
            // The chain slides into the blender.
            for (Ball b : chain) b.s += 260 * dt;
            chain.removeIf(b -> b.s > PATH_LEN + 4);
            smooth(dt);
            if (time - lostAt > 1.6) {
                if (lives <= 0) gameOver();
                else startLevel();
            }
            return;
        }
        if (levelClearAt >= 0) {
            if (time - levelClearAt > 2.2) nextLevel();
            return;
        }
        step(dt);
        for (Iterator<Shot> it = shots.iterator(); it.hasNext(); ) {
            Shot s = it.next();
            boolean done = false;
            for (int k = 0; k < 4 && !done; k++) {
                s.x += s.vx * dt / 4;
                s.y += s.vy * dt / 4;
                if (s.x < -10 || s.y < -10 || s.x > FW + 10 || s.y > FH + 10) done = true;
                else {
                    int hit = hitIndex(s.x, s.y);
                    if (hit >= 0) { insert(hit, s); done = true; }
                }
            }
            if (done) it.remove();
        }
        smooth(dt);

        if (!chain.isEmpty() && chain.get(0).s >= PATH_LEN) {
            lives--;
            lostAt = time;
            shots.clear();
            sound(SoundEvents.NOTE_BLOCK_DIDGERIDOO.value(), 0.6f, 0.8f);
        } else if (chain.isEmpty() && spawned >= quota) {
            levelClearAt = time;
            score += 1000 * level;
            sound(SoundEvents.PLAYER_LEVELUP, 1.3f, 0.6f);
        }
    }

    /** One tick of the chain: spawn at the start, push the back section, pull matching sections together. */
    void step(float dt) {
        // Spawn new flavors at the start of the conveyor.
        if (spawned < quota) {
            Ball last = chain.isEmpty() ? null : chain.get(chain.size() - 1);
            if (last == null || last.s >= D) {
                Ball b = new Ball();
                b.color = randomSpawnColor(last);
                b.s = last == null ? 0 : last.s - D;
                b.shown = b.s;
                chain.add(b);
                spawned++;
            }
        }
        if (chain.isEmpty()) return;
        if (rushing && chain.get(0).s > PATH_LEN * 0.32f) rushing = false;
        float v = rushing ? RUSH_SPEED : speed * (chain.get(0).s > PATH_LEN * 0.85f ? 0.55f : 1f);

        // Push the rear section forward (everything touching the last ball).
        int n = chain.size();
        int rearStart = n - 1;
        while (rearStart > 0 && chain.get(rearStart - 1).s - chain.get(rearStart).s <= D + 0.5f) rearStart--;
        for (int i = rearStart; i < n; i++) chain.get(i).s += v * dt;

        // Sections whose touching ends match get pulled back toward the section behind them.
        for (int i = 0; i < n - 1; i++) {
            Ball a = chain.get(i), b = chain.get(i + 1);
            float gap = a.s - b.s;
            if (gap <= D + 0.5f) continue;
            if (a.color != b.color) continue;
            int start = i;
            while (start > 0 && chain.get(start - 1).s - chain.get(start).s <= D + 0.5f) start--;
            float move = Math.min(RETRACT_SPEED * dt, gap - D);
            for (int k = start; k <= i; k++) chain.get(k).s -= move;
            if (a.s - b.s <= D + 0.5f) {
                // They've joined: does the seam make a group? (That's a chain reaction: worth more.)
                combo++;
                if (popGroupAt(i + 1)) return;
                combo--;
            }
        }
        resolveOverlaps();
    }

    /** Front balls get pushed forward so nothing overlaps (works from the back of the chain to the front). */
    void resolveOverlaps() {
        for (int i = chain.size() - 2; i >= 0; i--) {
            Ball a = chain.get(i), b = chain.get(i + 1);
            if (a.s < b.s + D) a.s = b.s + D;
        }
    }

    private int randomSpawnColor(Ball prev) {
        // Runs of the same flavor make the chain more playable.
        if (prev != null && random.nextFloat() < 0.45f) return prev.color;
        return random.nextInt(colors);
    }

    /** Index of the chain ball a shot at (x, y) has hit, or -1. */
    int hitIndex(float x, float y) {
        for (int i = 0; i < chain.size(); i++) {
            Ball b = chain.get(i);
            if (b.s < 0) continue;
            float[] p = at(b.shown);
            float dx = p[0] - x, dy = p[1] - y;
            if (dx * dx + dy * dy < (D * 0.85f) * (D * 0.85f)) return i;
        }
        return -1;
    }

    /** Puts the shot into the chain next to the ball it hit (in front or behind, whichever side it's on). */
    void insert(int hit, Shot s) {
        Ball h = chain.get(hit);
        float[] p = at(h.s), q = at(h.s + 1);
        float tx = q[0] - p[0], ty = q[1] - p[1];
        boolean inFront = (s.x - p[0]) * tx + (s.y - p[1]) * ty > 0;
        Ball b = new Ball();
        b.color = s.color;
        int idx;
        if (inFront) { b.s = h.s + D; idx = hit; }
        else { b.s = h.s - D; idx = hit + 1; }
        // Animate it in from where it struck.
        b.shown = inFront ? h.s + D * 0.5f : h.s - D * 0.5f;
        chain.add(idx, b);
        resolveOverlaps();
        sound(SoundEvents.NOTE_BLOCK_BASEDRUM.value(), 1.4f, 0.3f);
        popGroupAt(idx);
    }

    /** Pops the group of matching flavors around index i if it's 3 or more (touching balls only). */
    boolean popGroupAt(int i) {
        if (i < 0 || i >= chain.size()) return false;
        int color = chain.get(i).color;
        int a = i, b = i;
        while (a > 0 && chain.get(a - 1).color == color && chain.get(a - 1).s - chain.get(a).s <= D + 0.5f) a--;
        while (b < chain.size() - 1 && chain.get(b + 1).color == color && chain.get(b).s - chain.get(b + 1).s <= D + 0.5f) b++;
        int n = b - a + 1;
        if (n < 3) return false;
        int mult = combo + 1;
        float[] mid = at(chain.get((a + b) / 2).shown);
        for (int k = a; k <= b; k++) burst(chain.get(k));
        chain.subList(a, b + 1).clear();
        cleared += n;
        int pts = n * 10 * mult;
        score += pts;
        popText = mult > 1 ? "COMBO x" + mult + "  +" + pts : "+" + pts;
        popX = mid[0];
        popY = mid[1];
        popUntil = time + 1.0;
        sound(SoundEvents.NOTE_BLOCK_PLING.value(), 0.9f + Math.min(1f, mult * 0.15f), 0.5f);
        if (mult > 1) sound(SoundEvents.NOTE_BLOCK_CHIME.value(), 1f + mult * 0.1f, 0.5f);
        return true;
    }

    private void smooth(float dt) {
        float k = Math.min(1, dt * 18);
        for (Ball b : chain) b.shown += (b.s - b.shown) * k;
    }

    private void burst(Ball b) {
        float[] p = at(b.shown);
        for (int i = 0; i < 6; i++) {
            Fx f = new Fx();
            double a = random.nextDouble() * Math.PI * 2, v = 20 + random.nextDouble() * 50;
            f.x = p[0];
            f.y = p[1];
            f.vx = (float) (Math.cos(a) * v);
            f.vy = (float) (Math.sin(a) * v);
            f.life = 0.35f + random.nextFloat() * 0.3f;
            f.color = FLAVORS[b.color];
            fx.add(f);
        }
    }

    private void tickFx(float dt) {
        for (Iterator<Fx> it = fx.iterator(); it.hasNext(); ) {
            Fx f = it.next();
            f.age += dt;
            if (f.age >= f.life) { it.remove(); continue; }
            f.x += f.vx * dt;
            f.y += f.vy * dt;
            f.vy += 80 * dt;
        }
    }

    // ================================================================== drawing

    // Painted art (see ArcadeArt): the counter with its baked-in spiral conveyor and fruit crate, the fruit atlas,
    // the turret (base + rotating straw nozzle), the blender and the order cup.
    static final ArcadeArt.Tex BG = ArcadeArt.tex("smoothie/background", 640, 480);
    static final ArcadeArt.Tex FRUIT = ArcadeArt.tex("smoothie/fruit", 512, 64);
    static final ArcadeArt.Tex TURRET = ArcadeArt.tex("smoothie/turret", 144, 144);
    static final ArcadeArt.Tex NOZZLE = ArcadeArt.tex("smoothie/nozzle", 256, 64);
    static final ArcadeArt.Tex BLENDER = ArcadeArt.tex("smoothie/blender", 136, 184);
    static final ArcadeArt.Tex CUP = ArcadeArt.tex("smoothie/cup", 128, 192);
    private static final int DROP = 6, SPARKLE = 7;
    /** Top-left corners of the blender (34 x 46) and cup (32 x 48) sprites. */
    private static final float BLENDER_X = 176, BLENDER_Y = 63, CUP_X = 280, CUP_Y = 184;

    @Override
    protected void draw(GuiGraphics g) {
        float s = Math.min((height - 24) / FH, (width - 20) / FW);
        float ox = width / 2f - FW * s / 2, oy = (height - FH * s) / 2f - 4;
        lastScale = s;
        lastOx = ox;
        lastOy = oy;
        g.fill((int) ox - 3, (int) oy - 3, (int) (ox + FW * s) + 3, (int) (oy + FH * s) + 3, 0xFF2E5E8C); // cafe-blue trim
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(s, s, 1);

        ArcadeArt.whole(g, BG, 0, 0, FW, FH);
        boolean danger = !chain.isEmpty() && chain.get(0).s > PATH_LEN * 0.85f;
        drawConveyor(g, time, danger);
        for (int i = chain.size() - 1; i >= 0; i--) {
            Ball b = chain.get(i);
            if (b.shown < -D / 2) continue;
            float[] p = at(b.shown);
            flavor(g, p[0], p[1], BR, b.color, (float) Math.toDegrees(b.shown / BR)); // rolls along the belt
        }
        drawBlender(g, time, danger || lostAt >= 0);
        for (Shot sh : shots) flavor(g, sh.x, sh.y, BR, sh.color, (float) (time * 720 % 360));
        for (Fx f : fx) {
            float k = 1 - f.age / f.life;
            float deg = (float) Math.toDegrees(Math.atan2(f.vy, f.vx)) - 90; // the drop's tip trails behind it
            ArcadeArt.cell(g, FRUIT, 64, DROP, f.x, f.y, 4.5f, deg, f.color & 0xFFFFFF, k);
        }
        drawShooter(g, aim, current, next);
        // The order cup: fills as you clear the quota.
        drawCup(g, CUP_X, CUP_Y, quota == 0 ? 0 : Math.min(1f, cleared / (float) quota), time);
        g.pose().popPose();

        int left = (int) ox, right = (int) (ox + FW * s), top = (int) oy;
        g.drawString(font, "SCORE " + String.format("%,d", score), left + 5, top + 5, 0xFF1E3A66, false);
        String lv = "LEVEL " + level + "   ♥" + lives;
        g.drawString(font, lv, right - font.width(lv) - 5, top + 5, 0xFFD02A6A, false);
        if (time < popUntil) g.drawCenteredString(font, popText, (int) (ox + popX * s), (int) (oy + (popY - 14) * s), 0xFF8A2BE2);
        if (levelClearAt >= 0) g.drawCenteredString(font, "ORDER UP!  +" + 1000 * level, (left + right) / 2, (int) (oy + 40 * s), 0xFF2A9A4A);
        else if (lostAt >= 0) g.drawCenteredString(font, lives > 0 ? "Into the blender! Try again" : "Out of cups!", (left + right) / 2, (int) (oy + 40 * s), 0xFFD02A2A);
        else if (time - levelStart < 2) g.drawCenteredString(font, "LEVEL " + level + ": clear " + quota + " flavors", (left + right) / 2, (int) (oy + 40 * s), 0xFF5A2A4A);
        g.drawCenteredString(font, "MOUSE aim + click  (or ← → + SPACE)   RIGHT-CLICK / X swap   P pause   ESC menu",
                width / 2, height - 11, 0xFF6A6A88);
    }

    /** The belt itself is painted into the background; this adds the moving tread marks (red near the end when it's close). */
    static void drawConveyor(GuiGraphics g, double t, boolean danger) {
        int off = (int) (t * 20) % 12;
        boolean blink = ((int) (t * 6)) % 2 == 0;
        for (int i = off; i < PX.length - 4; i += 12) {
            boolean hot = danger && i > PATH_LEN * 0.85f;
            int col = hot ? (blink ? 0xC0FF3A5A : 0x80FF7A8A) : 0x38FFFFFF;
            float r = hot ? 1.4f : 1f;
            fillF(g, PX[i] - r, PY[i] - r, PX[i] + r, PY[i] + r, col);
        }
    }

    /** The blender at the end of the belt: smoothie swirling round a spinning blade, behind the glass jar. */
    static void drawBlender(GuiGraphics g, double t, boolean shaking) {
        float x = BLENDER_X + (shaking ? (float) Math.sin(t * 60) * 1.2f : 0), y = BLENDER_Y;
        float jx = x + 17, jy = y + 26;
        // Swirling smoothie at the bottom of the jar.
        fillF(g, x + 8.6f, jy - 2 + (float) Math.sin(t * 5) * 0.6f, x + 25.6f, y + 29.6f, 0xD0FF8AB4);
        fillF(g, x + 8.6f, jy - 2.4f + (float) Math.sin(t * 5) * 0.6f, x + 25.6f, jy - 1.2f + (float) Math.sin(t * 5) * 0.6f, 0xE0FFD0E2);
        g.pose().pushPose();
        g.pose().translate(jx, jy + 1, 0);
        g.pose().scale(1, 0.35f, 1); // the blade, seen at an angle
        g.pose().mulPose(Axis.ZP.rotationDegrees((float) (t * (shaking ? 1400 : 360) % 360)));
        fillF(g, -7, -1, 7, 1, 0xFFB8B8CC);
        fillF(g, -1, -5, 1, 5, 0xFF9A9AB0);
        g.pose().popPose();
        ArcadeArt.whole(g, BLENDER, x, y, 34, 46);
    }

    /** The turret: a striped straw nozzle that turns to aim, the loaded flavor in its mouth, the next one in the middle. */
    static void drawShooter(GuiGraphics g, float aimDeg, int current, int next) {
        ArcadeArt.centered(g, NOZZLE, CX, CY, 64, 16, aimDeg, 0, 0, 256, 64, 0xFFFFFF, 1f);
        ArcadeArt.whole(g, TURRET, CX - 18, CY - 18, 36, 36);
        double a = Math.toRadians(aimDeg);
        flavor(g, CX + (float) Math.cos(a) * 16, CY + (float) Math.sin(a) * 16, BR - 0.5f, current, aimDeg);
        flavor(g, CX, CY, 4.6f, next, 0);
    }

    /** The order cup: smoothie rises inside the tapered glass as you clear the quota, then the glass and straw on top. */
    static void drawCup(GuiGraphics g, float x, float y, float fill, double t) {
        // Interior of the glass, in sprite units: walls run from (3.5, 9.5)-(28.5, 9.5) down to (6.5, 45)-(25.5, 45).
        float bottom = 44.2f, h = 31 * Math.max(0, Math.min(1, fill)), surface = bottom - h;
        if (h > 0.3f) {
            for (float yy = surface; yy < bottom; yy += 1) {
                float y1 = Math.min(bottom, yy + 1.05f);
                float inset = (yy - 9.5f) * 3 / 35.5f + 0.9f;
                float k = (yy - surface) / 31f;
                int col = mixRgb(0xFFB0CC, 0xF05088, Math.min(1, k * 1.4f));
                fillF(g, x + 3.5f + inset, y + yy, x + 28.5f - inset, y + y1, 0xFF000000 | col);
            }
            // Foamy top.
            float inset = (surface - 9.5f) * 3 / 35.5f + 0.9f;
            for (int i = 0; i < 5; i++) {
                float fx = x + 3.5f + inset + i * (25 - 2 * inset) / 5;
                fillF(g, fx, y + surface - 0.6f + (float) Math.sin(t * 4 + i * 1.3) * 0.5f, fx + (25 - 2 * inset) / 5, y + surface + 1.2f, 0xFFFFE0EC);
            }
        }
        ArcadeArt.whole(g, CUP, x, y, 32, 48);
        if (fill >= 1f) ArcadeArt.cell(g, FRUIT, 64, SPARKLE, x + 9 + (float) Math.sin(t * 3) * 4, y + 6, 8, (float) (t * 90 % 360), 0xFFFFFF, 0.9f);
    }

    private static int mixRgb(int a, int b, float k) {
        int r = (int) ((a >> 16 & 255) * (1 - k) + (b >> 16 & 255) * k);
        int gr = (int) ((a >> 8 & 255) * (1 - k) + (b >> 8 & 255) * k);
        int bl = (int) ((a & 255) * (1 - k) + (b & 255) * k);
        return r << 16 | gr << 8 | bl;
    }

    /** A fruit: strawberry, banana slice, blueberry, kiwi slice, orange slice, grape. Shapes differ, not just colors. */
    static void flavor(GuiGraphics g, float x, float y, float r, int color, float deg) {
        ArcadeArt.cell(g, FRUIT, 64, Math.max(0, Math.min(5, color)), x, y, r * 16 / 7f, deg, 0xFFFFFF, 1f);
    }

    static void flavor(GuiGraphics g, float x, float y, float r, int color) {
        flavor(g, x, y, r, color, 0);
    }

    // ================================================================== menu preview

    public static void drawPreview(GuiGraphics g, int x, int y, int w, int h, double t) {
        float s = Math.min(h / FH, w / FW);
        g.pose().pushPose();
        g.pose().translate(x + w / 2f - FW * s / 2, y + h / 2f - FH * s / 2, 0);
        g.pose().scale(s, s, 1);
        ArcadeArt.whole(g, BG, 0, 0, FW, FH);
        drawConveyor(g, t, false);
        Random r = new Random(9);
        float head = (float) ((t * 30) % (PATH_LEN * 0.8));
        int color = r.nextInt(4);
        for (int i = 0; i < 40; i++) {
            float bs = head - i * D;
            if (bs < 0) break;
            if (r.nextFloat() < 0.45f) color = r.nextInt(4);
            float[] p = at(bs);
            flavor(g, p[0], p[1], BR, color, (float) Math.toDegrees(bs / BR));
        }
        drawBlender(g, t, false);
        drawShooter(g, (float) (t * 50 % 360), 1, 2);
        drawCup(g, CUP_X, CUP_Y, (float) ((t * 0.12) % 1), t);
        g.pose().popPose();
    }
}
