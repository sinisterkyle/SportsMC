package com.sportsmc.client.arcade;

import com.sportsmc.arcade.ArcadeGame;
import com.sportsmc.network.ArcadeBoardPacket;
import net.minecraftforge.fml.loading.FMLPaths;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;

/** The server's arcade boards (as last received), plus your own personal bests saved on this computer. */
public final class ClientArcadeData {

    private static List<List<ArcadeBoardPacket.Row>> boards = List.of();
    private static final Path FILE = FMLPaths.CONFIGDIR.get().resolve("sportsmc-arcade-best.properties");
    private static final Properties best = load();

    private ClientArcadeData() {}

    public static void apply(ArcadeBoardPacket p) {
        boards = p.boards();
    }

    public static List<ArcadeBoardPacket.Row> board(ArcadeGame g) {
        return g.ordinal() < boards.size() ? boards.get(g.ordinal()) : List.of();
    }

    public static int personalBest(ArcadeGame g) {
        try {
            return Integer.parseInt(best.getProperty(g.name(), "0"));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /** Remembers a score if it's a personal best; returns true if it was. */
    public static boolean recordBest(ArcadeGame g, int score) {
        if (score <= personalBest(g)) return false;
        best.setProperty(g.name(), String.valueOf(score));
        try (var out = Files.newOutputStream(FILE)) {
            best.store(out, "SportsMC arcade personal bests");
        } catch (Exception ignored) {
        }
        return true;
    }

    private static Properties load() {
        Properties p = new Properties();
        try (var in = Files.newInputStream(FILE)) {
            p.load(in);
        } catch (Exception ignored) {
        }
        return p;
    }
}
