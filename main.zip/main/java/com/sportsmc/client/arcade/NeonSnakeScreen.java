package com.sportsmc.client.arcade;

import com.sportsmc.arcade.ArcadeGame;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Neon Snake: eat the glowing orbs to grow; every orb makes you a little faster. Don't hit the walls or
 * yourself. A golden star shows up now and then for big points, but it fades fast. Turns are queued, so
 * quick double-taps (like a U-turn) work.
 */
public class NeonSnakeScreen extends ArcadeGameScreen {

    static final int GW = 32, GH = 22;
    private static final int[] DX = {0, -1, 0, 1}, DY = {-1, 0, 1, 0};

    private final Deque<int[]> body = new ArrayDeque<>(); // head first
    private final Deque<Integer> turns = new ArrayDeque<>();
    private int dir, grow;
    private double stepTimer, stepTime;
    private int[] food;
    private int[] star;
    private double starUntil;
    private int eaten;
    private boolean dead;
    private double deadAt;
    private final Random random = new Random();
    private final List<Spark> sparks = new ArrayList<>();

    private static final class Spark { float x, y, vx, vy, age, life; int color; }

    public NeonSnakeScreen() {
        super(ArcadeGame.NEON_SNAKE);
    }

    @Override
    protected void reset() {
        body.clear();
        turns.clear();
        for (int i = 0; i < 4; i++) body.addLast(new int[]{8 - i, GH / 2});
        dir = 3;
        grow = 0;
        stepTime = 0.13;
        stepTimer = 0;
        eaten = 0;
        dead = false;
        star = null;
        sparks.clear();
        food = freeCell();
    }

    private int[] freeCell() {
        for (int tries = 0; tries < 2000; tries++) {
            int x = random.nextInt(GW), y = random.nextInt(GH);
            if (!occupied(x, y) && (food == null || food[0] != x || food[1] != y)) return new int[]{x, y};
        }
        return new int[]{0, 0};
    }

    private boolean occupied(int x, int y) {
        for (int[] c : body) if (c[0] == x && c[1] == y) return true;
        return false;
    }

    @Override
    protected void onPress(int key) {
        int d = switch (key) {
            case GLFW.GLFW_KEY_UP, GLFW.GLFW_KEY_W -> 0;
            case GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_A -> 1;
            case GLFW.GLFW_KEY_DOWN, GLFW.GLFW_KEY_S -> 2;
            case GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_D -> 3;
            default -> -1;
        };
        if (d < 0 || turns.size() >= 3) return;
        int last = turns.isEmpty() ? dir : turns.peekLast();
        if (d == last || d == (last + 2) % 4) return; // no-op or straight back into yourself
        turns.addLast(d);
    }

    @Override
    protected void update() {
        tickSparks();
        if (dead) {
            if (time - deadAt > 1.2) gameOver();
            return;
        }
        if (star != null && time > starUntil) star = null;
        stepTimer += STEP;
        while (stepTimer >= stepTime && !dead) {
            stepTimer -= stepTime;
            stepSnake();
        }
    }

    private void stepSnake() {
        if (!turns.isEmpty()) dir = turns.pollFirst();
        int[] head = body.peekFirst();
        int nx = head[0] + DX[dir], ny = head[1] + DY[dir];
        boolean eatsFood = nx == food[0] && ny == food[1];
        // Moving into the cell the tail is leaving is fine (unless we're growing).
        int[] tail = body.peekLast();
        boolean hitsSelf = occupied(nx, ny) && !(grow == 0 && !eatsFood && tail[0] == nx && tail[1] == ny);
        if (nx < 0 || ny < 0 || nx >= GW || ny >= GH || hitsSelf) {
            die();
            return;
        }
        body.addFirst(new int[]{nx, ny});
        if (grow > 0) grow--;
        else if (!eatsFood) body.removeLast();

        if (eatsFood) {
            eaten++;
            score += 10 + eaten / 5 * 5;
            grow += 2;
            stepTime = Math.max(0.05, stepTime * 0.97);
            burst(nx, ny, 0xFF39FF14, 14);
            sound(SoundEvents.NOTE_BLOCK_PLING.value(), 1.0f + Math.min(1, eaten * 0.02f), 0.4f);
            food = freeCell();
            if (star == null && eaten % 7 == 0) {
                star = freeCell();
                starUntil = time + 6;
            }
        }
        if (star != null && nx == star[0] && ny == star[1]) {
            int bonus = 50 + (int) Math.max(0, (starUntil - time) * 25);
            score += bonus;
            burst(nx, ny, 0xFFFFD23C, 24);
            sound(SoundEvents.PLAYER_LEVELUP, 1.6f, 0.4f);
            star = null;
        }
    }

    private void die() {
        dead = true;
        deadAt = time;
        for (int[] c : body) burst(c[0], c[1], 0xFFFF2BD6, 3);
        sound(SoundEvents.NOTE_BLOCK_BASS.value(), 0.6f, 0.8f);
    }

    private void burst(int cx, int cy, int color, int n) {
        for (int i = 0; i < n; i++) {
            double a = random.nextDouble() * Math.PI * 2, v = 3 + random.nextDouble() * 8;
            Spark sp = new Spark();
            sp.x = cx + 0.5f;
            sp.y = cy + 0.5f;
            sp.vx = (float) (Math.cos(a) * v);
            sp.vy = (float) (Math.sin(a) * v);
            sp.life = 0.4f + random.nextFloat() * 0.5f;
            sp.color = color;
            sparks.add(sp);
        }
    }

    private void tickSparks() {
        for (Iterator<Spark> it = sparks.iterator(); it.hasNext(); ) {
            Spark p = it.next();
            p.age += STEP;
            if (p.age >= p.life) { it.remove(); continue; }
            p.x += p.vx * STEP;
            p.y += p.vy * STEP;
            p.vx *= 0.92f;
            p.vy *= 0.92f;
        }
    }

    // ================================================================== drawing

    @Override
    protected void draw(GuiGraphics g) {
        float cell = Math.min((width - 40) / (float) GW, (height - 50) / (float) GH);
        float ox = width / 2f - GW * cell / 2, oy = height / 2f - GH * cell / 2 + 4;
        drawBoard(g, ox, oy, cell, time);
        // Food (pulsing orb), star (spinning), snake (rainbow from head), sparks.
        float pulse = 0.75f + 0.25f * (float) Math.sin(time * 6);
        orb(g, ox + (food[0] + 0.5f) * cell, oy + (food[1] + 0.5f) * cell, cell * 0.38f * pulse, 0xFF39FF14);
        if (star != null) {
            boolean blink = starUntil - time < 2 && ((int) (time * 8)) % 2 == 0;
            if (!blink) orb(g, ox + (star[0] + 0.5f) * cell, oy + (star[1] + 0.5f) * cell, cell * 0.45f, 0xFFFFD23C);
        }
        if (!dead || ((int) ((time - deadAt) * 8)) % 2 == 0) drawSnake(g, body, dir, ox, oy, cell, time, dead);
        for (Spark p : sparks) {
            int a = (int) (255 * (1 - p.age / p.life));
            float s = cell * 0.2f;
            fillF(g, ox + p.x * cell - s, oy + p.y * cell - s, ox + p.x * cell + s, oy + p.y * cell + s, withAlpha(p.color, a));
        }
        g.drawString(font, "SCORE " + String.format("%,d", score), (int) ox, (int) oy - 12, TEXT);
        String best = "BEST " + String.format("%,d", Math.max(score, ClientArcadeData.personalBest(game)));
        g.drawString(font, best, (int) (ox + GW * cell) - font.width(best), (int) oy - 12, DIM);
        g.drawCenteredString(font, "LENGTH " + body.size(), width / 2, (int) oy - 12, 0xFF39FF14);
        if (time < 2.5 && !dead) g.drawCenteredString(font, "Eat the orbs - don't hit the walls or yourself!", width / 2, (int) (oy + GH * cell * 0.3f), DIM);
        g.drawCenteredString(font, "ARROWS / WASD turn   P pause   ESC menu", width / 2, height - 11, 0xFF6A6A88);
    }

    static void drawBoard(GuiGraphics g, float ox, float oy, float cell, double t) {
        g.fill((int) ox - 3, (int) oy - 3, (int) (ox + GW * cell) + 3, (int) (oy + GH * cell) + 3, 0xFFFF2BD6);
        g.fill((int) ox - 1, (int) oy - 1, (int) (ox + GW * cell) + 1, (int) (oy + GH * cell) + 1, 0xFF00F0FF);
        g.fill((int) ox, (int) oy, (int) (ox + GW * cell), (int) (oy + GH * cell), 0xFF07070F);
        for (int x = 1; x < GW; x++) fillF(g, ox + x * cell, oy, ox + x * cell + 0.5f, oy + GH * cell, 0x14FF2BD6);
        for (int y = 1; y < GH; y++) fillF(g, ox, oy + y * cell, ox + GW * cell, oy + y * cell + 0.5f, 0x1400F0FF);
    }

    static void drawSnake(GuiGraphics g, Iterable<int[]> body, int dir, float ox, float oy, float cell, double t, boolean dead) {
        int i = 0;
        for (int[] c : body) {
            float hue = (float) ((t * 0.15 + i * 0.035) % 1.0);
            int color = dead ? 0xFFFF2BD6 : hsv(hue, 0.85f, 1f);
            float inset = i == 0 ? cell * 0.04f : cell * 0.1f;
            float x0 = ox + c[0] * cell + inset, y0 = oy + c[1] * cell + inset;
            float x1 = ox + (c[0] + 1) * cell - inset, y1 = oy + (c[1] + 1) * cell - inset;
            fillF(g, x0 - 1, y0 - 1, x1 + 1, y1 + 1, withAlpha(color, 70)); // glow
            fillF(g, x0, y0, x1, y1, color);
            fillF(g, x0 + (x1 - x0) * 0.2f, y0 + (y1 - y0) * 0.2f, x0 + (x1 - x0) * 0.45f, y0 + (y1 - y0) * 0.45f, 0x60FFFFFF);
            if (i == 0) {
                // Eyes looking where it's going.
                float cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, e = cell * 0.13f;
                float fx = new float[]{0, -1, 0, 1}[dir], fy = new float[]{-1, 0, 1, 0}[dir];
                float sx = -fy * cell * 0.2f, sy = fx * cell * 0.2f;
                for (int s = -1; s <= 1; s += 2) {
                    float ex = cx + fx * cell * 0.15f + s * sx, ey = cy + fy * cell * 0.15f + s * sy;
                    fillF(g, ex - e, ey - e, ex + e, ey + e, 0xFFFFFFFF);
                    fillF(g, ex - e / 2 + fx * e / 2, ey - e / 2 + fy * e / 2, ex + e / 2 + fx * e / 2, ey + e / 2 + fy * e / 2, 0xFF000000);
                }
            }
            i++;
        }
    }

    static void orb(GuiGraphics g, float cx, float cy, float r, int color) {
        MazeMuncherScreen.disc(g, cx, cy, r * 1.6f, withAlpha(color, 50));
        MazeMuncherScreen.disc(g, cx, cy, r, color);
        MazeMuncherScreen.disc(g, cx - r * 0.3f, cy - r * 0.3f, r * 0.3f, 0xB0FFFFFF);
    }

    /** Hue (0..1), saturation, value to an opaque color. */
    static int hsv(float h, float s, float v) {
        float hh = (h - (float) Math.floor(h)) * 6f;
        int i = (int) hh;
        float f = hh - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        float r, g, b;
        switch (i) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return 0xFF000000 | (int) (r * 255) << 16 | (int) (g * 255) << 8 | (int) (b * 255);
    }

    // ================================================================== menu preview

    public static void drawPreview(GuiGraphics g, int x, int y, int w, int h, double t) {
        float cell = Math.min(w / (float) GW, h / (float) GH);
        float ox = x + w / 2f - GW * cell / 2, oy = y + h / 2f - GH * cell / 2;
        drawBoard(g, ox, oy, cell, t);
        // A snake slithering around a loop.
        int len = 14;
        List<int[]> b = new ArrayList<>();
        int pathLen = 2 * (20 + 10);
        int head = (int) (t * 8);
        for (int i = 0; i < len; i++) {
            int p = Math.floorMod(head - i, pathLen);
            int cx, cy;
            if (p < 20) { cx = 6 + p; cy = 6; }
            else if (p < 30) { cx = 26; cy = 6 + (p - 20); }
            else if (p < 50) { cx = 26 - (p - 30); cy = 16; }
            else { cx = 6; cy = 16 - (p - 50); }
            b.add(new int[]{cx, cy});
        }
        int hp = Math.floorMod(head, pathLen);
        int d = hp < 20 ? 3 : hp < 30 ? 2 : hp < 50 ? 1 : 0;
        drawSnake(g, b, d, ox, oy, cell, t, false);
        orb(g, ox + 17.5f * cell, oy + 11.5f * cell, cell * 0.38f, 0xFF39FF14);
    }
}
