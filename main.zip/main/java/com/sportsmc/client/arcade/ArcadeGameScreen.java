package com.sportsmc.client.arcade;

import com.sportsmc.arcade.ArcadeGame;
import com.sportsmc.network.ArcadeScorePacket;
import com.sportsmc.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;

/**
 * Shared base for arcade games: a fixed 60-steps-per-second game clock (smooth and identical at any frame
 * rate), held-key tracking, pausing (P, or automatically when you take damage or the window loses focus,
 * since your character is still standing in the world), and score submission at game over.
 *
 * Keys: P pause, R restart (after game over), ESC back to the arcade menu.
 */
public abstract class ArcadeGameScreen extends Screen {

    protected static final double STEP = 1 / 60.0;
    protected static final int TEXT = 0xFFFFFFFF, DIM = 0xFF9A9AB0, GOLD = 0xFFFFC83D;

    protected final ArcadeGame game;
    protected final Set<Integer> held = new HashSet<>();
    protected int score;
    protected boolean over;
    protected double overTime;
    private boolean paused;
    private String pauseReason = "";
    private double accumulator;
    private long lastNanos = System.nanoTime();
    private boolean newBest;
    /** Seconds since the game started (game time: stops while paused). */
    protected double time;

    protected ArcadeGameScreen(ArcadeGame game) {
        super(Component.literal(game.title));
        this.game = game;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------------ for the games

    /** Start (or restart) the game. */
    protected abstract void reset();

    /** One fixed game step (1/60 s). */
    protected abstract void update();

    /** Draw the game. Called inside one batched draw. */
    protected abstract void draw(GuiGraphics g);

    /** A key was pressed (not counting auto-repeat) while playing. */
    protected void onPress(int key) {}

    protected void gameOver() {
        if (over) return;
        over = true;
        overTime = time;
        newBest = ClientArcadeData.recordBest(game, score);
        if (score > 0) ModNetwork.sendToServer(new ArcadeScorePacket(game.ordinal(), score));
    }

    /** True while the game is running (not paused, not over): mouse-driven games check this before acting. */
    protected boolean playing() {
        return !paused && !over;
    }

    protected boolean isHeld(int... keys) {
        for (int k : keys) if (held.contains(k)) return true;
        return false;
    }

    protected static void sound(SoundEvent s, float pitch, float volume) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(s, pitch, volume));
    }

    // ------------------------------------------------------------------ screen plumbing

    @Override
    protected void init() {
        if (time == 0 && !over) reset();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        g.fill(0, 0, width, height, 0xF0080810);
        long now = System.nanoTime();
        double dt = Math.min(0.1, (now - lastNanos) / 1e9);
        lastNanos = now;

        Minecraft mc = Minecraft.getInstance();
        if (!paused && !over) {
            if (mc.player != null && mc.player.hurtTime > 0) pause("You're taking damage in the world!");
            else if (!mc.isWindowActive()) pause("Paused");
        }
        if (!paused && !over) {
            accumulator += dt;
            int steps = 0;
            while (accumulator >= STEP && steps++ < 6) {
                accumulator -= STEP;
                time += STEP;
                try {
                    update();
                } catch (RuntimeException e) {
                    crashed(e);
                }
                if (over) break;
            }
            if (steps >= 6) accumulator = 0;
        } else if (over) {
            time += dt; // keep end-screen animations moving
        }

        try {
            g.drawManaged(() -> draw(g));
        } catch (RuntimeException e) {
            crashed(e);
        }

        if (paused) {
            banner(g, "PAUSED", pauseReason + "   P = resume   ESC = arcade menu", GOLD);
        } else if (over && time - overTime > 0.8) {
            String sub = (newBest ? "NEW PERSONAL BEST!  " : "") + "Score " + String.format("%,d", score) + "   R = play again   ESC = arcade menu";
            banner(g, "GAME OVER", sub, 0xFFFF5A5A);
        }
        super.render(g, mx, my, partialTick);
    }

    private void banner(GuiGraphics g, String title, String sub, int color) {
        int cy = height / 2;
        g.fill(0, cy - 26, width, cy + 24, 0xD0000000);
        g.pose().pushPose();
        g.pose().translate(width / 2f, cy - 18, 0);
        g.pose().scale(2.5f, 2.5f, 1);
        g.drawCenteredString(font, title, 0, 0, color);
        g.pose().popPose();
        g.drawCenteredString(font, sub, width / 2, cy + 10, TEXT);
    }

    /** A bug in a game must never take Minecraft down: log it and end the game instead. */
    private void crashed(RuntimeException e) {
        com.sportsmc.SportsMC.LOGGER.error("SportsMC arcade: {} hit an error and was ended (please report this)", game.title, e);
        if (!over) gameOver();
        pauseReason = "";
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                "[SportsMC] " + game.title + " hit an error and was ended - details are in the log.")
                .withStyle(net.minecraft.ChatFormatting.RED), false);
    }

    private void pause(String reason) {
        paused = true;
        pauseReason = reason;
        held.clear();
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            Minecraft.getInstance().setScreen(new ArcadeScreen(game));
            return true;
        }
        if (over) {
            if (key == GLFW.GLFW_KEY_R || key == GLFW.GLFW_KEY_ENTER) {
                over = false;
                newBest = false;
                time = 0;
                score = 0;
                accumulator = 0;
                held.clear();
                reset();
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_P) {
            if (paused) { paused = false; lastNanos = System.nanoTime(); }
            else pause("");
            return true;
        }
        if (paused) return true;
        boolean repeat = held.contains(key);
        held.add(key);
        if (!repeat) onPress(key);
        return true;
    }

    @Override
    public boolean keyReleased(int key, int scan, int mods) {
        held.remove(key);
        return true;
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(new ArcadeScreen(game));
    }

    // ------------------------------------------------------------------ drawing helpers

    protected static void fillF(GuiGraphics g, float x0, float y0, float x1, float y1, int color) {
        g.pose().pushPose();
        g.pose().scale(0.25f, 0.25f, 1);
        g.fill(Math.round(x0 * 4), Math.round(y0 * 4), Math.round(x1 * 4), Math.round(y1 * 4), color);
        g.pose().popPose();
    }

    protected static int shade(int argb, float f) {
        int a = argb >>> 24;
        int r = Math.min(255, (int) ((argb >> 16 & 255) * f));
        int gr = Math.min(255, (int) ((argb >> 8 & 255) * f));
        int b = Math.min(255, (int) ((argb & 255) * f));
        return a << 24 | r << 16 | gr << 8 | b;
    }

    protected static int withAlpha(int rgb, int alpha) {
        return Math.max(0, Math.min(255, alpha)) << 24 | (rgb & 0xFFFFFF);
    }
}
