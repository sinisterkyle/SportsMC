package com.sportsmc.client.arcade;

import com.sportsmc.arcade.ArcadeGame;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Brick Blitz: bounce the ball off your paddle to smash every brick. Where the ball hits the paddle sets its
 * angle. Silver bricks take two hits, gold ones never break. Smashed bricks sometimes drop a power-up:
 * W wider paddle, M multi-ball, S slow ball, + extra life. Move with the arrow keys / A D or just the mouse;
 * SPACE or click launches the ball. Field is 240 x 280 units.
 */
public class BrickBlitzScreen extends ArcadeGameScreen {

    static final float FW = 240, FH = 280;
    static final int COLS = 12, ROWS_MAX = 10;
    static final float BW = 18, BH = 8, BX0 = 12, BY0 = 34;
    private static final float PADDLE_Y = 262, BALL_R = 2.6f;
    static final int[] ROW_COLORS = {0xFFFF4D4D, 0xFFFF9A3C, 0xFFFFE03C, 0xFF5CE65C, 0xFF3CC8FF, 0xFFB45CFF};
    static final String[][] LEVELS = {
            {"............", "111111111111", "222222222222", "333333333333", "444444444444", "555555555555", "666666666666"},
            {"S..S..S..S..", "1111111111111".substring(0, 12), ".2222222222.", "..33333333..", "...444444...", "....5555....", ".....66....."},
            {"SSSSSSSSSSSS", "1.1.1.1.1.1.", ".2.2.2.2.2.2", "3.3.3.3.3.3.", ".4.4.4.4.4.4", "5.5.5.5.5.5.", "GGG......GGG"},
            {"11....11....".substring(0, 12), "22S..S22S..S", "333..333...3", "4444444444G.", "55..55..55..", "66666666666.", "....SSSS...."},
            {"G..........G", ".SSSSSSSSSS.", ".1111111111.", ".2222222222.", ".3333333333.", ".4444444444.", ".5555555555.", ".6666666666.", "GGGG....GGGG"},
    };

    private static final class Ball { float x, y, vx, vy; boolean stuck; }
    private static final class Drop { float x, y; char kind; }
    private static final class Spark { float x, y, vx, vy, age, life; int color; }

    private final int[][] bricks = new int[ROWS_MAX][COLS]; // 0 empty, 1-6 color, 7 silver (2 hits), 8 silver cracked, 9 gold
    private final List<Ball> balls = new ArrayList<>();
    private final List<Drop> drops = new ArrayList<>();
    private final List<Spark> sparks = new ArrayList<>();
    private final Random random = new Random();
    private float paddleX = FW / 2;
    private double wideUntil, slowUntil;
    private int lives, level;
    private float speed;
    private double levelStart = -10;
    private boolean levelCleared;
    private double clearedAt;
    // Mouse control (screen -> field mapping from the last frame).
    private float lastScale = 1, lastOx;
    private double mouseFieldX = -1;
    private boolean mouseMoved;

    public BrickBlitzScreen() {
        super(ArcadeGame.BRICK_BLITZ);
    }

    @Override
    protected void reset() {
        lives = 3;
        level = 0;
        nextLevel();
    }

    private void nextLevel() {
        level++;
        String[] layout = LEVELS[(level - 1) % LEVELS.length];
        for (int[] row : bricks) java.util.Arrays.fill(row, 0);
        for (int r = 0; r < layout.length && r < ROWS_MAX; r++) {
            for (int c = 0; c < COLS && c < layout[r].length(); c++) {
                char ch = layout[r].charAt(c);
                bricks[r][c] = ch >= '1' && ch <= '6' ? ch - '0' : ch == 'S' ? 7 : ch == 'G' ? 9 : 0;
            }
        }
        drops.clear();
        levelCleared = false;
        levelStart = time;
        newBall();
    }

    private void newBall() {
        balls.clear();
        Ball b = new Ball();
        b.stuck = true;
        balls.add(b);
        speed = 150 + (level - 1) * 12;
        wideUntil = slowUntil = 0;
    }

    private float paddleW() {
        return time < wideUntil ? 54 : 36;
    }

    private float ballSpeed() {
        return time < slowUntil ? Math.min(speed, 130) : speed;
    }

    @Override
    protected void onPress(int key) {
        if (key == GLFW.GLFW_KEY_SPACE || key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_W) launch();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        launch();
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public void mouseMoved(double mx, double my) {
        mouseFieldX = (mx - lastOx) / lastScale;
        mouseMoved = true;
    }

    private void launch() {
        for (Ball b : balls) {
            if (!b.stuck) continue;
            b.stuck = false;
            double a = Math.toRadians(-60 + random.nextDouble() * 30 * (random.nextBoolean() ? 1 : -1) + 30);
            b.vx = (float) (Math.sin(a) * ballSpeed());
            b.vy = (float) (-Math.cos(a) * ballSpeed());
            sound(SoundEvents.NOTE_BLOCK_HAT.value(), 1.4f, 0.4f);
        }
    }

    // ================================================================== update

    @Override
    protected void update() {
        float dt = (float) STEP;
        tickSparks(dt);
        if (levelCleared) {
            if (time - clearedAt > 2.0) nextLevel();
            return;
        }
        // Paddle: keys, or follow the mouse when it moves.
        boolean left = isHeld(GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_A), right = isHeld(GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_D);
        if (left != right) { paddleX += (left ? -230 : 230) * dt; mouseMoved = false; }
        else if (mouseMoved && mouseFieldX >= 0) {
            float target = (float) mouseFieldX, step = 400 * dt;
            paddleX += Math.max(-step, Math.min(step, target - paddleX));
        }
        float half = paddleW() / 2;
        paddleX = Math.max(half + 2, Math.min(FW - half - 2, paddleX));

        // Balls (in sub-steps so a fast ball can't skip through a brick).
        for (Iterator<Ball> it = balls.iterator(); it.hasNext(); ) {
            Ball b = it.next();
            if (b.stuck) { b.x = paddleX; b.y = PADDLE_Y - BALL_R - 1; continue; }
            // Keep its speed matched to the current speed (slow ball / speed-ups).
            float len = (float) Math.sqrt(b.vx * b.vx + b.vy * b.vy), want = ballSpeed();
            if (len > 0.01f) { b.vx *= want / len; b.vy *= want / len; }
            boolean lost = false;
            for (int sub = 0; sub < 4 && !lost; sub++) lost = moveBall(b, dt / 4);
            if (lost) it.remove();
        }
        if (balls.isEmpty()) {
            lives--;
            sound(SoundEvents.NOTE_BLOCK_BASS.value(), 0.6f, 0.7f);
            if (lives <= 0) { gameOver(); return; }
            newBall();
        }

        // Power-ups falling.
        for (Iterator<Drop> it = drops.iterator(); it.hasNext(); ) {
            Drop d = it.next();
            d.y += 60 * dt;
            if (d.y > FH) { it.remove(); continue; }
            if (d.y >= PADDLE_Y - 4 && d.y <= PADDLE_Y + 6 && Math.abs(d.x - paddleX) < paddleW() / 2 + 6) {
                catchDrop(d.kind);
                it.remove();
            }
        }

        boolean any = false;
        for (int[] row : bricks) for (int v : row) if (v > 0 && v < 9) { any = true; break; }
        if (!any) {
            levelCleared = true;
            clearedAt = time;
            score += 500 * level;
            sound(SoundEvents.PLAYER_LEVELUP, 1.3f, 0.6f);
        }
    }

    /** Moves a ball one sub-step; returns true if it fell off the bottom. */
    private boolean moveBall(Ball b, float dt) {
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        // Walls.
        if (b.x < BALL_R) { b.x = BALL_R; b.vx = Math.abs(b.vx); wallSound(); }
        if (b.x > FW - BALL_R) { b.x = FW - BALL_R; b.vx = -Math.abs(b.vx); wallSound(); }
        if (b.y < BALL_R + 16) { b.y = BALL_R + 16; b.vy = Math.abs(b.vy); wallSound(); }
        if (b.y > FH + 6) return true;
        // Paddle: the further from the middle you hit it, the sharper the angle.
        float half = paddleW() / 2;
        if (b.vy > 0 && b.y + BALL_R >= PADDLE_Y && b.y - BALL_R <= PADDLE_Y + 5 && Math.abs(b.x - paddleX) <= half + BALL_R) {
            float off = Math.max(-1, Math.min(1, (b.x - paddleX) / half));
            double a = Math.toRadians(off * 62);
            float sp = ballSpeed();
            b.vx = (float) (Math.sin(a) * sp);
            b.vy = (float) (-Math.cos(a) * sp);
            b.y = PADDLE_Y - BALL_R;
            sound(SoundEvents.NOTE_BLOCK_HAT.value(), 1.0f, 0.35f);
        }
        // Bricks.
        int c0 = (int) Math.floor((b.x - BALL_R - BX0) / BW), c1 = (int) Math.floor((b.x + BALL_R - BX0) / BW);
        int r0 = (int) Math.floor((b.y - BALL_R - BY0) / BH), r1 = (int) Math.floor((b.y + BALL_R - BY0) / BH);
        for (int r = Math.max(0, r0); r <= Math.min(ROWS_MAX - 1, r1); r++) {
            for (int c = Math.max(0, c0); c <= Math.min(COLS - 1, c1); c++) {
                if (bricks[r][c] == 0) continue;
                float bx0 = BX0 + c * BW, by0 = BY0 + r * BH, bx1 = bx0 + BW, by1 = by0 + BH;
                // Closest point on the brick to the ball's center.
                float px = Math.max(bx0, Math.min(bx1, b.x)), py = Math.max(by0, Math.min(by1, b.y));
                float dx = b.x - px, dy = b.y - py;
                if (dx * dx + dy * dy > BALL_R * BALL_R) continue;
                // Bounce off the side we came through (the shallower overlap).
                float overlapX = Math.min(b.x + BALL_R - bx0, bx1 - (b.x - BALL_R));
                float overlapY = Math.min(b.y + BALL_R - by0, by1 - (b.y - BALL_R));
                if (overlapX < overlapY) {
                    b.vx = b.x < (bx0 + bx1) / 2 ? -Math.abs(b.vx) : Math.abs(b.vx);
                    b.x += b.vx > 0 ? overlapX : -overlapX;
                } else {
                    b.vy = b.y < (by0 + by1) / 2 ? -Math.abs(b.vy) : Math.abs(b.vy);
                    b.y += b.vy > 0 ? overlapY : -overlapY;
                }
                hitBrick(r, c);
                return false; // one brick per sub-step keeps bounces clean
            }
        }
        return false;
    }

    private void hitBrick(int r, int c) {
        int v = bricks[r][c];
        float cx = BX0 + c * BW + BW / 2, cy = BY0 + r * BH + BH / 2;
        if (v == 9) { sound(SoundEvents.ANVIL_LAND, 2.0f, 0.15f); return; }
        if (v == 7) {
            bricks[r][c] = 8;
            score += 10;
            sound(SoundEvents.NOTE_BLOCK_IRON_XYLOPHONE.value(), 1.5f, 0.4f);
            return;
        }
        int color = v == 8 ? 0xFFC8C8D8 : ROW_COLORS[v - 1];
        score += v == 8 ? 50 * level : (7 - v) * 10;
        bricks[r][c] = 0;
        speed = Math.min(270, speed + 1.2f);
        for (int i = 0; i < 10; i++) spark(cx, cy, color);
        sound(SoundEvents.NOTE_BLOCK_PLING.value(), 0.8f + (6 - Math.min(6, v)) * 0.12f, 0.35f);
        if (random.nextFloat() < 0.11f) {
            Drop d = new Drop();
            d.x = cx;
            d.y = cy;
            float roll = random.nextFloat();
            d.kind = roll < 0.32f ? 'W' : roll < 0.62f ? 'M' : roll < 0.9f ? 'S' : '+';
            drops.add(d);
        }
    }

    private void catchDrop(char kind) {
        score += 100;
        sound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.2f, 0.5f);
        switch (kind) {
            case 'W' -> wideUntil = time + 12;
            case 'S' -> slowUntil = time + 10;
            case '+' -> lives++;
            case 'M' -> {
                List<Ball> add = new ArrayList<>();
                for (Ball b : balls) {
                    if (b.stuck || add.size() >= 4) continue;
                    for (int s = -1; s <= 1; s += 2) {
                        Ball n = new Ball();
                        n.x = b.x;
                        n.y = b.y;
                        double a = Math.atan2(b.vx, -b.vy) + s * 0.45;
                        n.vx = (float) (Math.sin(a) * ballSpeed());
                        n.vy = (float) (-Math.cos(a) * ballSpeed());
                        add.add(n);
                    }
                }
                balls.addAll(add);
            }
            default -> {}
        }
    }

    private void wallSound() {
        sound(SoundEvents.NOTE_BLOCK_HAT.value(), 0.8f, 0.15f);
    }

    private void spark(float x, float y, int color) {
        Spark s = new Spark();
        double a = random.nextDouble() * Math.PI * 2, v = 20 + random.nextDouble() * 60;
        s.x = x; s.y = y;
        s.vx = (float) (Math.cos(a) * v);
        s.vy = (float) (Math.sin(a) * v);
        s.life = 0.4f + random.nextFloat() * 0.4f;
        s.color = color;
        sparks.add(s);
    }

    private void tickSparks(float dt) {
        for (Iterator<Spark> it = sparks.iterator(); it.hasNext(); ) {
            Spark s = it.next();
            s.age += dt;
            if (s.age >= s.life) { it.remove(); continue; }
            s.x += s.vx * dt;
            s.y += s.vy * dt;
            s.vy += 120 * dt;
        }
    }

    // ================================================================== drawing

    @Override
    protected void draw(GuiGraphics g) {
        float s = Math.min((height - 24) / FH, (width - 20) / FW);
        float ox = width / 2f - FW * s / 2, oy = (height - FH * s) / 2f - 4;
        lastScale = s;
        lastOx = ox;
        g.fill((int) ox - 3, (int) oy - 3, (int) (ox + FW * s) + 3, (int) (oy + FH * s) + 3, 0xFF8A8AA8);
        g.fillGradient((int) ox, (int) oy, (int) (ox + FW * s), (int) (oy + FH * s), 0xFF101028, 0xFF05050C);
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(s, s, 1);

        drawBricks(g, bricks, time);
        // Paddle.
        float half = paddleW() / 2;
        fillF(g, paddleX - half, PADDLE_Y, paddleX + half, PADDLE_Y + 5, 0xFFB8C0D8);
        fillF(g, paddleX - half, PADDLE_Y, paddleX + half, PADDLE_Y + 1.5f, 0xFFFFFFFF);
        fillF(g, paddleX - half, PADDLE_Y, paddleX - half + 4, PADDLE_Y + 5, 0xFFFF4D4D);
        fillF(g, paddleX + half - 4, PADDLE_Y, paddleX + half, PADDLE_Y + 5, 0xFFFF4D4D);
        for (Ball b : balls) {
            MazeMuncherScreen.disc(g, b.x, b.y, BALL_R + 1.5f, 0x40FFFFFF);
            MazeMuncherScreen.disc(g, b.x, b.y, BALL_R, 0xFFFFFFFF);
        }
        for (Drop d : drops) {
            int col = switch (d.kind) { case 'W' -> 0xFF3CC8FF; case 'M' -> 0xFFFF9A3C; case 'S' -> 0xFF5CE65C; default -> 0xFFFF4D4D; };
            fillF(g, d.x - 7, d.y - 3.5f, d.x + 7, d.y + 3.5f, col);
            fillF(g, d.x - 7, d.y - 3.5f, d.x + 7, d.y - 2, 0x80FFFFFF);
        }
        for (Spark sp : sparks) {
            int a = (int) (255 * (1 - sp.age / sp.life));
            fillF(g, sp.x - 1, sp.y - 1, sp.x + 1, sp.y + 1, withAlpha(sp.color, a));
        }
        g.pose().popPose();
        // Power-up letters (text is drawn unscaled).
        for (Drop d : drops) g.drawCenteredString(font, String.valueOf(d.kind), (int) (ox + d.x * s), (int) (oy + (d.y - 3.5f) * s), 0xFF101010);

        int left = (int) ox, right = (int) (ox + FW * s), top = (int) oy;
        g.drawString(font, "SCORE " + String.format("%,d", score), left + 4, top + 4, TEXT);
        String best = "BEST " + String.format("%,d", Math.max(score, ClientArcadeData.personalBest(game)));
        g.drawCenteredString(font, best, (left + right) / 2, top + 4, DIM);
        String info = "LV " + level + "  ♥" + lives;
        g.drawString(font, info, right - font.width(info) - 4, top + 4, 0xFFFF7A7A);
        if (!balls.isEmpty() && balls.get(0).stuck && !over) {
            g.drawCenteredString(font, "SPACE / click to launch", (left + right) / 2, (int) (oy + 200 * s), GOLD);
        }
        if (levelCleared) g.drawCenteredString(font, "LEVEL CLEAR!  +" + 500 * level, (left + right) / 2, (int) (oy + 150 * s), GOLD);
        else if (time - levelStart < 1.5) g.drawCenteredString(font, "LEVEL " + level, (left + right) / 2, (int) (oy + 150 * s), 0xFF3CC8FF);
        g.drawCenteredString(font, "MOUSE or ← → move   SPACE launch   P pause   ESC menu", width / 2, height - 11, 0xFF6A6A88);
    }

    static void drawBricks(GuiGraphics g, int[][] bricks, double t) {
        for (int r = 0; r < bricks.length; r++) {
            for (int c = 0; c < COLS; c++) {
                int v = bricks[r][c];
                if (v == 0) continue;
                float x0 = BX0 + c * BW, y0 = BY0 + r * BH;
                int col = v <= 6 ? ROW_COLORS[v - 1] : v == 9 ? 0xFFD8B030 : 0xFFC8C8D8;
                fillF(g, x0 + 0.5f, y0 + 0.5f, x0 + BW - 0.5f, y0 + BH - 0.5f, shade(col, 0.6f));
                fillF(g, x0 + 0.5f, y0 + 0.5f, x0 + BW - 1.5f, y0 + BH - 1.5f, col);
                fillF(g, x0 + 1.5f, y0 + 1.5f, x0 + BW - 2.5f, y0 + 2.5f, 0x70FFFFFF);
                if (v == 8) { // cracked silver
                    fillF(g, x0 + 6, y0 + 2, x0 + 7, y0 + 6, 0xFF606070);
                    fillF(g, x0 + 7, y0 + 4, x0 + 11, y0 + 5, 0xFF606070);
                }
                if (v == 9 && ((int) (t * 2 + c) % 6) == 0) fillF(g, x0 + 2, y0 + 1, x0 + 5, y0 + BH - 1, 0x90FFFFFF); // gold glint
            }
        }
    }

    // ================================================================== menu preview

    public static void drawPreview(GuiGraphics g, int x, int y, int w, int h, double t) {
        float s = Math.min(h / FH, w / FW);
        g.pose().pushPose();
        g.pose().translate(x + w / 2f - FW * s / 2, y + h / 2f - FH * s / 2, 0);
        g.pose().scale(s, s, 1);
        int[][] demo = new int[ROWS_MAX][COLS];
        String[] layout = LEVELS[0];
        long gone = (long) (t * 3);
        Random r = new Random(11);
        for (int row = 0; row < layout.length; row++) {
            for (int c = 0; c < COLS; c++) {
                char ch = layout[row].charAt(c);
                demo[row][c] = ch >= '1' && ch <= '6' ? ch - '0' : 0;
                if (r.nextInt(60) < gone % 60) demo[row][c] = 0;
            }
        }
        drawBricks(g, demo, t);
        // Ball bouncing in a zig-zag above a paddle that follows it.
        double bx = 20 + Math.abs(((t * 90) % 400) - 200), by = 120 + Math.abs(((t * 130) % 280) - 140);
        float px = (float) Math.max(20, Math.min(220, bx));
        fillF(g, px - 18, PADDLE_Y, px + 18, PADDLE_Y + 5, 0xFFB8C0D8);
        MazeMuncherScreen.disc(g, (float) bx, (float) by, BALL_R, 0xFFFFFFFF);
        g.pose().popPose();
    }
}
