package com.sportsmc.client.arcade;

import com.sportsmc.arcade.ArcadeGame;
import com.sportsmc.client.screen.SportsMenuScreen;
import com.sportsmc.network.ArcadeBoardPacket;
import com.sportsmc.network.ArcadeScorePacket;
import com.sportsmc.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * The Arcade cabinet (M -> Arcade). ◀ / ▶ (or the arrow keys) switch between games; each shows a live preview,
 * its controls, the server's top-10 board and your personal best. Play (or Enter) starts it.
 */
public class ArcadeScreen extends Screen {

    private static final int GOLD = 0xFFFFC83D, DIM = 0xFF9A9AB0, TEXT = 0xFFFFFFFF, NEON = 0xFFFF3EA5, CYAN = 0xFF2DE2E6;
    private ArcadeGame selected;

    public ArcadeScreen() {
        this(ArcadeGame.BLOCK_STACK);
    }

    public ArcadeScreen(ArcadeGame selected) {
        super(Component.literal("Arcade"));
        this.selected = selected;
    }

    public static void open() {
        Minecraft.getInstance().setScreen(new ArcadeScreen());
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private int cabW() { return Math.min(width - 20, 420); }
    private int cabL() { return width / 2 - cabW() / 2; }
    private int cabT() { return 26; }
    private int cabB() { return height - 34; }

    @Override
    protected void init() {
        ModNetwork.sendToServer(ArcadeScorePacket.request());
        int l = cabL(), w = cabW();
        addRenderableWidget(Button.builder(Component.literal("◀"), b -> cycle(-1)).bounds(l + 6, cabT() + 6, 20, 20).build());
        addRenderableWidget(Button.builder(Component.literal("▶"), b -> cycle(1)).bounds(l + w - 26, cabT() + 6, 20, 20).build());
        addRenderableWidget(Button.builder(Component.literal("▶ PLAY"), b -> play()).bounds(width / 2 - 50, cabB() - 26, 100, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> Minecraft.getInstance().setScreen(new SportsMenuScreen()))
                .bounds(width / 2 - 40, height - 26, 80, 20).build());
    }

    private void cycle(int step) {
        ArcadeGame[] all = ArcadeGame.values();
        selected = all[Math.floorMod(selected.ordinal() + step, all.length)];
    }

    private void play() {
        Minecraft.getInstance().setScreen(switch (selected) {
            case BLOCK_STACK -> new BlockStackScreen();
            case STAR_SWARM -> new StarSwarmScreen();
            case MAZE_MUNCHER -> new MazeMuncherScreen();
            case NEON_SNAKE -> new NeonSnakeScreen();
            case BRICK_BLITZ -> new BrickBlitzScreen();
            case ROCK_BLASTER -> new RockBlasterScreen();
            case BUBBLE_BURST -> new BubbleBurstScreen();
            case SMOOTHIE_SWIRL -> new SmoothieSwirlScreen();
            case ATOM_LAB -> new AtomLabScreen();
            case SPACE_PINBALL -> new SpacePinballScreen();
        });
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_A) { cycle(-1); return true; }
        if (key == GLFW.GLFW_KEY_RIGHT || key == GLFW.GLFW_KEY_D) { cycle(1); return true; }
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_SPACE) { play(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(new SportsMenuScreen());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        renderBackground(g);
        double t = System.currentTimeMillis() / 1000.0;
        int l = cabL(), w = cabW(), top = cabT(), bottom = cabB();

        // Title marquee.
        float glow = 0.6f + 0.4f * (float) Math.sin(t * 3);
        g.pose().pushPose();
        g.pose().translate(width / 2f, 8, 0);
        g.pose().scale(1.6f, 1.6f, 1);
        g.drawCenteredString(font, "★ ARCADE ★", 0, 0, blend(NEON, CYAN, glow));
        g.pose().popPose();

        // Cabinet body.
        g.fill(l - 3, top - 3, l + w + 3, bottom + 3, 0xFF2A1240);
        g.fillGradient(l, top, l + w, bottom, 0xFF140A24, 0xFF0A0614);
        g.fill(l, top, l + w, top + 1, NEON);
        g.fill(l, bottom - 1, l + w, bottom, CYAN);

        g.drawCenteredString(font, selected.title.toUpperCase(), width / 2, top + 12, GOLD);
        g.drawCenteredString(font, (selected.ordinal() + 1) + " / " + ArcadeGame.values().length, width / 2, top + 22, DIM);

        // Preview screen (left) and board (right).
        int screenW = (w - 30) / 2, screenH = bottom - top - 76;
        int sx = l + 10, sy = top + 36;
        g.fill(sx - 2, sy - 2, sx + screenW + 2, sy + screenH + 2, 0xFF3A3A4A);
        g.fill(sx, sy, sx + screenW, sy + screenH, 0xFF000000);
        g.enableScissor(sx, sy, sx + screenW, sy + screenH);
        g.drawManaged(() -> {
            switch (selected) {
                case BLOCK_STACK -> BlockStackScreen.drawPreview(g, sx, sy, screenW, screenH, t);
                case STAR_SWARM -> StarSwarmScreen.drawPreview(g, sx, sy, screenW, screenH, t);
                case MAZE_MUNCHER -> MazeMuncherScreen.drawPreview(g, sx, sy, screenW, screenH, t);
                case NEON_SNAKE -> NeonSnakeScreen.drawPreview(g, sx, sy, screenW, screenH, t);
                case BRICK_BLITZ -> BrickBlitzScreen.drawPreview(g, sx, sy, screenW, screenH, t);
                case ROCK_BLASTER -> RockBlasterScreen.drawPreview(g, sx, sy, screenW, screenH, t);
                case BUBBLE_BURST -> BubbleBurstScreen.drawPreview(g, sx, sy, screenW, screenH, t);
                case SMOOTHIE_SWIRL -> SmoothieSwirlScreen.drawPreview(g, sx, sy, screenW, screenH, t);
                case ATOM_LAB -> AtomLabScreen.drawPreview(g, sx, sy, screenW, screenH, t);
                case SPACE_PINBALL -> SpacePinballScreen.drawPreview(g, sx, sy, screenW, screenH, t);
            }
        });
        g.disableScissor();
        // Scanlines over the preview, for that CRT look.
        g.drawManaged(() -> { for (int y = sy; y < sy + screenH; y += 2) g.fill(sx, y, sx + screenW, y + 1, 0x22000000); });

        int bx = sx + screenW + 10, by = sy;
        g.drawString(font, font.plainSubstrByWidth(selected.blurb, screenW), bx, by, TEXT);
        String[] controls = selected.controls;
        for (int i = 0; i < controls.length; i++) g.drawString(font, controls[i], bx, by + 12 + i * 10, DIM);

        int ty = by + 14 + controls.length * 10 + 6;
        g.drawString(font, "TOP 10 (this server)", bx, ty, CYAN);
        List<ArcadeBoardPacket.Row> board = ClientArcadeData.board(selected);
        String me = Minecraft.getInstance().getUser().getName();
        if (board.isEmpty()) g.drawString(font, "No scores yet - be the first!", bx, ty + 12, DIM);
        for (int i = 0; i < board.size() && ty + 12 + i * 10 < bottom - 56; i++) {
            ArcadeBoardPacket.Row r = board.get(i);
            int color = r.name().equals(me) ? GOLD : i == 0 ? 0xFFFFE680 : TEXT;
            g.drawString(font, (i + 1) + ".", bx, ty + 12 + i * 10, DIM);
            g.drawString(font, font.plainSubstrByWidth(r.name(), screenW - 70), bx + 16, ty + 12 + i * 10, color);
            String sc = String.format("%,d", r.score());
            g.drawString(font, sc, bx + screenW - font.width(sc), ty + 12 + i * 10, color);
        }
        int pb = ClientArcadeData.personalBest(selected);
        g.drawString(font, "Your best: " + (pb > 0 ? String.format("%,d", pb) : "-"), bx, bottom - 54, GOLD); // clear of the hint line below

        g.drawCenteredString(font, "◀ ▶ switch game   ENTER play", width / 2, bottom - 38, DIM);
        super.render(g, mx, my, partialTick);
    }

    private static int blend(int a, int b, float k) {
        int r = (int) ((a >> 16 & 255) * k + (b >> 16 & 255) * (1 - k));
        int gr = (int) ((a >> 8 & 255) * k + (b >> 8 & 255) * (1 - k));
        int bl = (int) ((a & 255) * k + (b & 255) * (1 - k));
        return 0xFF000000 | r << 16 | gr << 8 | bl;
    }
}
