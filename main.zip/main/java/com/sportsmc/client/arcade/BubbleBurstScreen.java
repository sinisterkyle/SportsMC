package com.sportsmc.client.arcade;

import com.sportsmc.arcade.ArcadeGame;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Bubble Burst: aim the launcher (mouse, or ← →) and fire (click or SPACE). A bubble that lands touching two
 * or more of its own color pops the whole group; anything left hanging falls for bonus points. Bounce shots off
 * the side walls. Miss too many times in a row and the ceiling pushes the whole cluster down a row; if a bubble
 * crosses the line at the bottom, it's game over. Clear the board to go up a level. Right-click (or X) swaps
 * your bubble with the next one. Field is 240 x 300 units, bubbles sit on a hex grid.
 */
public class BubbleBurstScreen extends ArcadeGameScreen {

    static final float FW = 240, FH = 300, R = 10, ROWH = 17.32f, TOPY = 18, LAUNCH_X = 120, LAUNCH_Y = 282, LOSE_Y = 250;
    static final int COLS = 12, ROWS = 15;
    static final int[] COLORS = {0xFFFF4D5E, 0xFFFFA23C, 0xFFFFE04A, 0xFF4CD964, 0xFF3C9BFF, 0xFFB06BFF, 0xFFFF7AD9};
    private static final float SHOT_SPEED = 430;

    private static final class Shot { float x, y, vx, vy; int color; }
    private static final class Fx { float x, y, vx, vy, age; int color; }

    final int[][] grid = new int[ROWS][COLS];
    boolean topShort;
    private final Random random = new Random();
    private int level, colorsInPlay, dropEvery, misses;
    private float aim = 90; // degrees, 90 = straight up
    private Shot flying;
    private int current, next;
    private final List<Fx> popping = new ArrayList<>(), falling = new ArrayList<>();
    private double shakeUntil, levelStart, clearedAt = -1;
    private float lastScale = 1, lastOx, lastOy;
    private boolean mouseAim;

    public BubbleBurstScreen() {
        super(ArcadeGame.BUBBLE_BURST);
    }

    // ================================================================== grid helpers

    boolean isShort(int r) { return topShort ^ (r % 2 == 1); }
    int cols(int r) { return isShort(r) ? COLS - 1 : COLS; }
    static float cellY(int r) { return TOPY + R + r * ROWH; }
    float cellX(int r, int c) { return R + c * 2 * R + (isShort(r) ? R : 0); }

    List<int[]> neighbors(int r, int c) {
        List<int[]> out = new ArrayList<>(6);
        out.add(new int[]{r, c - 1});
        out.add(new int[]{r, c + 1});
        for (int dr = -1; dr <= 1; dr += 2) {
            int rr = r + dr;
            if (isShort(r)) { out.add(new int[]{rr, c}); out.add(new int[]{rr, c + 1}); }
            else { out.add(new int[]{rr, c - 1}); out.add(new int[]{rr, c}); }
        }
        out.removeIf(n -> n[0] < 0 || n[0] >= ROWS || n[1] < 0 || n[1] >= cols(n[0]));
        return out;
    }

    // ================================================================== setup

    @Override
    protected void reset() {
        level = 0;
        nextLevel();
    }

    private void nextLevel() {
        level++;
        colorsInPlay = Math.min(COLORS.length, 4 + level / 2);
        dropEvery = Math.max(3, 7 - level / 2);
        misses = 0;
        topShort = false;
        for (int[] row : grid) java.util.Arrays.fill(row, -1);
        int rows = Math.min(9, 4 + level);
        for (int r = 0; r < rows; r++) fillRow(r);
        flying = null;
        current = pickColor();
        next = pickColor();
        levelStart = time;
        clearedAt = -1;
    }

    /** Random colors, but often repeating the neighbor so groups form. */
    private void fillRow(int r) {
        for (int c = 0; c < COLS; c++) {
            if (c >= cols(r)) { grid[r][c] = -1; continue; }
            if (c > 0 && random.nextFloat() < 0.35f) grid[r][c] = grid[r][c - 1];
            else if (r > 0 && random.nextFloat() < 0.25f && grid[r - 1][Math.min(c, cols(r - 1) - 1)] >= 0) grid[r][c] = grid[r - 1][Math.min(c, cols(r - 1) - 1)];
            else grid[r][c] = random.nextInt(colorsInPlay);
        }
    }

    /** A color that's still on the board (so you're never handed a useless bubble). */
    private int pickColor() {
        Set<Integer> present = new HashSet<>();
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < cols(r); c++) if (grid[r][c] >= 0) present.add(grid[r][c]);
        if (present.isEmpty()) return random.nextInt(colorsInPlay);
        List<Integer> list = new ArrayList<>(present);
        return list.get(random.nextInt(list.size()));
    }

    // ================================================================== input

    @Override
    public void mouseMoved(double mx, double my) {
        float fx = (float) ((mx - lastOx) / lastScale), fy = (float) ((my - lastOy) / lastScale);
        if (fy < LAUNCH_Y - 4) {
            aim = clampAim((float) Math.toDegrees(Math.atan2(LAUNCH_Y - fy, fx - LAUNCH_X)));
            mouseAim = true;
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (!playing()) return false;
        if (button == 1) swap(); else fire();
        return true;
    }

    @Override
    protected void onPress(int key) {
        if (key == GLFW.GLFW_KEY_SPACE || key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_W) fire();
        if (key == GLFW.GLFW_KEY_X || key == GLFW.GLFW_KEY_C) swap();
    }

    private static float clampAim(float a) {
        return Math.max(12, Math.min(168, a));
    }

    private void swap() {
        if (flying != null) return;
        int t = current;
        current = next;
        next = t;
        sound(SoundEvents.BOOK_PAGE_TURN, 1.6f, 0.4f);
    }

    private void fire() {
        if (flying != null || clearedAt >= 0) return;
        Shot s = new Shot();
        s.x = LAUNCH_X;
        s.y = LAUNCH_Y;
        double a = Math.toRadians(aim);
        s.vx = (float) Math.cos(a) * SHOT_SPEED;
        s.vy = (float) -Math.sin(a) * SHOT_SPEED;
        s.color = current;
        flying = s;
        current = next;
        next = pickColor();
        sound(SoundEvents.NOTE_BLOCK_HAT.value(), 1.5f, 0.35f);
    }

    // ================================================================== update

    @Override
    protected void update() {
        float dt = (float) STEP;
        boolean left = isHeld(GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_A), right = isHeld(GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_D);
        if (left != right) { aim = clampAim(aim + (left ? 100 : -100) * dt); mouseAim = false; }

        for (Iterator<Fx> it = popping.iterator(); it.hasNext(); ) { Fx f = it.next(); f.age += dt; if (f.age > 0.3f) it.remove(); }
        for (Iterator<Fx> it = falling.iterator(); it.hasNext(); ) {
            Fx f = it.next();
            f.vy += 700 * dt;
            f.x += f.vx * dt;
            f.y += f.vy * dt;
            if (f.y > FH + 20) it.remove();
        }
        if (clearedAt >= 0) {
            if (time - clearedAt > 2.0) nextLevel();
            return;
        }
        if (flying != null) moveShot(flying, dt);
    }

    private void moveShot(Shot s, float dt) {
        int steps = 4;
        for (int i = 0; i < steps; i++) {
            s.x += s.vx * dt / steps;
            s.y += s.vy * dt / steps;
            if (s.x < R) { s.x = R; s.vx = Math.abs(s.vx); sound(SoundEvents.NOTE_BLOCK_HAT.value(), 0.9f, 0.15f); }
            if (s.x > FW - R) { s.x = FW - R; s.vx = -Math.abs(s.vx); sound(SoundEvents.NOTE_BLOCK_HAT.value(), 0.9f, 0.15f); }
            if (s.y <= TOPY + R || touchesBubble(s.x, s.y)) {
                land(s);
                return;
            }
        }
    }

    private boolean touchesBubble(float x, float y) {
        int r0 = Math.max(0, (int) ((y - TOPY - R) / ROWH) - 1), r1 = Math.min(ROWS - 1, r0 + 3);
        for (int r = r0; r <= r1; r++) {
            for (int c = 0; c < cols(r); c++) {
                if (grid[r][c] < 0) continue;
                float dx = cellX(r, c) - x, dy = cellY(r) - y;
                if (dx * dx + dy * dy < (2 * R - 3) * (2 * R - 3)) return true;
            }
        }
        return false;
    }

    /** Snap the shot to the nearest empty cell that's attached to the ceiling or another bubble. */
    int[] snapCell(float x, float y) {
        int[] best = null;
        float bestD = Float.MAX_VALUE;
        for (int r = 0; r < ROWS; r++) {
            if (Math.abs(cellY(r) - y) > 2.2f * ROWH) continue;
            for (int c = 0; c < cols(r); c++) {
                if (grid[r][c] >= 0) continue;
                boolean attached = r == 0;
                if (!attached) for (int[] n : neighbors(r, c)) if (grid[n[0]][n[1]] >= 0) { attached = true; break; }
                if (!attached) continue;
                float dx = cellX(r, c) - x, dy = cellY(r) - y, d = dx * dx + dy * dy;
                if (d < bestD) { bestD = d; best = new int[]{r, c}; }
            }
        }
        return best;
    }

    private void land(Shot s) {
        flying = null;
        int[] cell = snapCell(s.x, s.y);
        if (cell == null) { gameOver(); return; }
        int r = cell[0], c = cell[1];
        grid[r][c] = s.color;
        List<int[]> group = sameColorGroup(r, c);
        if (group.size() >= 3) {
            for (int[] g : group) { pop(g[0], g[1]); grid[g[0]][g[1]] = -1; }
            score += group.size() * 10;
            int dropped = dropFloating();
            if (dropped > 0) score += dropped * 20 * (dropped >= 5 ? 2 : 1);
            misses = 0;
            sound(SoundEvents.NOTE_BLOCK_PLING.value(), 1.0f + Math.min(0.8f, group.size() * 0.05f), 0.5f);
            if (dropped > 0) sound(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.2f, 0.5f);
        } else {
            sound(SoundEvents.NOTE_BLOCK_BASEDRUM.value(), 1.2f, 0.4f);
            if (++misses >= dropEvery) { pushRow(); misses = 0; }
        }
        if (boardEmpty()) {
            clearedAt = time;
            score += 1000 * level;
            sound(SoundEvents.PLAYER_LEVELUP, 1.3f, 0.6f);
            return;
        }
        if (crossedLine()) {
            sound(SoundEvents.NOTE_BLOCK_BASS.value(), 0.6f, 0.8f);
            gameOver();
        }
    }

    List<int[]> sameColorGroup(int r, int c) {
        int color = grid[r][c];
        List<int[]> out = new ArrayList<>();
        boolean[][] seen = new boolean[ROWS][COLS];
        Deque<int[]> q = new ArrayDeque<>();
        q.add(new int[]{r, c});
        seen[r][c] = true;
        while (!q.isEmpty()) {
            int[] p = q.poll();
            out.add(p);
            for (int[] n : neighbors(p[0], p[1])) {
                if (!seen[n[0]][n[1]] && grid[n[0]][n[1]] == color) { seen[n[0]][n[1]] = true; q.add(n); }
            }
        }
        return out;
    }

    /** Bubbles no longer connected to the ceiling fall off. Returns how many. */
    int dropFloating() {
        boolean[][] held = new boolean[ROWS][COLS];
        Deque<int[]> q = new ArrayDeque<>();
        for (int c = 0; c < cols(0); c++) if (grid[0][c] >= 0) { held[0][c] = true; q.add(new int[]{0, c}); }
        while (!q.isEmpty()) {
            int[] p = q.poll();
            for (int[] n : neighbors(p[0], p[1])) {
                if (!held[n[0]][n[1]] && grid[n[0]][n[1]] >= 0) { held[n[0]][n[1]] = true; q.add(n); }
            }
        }
        int n = 0;
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < cols(r); c++) {
                if (grid[r][c] >= 0 && !held[r][c]) {
                    Fx f = new Fx();
                    f.x = cellX(r, c);
                    f.y = cellY(r);
                    f.vx = (random.nextFloat() - 0.5f) * 60;
                    f.vy = -40 - random.nextFloat() * 60;
                    f.color = grid[r][c];
                    falling.add(f);
                    grid[r][c] = -1;
                    n++;
                }
            }
        }
        return n;
    }

    /** The ceiling pushes everything down a row and a new row appears at the top. */
    void pushRow() {
        for (int r = ROWS - 1; r > 0; r--) grid[r] = grid[r - 1].clone();
        grid[0] = new int[COLS];
        topShort = !topShort;
        fillRow(0);
        // Rows changed length with the shift: clear the unused last slot of short rows.
        for (int r = 0; r < ROWS; r++) if (isShort(r)) grid[r][COLS - 1] = -1;
        shakeUntil = time + 0.35;
        sound(SoundEvents.PISTON_EXTEND, 0.8f, 0.5f);
    }

    boolean boardEmpty() {
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < cols(r); c++) if (grid[r][c] >= 0) return false;
        return true;
    }

    boolean crossedLine() {
        for (int r = 0; r < ROWS; r++) {
            if (cellY(r) + R <= LOSE_Y) continue;
            for (int c = 0; c < cols(r); c++) if (grid[r][c] >= 0) return true;
        }
        return false;
    }

    private void pop(int r, int c) {
        Fx f = new Fx();
        f.x = cellX(r, c);
        f.y = cellY(r);
        f.color = grid[r][c];
        popping.add(f);
    }

    // ================================================================== drawing

    @Override
    protected void draw(GuiGraphics g) {
        float s = Math.min((height - 24) / FH, (width - 20) / FW);
        float ox = width / 2f - FW * s / 2, oy = (height - FH * s) / 2f - 4;
        if (time < shakeUntil) oy += (float) Math.sin(time * 80) * 2;
        lastScale = s;
        lastOx = ox;
        lastOy = oy;
        g.fill((int) ox - 3, (int) oy - 3, (int) (ox + FW * s) + 3, (int) (oy + FH * s) + 3, 0xFF6A4BA8);
        g.fillGradient((int) ox, (int) oy, (int) (ox + FW * s), (int) (oy + FH * s), 0xFF1B1440, 0xFF0B1E3A);
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(s, s, 1);

        // Ceiling and the danger line.
        fillF(g, 0, TOPY - 3, FW, TOPY, 0xFF8A6BD8);
        boolean danger = dangerClose();
        int lineColor = danger && ((int) (time * 6)) % 2 == 0 ? 0xFFFF4D5E : 0x60FFFFFF;
        for (float x = 0; x < FW; x += 8) fillF(g, x, LOSE_Y, x + 4, LOSE_Y + 1, lineColor);

        for (int r = 0; r < ROWS; r++) for (int c = 0; c < cols(r); c++) {
            if (grid[r][c] >= 0) ball(g, cellX(r, c), cellY(r), R, COLORS[grid[r][c]], 255);
        }
        for (Fx f : popping) {
            float k = f.age / 0.3f;
            ball(g, f.x, f.y, R * (1 + k * 0.6f), COLORS[f.color], (int) (255 * (1 - k)));
        }
        for (Fx f : falling) ball(g, f.x, f.y, R, COLORS[f.color], 230);

        // Aim guide (one bounce), launcher, current and next bubble.
        if (flying == null && clearedAt < 0 && !over) drawGuide(g);
        if (flying != null) ball(g, flying.x, flying.y, R, COLORS[flying.color], 255);
        drawLauncher(g, aim);
        if (flying == null) ball(g, LAUNCH_X, LAUNCH_Y, R, COLORS[current], 255);
        ball(g, LAUNCH_X + 40, LAUNCH_Y + 6, R * 0.75f, COLORS[next], 255);
        // Shots left before the ceiling drops.
        for (int i = 0; i < dropEvery; i++) {
            int col = i < dropEvery - misses ? 0xFFFFE04A : 0x40FFFFFF;
            MazeMuncherScreen.disc(g, 12 + i * 8, LAUNCH_Y + 6, 2.5f, col);
        }
        g.pose().popPose();

        int left = (int) ox, right = (int) (ox + FW * s), top = (int) oy;
        g.drawString(font, "SCORE " + String.format("%,d", score), left + 4, top + 4, TEXT);
        String lv = "LEVEL " + level;
        g.drawString(font, lv, right - font.width(lv) - 4, top + 4, 0xFFFFA23C);
        g.drawString(font, "NEXT", (int) (ox + (LAUNCH_X + 52) * s), (int) (oy + (LAUNCH_Y + 2) * s), DIM);
        if (clearedAt >= 0) g.drawCenteredString(font, "BOARD CLEAR!  +" + 1000 * level, (left + right) / 2, (int) (oy + 150 * s), GOLD);
        else if (time - levelStart < 1.5) g.drawCenteredString(font, "LEVEL " + level, (left + right) / 2, (int) (oy + 200 * s), 0xFF3C9BFF);
        g.drawCenteredString(font, "MOUSE aim + click  (or ← → + SPACE)   RIGHT-CLICK / X swap   P pause   ESC menu",
                width / 2, height - 11, 0xFF6A6A88);
    }

    private boolean dangerClose() {
        for (int r = 0; r < ROWS; r++) {
            if (cellY(r) + R + ROWH <= LOSE_Y) continue;
            for (int c = 0; c < cols(r); c++) if (grid[r][c] >= 0) return true;
        }
        return false;
    }

    private void drawGuide(GuiGraphics g) {
        double a = Math.toRadians(aim);
        float x = LAUNCH_X, y = LAUNCH_Y, vx = (float) Math.cos(a) * 4, vy = (float) -Math.sin(a) * 4;
        int bounces = 0;
        for (int i = 0; i < 140; i++) {
            x += vx;
            y += vy;
            if (x < R || x > FW - R) { vx = -vx; if (++bounces > 1) break; }
            if (y <= TOPY + R || touchesBubble(x, y)) break;
            if (i % 3 == 0) {
                int alpha = 200 - i;
                if (alpha <= 20) break;
                fillF(g, x - 0.8f, y - 0.8f, x + 0.8f, y + 0.8f, withAlpha(0xFFFFFF, alpha));
            }
        }
    }

    static void drawLauncher(GuiGraphics g, float aimDeg) {
        MazeMuncherScreen.disc(g, LAUNCH_X, LAUNCH_Y + 4, 16, 0xFF3A2C6A);
        MazeMuncherScreen.disc(g, LAUNCH_X, LAUNCH_Y + 4, 13, 0xFF5A46A0);
        g.pose().pushPose();
        g.pose().translate(LAUNCH_X, LAUNCH_Y, 0);
        g.pose().mulPose(com.mojang.math.Axis.ZP.rotationDegrees(90 - aimDeg));
        fillF(g, -3, -26, 3, -8, 0xFFB8A8F0);
        fillF(g, -3, -26, -1.5f, -8, 0xFFE8E0FF);
        g.pose().popPose();
    }

    /** A glossy bubble. */
    static void ball(GuiGraphics g, float x, float y, float r, int color, int alpha) {
        if (alpha <= 0) return;
        strips(g, x, y, r, withAlpha(shade(color, 0.6f), alpha));
        strips(g, x, y, r - 1, withAlpha(color, alpha));
        strips(g, x - r * 0.25f, y - r * 0.25f, r * 0.5f, withAlpha(shade(color, 1.35f), alpha * 3 / 4));
        strips(g, x - r * 0.35f, y - r * 0.38f, r * 0.17f, withAlpha(0xFFFFFF, alpha * 9 / 10));
    }

    /** A filled circle drawn as 1-unit strips. */
    static void strips(GuiGraphics g, float cx, float cy, float r, int color) {
        if (r <= 0.3f) return;
        for (float dy = -r; dy < r; dy += 1f) {
            float mid = dy + 0.5f;
            float half = (float) Math.sqrt(Math.max(0, r * r - mid * mid));
            fillF(g, cx - half, cy + dy, cx + half, cy + Math.min(r, dy + 1), color);
        }
    }

    // ================================================================== menu preview

    public static void drawPreview(GuiGraphics g, int x, int y, int w, int h, double t) {
        float s = Math.min(h / FH, w / FW);
        g.pose().pushPose();
        g.pose().translate(x + w / 2f - FW * s / 2, y + h / 2f - FH * s / 2, 0);
        g.pose().scale(s, s, 1);
        fillF(g, 0, 0, FW, FH, 0xFF140F30);
        Random r = new Random(4);
        for (int row = 0; row < 6; row++) {
            boolean shortRow = row % 2 == 1;
            for (int c = 0; c < (shortRow ? COLS - 1 : COLS); c++) {
                int col = r.nextInt(5);
                ball(g, R + c * 2 * R + (shortRow ? R : 0), TOPY + R + row * ROWH, R, COLORS[col], 255);
            }
        }
        float aim = 90 + (float) Math.sin(t * 1.2) * 50;
        double k = (t * 0.9) % 1;
        double a = Math.toRadians(aim);
        float bx = LAUNCH_X + (float) (Math.cos(a) * k * 160), by = LAUNCH_Y - (float) (Math.sin(a) * k * 160);
        ball(g, bx, by, R, COLORS[(int) (t * 0.9) % 5], 255);
        drawLauncher(g, aim);
        g.pose().popPose();
    }
}
