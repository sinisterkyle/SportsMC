package com.sportsmc.client.arcade;

import com.sportsmc.arcade.ArcadeGame;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Space Pinball: a full pinball table in deep space. Everything runs on the player's own screen (no server work at
 * all); only the final score goes to the server for the top-10 board, like every arcade game.
 *
 * Physics: the ball moves in 10 sub-steps per 1/60 s game step (600 Hz) against line walls, round bumpers and posts,
 * and two flippers that are moving capsules (a flipper's surface speed is added to the bounce, so where the ball
 * meets the flipper sets the shot). Ramps are raised plastic tubes: a ball that hits a ramp mouth fast enough rides
 * up and over and drops back into an inlane; too slow and it bounces back off the lip.
 *
 * Missions: knock down the three FORCE FIELD targets ("FORCE FIELDS LOWERED") and hit both LASER targets ("LASERS
 * CHARGED"), then shoot either ramp to ATTACK: a big award and a promotion (Cadet up to Admiral). The wormhole
 * lights HYPERSPACE; three jumps in a row and you make the HYPERSPACE JUMP (and an extra ball, once per game). The
 * three top lanes raise the bonus multiplier (the flippers move the lit lanes). Ramps, the orbit and the wormhole
 * hit in quick succession are COMBOS.
 */
public class SpacePinballScreen extends ArcadeGameScreen {

    // ------------------------------------------------------------------ table layout (units; the table is 200 x 340)
    static final float FW = 320, FH = 340;
    private static final float BALL_R = 4.5f, G = 420f, MAX_V = 900f;
    private static final int SUB = 10;
    private static final float DT = (float) (STEP / SUB);

    /** Walls: {ax, ay, bx, by, bounciness} (generated from the table layout in tools/arcade_art/pinball/spec.py). */
    private static final float[][] WALLS = {
            {4f, 345f, 4f, 104f, 0.45f}, {4f, 104f, 4.23f, 97.3f, 0.45f}, {4.23f, 97.3f, 4.93f, 90.64f, 0.45f},
            {4.93f, 90.64f, 6.1f, 84.04f, 0.45f}, {6.1f, 84.04f, 7.72f, 77.54f, 0.45f}, {7.72f, 77.54f, 9.79f, 71.17f, 0.45f},
            {9.79f, 71.17f, 12.3f, 64.95f, 0.45f}, {12.3f, 64.95f, 15.24f, 58.93f, 0.45f}, {15.24f, 58.93f, 18.59f, 53.13f, 0.45f},
            {18.59f, 53.13f, 22.33f, 47.57f, 0.45f}, {22.33f, 47.57f, 26.46f, 42.29f, 0.45f}, {26.46f, 42.29f, 30.94f, 37.31f, 0.45f},
            {30.94f, 37.31f, 35.76f, 32.66f, 0.45f}, {35.76f, 32.66f, 40.9f, 28.35f, 0.45f}, {40.9f, 28.35f, 46.32f, 24.41f, 0.45f},
            {46.32f, 24.41f, 52f, 20.86f, 0.45f}, {52f, 20.86f, 57.92f, 17.72f, 0.45f}, {57.92f, 17.72f, 64.04f, 14.99f, 0.45f},
            {64.04f, 14.99f, 70.33f, 12.7f, 0.45f}, {70.33f, 12.7f, 76.78f, 10.85f, 0.45f}, {76.78f, 10.85f, 83.33f, 9.46f, 0.45f},
            {83.33f, 9.46f, 89.97f, 8.53f, 0.45f}, {89.97f, 8.53f, 96.65f, 8.06f, 0.45f}, {96.65f, 8.06f, 103.35f, 8.06f, 0.45f},
            {103.35f, 8.06f, 110.03f, 8.53f, 0.45f}, {110.03f, 8.53f, 116.67f, 9.46f, 0.45f}, {116.67f, 9.46f, 123.22f, 10.85f, 0.45f},
            {123.22f, 10.85f, 129.67f, 12.7f, 0.45f}, {129.67f, 12.7f, 135.96f, 14.99f, 0.45f}, {135.96f, 14.99f, 142.08f, 17.72f, 0.45f},
            {142.08f, 17.72f, 148f, 20.86f, 0.45f}, {148f, 20.86f, 153.68f, 24.41f, 0.45f}, {153.68f, 24.41f, 159.1f, 28.35f, 0.45f},
            {159.1f, 28.35f, 164.24f, 32.66f, 0.45f}, {164.24f, 32.66f, 169.06f, 37.31f, 0.45f}, {169.06f, 37.31f, 173.54f, 42.29f, 0.45f},
            {173.54f, 42.29f, 177.67f, 47.57f, 0.45f}, {177.67f, 47.57f, 181.41f, 53.13f, 0.45f}, {181.41f, 53.13f, 184.76f, 58.93f, 0.45f},
            {184.76f, 58.93f, 187.7f, 64.95f, 0.45f}, {187.7f, 64.95f, 190.21f, 71.17f, 0.45f}, {190.21f, 71.17f, 192.28f, 77.54f, 0.45f},
            {192.28f, 77.54f, 193.9f, 84.04f, 0.45f}, {193.9f, 84.04f, 195.07f, 90.64f, 0.45f}, {195.07f, 90.64f, 195.77f, 97.3f, 0.45f},
            {195.77f, 97.3f, 196f, 104f, 0.45f}, {196f, 104f, 196f, 345f, 0.45f}, {180f, 345f, 180f, 112f, 0.45f},
            {16f, 112f, 16f, 206f, 0.45f}, {168f, 112f, 168f, 190f, 0.45f}, {4f, 252f, 54.5f, 290.6f, 0.45f},
            {180f, 252f, 129.5f, 290.6f, 0.45f}, {59.2f, 16.9f, 62.6f, 24f, 0.12f}, {62.6f, 24f, 64f, 32f, 0.12f},
            {64f, 32f, 64f, 46f, 0.45f}, {84f, 30f, 84f, 46f, 0.45f}, {104f, 30f, 104f, 46f, 0.45f},
            {124f, 32f, 124f, 46f, 0.45f}, {180f, 338f, 196f, 338f, 0.45f}, {44f, 268f, 26f, 256f, 0.6f},
            {26f, 256f, 26f, 230f, 0.6f}, {140f, 268f, 158f, 256f, 0.6f}, {158f, 256f, 158f, 230f, 0.6f},
    };
    private static final float[][] RAMP_L_PATH = {{33f, 116f}, {34f, 88f}, {38f, 64f}, {36f, 50f}, {26f, 52f}, {18f, 66f}, {11f, 84f}, {10f, 112f}, {10f, 150f}, {10f, 196f}};
    private static final float[] RAMP_L_MOUTH = {22f, 120f, 44f, 112f};
    private static final float[][] RAMP_R_PATH = {{144f, 120f}, {150f, 92f}, {156f, 66f}, {166f, 52f}, {176f, 58f}, {176f, 90f}, {175f, 140f}, {174f, 190f}, {172f, 226f}};
    private static final float[] RAMP_R_MOUTH = {134f, 116f, 154f, 124f};
    /** Lamp inserts painted on the playfield: {x, y, rgb}. */
    private static final String[] LAMP_NAMES = {"lane0", "lane1", "lane2", "drop0", "drop1", "drop2", "laser0", "laser1", "rampL", "rampR", "orbit", "worm", "hyper0", "hyper1", "hyper2", "rank0", "rank1", "rank2", "rank3", "rank4", "rank5", "mult0", "mult1", "mult2", "mult3", "again"};
    private static final float[][] LAMP_POS = {{74f, 54f}, {94f, 54f}, {114f, 54f}, {31f, 146f}, {31f, 163f}, {31f, 180f}, {153f, 146f}, {153f, 166f}, {44f, 136f}, {140f, 140f}, {172f, 208f}, {60f, 84f}, {92f, 150f}, {92f, 163f}, {92f, 176f}, {62f, 204f}, {74f, 204f}, {86f, 204f}, {98f, 204f}, {110f, 204f}, {122f, 204f}, {68f, 226f}, {84f, 226f}, {100f, 226f}, {116f, 226f}, {92f, 262f}};
    private static final int[] LAMP_RGB = {0x5AC8FF, 0x5AC8FF, 0x5AC8FF, 0x3CE6FF, 0x3CE6FF, 0x3CE6FF, 0xFF4646, 0xFF4646, 0xFFBE28, 0xFFBE28, 0x78FF8C, 0xC86EFF, 0xFF78DC, 0xFF78DC, 0xFF78DC, 0xFFD23C, 0xFFD23C, 0xFFD23C, 0xFFD23C, 0xFFD23C, 0xFFD23C, 0x78FFC8, 0x78FFC8, 0x78FFC8, 0x78FFC8, 0xFF5A3C};
    private static final float[][] SLINGS = {{26, 230, 44, 268}, {140, 268, 158, 230}};
    private static final float[][] BUMPERS = {{72, 92}, {112, 92}, {92, 122}};
    private static final float BUMPER_R = 10;
    /** Mid-table kickers: small, punchy, they throw the ball out sideways toward the targets. */
    private static final float[][] MINIS = {{58, 180}, {126, 180}};
    private static final float MINI_R = 6, MINI_KICK = 250;
    /**
     * Making a ramp: the ball must hit the middle of the mouth (not its ends: RAMP_EDGE of each side doesn't count),
     * heading mostly straight in (RAMP_ALIGN = at least 80% of its speed going into the ramp, about 37 degrees either
     * way) and fast enough (RAMP_MIN). Glancing or slow balls just bounce off the lip and keep their line.
     */
    private static final float RAMP_MIN = 260, RAMP_ALIGN = 0.8f, RAMP_EDGE = 0.12f;
    private static final float[][] DROPS = {{19, 140, 19, 152}, {19, 157, 19, 169}, {19, 174, 19, 186}};
    private static final float[][] LASERS = {{165, 140, 165, 152}, {165, 160, 165, 172}};
    private static final float[] GATE = {180, 112, 195.6f, 95.6f};
    private static final float SAUCER_X = 60, SAUCER_Y = 64;
    private static final float[] LANE_X = {74, 94, 114};
    private static final float LANE_Y = 36;
    private static final float FLIP_LEN = 28, FLIP_R0 = 5.5f, FLIP_R1 = 3f, FLIP_REST = 30, FLIP_UP = -32;
    private static final float PLUNGE_X = 188, PLUNGE_Y = 333;
    private static final String[] RANKS = {"CADET", "ENSIGN", "LIEUTENANT", "CAPTAIN", "COMMANDER", "ADMIRAL"};

    // lamp indices (same order as LAMP_NAMES)
    private static final int L_LANE = 0, L_DROP = 3, L_LASER = 6, L_RAMP_L = 8, L_RAMP_R = 9, L_ORBIT = 10, L_WORM = 11,
            L_HYPER = 12, L_RANK = 15, L_MULT = 21, L_AGAIN = 25;

    // ------------------------------------------------------------------ art
    static final ArcadeArt.Tex TABLE = ArcadeArt.tex("pinball/table", 640, 680);
    static final ArcadeArt.Tex RAMPS = ArcadeArt.tex("pinball/ramps", 400, 680);
    static final ArcadeArt.Tex SPRITES = ArcadeArt.tex("pinball/sprites", 512, 128);
    static final ArcadeArt.Tex FLIPPER = ArcadeArt.tex("pinball/flipper", 168, 56);
    private static final int S_BALL = 0, S_SHADOW = 1, S_CAP = 2, S_CAP_LIT = 3, S_GLOW = 4, S_DROP = 5, S_STANDUP = 6,
            S_SWIRL = 7, S_LENS = 8, S_SPARKLE = 9, S_PLUNGER = 10, S_MINI = 11;
    /** Ball sprite size: the ball is 7.6 of a 16-unit cell. */
    private static final float BALL_SPRITE = 16 * BALL_R / 7.6f;

    // ------------------------------------------------------------------ state
    private float bx, by, vx, vy;
    /** Ball waiting on the plunger (not yet launched). */
    private boolean onPlunger;
    private float charge;
    private boolean charging;
    private final Flipper left = new Flipper(56, 296, true), right = new Flipper(128, 296, false);
    private final boolean[] dropDown = new boolean[3], laserLit = new boolean[2], laneLit = new boolean[3];
    private boolean forceDown, lasersCharged, extraGiven;
    private int rank, hyper, mult, bonus, ball, ballsLeft, combo, skillLane;
    private double saveUntil, lastMajor = -99, launchedAt = -99, saucerUntil = -1, drainAt = -1, stillSince;
    private boolean saucerArmed = true;
    private boolean skillLive, ballSaved;
    /** Ramp ride: which ramp (-1 none), distance along it, speed. */
    private int ride = -1;
    private float rideS, rideV;
    private final double[] bumperFlash = new double[3], slingFlash = new double[2], laserFlash = new double[2], miniFlash = new double[2];
    /** Sounds waiting to play: {time, index into DELAYED_NAMES}. */
    private final List<Object[]> delayed = new ArrayList<>();
    private final ArrayDeque<String> messages = new ArrayDeque<>();
    private String message = "";
    private double messageUntil;
    private final List<Spark> sparks = new ArrayList<>();
    private final Random rnd = new Random();
    private boolean prevLeft, prevRight;
    // contact info from the last collision test
    private float hitNx, hitNy, hitSpeed;

    private static final class Flipper {
        final float px, py;
        final boolean isLeft;
        float angle = FLIP_REST, omega;
        boolean up;

        Flipper(float px, float py, boolean isLeft) {
            this.px = px;
            this.py = py;
            this.isLeft = isLeft;
        }

        /** World angle in degrees (screen y points down, so positive turns clockwise). */
        float worldDeg() {
            return isLeft ? angle : 180 - angle;
        }

        float tipX() { return px + (float) Math.cos(Math.toRadians(worldDeg())) * FLIP_LEN; }
        float tipY() { return py + (float) Math.sin(Math.toRadians(worldDeg())) * FLIP_LEN; }

        void step(float dt) {
            float target = up ? FLIP_UP : FLIP_REST;
            float speed = up ? 1500 : 900; // degrees per second
            float old = angle;
            if (angle > target) angle = Math.max(target, angle - speed * dt);
            else if (angle < target) angle = Math.min(target, angle + speed * dt);
            float w = (float) Math.toRadians(angle - old) / dt;
            omega = isLeft ? w : -w;
        }
    }

    private static final class Spark {
        float x, y, vx, vy, life, age;
        int rgb;
    }

    public SpacePinballScreen() {
        super(ArcadeGame.SPACE_PINBALL);
    }

    // ================================================================== game flow

    @Override
    protected void reset() {
        // A rematch (R) restarts the game clock at 0, so every remembered time from the last game has to go too:
        // a flash time from the old game would otherwise be "in the future" and draw things huge and stuck on.
        java.util.Arrays.fill(bumperFlash, -99);
        java.util.Arrays.fill(slingFlash, -99);
        java.util.Arrays.fill(laserFlash, -99);
        java.util.Arrays.fill(miniFlash, -99);
        lastMajor = -99;
        messageUntil = 0;
        stillSince = 0;
        saucerUntil = -1;
        saucerArmed = true;
        combo = 0;
        prevLeft = prevRight = false;
        rank = 0;
        hyper = 0;
        extraGiven = false;
        forceDown = lasersCharged = false;
        java.util.Arrays.fill(dropDown, false);
        java.util.Arrays.fill(laserLit, false);
        ball = 0;
        ballsLeft = 3;
        messages.clear();
        message = "";
        sparks.clear();
        delayed.clear();
        nextBall();
        say("WELCOME, CADET");
        say("HOLD SPACE, RELEASE TO LAUNCH");
    }

    private void nextBall() {
        ball++;
        ballsLeft--;
        mult = 1;
        bonus = 0;
        combo = 0;
        java.util.Arrays.fill(laneLit, false);
        toPlunger();
        ballSaved = false;
        saveUntil = -1;
        launchedAt = -99;
        skillLane = rnd.nextInt(3);
        skillLive = true;
        drainAt = -1;
    }

    private void toPlunger() {
        bx = PLUNGE_X;
        by = PLUNGE_Y;
        vx = vy = 0;
        onPlunger = true;
        charge = 0;
        charging = false;
        ride = -1;
        saucerUntil = -1;
    }

    private void say(String m) {
        if (messages.size() < 6) messages.add(m);
    }

    /** Score with the rank bonus (+25% per rank). */
    private void award(int pts) {
        score += Math.round(pts * (1 + rank * 0.25f));
    }

    private boolean leftHeld() {
        return isHeld(GLFW.GLFW_KEY_Z, GLFW.GLFW_KEY_LEFT_SHIFT, GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_A) || mouse(GLFW.GLFW_MOUSE_BUTTON_LEFT);
    }

    private boolean rightHeld() {
        return isHeld(GLFW.GLFW_KEY_M, GLFW.GLFW_KEY_SLASH, GLFW.GLFW_KEY_RIGHT_SHIFT, GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_D)
                || mouse(GLFW.GLFW_MOUSE_BUTTON_RIGHT);
    }

    private static boolean mouse(int button) {
        return GLFW.glfwGetMouseButton(Minecraft.getInstance().getWindow().getWindow(), button) == GLFW.GLFW_PRESS;
    }

    @Override
    protected void onPress(int key) {
        if (key == GLFW.GLFW_KEY_SPACE || key == GLFW.GLFW_KEY_DOWN || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_S) {
            if (onPlunger && drainAt < 0) charging = true;
        }
    }

    @Override
    protected void update() {
        for (Iterator<Object[]> it = delayed.iterator(); it.hasNext(); ) {
            Object[] d = it.next();
            if (time >= (double) d[0]) { sfx((String) d[1], 1f, 0.9f); it.remove(); }
        }
        // Messages roll through the display one after another.
        if (time >= messageUntil && !messages.isEmpty()) {
            message = messages.poll();
            messageUntil = time + 1.7;
        }
        // Flippers (and lane change: each new press moves the lit top lanes).
        boolean l = leftHeld(), r = rightHeld();
        if (drainAt >= 0) l = r = false;
        if (l && !prevLeft) { flipperSound(); rotateLanes(-1); }
        if (r && !prevRight) { flipperSound(); rotateLanes(1); }
        prevLeft = l;
        prevRight = r;
        left.up = l;
        right.up = r;

        for (Iterator<Spark> it = sparks.iterator(); it.hasNext(); ) {
            Spark s = it.next();
            s.age += STEP;
            s.x += s.vx * STEP;
            s.y += s.vy * STEP;
            s.vy += 60 * STEP;
            if (s.age >= s.life) it.remove();
        }

        if (drainAt >= 0) {
            for (int i = 0; i < SUB; i++) { left.step(DT); right.step(DT); }
            if (time - drainAt > 2.6) {
                if (ballsLeft <= 0) gameOver();
                else nextBall();
            }
            return;
        }

        if (onPlunger) {
            for (int i = 0; i < SUB; i++) { left.step(DT); right.step(DT); }
            boolean launchHeld = isHeld(GLFW.GLFW_KEY_SPACE, GLFW.GLFW_KEY_DOWN, GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_S);
            if (charging) {
                charge = Math.min(1, charge + (float) STEP / 0.9f);
                if (!launchHeld) launch();
            }
            return;
        }

        if (saucerUntil >= 0) {
            for (int i = 0; i < SUB; i++) { left.step(DT); right.step(DT); }
            bx = SAUCER_X;
            by = SAUCER_Y;
            if (time >= saucerUntil) {
                saucerUntil = -1;
                saucerArmed = false; // re-arms once the ball is well clear
                vx = -35; // down and slightly left: clear of the bumpers, so it can't bounce straight back in
                vy = 210;
                sfx("eject", 1f, 0.7f);
            }
            return;
        }

        if (ride >= 0) {
            for (int i = 0; i < SUB; i++) { left.step(DT); right.step(DT); }
            rideStep();
            return;
        }

        float prevY = by;
        for (int i = 0; i < SUB && ride < 0 && saucerUntil < 0; i++) substep();
        if (ride >= 0 || saucerUntil >= 0) return;

        // Top lanes (rollovers) and the orbit.
        if ((prevY - LANE_Y) * (by - LANE_Y) <= 0 && prevY != by) {
            for (int i = 0; i < 3; i++) if (Math.abs(bx - LANE_X[i]) < 9) lane(i);
        }
        if (bx > 168 && bx < 180 && prevY >= 116 && by < 116 && vy < 0) major("ORBIT", 2000, "orbit");

        // Ball back on the plunger after a weak launch.
        if (bx > 180 && by > 320 && Math.abs(vy) < 20 && Math.abs(vx) < 20) { toPlunger(); return; }

        // Stuck somewhere? A gentle nudge.
        boolean cradled = (left.up || right.up) && by > 260; // holding the ball on a raised flipper is fine
        if (Math.abs(vx) + Math.abs(vy) > 12 || cradled) stillSince = time;
        else if (time - stillSince > 4) {
            vx = (rnd.nextFloat() - 0.5f) * 120;
            vy = -160;
            stillSince = time;
            say("NUDGE!");
            sfx("nudge", 1f, 0.8f);
        }

        if (by > 348) drain();
    }

    private void launch() {
        float power = charge;
        onPlunger = false;
        charging = false;
        vy = -(300 + 560 * power);
        vx = 0;
        if (launchedAt < 0 || saveUntil < 0) saveUntil = time + 12;
        launchedAt = time;
        stillSince = time;
        charge = 0;
        sfx("launch", 0.9f + power * 0.25f, 0.8f);
    }

    private void drain() {
        if (time < saveUntil && !ballSaved) {
            ballSaved = true;
            saveUntil = -1;
            say("BALL SAVED");
            sfx("saved", 1f, 0.8f);
            toPlunger();
            return;
        }
        drainAt = time;
        int total = bonus * mult;
        score += total;
        messages.clear();
        say("BONUS " + String.format("%,d", bonus) + (mult > 1 ? " x" + mult : ""));
        if (ballsLeft <= 0) say("MISSION OVER");
        else say("BALL " + (ball + 1));
        sfx("drain", 1f, 0.8f);
    }

    // ================================================================== scoring events

    private void rotateLanes(int dir) {
        boolean[] n = new boolean[3];
        for (int i = 0; i < 3; i++) n[Math.floorMod(i + dir, 3)] = laneLit[i];
        System.arraycopy(n, 0, laneLit, 0, 3);
    }

    private void lane(int i) {
        if (skillLive && i == skillLane && time - launchedAt < 6) {
            say("SKILL SHOT!");
            award(10000);
            sfx("skill", 1f, 0.8f);
        }
        skillLive = false;
        if (!laneLit[i]) {
            laneLit[i] = true;
            award(500);
            bonus += 200;
            sfx("lane", 1f + i * 0.12f, 0.6f);
            if (laneLit[0] && laneLit[1] && laneLit[2]) {
                java.util.Arrays.fill(laneLit, false);
                if (mult < 5) mult++;
                award(2500);
                say("BONUS " + mult + "X");
                sfx("multiplier", 1f, 0.8f);
            }
        } else award(100);
    }

    private void bumper(int i) {
        bumperFlash[i] = time;
        award(100);
        bonus += 20;
        skillLive = false;
        sfx("bumper", 0.9f + i * 0.1f, 0.7f);
        burst(BUMPERS[i][0], BUMPERS[i][1], 0xD08CFF, 5);
    }

    private void drop(int i) {
        dropDown[i] = true;
        award(750);
        bonus += 100;
        sfx("drop", 1f, 0.8f);
        if (!forceDown && dropDown[0] && dropDown[1] && dropDown[2]) {
            forceDown = true;
            award(5000);
            say("FORCE FIELDS LOWERED");
            say(lasersCharged ? "ATTACK! SHOOT A RAMP" : "NOW CHARGE THE LASERS");
            sfx("force_down", 1f, 0.8f);
        }
    }

    private void laser(int i) {
        laserFlash[i] = time;
        award(laserLit[i] ? 250 : 750);
        bonus += 100;
        laserLit[i] = true;
        sfx("laser", 1f, 0.7f);
        if (!lasersCharged && laserLit[0] && laserLit[1]) {
            lasersCharged = true;
            award(5000);
            say("LASERS CHARGED");
            say(forceDown ? "ATTACK! SHOOT A RAMP" : "NOW LOWER THE FORCE FIELDS");
            sfx("lasers_charged", 1f, 0.8f);
        }
    }

    /** A major shot: ramps, orbit, wormhole. Quick successive shots are combos. */
    private void major(String name, int pts, String shotSound) {
        combo = time - lastMajor < 4 ? combo + 1 : 0;
        lastMajor = time;
        skillLive = false;
        award(pts * (combo + 1));
        bonus += 1000;
        if (combo > 0) {
            say(name + "  COMBO x" + (combo + 1));
            sfx(shotSound, 1f, 0.7f);
            sfx("combo", 1f + Math.min(0.6f, combo * 0.15f), 0.7f);
        } else {
            say(name);
            sfx(shotSound, 1f, 0.7f);
        }
    }

    private void rampMade(int which) {
        major(which == 0 ? "LEFT RAMP" : "RIGHT RAMP", 2500, "ramp");
        if (forceDown && lasersCharged) {
            int award = 25000 * (rank + 1);
            award(award);
            say("ATTACK!");
            say("TARGET DESTROYED +" + String.format("%,d", Math.round(award * (1 + rank * 0.25f))));
            if (rank < RANKS.length - 1) {
                rank++;
                say("PROMOTED TO " + RANKS[rank]);
            } else award(50000);
            forceDown = lasersCharged = false;
            java.util.Arrays.fill(dropDown, false);
            java.util.Arrays.fill(laserLit, false);
            sfx("attack", 1f, 0.9f);
            later("fanfare", 1.1);
        } else if (!forceDown) say("LOWER THE FORCE FIELDS");
        else if (!lasersCharged) say("CHARGE THE LASERS");
    }

    private void wormhole() {
        major("WORMHOLE", 3000, "wormhole");
        hyper++;
        if (hyper >= 3) {
            hyper = 0;
            int pts = 20000 * (rank + 1);
            award(pts);
            say("HYPERSPACE JUMP!");
            if (!extraGiven) {
                extraGiven = true;
                ballsLeft++;
                say("EXTRA BALL");
                later("extra_ball", 1.6);
            }
            sfx("hyperjump", 1f, 0.9f);
        } else {
            say("HYPERSPACE " + hyper + " / 3");
            sfx("wormhole", 1f, 0.8f);
        }
    }

    /**
     * Plays one of Space Pinball's own sounds (assets/sportsmc/sounds/pinball/, listed in sounds.json). They're
     * played straight from the resource pack on this client only, so the server needs nothing registered.
     */
    private static void sfx(String name, float pitch, float volume) {
        Minecraft.getInstance().getSoundManager().play(new SimpleSoundInstance(new ResourceLocation("sportsmc", "pinball." + name),
                SoundSource.MASTER, volume, pitch, SoundInstance.createUnseededRandom(), false, 0, SoundInstance.Attenuation.NONE,
                0, 0, 0, true));
    }

    private void later(String name, double delay) {
        delayed.add(new Object[]{time + delay, name});
    }

    private void flipperSound() {
        sfx("flipper", 0.95f + rnd.nextFloat() * 0.1f, 0.6f);
    }

    private void burst(float x, float y, int rgb, int n) {
        for (int i = 0; i < n && sparks.size() < 80; i++) {
            Spark s = new Spark();
            double a = rnd.nextDouble() * Math.PI * 2;
            float sp = 30 + rnd.nextFloat() * 60;
            s.x = x;
            s.y = y;
            s.vx = (float) Math.cos(a) * sp;
            s.vy = (float) Math.sin(a) * sp;
            s.life = 0.35f + rnd.nextFloat() * 0.3f;
            s.rgb = rgb;
            sparks.add(s);
        }
    }

    // ================================================================== physics

    private void substep() {
        left.step(DT);
        right.step(DT);
        vy += G * DT;
        float sp = (float) Math.sqrt(vx * vx + vy * vy);
        if (sp > MAX_V) { vx *= MAX_V / sp; vy *= MAX_V / sp; }
        bx += vx * DT;
        by += vy * DT;

        for (float[] w : WALLS) segment(w[0], w[1], w[2], w[3], w[4], 0, 0);
        // One-way gate at the top of the plunger lane: only stops a ball on its upper-left side.
        {
            float gx = GATE[2] - GATE[0], gy = GATE[3] - GATE[1], gl = (float) Math.sqrt(gx * gx + gy * gy);
            segment(GATE[0], GATE[1], GATE[2], GATE[3], 0.4f, gy / gl, -gx / gl);
        }
        for (int i = 0; i < 3; i++) {
            if (circle(BUMPERS[i][0], BUMPERS[i][1], BUMPER_R, 0.5f)) {
                float vn = vx * hitNx + vy * hitNy;
                vx += (330 - vn) * hitNx;
                vy += (330 - vn) * hitNy;
                bumper(i);
            }
        }
        for (int i = 0; i < 2; i++) {
            if (circle(MINIS[i][0], MINIS[i][1], MINI_R, 0.5f)) {
                float vn = vx * hitNx + vy * hitNy;
                vx += (MINI_KICK - vn) * hitNx;
                vy += (MINI_KICK - vn) * hitNy;
                miniFlash[i] = time;
                award(50);
                bonus += 10;
                sfx("mini", 0.95f + i * 0.1f, 0.6f);
                burst(MINIS[i][0], MINIS[i][1], 0x60F0FF, 3);
            }
        }
        for (int i = 0; i < 2; i++) {
            float[] s = SLINGS[i];
            float dx = s[2] - s[0], dy = s[3] - s[1], len = (float) Math.sqrt(dx * dx + dy * dy);
            float nx = dy / len, ny = -dx / len;
            float mx = (s[0] + s[2]) / 2, my = (s[1] + s[3]) / 2;
            if ((92 - mx) * nx + (200 - my) * ny < 0) { nx = -nx; ny = -ny; }
            if (segment(s[0], s[1], s[2], s[3], 0.6f, nx, ny) && hitSpeed > 40) {
                vx += nx * 260;
                vy += ny * 260;
                slingFlash[i] = time;
                award(10);
                sfx("sling", 1f, 0.7f);
            }
        }
        for (int i = 0; i < 3; i++) {
            if (!dropDown[i] && segment(DROPS[i][0], DROPS[i][1], DROPS[i][2], DROPS[i][3], 0.4f, 1, 0) && hitSpeed > 30) drop(i);
        }
        for (int i = 0; i < 2; i++) {
            if (segment(LASERS[i][0], LASERS[i][1], LASERS[i][2], LASERS[i][3], 0.4f, -1, 0) && hitSpeed > 30) laser(i);
        }
        if (rampMouth(0, RAMP_L_MOUTH) || rampMouth(1, RAMP_R_MOUTH)) return;
        flipper(left);
        flipper(right);
        // The wormhole swallows a slow-enough ball.
        float ddx = bx - SAUCER_X, ddy = by - SAUCER_Y, dd = ddx * ddx + ddy * ddy;
        if (dd > 18 * 18) saucerArmed = true;
        if (saucerArmed && dd < 25 && vx * vx + vy * vy < 450 * 450) {
            saucerUntil = time + 1.1;
            vx = vy = 0;
            wormhole();
        }
    }

    /**
     * Ball against segment a-b. If (fnx, fny) isn't zero the segment only stops a ball on that side of it. Returns
     * true on contact (hitNx/hitNy = push-out normal, hitSpeed = speed into the wall before the bounce).
     */
    private boolean segment(float ax, float ay, float bx2, float by2, float e, float fnx, float fny) {
        float dx = bx2 - ax, dy = by2 - ay, l2 = dx * dx + dy * dy;
        float u = l2 == 0 ? 0 : Math.max(0, Math.min(1, ((bx - ax) * dx + (by - ay) * dy) / l2));
        float qx = ax + dx * u, qy = ay + dy * u;
        float ox = bx - qx, oy = by - qy, d2 = ox * ox + oy * oy;
        if (d2 >= BALL_R * BALL_R || d2 == 0) return false;
        float d = (float) Math.sqrt(d2), nx = ox / d, ny = oy / d;
        if ((fnx != 0 || fny != 0) && nx * fnx + ny * fny <= 0) return false;
        return resolve(qx, qy, nx, ny, BALL_R, e);
    }

    private boolean circle(float cx, float cy, float r, float e) {
        float ox = bx - cx, oy = by - cy, d2 = ox * ox + oy * oy, rr = BALL_R + r;
        if (d2 >= rr * rr || d2 == 0) return false;
        float d = (float) Math.sqrt(d2);
        return resolve(cx, cy, ox / d, oy / d, rr, e);
    }

    private boolean resolve(float qx, float qy, float nx, float ny, float dist, float e) {
        bx = qx + nx * dist;
        by = qy + ny * dist;
        float vn = vx * nx + vy * ny;
        if (vn < 0) {
            vx -= (1 + e) * vn * nx;
            vy -= (1 + e) * vn * ny;
        }
        hitNx = nx;
        hitNy = ny;
        hitSpeed = -vn;
        return true;
    }

    /** A flipper is a moving capsule: the bounce adds its surface speed at the contact point. */
    private void flipper(Flipper f) {
        float ax = f.px, ay = f.py, tx = f.tipX(), ty = f.tipY();
        float dx = tx - ax, dy = ty - ay, l2 = dx * dx + dy * dy;
        float u = Math.max(0, Math.min(1, ((bx - ax) * dx + (by - ay) * dy) / l2));
        float qx = ax + dx * u, qy = ay + dy * u;
        float rr = FLIP_R0 + (FLIP_R1 - FLIP_R0) * u;
        float ox = bx - qx, oy = by - qy, d2 = ox * ox + oy * oy, lim = BALL_R + rr;
        if (d2 >= lim * lim || d2 == 0) return;
        float d = (float) Math.sqrt(d2), nx = ox / d, ny = oy / d;
        bx = qx + nx * lim;
        by = qy + ny * lim;
        float cx = qx + nx * rr - ax, cy = qy + ny * rr - ay;
        float svx = -f.omega * cy, svy = f.omega * cx;
        float rvx = vx - svx, rvy = vy - svy, vn = rvx * nx + rvy * ny;
        if (vn < 0) {
            rvx -= 1.35f * vn * nx;
            rvy -= 1.35f * vn * ny;
            vx = rvx + svx;
            vy = rvy + svy;
        }
    }

    /** A ramp mouth: fast enough into it and the ball rides the ramp; otherwise it bounces off the lip. */
    private boolean rampMouth(int which, float[] m) {
        float dx = m[2] - m[0], dy = m[3] - m[1], len = (float) Math.sqrt(dx * dx + dy * dy);
        float nx = dy / len, ny = -dx / len;
        if (ny < 0) { nx = -nx; ny = -ny; } // the playfield side is below the mouth
        float u = Math.max(0, Math.min(1, ((bx - m[0]) * dx + (by - m[1]) * dy) / (len * len)));
        float qx = m[0] + dx * u, qy = m[1] + dy * u;
        float ox = bx - qx, oy = by - qy;
        if (ox * ox + oy * oy >= BALL_R * BALL_R || ox * nx + oy * ny <= 0) return false;
        float into = -(vx * nx + vy * ny), speed = (float) Math.sqrt(vx * vx + vy * vy);
        if (into > RAMP_MIN && into >= RAMP_ALIGN * speed && u > RAMP_EDGE && u < 1 - RAMP_EDGE) {
            ride = which;
            rideS = 0;
            rideV = Math.min(420, Math.max(220, into * 0.7f));
            sfx("ramp_enter", 1f, 0.6f);
            return true;
        }
        segment(m[0], m[1], m[2], m[3], 0.3f, nx, ny);
        return false;
    }

    private void rideStep() {
        float[][] path = ride == 0 ? RAMP_L_PATH : RAMP_R_PATH;
        rideS += rideV * (float) STEP;
        float[] p = pathPoint(path, rideS);
        if (p == null) {
            float[] end = path[path.length - 1];
            bx = end[0];
            by = end[1];
            vx = ride == 0 ? 0 : -30;
            vy = 140;
            int which = ride;
            ride = -1;
            stillSince = time;
            rampMade(which);
            return;
        }
        bx = p[0];
        by = p[1];
    }

    /** Point at distance s along a path, plus how far along (0..1) in [2]; null past the end. */
    private static float[] pathPoint(float[][] path, float s) {
        float total = 0;
        for (int i = 0; i < path.length - 1; i++) total += dist(path[i], path[i + 1]);
        float acc = 0;
        for (int i = 0; i < path.length - 1; i++) {
            float l = dist(path[i], path[i + 1]);
            if (acc + l >= s) {
                float k = (s - acc) / l;
                return new float[]{path[i][0] + (path[i + 1][0] - path[i][0]) * k, path[i][1] + (path[i + 1][1] - path[i][1]) * k, s / total};
            }
            acc += l;
        }
        return null;
    }

    private static float dist(float[] a, float[] b) {
        return (float) Math.hypot(b[0] - a[0], b[1] - a[1]);
    }

    // ================================================================== drawing

    @Override
    protected void draw(GuiGraphics g) {
        float s = Math.min((height - 24) / FH, (width - 20) / FW);
        float ox = width / 2f - FW * s / 2, oy = (height - FH * s) / 2f - 4;
        g.fill((int) ox - 2, (int) oy - 2, (int) (ox + FW * s) + 2, (int) (oy + FH * s) + 2, 0xFF1A1E38);
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(s, s, 1);
        drawTable(g, time, this);
        g.pose().popPose();
        drawPanel(g, ox, oy, s);
    }

    /** The table and everything on it. game == null draws the idle attract mode for the menu preview. */
    static void drawTable(GuiGraphics g, double t, SpacePinballScreen game) {
        if (game != null) ArcadeArt.whole(g, TABLE, 0, 0, FW, FH);
        else ArcadeArt.topLeft(g, TABLE, 0, 0, 200, FH, 0, 0, 400, 680, 1f); // preview: just the table
        // Lamps.
        for (int i = 0; i < LAMP_NAMES.length; i++) {
            float k = game == null ? attractLamp(i, t) : game.lamp(i, t);
            if (k <= 0.02f) continue;
            float x = LAMP_POS[i][0], y = LAMP_POS[i][1];
            ArcadeArt.cell(g, SPRITES, 64, S_GLOW, x, y, i == L_AGAIN ? 30 : 20, 0, LAMP_RGB[i], 0.55f * k);
            ArcadeArt.cell(g, SPRITES, 64, S_LENS, x, y, i == L_AGAIN ? 13 : 9, 0, LAMP_RGB[i], k);
        }
        // Wormhole swirl.
        ArcadeArt.cell(g, SPRITES, 64, S_SWIRL, SAUCER_X, SAUCER_Y, 16, (float) (-t * 200 % 360), 0xFFFFFF, 0.95f);
        // Drop targets and laser targets.
        for (int i = 0; i < 3; i++) {
            boolean down = game != null && game.dropDown[i];
            if (!down) ArcadeArt.cell(g, SPRITES, 64, S_DROP, DROPS[i][0], (DROPS[i][1] + DROPS[i][3]) / 2, 16, 0, 0xFFFFFF, 1f);
        }
        for (int i = 0; i < 2; i++) {
            float y = (LASERS[i][1] + LASERS[i][3]) / 2;
            ArcadeArt.cell(g, SPRITES, 64, S_STANDUP, LASERS[i][0], y, 16, 0, 0xFFFFFF, 1f);
            double since = game == null ? 9 : age(t, game.laserFlash[i]);
            if (since < 0.3) ArcadeArt.cell(g, SPRITES, 64, S_GLOW, LASERS[i][0], y, 22, 0, 0xFF5050, (float) (1 - since / 0.3));
        }
        // Slingshot flashes.
        for (int i = 0; i < 2; i++) {
            double since = game == null ? 9 : age(t, game.slingFlash[i]);
            if (since < 0.2) {
                float[] sl = SLINGS[i];
                ArcadeArt.cell(g, SPRITES, 64, S_GLOW, (sl[0] + sl[2]) / 2, (sl[1] + sl[3]) / 2, 26, 0, 0x60B0FF, (float) (1 - since / 0.2));
            }
        }
        // Bumper caps (light up when hit).
        for (int i = 0; i < 3; i++) {
            double since = game == null ? ((t * 1.3 + i * 0.37) % 1.5) : age(t, game.bumperFlash[i]);
            float k = since < 0.25 ? (float) (1 - since / 0.25) : 0;
            float cx = BUMPERS[i][0], cy = BUMPERS[i][1];
            if (k > 0) ArcadeArt.cell(g, SPRITES, 64, S_GLOW, cx, cy, 34, 0, 0xD080FF, k * 0.8f);
            ArcadeArt.cell(g, SPRITES, 64, S_CAP, cx, cy, 19, 0, 0xFFFFFF, 1f);
            if (k > 0) ArcadeArt.cell(g, SPRITES, 64, S_CAP_LIT, cx, cy, 19, 0, 0xFFD8FF, k);
        }
        for (int i = 0; i < 2; i++) {
            double since = game == null ? 9 : age(t, game.miniFlash[i]);
            float k = since < 0.2 ? (float) (1 - since / 0.2) : 0;
            if (k > 0) ArcadeArt.cell(g, SPRITES, 64, S_GLOW, MINIS[i][0], MINIS[i][1], 24, 0, 0x60F0FF, k);
            ArcadeArt.cell(g, SPRITES, 64, S_MINI, MINIS[i][0], MINIS[i][1], 11.6f * (1 + 0.12f * k), 0, 0xFFFFFF, 1f);
        }
        // Flippers.
        Flipper fl = game != null ? game.left : null, fr = game != null ? game.right : null;
        float la = fl != null ? fl.worldDeg() : FLIP_REST, ra = fr != null ? fr.worldDeg() : 180 - FLIP_REST;
        ArcadeArt.pivoted(g, FLIPPER, 56, 296, la, 7, 7, 42, 14, 1f);
        ArcadeArt.pivoted(g, FLIPPER, 128, 296, ra, 7, 7, 42, 14, 1f);
        // Plunger.
        float pull = game != null ? game.charge : (float) Math.max(0, Math.sin(t * 1.4)) ;
        if (game != null && game.onPlunger && game.charging) {
            float h = 70 * pull;
            fillF(g, 181.2f, 338 - h, 182.8f, 338, 0xFF000000 | NeonSnakeScreen.hsv(0.33f - pull * 0.33f, 0.9f, 1f));
        }
        ArcadeArt.cell(g, SPRITES, 64, S_PLUNGER, PLUNGE_X, 341 + pull * 5, 16, 0, 0xFFFFFF, 1f);

        // The ball on the playfield (under the ramps).
        float ballX, ballY;
        boolean riding = false;
        float rideK = 0;
        if (game != null) {
            ballX = game.bx;
            ballY = game.by + (game.onPlunger ? game.charge * 5 : 0);
            if (game.ride >= 0) {
                float[] p = pathPoint(game.ride == 0 ? RAMP_L_PATH : RAMP_R_PATH, game.rideS);
                riding = true;
                rideK = p == null ? 0 : (float) Math.sin(Math.PI * p[2]);
            }
        } else {
            // attract mode: the ball bounces round the bumpers
            ballX = 92 + (float) Math.sin(t * 1.7) * 42;
            ballY = 160 + (float) Math.sin(t * 2.3) * 70;
        }
        boolean visible = game == null || game.drainAt < 0;
        if (visible && !riding) {
            float shrink = game != null && game.saucerUntil >= 0 ? 0.75f + 0.2f * (float) Math.sin(t * 20) : 1f;
            ArcadeArt.cell(g, SPRITES, 64, S_SHADOW, ballX + 1.6f, ballY + 2.4f, BALL_SPRITE * 1.15f * shrink, 0, 0xFFFFFF, 0.55f);
            ArcadeArt.cell(g, SPRITES, 64, S_BALL, ballX, ballY, BALL_SPRITE * shrink, 0, 0xFFFFFF, 1f);
        }
        // Ramps (raised plastic) over the playfield ball.
        ArcadeArt.whole(g, RAMPS, 0, 0, 200, FH);
        if (visible && riding) {
            float sc = 1 + 0.3f * rideK, off = 2 + 5 * rideK;
            ArcadeArt.cell(g, SPRITES, 64, S_SHADOW, ballX + off, ballY + off * 1.3f, BALL_SPRITE * 1.2f * sc, 0, 0xFFFFFF, 0.45f);
            ArcadeArt.cell(g, SPRITES, 64, S_BALL, ballX, ballY, BALL_SPRITE * sc, 0, 0xFFFFFF, 1f);
        }
        // Sparks.
        if (game != null) {
            for (Spark sp : game.sparks) {
                float k = 1 - sp.age / sp.life;
                ArcadeArt.cell(g, SPRITES, 64, S_SPARKLE, sp.x, sp.y, 6 * k + 1, (float) (sp.age * 400), sp.rgb, k);
            }
        }
    }

    /** Seconds since a flash started; a time in the future (shouldn't happen) counts as long ago. */
    private static double age(double now, double at) {
        double a = now - at;
        return a < 0 ? 99 : a;
    }

    /** How lit (0..1) lamp i is right now. */
    private float lamp(int i, double t) {
        boolean fast = ((int) (t * 8)) % 2 == 0, slow = ((int) (t * 3)) % 2 == 0;
        if (i < L_DROP) {
            int lane = i - L_LANE;
            if (skillLive && onPlunger && lane == skillLane) return fast ? 1 : 0.2f;
            return laneLit[lane] ? 1 : 0;
        }
        if (i < L_LASER) return dropDown[i - L_DROP] ? 1 : (forceDown ? 0 : (slow ? 0.25f : 0));
        if (i < L_RAMP_L) return laserLit[i - L_LASER] ? 1 : 0;
        if (i == L_RAMP_L || i == L_RAMP_R) {
            if (forceDown && lasersCharged) return fast ? 1 : 0.15f;
            return time - lastMajor < 4 ? (slow ? 0.8f : 0.2f) : 0;
        }
        if (i == L_ORBIT) return time - lastMajor < 4 ? (fast ? 0.9f : 0.1f) : 0;
        if (i == L_WORM) return hyper == 2 ? (fast ? 1 : 0.2f) : 0.35f + 0.25f * (float) Math.sin(t * 3);
        if (i < L_RANK) return hyper > i - L_HYPER ? 1 : 0;
        if (i < L_MULT) return rank >= i - L_RANK ? 1 : 0;
        if (i < L_AGAIN) return mult >= i - L_MULT + 2 ? 1 : 0;
        // shoot again: blinking while the ball saver runs
        if (saveUntil > time && !ballSaved) return slow ? 1 : 0.3f;
        return 0;
    }

    /** Attract mode for the menu preview: lamps chase. */
    private static float attractLamp(int i, double t) {
        float k = (float) Math.sin(t * 4 - i * 0.6);
        return Math.max(0, k);
    }

    private float lastPanelW = 100;

    private void drawPanel(GuiGraphics g, float ox, float oy, float s) {
        lastPanelW = 100 * s; // text never runs off the console
        float x0 = ox + 210 * s, cx = ox + 260 * s;
        float ts = Math.max(0.6f, Math.min(1f, s * 0.95f));
        // Display: score, ball, rank, the current message.
        label(g, "SCORE", x0, oy + 12 * s, 0xFF5FD0FF, ts * 0.8f, false);
        label(g, String.format("%,d", score), cx, oy + 22 * s, TEXT, ts * 1.5f, true);
        label(g, "BALL " + ball + (ballsLeft > 0 ? "   (+" + ballsLeft + ")" : "   LAST"), x0, oy + 42 * s, 0xFFB0C8E8, ts * 0.8f, false);
        label(g, "RANK  " + RANKS[rank], x0, oy + 52 * s, 0xFFFFD23C, ts * 0.8f, false);
        boolean blink = ((int) (time * 6)) % 2 == 0;
        if (time < messageUntil && !message.isEmpty()) {
            label(g, message, cx, oy + 78 * s, blink || messageUntil - time < 1.2 ? 0xFFFFE070 : 0xFFFF9A40, ts * 1.0f, true);
        } else if (onPlunger && drainAt < 0) {
            label(g, "HOLD SPACE TO LAUNCH", cx, oy + 78 * s, blink ? 0xFF5FD0FF : 0xFF2F80A0, ts * 0.85f, true);
        } else {
            label(g, nextGoal(), cx, oy + 78 * s, 0xFF7FA8C8, ts * 0.75f, true);
        }
        if (onPlunger && charging) {
            float w = 96 * charge;
            g.pose().pushPose();
            g.pose().translate(ox, oy, 0);
            g.pose().scale(s, s, 1);
            fillF(g, 212, 100, 212 + w, 106, 0xFF000000 | NeonSnakeScreen.hsv(0.33f - charge * 0.33f, 0.9f, 1f));
            g.pose().popPose();
        }

        // Mission status.
        float y = oy + 143 * s, step = 14 * s, sm = ts * 0.75f;
        row(g, "FORCE FIELDS", forceDown ? "LOWERED" : count(dropDown) + " / 3", forceDown, x0, y, sm, ox, s);
        row(g, "LASERS", lasersCharged ? "CHARGED" : count(laserLit) + " / 2", lasersCharged, x0, y + step, sm, ox, s);
        row(g, "ATTACK", forceDown && lasersCharged ? "SHOOT A RAMP!" : "not ready", forceDown && lasersCharged, x0, y + step * 2, sm, ox, s);
        row(g, "HYPERSPACE", hyper + " / 3", hyper == 2, x0, y + step * 3, sm, ox, s);
        row(g, "BONUS", String.format("%,d", bonus) + " x" + mult, mult > 1, x0, y + step * 4, sm, ox, s);
        row(g, "COMBO", time - lastMajor < 4 && combo > 0 ? "x" + (combo + 1) : "-", time - lastMajor < 4 && combo > 0, x0, y + step * 5, sm, ox, s);
        row(g, "BALL SAVE", saveUntil > time && !ballSaved ? (int) Math.ceil(saveUntil - time) + "s" : "off", saveUntil > time && !ballSaved, x0, y + step * 6, sm, ox, s);
        row(g, "EXTRA BALL", extraGiven ? "used" : "3 jumps", false, x0, y + step * 7, sm, ox, s);

        // Controls.
        float cy = oy + 274 * s, cs = ts * 0.68f;
        label(g, "LEFT FLIPPER   L-CLICK / Z", x0, cy, 0xFF9AA8C8, cs, false);
        label(g, "RIGHT FLIPPER  R-CLICK / M", x0, cy + 11 * s, 0xFF9AA8C8, cs, false);
        label(g, "LAUNCH  hold + let go SPACE", x0, cy + 22 * s, 0xFF9AA8C8, cs, false);
        label(g, "P pause   ESC arcade menu", x0, cy + 33 * s, 0xFF6A7898, cs, false);
        label(g, "Best: " + String.format("%,d", ClientArcadeData.personalBest(game)), x0, cy + 46 * s, GOLD, cs, false);
    }

    private String nextGoal() {
        if (forceDown && lasersCharged) return "SHOOT A RAMP TO ATTACK";
        if (!forceDown) return "HIT THE FORCE FIELD TARGETS";
        return "HIT THE LASER TARGETS";
    }

    private static int count(boolean[] b) {
        int n = 0;
        for (boolean v : b) if (v) n++;
        return n;
    }

    private void row(GuiGraphics g, String name, String value, boolean hot, float x, float y, float sz, float ox, float s) {
        label(g, name, x, y, 0xFF8FA0C0, sz, false);
        int w = (int) (font.width(value) * sz);
        label(g, value, ox + 308 * s - w, y, hot ? 0xFF7CFF9A : 0xFFE0E8FF, sz, false);
    }

    private void label(GuiGraphics g, String text, float x, float y, int color, float size, boolean centered) {
        float maxW = lastPanelW;
        if (font.width(text) * size > maxW) size = maxW / Math.max(1, font.width(text));
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(size, size, 1);
        if (centered) g.drawCenteredString(font, text, 0, 0, color);
        else g.drawString(font, text, 0, 0, color);
        g.pose().popPose();
    }

    // ================================================================== menu preview

    public static void drawPreview(GuiGraphics g, int x, int y, int w, int h, double t) {
        float s = Math.min(h / FH, w / 200f);
        g.pose().pushPose();
        g.pose().translate(x + w / 2f - 200 * s / 2, y + h / 2f - FH * s / 2, 0);
        g.pose().scale(s, s, 1);
        drawTable(g, t, null);
        g.pose().popPose();
    }
}
