package com.sportsmc.client.arcade;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.resources.ResourceLocation;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

/**
 * Painted sprites for the arcade games that use textures (Atom Lab, Smoothie Swirl). The art lives in
 * assets/sportsmc/textures/gui/arcade/. Sprites are drawn with smooth (linear) filtering, at fractional positions
 * and sizes in the game's own units, optionally rotated, tinted and faded.
 *
 * Games draw inside a managed (batched) GuiGraphics pass where fills are queued but blits draw at once, so every
 * sprite flushes the queued fills first: that keeps the layering exactly in the order things are drawn.
 */
final class ArcadeArt {

    /** A texture and its pixel size. */
    record Tex(ResourceLocation id, int w, int h) {}

    private static final Set<AbstractTexture> SMOOTHED = Collections.newSetFromMap(new WeakHashMap<>());

    private ArcadeArt() {}

    static Tex tex(String path, int w, int h) {
        return new Tex(new ResourceLocation("sportsmc", "textures/gui/arcade/" + path + ".png"), w, h);
    }

    /** A whole texture into the rectangle (x, y, w, h). */
    static void whole(GuiGraphics g, Tex t, float x, float y, float w, float h) {
        topLeft(g, t, x, y, w, h, 0, 0, t.w(), t.h(), 1f);
    }

    /** The region (u, v, uw, vh) of a texture into the rectangle (x, y, w, h). */
    static void topLeft(GuiGraphics g, Tex t, float x, float y, float w, float h, int u, int v, int uw, int vh, float alpha) {
        if (alpha <= 0.004f || w <= 0 || h <= 0 || uw <= 0 || vh <= 0) return;
        begin(g, t, 1f, 1f, 1f, alpha);
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(w / uw, h / vh, 1);
        g.blit(t.id(), 0, 0, uw, vh, u, v, uw, vh, t.w(), t.h());
        g.pose().popPose();
        end();
    }

    /** The region (u, v, uw, vh) of a texture, centered on (cx, cy), w x h big, rotated by deg, tinted rgb, faded. */
    static void centered(GuiGraphics g, Tex t, float cx, float cy, float w, float h, float deg,
                         int u, int v, int uw, int vh, int rgb, float alpha) {
        if (alpha <= 0.004f || w <= 0 || h <= 0) return;
        begin(g, t, (rgb >> 16 & 255) / 255f, (rgb >> 8 & 255) / 255f, (rgb & 255) / 255f, Math.min(1f, alpha));
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0);
        if (deg != 0) g.pose().mulPose(Axis.ZP.rotationDegrees(deg));
        g.pose().scale(w / uw, h / vh, 1);
        g.pose().translate(-uw / 2f, -vh / 2f, 0);
        g.blit(t.id(), 0, 0, uw, vh, u, v, uw, vh, t.w(), t.h());
        g.pose().popPose();
        end();
    }

    /**
     * A whole texture w x h big whose point (offX, offY) (in those same units) sits on (px, py), rotated about that
     * point by deg: for things that turn on a pivot, like pinball flippers.
     */
    static void pivoted(GuiGraphics g, Tex t, float px, float py, float deg, float offX, float offY, float w, float h, float alpha) {
        if (alpha <= 0.004f) return;
        begin(g, t, 1f, 1f, 1f, Math.min(1f, alpha));
        g.pose().pushPose();
        g.pose().translate(px, py, 0);
        if (deg != 0) g.pose().mulPose(Axis.ZP.rotationDegrees(deg));
        g.pose().translate(-offX, -offY, 0);
        g.pose().scale(w / t.w(), h / t.h(), 1);
        g.blit(t.id(), 0, 0, t.w(), t.h(), 0, 0, t.w(), t.h(), t.w(), t.h());
        g.pose().popPose();
        end();
    }

    /** Cell i of an atlas made of square cells (left to right, then the next row). */
    static void cell(GuiGraphics g, Tex t, int cellPx, int i, float cx, float cy, float size, float deg, int rgb, float alpha) {
        int cols = t.w() / cellPx;
        centered(g, t, cx, cy, size, size, deg, (i % cols) * cellPx, (i / cols) * cellPx, cellPx, cellPx, rgb, alpha);
    }

    private static void begin(GuiGraphics g, Tex t, float r, float gr, float b, float a) {
        g.flush(); // draw the queued fills first, so layering follows drawing order
        AbstractTexture at = Minecraft.getInstance().getTextureManager().getTexture(t.id());
        if (SMOOTHED.add(at)) at.setFilter(true, false);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(r, gr, b, a);
    }

    private static void end() {
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.disableBlend();
    }
}
