package com.sportsmc.client.arcade;

import com.sportsmc.arcade.ArcadeGame;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Atom Lab: swap neighboring atoms to line up 3 or more of a kind. Special atoms:
 *  - 4 in a row makes a CHARGED atom: when it's matched it zaps its whole row (or column).
 *  - An L or T shape (two lines through one atom) makes an UNSTABLE atom: it explodes, clearing everything around it.
 *  - 5 in a row makes a SUPERCHARGED atom: swap it with any atom to clear every atom of that kind.
 * Fill the beaker (reach the target score) before the timer runs out to finish a level. From level 3, lab slime
 * covers some squares: slimed atoms can't be swapped, and the slime spreads; clear atoms next to it to clean it up.
 *
 * Click an atom then a neighbor (or drag), or use the arrow keys + SPACE. Board 8 x 8, cells 26 units.
 */
public class AtomLabScreen extends ArcadeGameScreen {

    static final int N = 8;
    static final float CELL = 26, BX = 10, BY = 22, FW = 330, FH = 244;
    static final int[] ATOM_COLORS = {0xFFFF4D5E, 0xFFFFA23C, 0xFFFFE04A, 0xFF4CD964, 0xFF3C9BFF, 0xFFB06BFF};
    static final int NONE = 0, LINE_H = 1, LINE_V = 2, BOMB = 3, COLOR = 4;
    private static final double SWAP_TIME = 0.16, CLEAR_TIME = 0.24, LEVEL_TIME = 90;

    private enum Phase { IDLE, SWAP, SWAP_BACK, CLEAR, FALL, LEVEL_CLEAR }

    final int[][] type = new int[N][N];
    final int[][] special = new int[N][N];
    final boolean[][] slime = new boolean[N][N];
    private final float[][] fall = new float[N][N]; // how far above its spot an atom is still drawn (cells)
    private final boolean[][] clearing = new boolean[N][N];
    final Random random = new Random();
    private Phase phase = Phase.IDLE;
    private double phaseStart;
    private int ar = -1, ac = -1, br, bc; // the swap
    private int selR = -1, selC = -1, curR = 3, curC = 3;
    private int pressR = -1, pressC = -1;
    int level, kinds, target, chain;
    private int levelScore;
    private double timeLeft, nextSlimeSpread, lastMoveAt;
    private String popText = "";
    private double popUntil;
    private float lastScale = 1, lastOx, lastOy;

    public AtomLabScreen() {
        super(ArcadeGame.ATOM_LAB);
    }

    // ================================================================== setup

    @Override
    protected void reset() {
        level = 0;
        nextLevel();
    }

    private void nextLevel() {
        level++;
        kinds = level >= 3 ? 6 : 5;
        target = 3500 + (level - 1) * 1500;
        levelScore = 0;
        timeLeft = LEVEL_TIME;
        fillBoard();
        for (boolean[] row : slime) java.util.Arrays.fill(row, false);
        if (level >= 3) {
            int n = Math.min(14, 2 + level);
            for (int i = 0; i < n; i++) slime[2 + random.nextInt(N - 2)][random.nextInt(N)] = true;
        }
        nextSlimeSpread = time + slimeEvery();
        phase = Phase.FALL; // the new board drops in before you can play
        phaseStart = time;
        lastMoveAt = time;
        selR = -1;
        pop("LEVEL " + level + ": fill the beaker!");
    }

    private double slimeEvery() {
        return Math.max(5, 13 - level);
    }

    /** A fresh board with no ready-made matches and at least one move. */
    void fillBoard() {
        do {
            for (int r = 0; r < N; r++) {
                for (int c = 0; c < N; c++) {
                    int t;
                    do { t = random.nextInt(kinds); }
                    while ((c >= 2 && type[r][c - 1] == t && type[r][c - 2] == t) || (r >= 2 && type[r - 1][c] == t && type[r - 2][c] == t));
                    type[r][c] = t;
                    special[r][c] = NONE;
                    fall[r][c] = N; // they all drop in
                }
            }
        } while (!hasMove());
    }

    // ================================================================== matching

    /** All horizontal and vertical runs of 3+ (each as a list of {r, c}). */
    List<List<int[]>> runs() {
        List<List<int[]>> out = new ArrayList<>();
        for (int r = 0; r < N; r++) {
            int c = 0;
            while (c < N) {
                int e = c;
                while (e + 1 < N && type[r][c] >= 0 && type[r][e + 1] == type[r][c] && special[r][e + 1] != COLOR && special[r][c] != COLOR) e++;
                if (e - c >= 2) { List<int[]> run = new ArrayList<>(); for (int k = c; k <= e; k++) run.add(new int[]{r, k, 0}); out.add(run); }
                c = e + 1;
            }
        }
        for (int c = 0; c < N; c++) {
            int r = 0;
            while (r < N) {
                int e = r;
                while (e + 1 < N && type[r][c] >= 0 && type[e + 1][c] == type[r][c] && special[e + 1][c] != COLOR && special[r][c] != COLOR) e++;
                if (e - r >= 2) { List<int[]> run = new ArrayList<>(); for (int k = r; k <= e; k++) run.add(new int[]{k, c, 1}); out.add(run); }
                r = e + 1;
            }
        }
        return out;
    }

    boolean hasMove() {
        for (int r = 0; r < N; r++) {
            for (int c = 0; c < N; c++) {
                if (slime[r][c]) continue;
                if (special[r][c] == COLOR) return true;
                int[][] dirs = {{0, 1}, {1, 0}};
                for (int[] d : dirs) {
                    int r2 = r + d[0], c2 = c + d[1];
                    if (r2 >= N || c2 >= N || slime[r2][c2]) continue;
                    swapCells(r, c, r2, c2);
                    boolean ok = !runs().isEmpty();
                    swapCells(r, c, r2, c2);
                    if (ok) return true;
                }
            }
        }
        return false;
    }

    /** A valid move, for the hint after a few idle seconds. */
    private int[] findMove() {
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            if (slime[r][c]) continue;
            int[][] dirs = {{0, 1}, {1, 0}};
            for (int[] d : dirs) {
                int r2 = r + d[0], c2 = c + d[1];
                if (r2 >= N || c2 >= N || slime[r2][c2]) continue;
                swapCells(r, c, r2, c2);
                boolean ok = !runs().isEmpty();
                swapCells(r, c, r2, c2);
                if (ok) return new int[]{r, c, r2, c2};
            }
        }
        return null;
    }

    void swapCells(int r1, int c1, int r2, int c2) {
        int t = type[r1][c1]; type[r1][c1] = type[r2][c2]; type[r2][c2] = t;
        int s = special[r1][c1]; special[r1][c1] = special[r2][c2]; special[r2][c2] = s;
    }

    /**
     * Works out what a set of runs clears and which special atoms it creates. `swapR/swapC` is where the player's
     * moved atom landed (special atoms appear there), or -1 for cascades. Fills `clearing`; returns atoms cleared.
     */
    int resolveRuns(List<List<int[]>> runs, int swapR, int swapC, int swapR2, int swapC2) {
        boolean[][] inRun = new boolean[N][N];
        int[][] hits = new int[N][N];
        for (List<int[]> run : runs) for (int[] p : run) { inRun[p[0]][p[1]] = true; hits[p[0]][p[1]]++; }
        // Specials to create: {r, c, kind, atomType}.
        List<int[]> create = new ArrayList<>();
        Set<Integer> used = new HashSet<>();
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            if (hits[r][c] >= 2 && used.add(r * N + c)) create.add(new int[]{r, c, BOMB, type[r][c]});
        }
        for (List<int[]> run : runs) {
            int len = run.size();
            if (len < 4) continue;
            int[] spot = run.get(len / 2);
            for (int[] p : run) {
                if ((p[0] == swapR && p[1] == swapC) || (p[0] == swapR2 && p[1] == swapC2)) { spot = p; break; }
            }
            boolean taken = false;
            for (int[] p : run) if (used.contains(p[0] * N + p[1])) { taken = true; break; }
            if (taken && len < 5) continue;
            int kind = len >= 5 ? COLOR : (spot[2] == 0 ? LINE_H : LINE_V);
            if (used.add(spot[0] * N + spot[1])) create.add(new int[]{spot[0], spot[1], kind, type[spot[0]][spot[1]]});
            else for (int[] c : create) if (c[0] == spot[0] && c[1] == spot[1] && kind == COLOR) c[2] = COLOR;
        }
        // Clear the runs, setting off any special atoms caught in them (which can set off others).
        Deque<int[]> queue = new ArrayDeque<>();
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) if (inRun[r][c]) queue.add(new int[]{r, c});
        int count = expand(queue, used);
        // The new specials stay on the board.
        for (int[] cr : create) {
            clearing[cr[0]][cr[1]] = false;
            special[cr[0]][cr[1]] = cr[2];
            type[cr[0]][cr[1]] = cr[2] == COLOR ? type[cr[0]][cr[1]] : cr[3];
            count--;
            score(100);
        }
        return count;
    }

    /** Clears the queued cells and whatever their special atoms zap. `keep` cells are being turned into specials. */
    int expand(Deque<int[]> queue, Set<Integer> keep) {
        int count = 0;
        while (!queue.isEmpty()) {
            int[] p = queue.poll();
            int r = p[0], c = p[1];
            if (r < 0 || c < 0 || r >= N || c >= N || clearing[r][c] || type[r][c] < 0) continue;
            clearing[r][c] = true;
            count++;
            int sp = special[r][c];
            if (keep.contains(r * N + c) && sp == NONE) continue;
            switch (sp) {
                case LINE_H -> { for (int k = 0; k < N; k++) queue.add(new int[]{r, k}); zap(); }
                case LINE_V -> { for (int k = 0; k < N; k++) queue.add(new int[]{k, c}); zap(); }
                case BOMB -> { for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) queue.add(new int[]{r + dr, c + dc}); boom(); }
                case COLOR -> {
                    int kind = random.nextInt(kinds);
                    for (int rr = 0; rr < N; rr++) for (int cc = 0; cc < N; cc++) if (type[rr][cc] == kind) queue.add(new int[]{rr, cc});
                    zap();
                }
                default -> {}
            }
        }
        return count;
    }

    /** A supercharged atom swapped with another: clear every atom of that kind (or the whole board for two). */
    int superSwap(int r1, int c1, int r2, int c2) {
        Deque<int[]> queue = new ArrayDeque<>();
        boolean both = special[r1][c1] == COLOR && special[r2][c2] == COLOR;
        int kind = special[r1][c1] == COLOR ? type[r2][c2] : type[r1][c1];
        int sr = special[r1][c1] == COLOR ? r1 : r2, sc = special[r1][c1] == COLOR ? c1 : c2;
        special[sr][sc] = NONE; // it's used up (cleared below)
        queue.add(new int[]{sr, sc});
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            if (both || type[r][c] == kind) queue.add(new int[]{r, c});
        }
        zap();
        return expand(queue, new HashSet<>());
    }

    private void zap() { sound(SoundEvents.NOTE_BLOCK_BIT.value(), 1.6f, 0.35f); }
    private void boom() { sound(SoundEvents.GENERIC_EXPLODE, 1.6f, 0.25f); }

    /** Removes cleared atoms, cleans slime next to them, and drops everything down with new atoms on top. */
    void collapse() {
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            if (!clearing[r][c]) continue;
            slime[r][c] = false;
            if (r > 0) slime[r - 1][c] = false;
            if (r < N - 1) slime[r + 1][c] = false;
            if (c > 0) slime[r][c - 1] = false;
            if (c < N - 1) slime[r][c + 1] = false;
            type[r][c] = -1;
            special[r][c] = NONE;
            clearing[r][c] = false;
        }
        for (int c = 0; c < N; c++) {
            int write = N - 1;
            for (int r = N - 1; r >= 0; r--) {
                if (type[r][c] < 0) continue;
                if (write != r) {
                    type[write][c] = type[r][c];
                    special[write][c] = special[r][c];
                    fall[write][c] = write - r;
                    type[r][c] = -1;
                    special[r][c] = NONE;
                }
                write--;
            }
            int missing = write + 1;
            for (int r = write; r >= 0; r--) {
                type[r][c] = random.nextInt(kinds);
                special[r][c] = NONE;
                fall[r][c] = missing;
            }
        }
    }

    private void score(int pts) {
        score += pts;
        levelScore += pts;
    }

    // ================================================================== input

    private int[] cellAt(double mx, double my) {
        float fx = (float) ((mx - lastOx) / lastScale), fy = (float) ((my - lastOy) / lastScale);
        int c = (int) Math.floor((fx - BX) / CELL), r = (int) Math.floor((fy - BY) / CELL);
        return r >= 0 && c >= 0 && r < N && c < N ? new int[]{r, c} : null;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (!playing() || phase != Phase.IDLE) return false;
        int[] cell = cellAt(mx, my);
        if (cell == null) { selR = -1; return false; }
        pressR = cell[0];
        pressC = cell[1];
        clickCell(cell[0], cell[1]);
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (!playing() || phase != Phase.IDLE || pressR < 0) return false;
        int[] cell = cellAt(mx, my);
        if (cell != null && Math.abs(cell[0] - pressR) + Math.abs(cell[1] - pressC) == 1) {
            trySwap(pressR, pressC, cell[0], cell[1]);
            pressR = -1;
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        pressR = -1;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    protected void onPress(int key) {
        if (phase != Phase.IDLE) return;
        switch (key) {
            case GLFW.GLFW_KEY_UP, GLFW.GLFW_KEY_W -> curR = Math.max(0, curR - 1);
            case GLFW.GLFW_KEY_DOWN, GLFW.GLFW_KEY_S -> curR = Math.min(N - 1, curR + 1);
            case GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_A -> curC = Math.max(0, curC - 1);
            case GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_D -> curC = Math.min(N - 1, curC + 1);
            case GLFW.GLFW_KEY_SPACE, GLFW.GLFW_KEY_ENTER -> clickCell(curR, curC);
            default -> {}
        }
    }

    private void clickCell(int r, int c) {
        if (selR >= 0 && Math.abs(selR - r) + Math.abs(selC - c) == 1) {
            trySwap(selR, selC, r, c);
            return;
        }
        if (slime[r][c]) { sound(SoundEvents.SLIME_SQUISH, 1.2f, 0.4f); selR = -1; return; }
        selR = r;
        selC = c;
        sound(SoundEvents.UI_BUTTON_CLICK.value(), 1.6f, 0.2f);
    }

    private void trySwap(int r1, int c1, int r2, int c2) {
        selR = -1;
        if (slime[r1][c1] || slime[r2][c2]) { sound(SoundEvents.SLIME_SQUISH, 1.2f, 0.4f); return; }
        ar = r1; ac = c1; br = r2; bc = c2;
        swapCells(r1, c1, r2, c2);
        phase = Phase.SWAP;
        phaseStart = time;
        lastMoveAt = time;
        chain = 0;
        sound(SoundEvents.BOOK_PAGE_TURN, 1.4f, 0.4f);
    }

    // ================================================================== update

    @Override
    protected void update() {
        float dt = (float) STEP;
        if (phase != Phase.LEVEL_CLEAR) {
            timeLeft -= dt;
            if (timeLeft <= 0) { timeLeft = 0; sound(SoundEvents.NOTE_BLOCK_BASS.value(), 0.6f, 0.8f); gameOver(); return; }
        }
        // Falling atoms settle.
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) if (fall[r][c] > 0) fall[r][c] = Math.max(0, fall[r][c] - dt * 14);

        switch (phase) {
            case SWAP -> {
                if (time - phaseStart < SWAP_TIME) return;
                int cleared;
                if (special[ar][ac] == COLOR || special[br][bc] == COLOR) {
                    cleared = superSwap(ar, ac, br, bc);
                } else {
                    List<List<int[]>> runs = runs();
                    if (runs.isEmpty()) {
                        swapCells(ar, ac, br, bc); // no match: swap back
                        phase = Phase.SWAP_BACK;
                        phaseStart = time;
                        sound(SoundEvents.NOTE_BLOCK_DIDGERIDOO.value(), 1.4f, 0.3f);
                        return;
                    }
                    cleared = resolveRuns(runs, br, bc, ar, ac);
                }
                startClear(cleared);
            }
            case SWAP_BACK -> { if (time - phaseStart >= SWAP_TIME) phase = Phase.IDLE; }
            case CLEAR -> {
                if (time - phaseStart < CLEAR_TIME) return;
                collapse();
                phase = Phase.FALL;
                phaseStart = time;
            }
            case FALL -> {
                for (float[] row : fall) for (float f : row) if (f > 0) return;
                List<List<int[]>> runs = runs();
                if (!runs.isEmpty()) {
                    startClear(resolveRuns(runs, -1, -1, -1, -1)); // cascade
                    return;
                }
                if (levelScore >= target) {
                    phase = Phase.LEVEL_CLEAR;
                    phaseStart = time;
                    int bonus = (int) timeLeft * 25;
                    score += bonus;
                    pop("BEAKER FULL!  time bonus +" + bonus);
                    sound(SoundEvents.PLAYER_LEVELUP, 1.3f, 0.6f);
                    return;
                }
                if (!hasMove()) shuffle();
                phase = Phase.IDLE;
            }
            case LEVEL_CLEAR -> { if (time - phaseStart > 2.5) nextLevel(); }
            case IDLE -> {
                if (level >= 3 && time > nextSlimeSpread) { spreadSlime(); nextSlimeSpread = time + slimeEvery(); }
            }
        }
    }

    private void startClear(int cleared) {
        chain++;
        int pts = Math.max(0, cleared) * 20 * chain;
        score(pts);
        if (chain > 1) pop("CHAIN x" + chain + "  +" + pts);
        sound(SoundEvents.NOTE_BLOCK_PLING.value(), 0.9f + Math.min(1f, chain * 0.15f), 0.5f);
        phase = Phase.CLEAR;
        phaseStart = time;
    }

    private void spreadSlime() {
        List<int[]> spots = new ArrayList<>();
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            if (!slime[r][c]) continue;
            int[][] d = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
            for (int[] k : d) {
                int r2 = r + k[0], c2 = c + k[1];
                if (r2 >= 0 && c2 >= 0 && r2 < N && c2 < N && !slime[r2][c2]) spots.add(new int[]{r2, c2});
            }
        }
        if (spots.isEmpty()) return;
        int[] s = spots.get(random.nextInt(spots.size()));
        slime[s[0]][s[1]] = true;
        sound(SoundEvents.SLIME_SQUISH, 0.8f, 0.5f);
        if (!hasMove()) shuffle();
    }

    void shuffle() {
        int tries = 0;
        do {
            for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
                if (special[r][c] != NONE) continue;
                type[r][c] = random.nextInt(kinds);
            }
        } while ((!runs().isEmpty() || !hasMove()) && ++tries < 200);
        pop("No moves - shuffle!");
    }

    private void pop(String text) {
        popText = text;
        popUntil = time + 1.8;
    }

    // ================================================================== drawing

    // Painted art (see ArcadeArt): the reactor background, the atom sprite atlas, the beaker glass and its liquid.
    static final ArcadeArt.Tex BG = ArcadeArt.tex("atomlab/background", 660, 488);
    static final ArcadeArt.Tex ATOMS = ArcadeArt.tex("atomlab/atoms", 512, 128);
    static final ArcadeArt.Tex BEAKER = ArcadeArt.tex("atomlab/beaker", 128, 256);
    static final ArcadeArt.Tex LIQUID = ArcadeArt.tex("atomlab/liquid", 32, 128);
    /** Atlas cells (64 px; an atom sprite spans 30 units at scale 1). */
    private static final int SUPER = 6, HALO = 7, BEAM = 8, HAZARD = 9, SLIME = 10, SELECT = 11, CURSOR = 12, ELECTRON = 13, BUBBLE = 14, SPARKLE = 15;
    /** How much of the available screen the lab uses. */
    private static final float SIZE = 0.6f;
    private static final float SPRITE = 30, ORBIT_A = 12.5f, ORBIT_B = 4.6f;
    /** The beaker sits in the console's bay; this is the top-left corner of its 64 x 128 sprite. */
    private static final float BEAKER_X = 245, BEAKER_Y = 60;

    private static void sprite(GuiGraphics g, int cell, float x, float y, float size, float deg, float alpha) {
        ArcadeArt.cell(g, ATOMS, 64, cell, x, y, size, deg, 0xFFFFFF, alpha);
    }

    private static void tinted(GuiGraphics g, int cell, float x, float y, float size, int rgb, float alpha) {
        ArcadeArt.cell(g, ATOMS, 64, cell, x, y, size, 0, rgb, alpha);
    }

    @Override
    protected void draw(GuiGraphics g) {
        // The lab takes up 60% of what would fit on screen, so the game around you stays visible.
        float s = Math.min((height - 24) / FH, (width - 20) / FW) * SIZE;
        float ox = width / 2f - FW * s / 2, oy = (height - FH * s) / 2f - 4;
        lastScale = s;
        lastOx = ox;
        lastOy = oy;
        g.fill((int) ox - 2, (int) oy - 2, (int) (ox + FW * s) + 2, (int) (oy + FH * s) + 2, 0xFF0A1018);
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(s, s, 1);

        // The reactor: lab wall, steel frame, glass cells, control console (one painted texture).
        ArcadeArt.whole(g, BG, 0, 0, FW, FH);

        // Hint after 6 idle seconds.
        int[] hint = phase == Phase.IDLE && time - lastMoveAt > 6 ? findMove() : null;
        float swapK = phase == Phase.SWAP || phase == Phase.SWAP_BACK ? (float) Math.min(1, (time - phaseStart) / SWAP_TIME) : 1;
        float clearK = (float) Math.min(1, (time - phaseStart) / CLEAR_TIME);
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            if (type[r][c] < 0) continue;
            float x = BX + c * CELL + CELL / 2, y = BY + r * CELL + CELL / 2 - fall[r][c] * CELL;
            // During a swap, the two atoms slide past each other.
            if (swapK < 1 && ((r == ar && c == ac) || (r == br && c == bc))) {
                boolean isA = r == ar && c == ac;
                int fr = isA ? br : ar, fc = isA ? bc : ac;
                float k = phase == Phase.SWAP ? swapK : 1 - swapK;
                float fx = BX + fc * CELL + CELL / 2, fy = BY + fr * CELL + CELL / 2;
                x = fx + (x - fx) * k;
                y = fy + (y - fy) * k;
            }
            if (y < BY - CELL) continue;
            float scale = 1;
            int alpha = 255;
            if (clearing[r][c]) {
                scale = 1 + clearK * 0.6f;
                alpha = (int) (255 * Math.max(0, 1 - clearK));
                // A flash of the atom's color as it splits.
                int col = special[r][c] == COLOR ? 0xFFFFFF : ATOM_COLORS[Math.max(0, type[r][c])];
                tinted(g, HALO, x, y, SPRITE * (1.2f + clearK), col, 0.9f * (1 - clearK));
                sprite(g, SPARKLE, x, y, 26 * (0.4f + clearK), clearK * 120, 1 - clearK);
            }
            if (hint != null && ((r == hint[0] && c == hint[1]) || (r == hint[2] && c == hint[3]))) scale *= 1 + 0.08f * (float) Math.sin(time * 10);
            atom(g, x, y, scale, type[r][c], special[r][c], alpha, time + r * 0.37 + c * 0.73);
        }
        // Slime over the board: a wobbling blob of goo per square.
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            if (!slime[r][c]) continue;
            float wob = (float) Math.sin(time * 2.2 + r * 1.3 + c * 0.7) * 0.6f;
            sprite(g, SLIME, BX + c * CELL + CELL / 2, BY + r * CELL + CELL / 2 + 1, SPRITE + wob, 0, 1f);
        }
        // Selection and keyboard cursor.
        if (selR >= 0) sprite(g, SELECT, BX + selC * CELL + CELL / 2, BY + selR * CELL + CELL / 2, SPRITE * (1 + 0.04f * (float) Math.sin(time * 7)), 0, 1f);
        sprite(g, CURSOR, BX + curC * CELL + CELL / 2, BY + curR * CELL + CELL / 2, SPRITE, 0, 0.55f);

        // Beaker (progress to the target) and the core timer.
        drawBeaker(g, BEAKER_X, BEAKER_Y, Math.min(1f, levelScore / (float) target), time);
        float tf = (float) Math.max(0, timeLeft / LEVEL_TIME);
        int tc = tf > 0.25f ? 0xFF4CD9E4 : (((int) (time * 4)) % 2 == 0 ? 0xFFFF4D5E : 0xFFFFA23C);
        fillF(g, 236, 209, 236 + 83 * tf, 217, tc);
        fillF(g, 236, 209, 236 + 83 * tf, 210.5f, withAlpha(0xFFFFFF, 110));
        g.pose().popPose();

        int top = (int) oy;
        float px = ox + 237 * s;
        float ts = Math.max(0.7f, Math.min(1f, s)); // console text shrinks with the lab so it stays on its screen
        label(g, "LEVEL " + level, px, top + 10 * s, 0xFF4CD9E4, ts);
        label(g, String.format("%,d", score), px, top + 22 * s, TEXT, ts);
        label(g, levelScore + " / " + target, px, top + 34 * s, 0xFF8FB8C8, ts);
        label(g, (int) Math.ceil(timeLeft) + "s", px, top + 197 * s, timeLeft < 15 ? 0xFFFF4D5E : TEXT, ts);
        if (time < popUntil) g.drawCenteredString(font, popText, (int) (ox + (BX + N * CELL / 2) * s), (int) (oy + 5 * s), GOLD);
        g.drawCenteredString(font, "CLICK atom + neighbor (or drag)   ARROWS + SPACE   P pause   ESC menu", width / 2, height - 11, 0xFF6A6A88);
    }

    /** Panel text at a (possibly reduced) size ts. */
    private void label(GuiGraphics g, String text, float x, float y, int color, float ts) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(ts, ts, 1);
        g.drawString(font, text, 0, 0, color);
        g.pose().popPose();
    }

    /**
     * An atom: a glowing nucleus (one color per kind), two orbits and two electrons whizzing
     * round them. Charged atoms carry an energy beam, unstable ones a spinning hazard ring, supercharged ones are a
     * spinning rainbow core.
     */
    static void atom(GuiGraphics g, float x, float y, float scale, int kind, int sp, int alpha, double t) {
        if (alpha <= 0) return;
        float a = alpha / 255f, size = SPRITE * scale;
        if (sp == BOMB) {
            x += (float) Math.sin(t * 40) * 0.5f;
            float pulse = 0.5f + 0.5f * (float) Math.sin(t * 8);
            tinted(g, HALO, x, y, size * (1.25f + 0.2f * pulse), 0xFF5A1E, a * (0.2f + 0.25f * pulse));
        }
        if (sp == COLOR) {
            tinted(g, HALO, x, y, size * 1.3f, NeonSnakeScreen.hsv((float) (t * 0.5 % 1), 0.6f, 1f), a * 0.45f);
            sprite(g, SUPER, x, y, size, (float) (t * 90 % 360), a);
        } else {
            sprite(g, Math.max(0, Math.min(5, kind)), x, y, size, 0, a);
        }
        // Electrons on the two orbits painted into the sprite (12.5 x 4.6 ellipses tilted +-35 degrees).
        for (int o = 0; o < 2; o++) {
            double tilt = Math.toRadians(o == 0 ? 35 : -35);
            double ea = t * (o == 0 ? 3.1 : -2.6) + o * 1.7;
            float ex = (float) (Math.cos(ea) * ORBIT_A * scale), ey = (float) (Math.sin(ea) * ORBIT_B * scale);
            float px = x + (float) (ex * Math.cos(tilt) - ey * Math.sin(tilt)), py = y + (float) (ex * Math.sin(tilt) + ey * Math.cos(tilt));
            sprite(g, ELECTRON, px, py, 6.5f * scale, 0, a);
        }
        if (sp == LINE_H || sp == LINE_V) {
            float p = 0.7f + 0.3f * (float) Math.sin(t * 12);
            sprite(g, BEAM, x, y, size * 1.04f, sp == LINE_V ? 90 : 0, a * p);
        }
        if (sp == BOMB) sprite(g, HAZARD, x, y, size, (float) (t * 140 % 360), a);
    }

    /** The beaker: glowing liquid rising to the target, bubbles, a drip from the feed pipe, then the glass on top. */
    static void drawBeaker(GuiGraphics g, float bx, float by, float fill, double t) {
        float lx0 = bx + 10.2f, lx1 = bx + 53.8f, bottom = by + 118, full = 102;
        float h = full * Math.max(0, Math.min(1, fill));
        float surface = bottom - h;
        if (h > 0.6f) {
            int vh = Math.max(1, Math.min(128, Math.round(128 * h / full)));
            ArcadeArt.topLeft(g, LIQUID, lx0, surface, lx1 - lx0, h, 0, 128 - vh, 32, vh, 0.95f);
            // Rippling surface.
            for (int i = 0; i < 11; i++) {
                float xx = lx0 + i * (lx1 - lx0) / 11, wv = (float) Math.sin(t * 3 + i * 0.9) * 0.5f;
                fillF(g, xx, surface - 0.4f + wv, xx + (lx1 - lx0) / 11, surface + 1.1f, 0xA0D8FFF0);
            }
            // Bubbles rising through it.
            Random r = new Random(5);
            for (int i = 0; i < 9; i++) {
                float bxp = lx0 + 4 + r.nextFloat() * (lx1 - lx0 - 8);
                float speed = 9 + r.nextFloat() * 12, off = r.nextFloat() * 100;
                float span = Math.max(1, h - 4);
                float byp = bottom - 2 - (float) ((t * speed + off) % span);
                float sz = 2.6f + r.nextFloat() * 2.2f;
                sprite(g, BUBBLE, bxp + (float) Math.sin(t * 3 + i) * 0.8f, byp, sz, 0, 0.85f);
            }
        }
        // A drop falls from the feed pipe now and then.
        double cyc = (t * 0.7) % 1.0;
        float dropY = (float) (by + 2 + cyc * cyc * 160);
        if (dropY < surface - 1) MazeMuncherScreen.disc(g, bx + 32, dropY, 1.1f, 0xE08CFFD8);
        ArcadeArt.whole(g, BEAKER, bx, by, 64, 128);
        if (fill >= 1f) tinted(g, HALO, bx + 32, by + 70, 90, 0x5CFFC0, 0.25f + 0.15f * (float) Math.sin(t * 6));
    }

    // ================================================================== menu preview

    public static void drawPreview(GuiGraphics g, int x, int y, int w, int h, double t) {
        float s = Math.min(h / FH, w / FW);
        g.pose().pushPose();
        g.pose().translate(x + w / 2f - FW * s / 2, y + h / 2f - FH * s / 2, 0);
        g.pose().scale(s, s, 1);
        ArcadeArt.whole(g, BG, 0, 0, FW, FH);
        Random r = new Random(6);
        for (int row = 0; row < N; row++) for (int c = 0; c < N; c++) {
            float cx = BX + c * CELL, cy = BY + row * CELL;
            int kind = r.nextInt(6);
            int sp = (row * N + c) % 23 == 7 ? LINE_H : (row * N + c) % 29 == 11 ? BOMB : (row * N + c) == 36 ? COLOR : NONE;
            atom(g, cx + CELL / 2, cy + CELL / 2, 1, kind, sp, 255, t + row * 0.37 + c * 0.73);
        }
        drawBeaker(g, BEAKER_X, BEAKER_Y, (float) ((t * 0.15) % 1), t);
        g.pose().popPose();
    }
}
