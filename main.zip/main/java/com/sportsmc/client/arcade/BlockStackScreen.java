package com.sportsmc.client.arcade;

import com.sportsmc.arcade.ArcadeGame;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Block Stack: a falling-blocks game. 10 x 20 well, seven shapes dealt from shuffled bags of seven, rotation
 * with wall kicks, ghost piece, hold, three-piece preview, delayed auto-shift, lock delay, levels that speed
 * up every 10 lines, and the classic 100 / 300 / 500 / 800 line scores times the level.
 */
public class BlockStackScreen extends ArcadeGameScreen {

    static final int W = 10, H = 22, HIDDEN = 2; // 2 rows above the visible 20 where pieces appear

    // Shapes in their spawn orientation (x right, y down), inside a 3x3 box (I: 4x4, O: special).
    static final int I = 0, O = 1, T = 2, S = 3, Z = 4, J = 5, L = 6;
    static final int[][][] SPAWN = {
            {{0, 1}, {1, 1}, {2, 1}, {3, 1}},     // I
            {{1, 0}, {2, 0}, {1, 1}, {2, 1}},     // O
            {{1, 0}, {0, 1}, {1, 1}, {2, 1}},     // T
            {{1, 0}, {2, 0}, {0, 1}, {1, 1}},     // S
            {{0, 0}, {1, 0}, {1, 1}, {2, 1}},     // Z
            {{0, 0}, {0, 1}, {1, 1}, {2, 1}},     // J
            {{2, 0}, {0, 1}, {1, 1}, {2, 1}},     // L
    };
    static final int[] COLORS = {0xFF2EE6F0, 0xFFF5D90A, 0xFFB24DF0, 0xFF4FE04F, 0xFFF0434F, 0xFF3F6BF5, 0xFFF59A2E};
    static final int GARBAGE = 7;

    /** [piece][rotation][cell] = {x, y}. */
    static final int[][][][] SHAPES = new int[7][4][4][2];

    static {
        for (int p = 0; p < 7; p++) {
            int box = p == I ? 4 : 3;
            int[][] cur = SPAWN[p];
            for (int r = 0; r < 4; r++) {
                SHAPES[p][r] = cur;
                if (p == O) continue;
                int[][] next = new int[4][2];
                for (int c = 0; c < 4; c++) { next[c][0] = box - 1 - cur[c][1]; next[c][1] = cur[c][0]; }
                cur = next;
            }
            if (p == O) for (int r = 0; r < 4; r++) SHAPES[p][r] = SPAWN[O];
        }
    }

    // Wall kicks (x right, y DOWN), tried in order when rotating from state `from` clockwise / counter-clockwise.
    private static final int[][][] KICKS_CW = {
            {{0, 0}, {-1, 0}, {-1, -1}, {0, 2}, {-1, 2}},  // 0 -> R
            {{0, 0}, {1, 0}, {1, 1}, {0, -2}, {1, -2}},    // R -> 2
            {{0, 0}, {1, 0}, {1, -1}, {0, 2}, {1, 2}},     // 2 -> L
            {{0, 0}, {-1, 0}, {-1, 1}, {0, -2}, {-1, -2}}, // L -> 0
    };
    private static final int[][][] KICKS_CCW = {
            {{0, 0}, {1, 0}, {1, -1}, {0, 2}, {1, 2}},     // 0 -> L
            {{0, 0}, {1, 0}, {1, 1}, {0, -2}, {1, -2}},    // R -> 0
            {{0, 0}, {-1, 0}, {-1, -1}, {0, 2}, {-1, 2}},  // 2 -> R
            {{0, 0}, {-1, 0}, {-1, 1}, {0, -2}, {-1, -2}}, // L -> 2
    };
    private static final int[][][] KICKS_I_CW = {
            {{0, 0}, {-2, 0}, {1, 0}, {-2, 1}, {1, -2}},   // 0 -> R
            {{0, 0}, {-1, 0}, {2, 0}, {-1, -2}, {2, 1}},   // R -> 2
            {{0, 0}, {2, 0}, {-1, 0}, {2, -1}, {-1, 2}},   // 2 -> L
            {{0, 0}, {1, 0}, {-2, 0}, {1, 2}, {-2, -1}},   // L -> 0
    };
    private static final int[][][] KICKS_I_CCW = {
            {{0, 0}, {-1, 0}, {2, 0}, {-1, -2}, {2, 1}},   // 0 -> L
            {{0, 0}, {2, 0}, {-1, 0}, {2, -1}, {-1, 2}},   // R -> 0
            {{0, 0}, {1, 0}, {-2, 0}, {1, 2}, {-2, -1}},   // 2 -> R
            {{0, 0}, {-2, 0}, {1, 0}, {-2, 1}, {1, -2}},   // L -> 2
    };

    // Feel.
    private static final double DAS = 0.17, ARR = 0.05, SOFT_DROP = 0.03, LOCK_DELAY = 0.5, CLEAR_TIME = 0.3;
    private static final int MAX_LOCK_RESETS = 15;

    final int[][] board = new int[H][W]; // -1 empty, else color index
    private final Random random = new Random();
    private final List<Integer> queue = new ArrayList<>();
    int piece, rot, px, py;
    private int hold = -1;
    private boolean holdUsed;
    private double fallTimer, lockTimer, softTimer;
    private int lockResets;
    private boolean onGround;
    private int dasDir;
    private double dasTimer;
    private int lines, level = 1;
    private final List<Integer> clearing = new ArrayList<>();
    private double clearTimer;
    private String popText = "";
    private double popTime = -10;
    private double shakeTime = -10;

    public BlockStackScreen() {
        super(ArcadeGame.BLOCK_STACK);
    }

    // ================================================================== game

    @Override
    protected void reset() {
        for (int[] row : board) java.util.Arrays.fill(row, -1);
        queue.clear();
        hold = -1;
        lines = 0;
        level = 1;
        clearing.clear();
        popText = "";
        spawn(next());
    }

    private int next() {
        while (queue.size() < 7) {
            List<Integer> bag = new ArrayList<>(List.of(0, 1, 2, 3, 4, 5, 6));
            Collections.shuffle(bag, random);
            queue.addAll(bag);
        }
        return queue.remove(0);
    }

    private void spawn(int p) {
        piece = p;
        rot = 0;
        px = 3;
        py = 0;
        holdUsed = false;
        fallTimer = 0;
        lockTimer = 0;
        lockResets = 0;
        if (!fits(piece, rot, px, py)) { topOut(); return; }
        if (fits(piece, rot, px, py + 1)) py++; // appear right at the top of the visible well
    }

    boolean fits(int p, int r, int x, int y) {
        for (int[] c : SHAPES[p][r]) {
            int bx = x + c[0], by = y + c[1];
            if (bx < 0 || bx >= W || by >= H) return false;
            if (by >= 0 && board[by][bx] >= 0) return false;
        }
        return true;
    }

    /** Seconds per row of gravity at a level (gets very fast after level 10). */
    static double gravity(int level) {
        return Math.pow(0.8 - (level - 1) * 0.007, level - 1);
    }

    @Override
    protected void update() {
        if (!clearing.isEmpty()) {
            clearTimer -= STEP;
            if (clearTimer <= 0) finishClear();
            return;
        }
        // Left / right with delayed auto-shift.
        boolean left = isHeld(GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_A), right = isHeld(GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_D);
        int dir = left == right ? 0 : left ? -1 : 1;
        if (dir != dasDir) { dasDir = dir; dasTimer = 0; }
        else if (dir != 0) {
            dasTimer += STEP;
            if (dasTimer >= DAS) {
                while (dasTimer >= DAS + ARR) { dasTimer -= ARR; move(dir); }
            }
        }
        // Gravity (soft drop speeds it up and scores a point per row).
        boolean soft = isHeld(GLFW.GLFW_KEY_DOWN, GLFW.GLFW_KEY_S);
        double g = gravity(level);
        if (soft) {
            softTimer += STEP;
            while (softTimer >= Math.min(SOFT_DROP, g)) {
                softTimer -= Math.min(SOFT_DROP, g);
                if (fits(piece, rot, px, py + 1)) { py++; score += 1; fallTimer = 0; } else break;
            }
        } else {
            softTimer = 0;
            fallTimer += STEP;
            while (fallTimer >= g) {
                fallTimer -= g;
                if (fits(piece, rot, px, py + 1)) py++; else { fallTimer = 0; break; }
            }
        }
        // Lock delay once it's resting on something.
        onGround = !fits(piece, rot, px, py + 1);
        if (onGround) {
            lockTimer += STEP;
            if (lockTimer >= LOCK_DELAY) lock();
        } else {
            lockTimer = 0;
        }
    }

    @Override
    protected void onPress(int key) {
        if (!clearing.isEmpty()) return;
        switch (key) {
            case GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_A -> move(-1);
            case GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_D -> move(1);
            case GLFW.GLFW_KEY_UP, GLFW.GLFW_KEY_X, GLFW.GLFW_KEY_W -> rotate(true);
            case GLFW.GLFW_KEY_Z, GLFW.GLFW_KEY_LEFT_CONTROL, GLFW.GLFW_KEY_RIGHT_CONTROL -> rotate(false);
            case GLFW.GLFW_KEY_SPACE -> hardDrop();
            case GLFW.GLFW_KEY_C, GLFW.GLFW_KEY_LEFT_SHIFT, GLFW.GLFW_KEY_RIGHT_SHIFT -> hold();
            default -> {}
        }
    }

    private void move(int dx) {
        if (fits(piece, rot, px + dx, py)) {
            px += dx;
            touchedOnGround();
            sound(SoundEvents.UI_BUTTON_CLICK.value(), 2.0f, 0.08f);
        }
    }

    void rotate(boolean cw) {
        if (piece == O) return;
        int to = (rot + (cw ? 1 : 3)) % 4;
        int[][] kicks = (piece == I ? (cw ? KICKS_I_CW : KICKS_I_CCW) : (cw ? KICKS_CW : KICKS_CCW))[rot];
        for (int[] k : kicks) {
            if (fits(piece, to, px + k[0], py + k[1])) {
                px += k[0];
                py += k[1];
                rot = to;
                touchedOnGround();
                sound(SoundEvents.UI_BUTTON_CLICK.value(), 1.6f, 0.12f);
                return;
            }
        }
    }

    /** Moving or turning while resting buys more time before it locks (a limited number of times). */
    private void touchedOnGround() {
        if (onGround && lockResets < MAX_LOCK_RESETS) { lockTimer = 0; lockResets++; }
    }

    private void hardDrop() {
        int dropped = 0;
        while (fits(piece, rot, px, py + 1)) { py++; dropped++; }
        score += dropped * 2;
        shakeTime = time;
        sound(SoundEvents.STONE_PLACE, 0.8f, 0.5f);
        lock();
    }

    private void hold() {
        if (holdUsed) return;
        int current = piece;
        if (hold < 0) { hold = current; spawn(next()); }
        else { int h = hold; hold = current; spawn(h); }
        holdUsed = true;
        sound(SoundEvents.BOOK_PAGE_TURN, 1.4f, 0.4f);
    }

    private void lock() {
        boolean allHidden = true;
        for (int[] c : SHAPES[piece][rot]) {
            int bx = px + c[0], by = py + c[1];
            if (by >= 0 && by < H) board[by][bx] = piece;
            if (by >= HIDDEN) allHidden = false;
        }
        if (allHidden) { topOut(); return; }
        for (int y = 0; y < H; y++) {
            boolean full = true;
            for (int x = 0; x < W; x++) if (board[y][x] < 0) { full = false; break; }
            if (full) clearing.add(y);
        }
        if (!clearing.isEmpty()) {
            clearTimer = CLEAR_TIME;
            int n = clearing.size();
            score += new int[]{0, 100, 300, 500, 800}[Math.min(4, n)] * level;
            if (n == 4) {
                pop("STACK!");
                sound(SoundEvents.PLAYER_LEVELUP, 1.3f, 0.6f);
            } else {
                sound(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.0f + n * 0.15f, 0.6f);
            }
        } else {
            sound(SoundEvents.STONE_HIT, 1.2f, 0.25f);
            spawn(next());
        }
    }

    private void finishClear() {
        Collections.sort(clearing);
        for (int row : clearing) {
            for (int y = row; y > 0; y--) board[y] = board[y - 1].clone();
            board[0] = new int[W];
            java.util.Arrays.fill(board[0], -1);
        }
        int before = level;
        lines += clearing.size();
        level = Math.min(20, 1 + lines / 10);
        clearing.clear();
        if (level > before) {
            pop("LEVEL " + level);
            sound(SoundEvents.NOTE_BLOCK_BELL.value(), 1.5f, 0.7f);
        }
        spawn(next());
    }

    private void topOut() {
        sound(SoundEvents.NOTE_BLOCK_BASS.value(), 0.6f, 0.9f);
        gameOver();
    }

    private void pop(String text) {
        popText = text;
        popTime = time;
    }

    int ghostY() {
        int y = py;
        while (fits(piece, rot, px, y + 1)) y++;
        return y;
    }

    // ================================================================== drawing

    @Override
    protected void draw(GuiGraphics g) {
        int cs = Math.max(6, Math.min(14, (height - 40) / 20));
        int bw = cs * W, bh = cs * (H - HIDDEN);
        int bx = width / 2 - bw / 2, by = height / 2 - bh / 2 + 4;
        double shake = time - shakeTime < 0.12 ? (0.12 - (time - shakeTime)) * 20 : 0;
        by += (int) shake;

        // Backdrop: slowly scrolling grid.
        int off = (int) (time * 8) % 16;
        for (int y = -16 + off; y < height; y += 16) g.fill(0, y, width, y + 1, 0x14FFFFFF);
        for (int x = 0; x < width; x += 16) g.fill(x, 0, x + 1, height, 0x0CFFFFFF);

        // Well.
        g.fill(bx - 3, by - 3, bx + bw + 3, by + bh + 3, 0xFF4A4A66);
        g.fill(bx, by, bx + bw, by + bh, 0xFF0C0C14);
        for (int x = 1; x < W; x++) g.fill(bx + x * cs, by, bx + x * cs + 1, by + bh, 0x10FFFFFF);
        for (int y = 1; y < H - HIDDEN; y++) g.fill(bx, by + y * cs, bx + bw, by + y * cs + 1, 0x10FFFFFF);

        // Settled blocks (game over: they turn grey from the bottom up).
        int greyFrom = over ? H - (int) Math.min(H, (time - overTime) / 0.04) : H;
        for (int y = HIDDEN; y < H; y++) {
            boolean flashing = clearing.contains(y);
            for (int x = 0; x < W; x++) {
                int c = board[y][x];
                if (c < 0) continue;
                int color = y >= greyFrom ? 0xFF6A6A78 : COLORS[c];
                if (flashing) {
                    float k = (float) (clearTimer / CLEAR_TIME);
                    int inset = (int) ((1 - k) * cs / 2);
                    g.fill(bx + x * cs + inset, by + (y - HIDDEN) * cs + inset, bx + (x + 1) * cs - inset, by + (y - HIDDEN + 1) * cs - inset,
                            (int) (k * 255) << 24 | 0xFFFFFF);
                } else {
                    cell(g, bx + x * cs, by + (y - HIDDEN) * cs, cs, color);
                }
            }
        }

        if (!over && clearing.isEmpty()) {
            // Ghost, then the piece.
            int gy = ghostY();
            for (int[] c : SHAPES[piece][rot]) {
                int y = gy + c[1] - HIDDEN;
                if (y < 0) continue;
                int x0 = bx + (px + c[0]) * cs, y0 = by + y * cs;
                outline(g, x0 + 1, y0 + 1, x0 + cs - 1, y0 + cs - 1, withAlpha(COLORS[piece], 110));
            }
            float lockFade = onGround ? (float) (1 - 0.35 * lockTimer / LOCK_DELAY) : 1f;
            for (int[] c : SHAPES[piece][rot]) {
                int y = py + c[1] - HIDDEN;
                if (y < 0) continue;
                cell(g, bx + (px + c[0]) * cs, by + y * cs, cs, shade(COLORS[piece], lockFade));
            }
        }

        // Side panels: hold (left), next (right), stats.
        int pw = cs * 5, lx = bx - pw - 10, rx = bx + bw + 10;
        panel(g, lx, by, pw, cs * 4, "HOLD");
        if (hold >= 0) mini(g, hold, lx + pw / 2, by + cs * 2 + 4, cs * 0.75f, holdUsed ? 0.45f : 1f);
        panel(g, rx, by, pw, cs * 10, "NEXT");
        for (int i = 0; i < 3 && i < queue.size(); i++) {
            float s = i == 0 ? cs * 0.8f : cs * 0.6f;
            mini(g, queue.get(i), rx + pw / 2, by + cs * 2 + 4 + i * cs * 3, s, 1f);
        }
        int sy = by + cs * 5;
        panel(g, lx, sy, pw, cs * 7, "");
        stat(g, lx + 4, sy + 4, "SCORE", String.format("%,d", score));
        stat(g, lx + 4, sy + 26, "LEVEL", String.valueOf(level));
        stat(g, lx + 4, sy + 48, "LINES", String.valueOf(lines));
        int best = ClientArcadeData.personalBest(game);
        g.drawString(font, "BEST " + String.format("%,d", Math.max(best, score)), rx, by + cs * 10 + 6, DIM);

        // Pop-up text (STACK!, LEVEL n).
        double pt = time - popTime;
        if (pt < 1.2 && !popText.isEmpty()) {
            float s = (float) (2.2 + Math.min(0.4, pt * 2));
            int a = (int) (255 * Math.max(0, 1 - Math.max(0, pt - 0.6) / 0.6));
            g.pose().pushPose();
            g.pose().translate(bx + bw / 2f, by + bh / 3f - (float) pt * 12, 0);
            g.pose().scale(s, s, 1);
            g.drawCenteredString(font, popText, 0, 0, withAlpha(0xFFE680, a));
            g.pose().popPose();
        }
        g.drawCenteredString(font, "← → move  ↓ soft  SPACE drop  ↑/X Z rotate  C hold  P pause  ESC menu", width / 2, height - 11, 0xFF6A6A88);
    }

    private void panel(GuiGraphics g, int x, int y, int w, int h, String title) {
        g.fill(x - 2, y - 2, x + w + 2, y + h + 2, 0xFF4A4A66);
        g.fill(x, y, x + w, y + h, 0xFF0C0C14);
        if (!title.isEmpty()) g.drawCenteredString(font, title, x + w / 2, y + 3, DIM);
    }

    private void stat(GuiGraphics g, int x, int y, String label, String value) {
        g.drawString(font, label, x, y, DIM);
        g.drawString(font, value, x, y + 10, TEXT);
    }

    /** A block: base color with a light top-left bevel and a dark bottom-right edge. */
    static void cell(GuiGraphics g, int x, int y, int cs, int color) {
        g.fill(x, y, x + cs, y + cs, shade(color, 0.55f));
        g.fill(x, y, x + cs - 1, y + cs - 1, shade(color, 1.25f));
        g.fill(x + 1, y + 1, x + cs - 1, y + cs - 1, color);
        if (cs >= 8) g.fill(x + 2, y + 2, x + 4, y + 4, 0x70FFFFFF);
    }

    /** A small piece centered at (cx, cy) for the hold / next panels. */
    private void mini(GuiGraphics g, int p, float cx, float cy, float s, float bright) {
        int[][] cells = SHAPES[p][0];
        float minX = 9, maxX = -9, minY = 9, maxY = -9;
        for (int[] c : cells) { minX = Math.min(minX, c[0]); maxX = Math.max(maxX, c[0]); minY = Math.min(minY, c[1]); maxY = Math.max(maxY, c[1]); }
        float ox = cx - (maxX - minX + 1) * s / 2, oy = cy - (maxY - minY + 1) * s / 2;
        int size = Math.max(3, Math.round(s));
        for (int[] c : cells) {
            cell(g, Math.round(ox + (c[0] - minX) * s), Math.round(oy + (c[1] - minY) * s), size, shade(COLORS[p], bright));
        }
    }

    private static void outline(GuiGraphics g, int x0, int y0, int x1, int y1, int color) {
        g.fill(x0, y0, x1, y0 + 1, color);
        g.fill(x0, y1 - 1, x1, y1, color);
        g.fill(x0, y0, x0 + 1, y1, color);
        g.fill(x1 - 1, y0, x1, y1, color);
    }

    // ================================================================== menu preview

    /** Attract-mode loop for the arcade menu: pieces raining into a little well. */
    public static void drawPreview(GuiGraphics g, int x, int y, int w, int h, double t) {
        int cs = Math.max(4, Math.min(w / 12, h / 22));
        int bw = cs * 10, bx = x + w / 2 - bw / 2, bh = cs * 20, by = y + h / 2 - bh / 2;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, 0xFF4A4A66);
        g.fill(bx, by, bx + bw, by + bh, 0xFF0C0C14);
        // A fixed little stack at the bottom (with one gap), and pieces falling into place.
        long seed = (long) (t / 6);
        Random r = new Random(seed);
        int fill = 3 + r.nextInt(3);
        for (int row = 0; row < fill; row++) {
            int gap = r.nextInt(10);
            for (int col = 0; col < 10; col++) if (col != gap) cell(g, bx + col * cs, by + (19 - row) * cs, cs, COLORS[r.nextInt(7)]);
        }
        double phase = t % 6;
        for (int k = 0; k < 3; k++) {
            double pt = phase - k * 1.6;
            if (pt < 0) continue;
            int p = (int) ((seed * 3 + k) % 7);
            int col = 1 + (int) ((seed + k * 3) % 6);
            int rot = (int) ((seed + k) % 4);
            int fall = (int) Math.min(19 - fill - 3, pt * 9);
            for (int[] c : SHAPES[p][rot]) cell(g, bx + (col + c[0]) * cs, by + (fall + c[1]) * cs, cs, COLORS[p]);
        }
    }
}
