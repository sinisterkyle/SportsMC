package com.sportsmc.client.arcade;

import com.mojang.math.Axis;
import com.sportsmc.arcade.ArcadeGame;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Rock Blaster: a drifting ship in a field of space rocks. Turn with ← →, thrust with ↑, fire with SPACE,
 * warp to a random spot with ↓. Big rocks split into medium, medium into small. Saucers show up to make
 * trouble: the big one shoots at random, the small one aims at you. Everything wraps around the screen.
 * Drawn as glowing vector lines. Field is 256 x 224 units.
 */
public class RockBlasterScreen extends ArcadeGameScreen {

    static final float FW = 256, FH = 224;
    private static final int LINE = 0xFFE8F4FF, GLOW = 0x406FD8FF;

    private static final class Rock {
        float x, y, vx, vy, angle, spin;
        int size; // 3 big, 2 medium, 1 small
        float[] shape;
        float radius() { return size == 3 ? 16 : size == 2 ? 9 : 5; }
    }
    private static final class Bullet { float x, y, vx, vy, life; boolean enemy; }
    private static final class Saucer { float x, y, vx, vy; boolean small; double nextShot, nextTurn; }
    private static final class Debris { float x, y, vx, vy, angle, spin, len, age, life; }

    private final List<Rock> rocks = new ArrayList<>();
    private final List<Bullet> bullets = new ArrayList<>();
    private final List<Debris> debris = new ArrayList<>();
    private Saucer saucer;
    private final Random random = new Random();
    private float sx, sy, svx, svy, sAngle; // ship (angle in degrees, 0 = up)
    private boolean alive, thrusting;
    private double deadAt = -10, invulnUntil, warpedUntil, lastShot = -10, nextSaucer;
    private int lives, wave, nextExtra;
    private double waveClearAt = -1;

    public RockBlasterScreen() {
        super(ArcadeGame.ROCK_BLASTER);
    }

    @Override
    protected void reset() {
        lives = 3;
        wave = 0;
        nextExtra = 10_000;
        rocks.clear();
        bullets.clear();
        debris.clear();
        saucer = null;
        spawnShip();
        nextWave();
    }

    private void spawnShip() {
        sx = FW / 2;
        sy = FH / 2;
        svx = svy = 0;
        sAngle = 0;
        alive = true;
        invulnUntil = time + 2.5;
    }

    private void nextWave() {
        wave++;
        waveClearAt = -1;
        int n = Math.min(11, 3 + wave);
        for (int i = 0; i < n; i++) {
            float x, y;
            do { x = random.nextFloat() * FW; y = random.nextFloat() * FH; } while (dist(x, y, sx, sy) < 70);
            rocks.add(rock(3, x, y));
        }
        nextSaucer = time + 12 + random.nextDouble() * 10;
        sound(SoundEvents.NOTE_BLOCK_BELL.value(), 0.9f, 0.5f);
    }

    private Rock rock(int size, float x, float y) {
        Rock r = new Rock();
        r.size = size;
        r.x = x;
        r.y = y;
        double a = random.nextDouble() * Math.PI * 2;
        float sp = (size == 3 ? 18 : size == 2 ? 32 : 48) * (0.6f + random.nextFloat() * 0.8f) * (1 + wave * 0.04f);
        r.vx = (float) Math.cos(a) * sp;
        r.vy = (float) Math.sin(a) * sp;
        r.spin = (random.nextFloat() - 0.5f) * 90;
        r.shape = new float[11];
        for (int i = 0; i < 11; i++) r.shape[i] = 0.72f + random.nextFloat() * 0.42f;
        return r;
    }

    private static float dist(float ax, float ay, float bx, float by) {
        float dx = Math.abs(ax - bx), dy = Math.abs(ay - by);
        dx = Math.min(dx, FW - dx);
        dy = Math.min(dy, FH - dy);
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static float wrapX(float x) { return (x % FW + FW) % FW; }
    private static float wrapY(float y) { return (y % FH + FH) % FH; }

    // ================================================================== update

    @Override
    protected void onPress(int key) {
        if ((key == GLFW.GLFW_KEY_DOWN || key == GLFW.GLFW_KEY_S) && alive && time > warpedUntil) {
            // Warp: vanish and reappear somewhere random (risky!).
            sx = random.nextFloat() * FW;
            sy = random.nextFloat() * FH;
            svx = svy = 0;
            warpedUntil = time + 0.6;
            sound(SoundEvents.ENDERMAN_TELEPORT, 1.4f, 0.4f);
        }
    }

    @Override
    protected void update() {
        float dt = (float) STEP;
        boolean warping = time < warpedUntil - 0.3;
        if (alive) {
            boolean left = isHeld(GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_A), right = isHeld(GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_D);
            if (left != right) sAngle += (left ? -250 : 250) * dt;
            thrusting = isHeld(GLFW.GLFW_KEY_UP, GLFW.GLFW_KEY_W);
            if (thrusting) {
                double a = Math.toRadians(sAngle);
                svx += (float) Math.sin(a) * 170 * dt;
                svy -= (float) Math.cos(a) * 170 * dt;
                float sp = (float) Math.sqrt(svx * svx + svy * svy);
                if (sp > 190) { svx *= 190 / sp; svy *= 190 / sp; }
            }
            svx *= 0.992f;
            svy *= 0.992f;
            sx = wrapX(sx + svx * dt);
            sy = wrapY(sy + svy * dt);
            if (isHeld(GLFW.GLFW_KEY_SPACE) && time - lastShot > 0.17 && !warping) fire();
        } else if (time - deadAt > 2.0) {
            if (lives <= 0) { gameOver(); return; }
            // Respawn once the middle is clear.
            boolean clear = true;
            for (Rock r : rocks) if (dist(r.x, r.y, FW / 2, FH / 2) < 45) { clear = false; break; }
            if (clear) spawnShip();
        }

        for (Rock r : rocks) {
            r.x = wrapX(r.x + r.vx * dt);
            r.y = wrapY(r.y + r.vy * dt);
            r.angle += r.spin * dt;
        }
        tickSaucer(dt);
        tickBullets(dt);
        if (alive && time > invulnUntil && !warping) {
            for (Rock r : rocks) if (dist(r.x, r.y, sx, sy) < r.radius() + 4) { killShip(); break; }
            if (alive && saucer != null && dist(saucer.x, saucer.y, sx, sy) < 10) { killShip(); destroySaucer(false); }
        }
        for (Iterator<Debris> it = debris.iterator(); it.hasNext(); ) {
            Debris d = it.next();
            d.age += dt;
            if (d.age >= d.life) { it.remove(); continue; }
            d.x += d.vx * dt;
            d.y += d.vy * dt;
            d.angle += d.spin * dt;
        }
        if (rocks.isEmpty() && saucer == null) {
            if (waveClearAt < 0) waveClearAt = time;
            else if (time - waveClearAt > 2.0) nextWave();
        }
    }

    private void fire() {
        int mine = 0;
        for (Bullet b : bullets) if (!b.enemy) mine++;
        if (mine >= 4) return;
        double a = Math.toRadians(sAngle);
        Bullet b = new Bullet();
        b.x = sx + (float) Math.sin(a) * 8;
        b.y = sy - (float) Math.cos(a) * 8;
        b.vx = svx + (float) Math.sin(a) * 250;
        b.vy = svy - (float) Math.cos(a) * 250;
        b.life = 0.85f;
        bullets.add(b);
        lastShot = time;
        sound(SoundEvents.NOTE_BLOCK_HAT.value(), 1.8f, 0.25f);
    }

    private void tickBullets(float dt) {
        List<Rock> born = new ArrayList<>();
        for (Iterator<Bullet> it = bullets.iterator(); it.hasNext(); ) {
            Bullet b = it.next();
            b.life -= dt;
            if (b.life <= 0) { it.remove(); continue; }
            b.x = wrapX(b.x + b.vx * dt);
            b.y = wrapY(b.y + b.vy * dt);
            boolean hit = false;
            for (Iterator<Rock> rt = rocks.iterator(); rt.hasNext(); ) {
                Rock r = rt.next();
                if (dist(b.x, b.y, r.x, r.y) > r.radius()) continue;
                rt.remove();
                if (r.size > 1) for (int k = 0; k < 2; k++) born.add(rock(r.size - 1, r.x, r.y));
                if (!b.enemy) addScore(r.size == 3 ? 20 : r.size == 2 ? 50 : 100);
                shatter(r.x, r.y, r.size * 4);
                sound(SoundEvents.GENERIC_EXPLODE, r.size == 3 ? 0.7f : r.size == 2 ? 1.0f : 1.4f, 0.25f);
                hit = true;
                break;
            }
            if (!hit && !b.enemy && saucer != null && dist(b.x, b.y, saucer.x, saucer.y) < (saucer.small ? 5 : 9)) {
                addScore(saucer.small ? 1000 : 200);
                destroySaucer(true);
                hit = true;
            }
            if (!hit && b.enemy && alive && time > invulnUntil && time > warpedUntil - 0.3 && dist(b.x, b.y, sx, sy) < 5) {
                killShip();
                hit = true;
            }
            if (hit) it.remove();
        }
        rocks.addAll(born);
    }

    private void tickSaucer(float dt) {
        if (saucer == null) {
            if (time > nextSaucer && !rocks.isEmpty()) {
                saucer = new Saucer();
                saucer.small = score > 10_000 ? random.nextFloat() < 0.6f : random.nextFloat() < 0.15f;
                boolean fromLeft = random.nextBoolean();
                saucer.x = fromLeft ? 0 : FW - 1;
                saucer.y = 20 + random.nextFloat() * (FH - 40);
                saucer.vx = (fromLeft ? 1 : -1) * (saucer.small ? 55 : 40);
                saucer.nextShot = time + 1;
                saucer.nextTurn = time + 1.5;
                sound(SoundEvents.NOTE_BLOCK_BIT.value(), 0.6f, 0.4f);
            }
            return;
        }
        Saucer u = saucer;
        u.x += u.vx * dt;
        u.y = wrapY(u.y + u.vy * dt);
        if (time > u.nextTurn) { u.vy = (random.nextInt(3) - 1) * 30; u.nextTurn = time + 1 + random.nextDouble(); }
        if (u.x < -10 || u.x > FW + 10) { saucer = null; nextSaucer = time + 15 + random.nextDouble() * 10; return; }
        if (time > u.nextShot) {
            u.nextShot = time + (u.small ? 1.0 : 1.4);
            double a;
            if (u.small && alive) a = Math.atan2(sy - u.y, sx - u.x) + (random.nextDouble() - 0.5) * 0.3;
            else a = random.nextDouble() * Math.PI * 2;
            Bullet b = new Bullet();
            b.enemy = true;
            b.x = u.x;
            b.y = u.y;
            b.vx = (float) Math.cos(a) * 140;
            b.vy = (float) Math.sin(a) * 140;
            b.life = 1.3f;
            bullets.add(b);
            sound(SoundEvents.NOTE_BLOCK_BIT.value(), 1.2f, 0.25f);
        }
        for (Iterator<Rock> it = rocks.iterator(); it.hasNext(); ) {
            Rock r = it.next();
            if (dist(r.x, r.y, u.x, u.y) < r.radius() + 6) { destroySaucer(false); return; }
        }
    }

    private void destroySaucer(boolean byPlayer) {
        if (saucer == null) return;
        shatter(saucer.x, saucer.y, 10);
        sound(SoundEvents.GENERIC_EXPLODE, 1.2f, 0.4f);
        saucer = null;
        nextSaucer = time + 15 + random.nextDouble() * 10;
    }

    private void killShip() {
        alive = false;
        deadAt = time;
        lives--;
        thrusting = false;
        shatter(sx, sy, 8);
        sound(SoundEvents.GENERIC_EXPLODE, 0.6f, 0.6f);
    }

    private void addScore(int pts) {
        score += pts;
        if (score >= nextExtra) {
            lives++;
            nextExtra += 10_000;
            sound(SoundEvents.PLAYER_LEVELUP, 1.6f, 0.5f);
        }
    }

    private void shatter(float x, float y, int n) {
        for (int i = 0; i < n; i++) {
            Debris d = new Debris();
            double a = random.nextDouble() * Math.PI * 2, v = 15 + random.nextDouble() * 45;
            d.x = x; d.y = y;
            d.vx = (float) (Math.cos(a) * v);
            d.vy = (float) (Math.sin(a) * v);
            d.angle = random.nextFloat() * 360;
            d.spin = (random.nextFloat() - 0.5f) * 400;
            d.len = 2 + random.nextFloat() * 4;
            d.life = 0.6f + random.nextFloat() * 0.6f;
            debris.add(d);
        }
    }

    // ================================================================== drawing

    @Override
    protected void draw(GuiGraphics g) {
        float s = Math.min((height - 24) / FH, (width - 20) / FW);
        float ox = width / 2f - FW * s / 2, oy = (height - FH * s) / 2f - 2;
        g.fill((int) ox - 2, (int) oy - 2, (int) (ox + FW * s) + 2, (int) (oy + FH * s) + 2, 0xFF22223A);
        g.fill((int) ox, (int) oy, (int) (ox + FW * s), (int) (oy + FH * s), 0xFF000006);
        g.flush(); // batched drawing: finish what's queued before clipping
        g.enableScissor((int) ox, (int) oy, (int) (ox + FW * s), (int) (oy + FH * s));
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(s, s, 1);

        StarSwarmScreen.drawStars(g, time * 0.15, FW, FH);
        for (Rock r : rocks) drawWrapped(g, r.x, r.y, r.radius() + 2, (gx, gy) -> drawRock(g, r, gx, gy));
        if (saucer != null) {
            Saucer u = saucer;
            drawWrapped(g, u.x, u.y, 12, (gx, gy) -> drawSaucer(g, gx, gy, u.small ? 0.6f : 1f));
        }
        boolean warping = time < warpedUntil - 0.3;
        boolean blink = time < invulnUntil && ((int) (time * 8)) % 2 == 0;
        if (alive && !warping && !blink) drawWrapped(g, sx, sy, 10, (gx, gy) -> drawShip(g, gx, gy, sAngle, thrusting && ((int) (time * 20)) % 2 == 0));
        for (Bullet b : bullets) fillF(g, b.x - 1, b.y - 1, b.x + 1, b.y + 1, b.enemy ? 0xFFFF7A7A : 0xFFFFFFFF);
        for (Debris d : debris) {
            int a = (int) (255 * (1 - d.age / d.life));
            line(g, d.x, d.y, d.angle, d.len, withAlpha(LINE, a), false);
        }
        g.pose().popPose();
        g.flush();
        g.disableScissor();

        int left = (int) ox, right = (int) (ox + FW * s), top = (int) oy;
        g.drawString(font, String.format("%,d", score), left + 4, top + 4, TEXT);
        String best = "BEST " + String.format("%,d", Math.max(score, ClientArcadeData.personalBest(game)));
        g.drawCenteredString(font, best, (left + right) / 2, top + 4, DIM);
        String info = "WAVE " + wave;
        g.drawString(font, info, right - font.width(info) - 4, top + 4, 0xFF6FD8FF);
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(s, s, 1);
        for (int i = 0; i < Math.min(8, lives - (alive ? 1 : 0)); i++) drawShip(g, 8 + i * 9, 24, 0, false);
        g.pose().popPose();
        if (waveClearAt >= 0) g.drawCenteredString(font, "WAVE CLEAR", (left + right) / 2, (int) (oy + FH * s / 2), GOLD);
        if (wave == 1 && time < 3) g.drawCenteredString(font, "← → turn   ↑ thrust   SPACE fire   ↓ warp", (left + right) / 2, (int) (oy + FH * s * 0.7f), DIM);
        g.drawCenteredString(font, "← → turn   ↑ thrust   SPACE fire   ↓ warp   P pause   ESC menu", width / 2, height - 11, 0xFF6A6A88);
    }

    private interface At { void draw(float x, float y); }

    /** Draws something, plus its copies across the edges when it's near one (so wrapping looks seamless). */
    private static void drawWrapped(GuiGraphics g, float x, float y, float r, At at) {
        at.draw(x, y);
        boolean nl = x < r, nr = x > FW - r, nt = y < r, nb = y > FH - r;
        if (nl) at.draw(x + FW, y);
        if (nr) at.draw(x - FW, y);
        if (nt) at.draw(x, y + FH);
        if (nb) at.draw(x, y - FH);
        if (nl && nt) at.draw(x + FW, y + FH);
        if (nr && nt) at.draw(x - FW, y + FH);
        if (nl && nb) at.draw(x + FW, y - FH);
        if (nr && nb) at.draw(x - FW, y - FH);
    }

    /** A glowing line from (x, y) at an angle (degrees, 0 = right) and length. */
    static void line(GuiGraphics g, float x, float y, float deg, float len, int color, boolean glow) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().mulPose(Axis.ZP.rotationDegrees(deg));
        if (glow) fillF(g, -0.5f, -1.2f, len + 0.5f, 1.2f, GLOW);
        fillF(g, 0, -0.4f, len, 0.4f, color);
        g.pose().popPose();
    }

    static void segment(GuiGraphics g, float x0, float y0, float x1, float y1, int color) {
        float dx = x1 - x0, dy = y1 - y0;
        line(g, x0, y0, (float) Math.toDegrees(Math.atan2(dy, dx)), (float) Math.sqrt(dx * dx + dy * dy), color, true);
    }

    private static void drawRock(GuiGraphics g, Rock r, float x, float y) {
        int n = r.shape.length;
        float rad = r.radius();
        float px = 0, py = 0, fx = 0, fy = 0;
        for (int i = 0; i <= n; i++) {
            double a = Math.toRadians(r.angle) + i * Math.PI * 2 / n;
            float rr = rad * r.shape[i % n];
            float vx = x + (float) Math.cos(a) * rr, vy = y + (float) Math.sin(a) * rr;
            if (i > 0) segment(g, px, py, vx, vy, LINE);
            else { fx = vx; fy = vy; }
            px = vx;
            py = vy;
        }
    }

    static void drawShip(GuiGraphics g, float x, float y, float angle, boolean flame) {
        double a = Math.toRadians(angle);
        float cos = (float) Math.cos(a), sin = (float) Math.sin(a);
        float[][] pts = {{0, -8}, {5, 6}, {0, 3}, {-5, 6}};
        float[][] w = new float[4][2];
        for (int i = 0; i < 4; i++) {
            w[i][0] = x + pts[i][0] * cos - pts[i][1] * sin;
            w[i][1] = y + pts[i][0] * sin + pts[i][1] * cos;
        }
        for (int i = 0; i < 4; i++) segment(g, w[i][0], w[i][1], w[(i + 1) % 4][0], w[(i + 1) % 4][1], LINE);
        if (flame) {
            float fx = x + 0 * cos - 10 * sin, fy = y + 0 * sin + 10 * cos;
            float lx = x + -2.5f * cos - 4.5f * sin, ly = y + -2.5f * sin + 4.5f * cos;
            float rx = x + 2.5f * cos - 4.5f * sin, ry = y + 2.5f * sin + 4.5f * cos;
            segment(g, lx, ly, fx, fy, 0xFFFFB040);
            segment(g, rx, ry, fx, fy, 0xFFFFB040);
        }
    }

    static void drawSaucer(GuiGraphics g, float x, float y, float k) {
        float w = 10 * k, h = 3 * k;
        segment(g, x - w, y, x + w, y, LINE);
        segment(g, x - w, y, x - w * 0.5f, y - h, LINE);
        segment(g, x + w, y, x + w * 0.5f, y - h, LINE);
        segment(g, x - w * 0.5f, y - h, x + w * 0.5f, y - h, LINE);
        segment(g, x - w, y, x - w * 0.5f, y + h, LINE);
        segment(g, x + w, y, x + w * 0.5f, y + h, LINE);
        segment(g, x - w * 0.5f, y + h, x + w * 0.5f, y + h, LINE);
        segment(g, x - w * 0.3f, y - h, x - w * 0.2f, y - h * 2.2f, LINE);
        segment(g, x + w * 0.3f, y - h, x + w * 0.2f, y - h * 2.2f, LINE);
        segment(g, x - w * 0.2f, y - h * 2.2f, x + w * 0.2f, y - h * 2.2f, LINE);
    }

    // ================================================================== menu preview

    public static void drawPreview(GuiGraphics g, int x, int y, int w, int h, double t) {
        float s = Math.min(h / FH, w / FW);
        g.pose().pushPose();
        g.pose().translate(x + w / 2f - FW * s / 2, y + h / 2f - FH * s / 2, 0);
        g.pose().scale(s, s, 1);
        StarSwarmScreen.drawStars(g, t * 0.15, FW, FH);
        Random r = new Random(3);
        for (int i = 0; i < 6; i++) {
            Rock rk = new Rock();
            rk.size = 3 - i % 3;
            rk.shape = new float[11];
            for (int k = 0; k < 11; k++) rk.shape[k] = 0.72f + r.nextFloat() * 0.42f;
            float vx = (r.nextFloat() - 0.5f) * 40, vy = (r.nextFloat() - 0.5f) * 40;
            rk.x = wrapX(r.nextFloat() * FW + vx * (float) t);
            rk.y = wrapY(r.nextFloat() * FH + vy * (float) t);
            rk.angle = (float) (t * 30 * (i % 2 == 0 ? 1 : -1));
            drawRock(g, rk, rk.x, rk.y);
        }
        float ang = (float) (t * 60 % 360);
        drawShip(g, FW / 2, FH / 2, ang, ((int) (t * 20)) % 2 == 0);
        double bt = (t * 2) % 1;
        double a = Math.toRadians(ang);
        fillF(g, FW / 2 + (float) (Math.sin(a) * bt * 100) - 1, FH / 2 - (float) (Math.cos(a) * bt * 100) - 1,
                FW / 2 + (float) (Math.sin(a) * bt * 100) + 1, FH / 2 - (float) (Math.cos(a) * bt * 100) + 1, 0xFFFFFFFF);
        g.pose().popPose();
    }
}
