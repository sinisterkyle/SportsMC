package com.sportsmc.client.arcade;

import com.mojang.math.Axis;
import com.sportsmc.arcade.ArcadeGame;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Star Swarm: a space shooter. Each stage, 40 aliens swoop in along curved paths and lock into a swaying
 * formation; then they break off to dive-bomb you, shooting on the way down (overlords bring wasp escorts).
 * Clear the swarm to advance; stages get faster and meaner. Field is 224 x 288 units, scaled to the screen.
 */
public class StarSwarmScreen extends ArcadeGameScreen {

    static final float FW = 224, FH = 288;
    private static final float PLAYER_Y = 266, PLAYER_SPEED = 130, SHOT_SPEED = 330, ENEMY_SHOT_SPEED = 140;

    // ---- sprites (original pixel art). Letters are colors; '.' is empty --------------------------------------
    static final String[] SHIP = {
            ".....W.....",
            ".....W.....",
            "....WWW....",
            "....WRW....",
            "...WWWWW...",
            ".B.WWWWW.B.",
            ".B.WWBWW.B.",
            "WWWWWBWWWWW",
            "WWWWWWWWWWW",
            "WW.WWWWW.WW",
            "W...R.R...W",
            "....R.R....",
    };
    static final String[][] DRONE = {{
            "..Y.....Y..",
            "...Y...Y...",
            "..BBBBBBB..",
            ".BBYBBBYBB.",
            "BBBBBBBBBBB",
            "B.BBBBBBB.B",
            "B.B.....B.B",
            "...BB.BB...",
    }, {
            "..Y.....Y..",
            "B..Y...Y..B",
            "B.BBBBBBB.B",
            "BBBYBBBYBBB",
            "BBBBBBBBBBB",
            "..BBBBBBB..",
            "..B.....B..",
            ".B.......B.",
    }};
    static final String[][] WASP = {{
            "....W.W....",
            ".....W.....",
            ".RR.RRR.RR.",
            "RRRWRRRWRRR",
            "RRRRRRRRRRR",
            ".RR.RRR.RR.",
            "....R.R....",
            "...R...R...",
    }, {
            "....W.W....",
            "R....W....R",
            "RR..RRR..RR",
            "RRRWRRRWRRR",
            ".RRRRRRRRR.",
            "...RRRRR...",
            "....R.R....",
            "....R.R....",
    }};
    static final String[][] BOSS = {{
            "...G.....G...",
            "....G...G....",
            "..GGGGGGGGG..",
            ".GGCCGGGCCGG.",
            "GGGCCGGGCCGGG",
            "GGGGGGGGGGGGG",
            ".GG.GGGGG.GG.",
            ".G..G...G..G.",
            "G...........G",
    }, {
            "...G.....G...",
            "....G...G....",
            "..GGGGGGGGG..",
            ".GGCCGGGCCGG.",
            "GGGCCGGGCCGGG",
            ".GGGGGGGGGGG.",
            "..GGGGGGGGG..",
            "...G.G.G.G...",
            "....G...G....",
    }};

    static int colorOf(char c, boolean hurt) {
        return switch (c) {
            case 'W' -> 0xFFE8E8F0;
            case 'R' -> 0xFFFF3B3B;
            case 'B' -> 0xFF3B7BFF;
            case 'Y' -> 0xFFFFE03B;
            case 'G' -> hurt ? 0xFFB04DF0 : 0xFF35D07A;
            case 'C' -> hurt ? 0xFFFF7AE0 : 0xFF6FF2FF;
            default -> 0;
        };
    }

    // ---- entities -------------------------------------------------------------------------------------------

    private enum Kind { DRONE, WASP, BOSS }
    private enum State { WAITING, ENTERING, FORMATION, DIVING, RETURNING }

    private static final class Enemy {
        Kind kind;
        int row, col, hp;
        State state = State.WAITING;
        float x, y, angle;
        List<float[]> path = new ArrayList<>();
        int pathIndex;
        double startAt;
        float speed = 150;
        float[] shootAtY = {};
        int shotsFired;
        float escortDx; // escorts trail the overlord
        Enemy leader;
    }

    private static final class Shot { float x, y, vx, vy; }
    private static final class Spark { float x, y, vx, vy, life, age, size; int color; }

    private final Random random = new Random();
    private final List<Enemy> enemies = new ArrayList<>();
    private final List<Shot> shots = new ArrayList<>(), enemyShots = new ArrayList<>();
    private final List<Spark> sparks = new ArrayList<>();
    private float playerX = FW / 2;
    private int lives, stage, nextExtraLife;
    private boolean playerAlive;
    private double deadAt = -10, invulnUntil, stageStart, stageClearAt = -1, lastShotAt = -10, nextDiveAt;
    private double hurtFlash = -10;

    public StarSwarmScreen() {
        super(ArcadeGame.STAR_SWARM);
    }

    // ================================================================== setup

    @Override
    protected void reset() {
        enemies.clear();
        shots.clear();
        enemyShots.clear();
        sparks.clear();
        lives = 3;
        stage = 0;
        nextExtraLife = 20_000;
        playerX = FW / 2;
        playerAlive = true;
        invulnUntil = 0;
        nextStage();
    }

    private void nextStage() {
        stage++;
        stageStart = time;
        stageClearAt = -1;
        enemies.clear();
        enemyShots.clear();
        nextDiveAt = time + 9;
        sound(SoundEvents.NOTE_BLOCK_BELL.value(), 1.2f, 0.6f);
        // Five groups of eight, each with its own entry path.
        int[][][] groups = {
                {{3, 3}, {3, 4}, {3, 5}, {3, 6}, {1, 3}, {1, 4}, {1, 5}, {1, 6}},
                {{0, 3}, {1, 1}, {0, 4}, {1, 2}, {0, 5}, {1, 7}, {0, 6}, {1, 8}},
                {{2, 1}, {2, 2}, {2, 3}, {2, 4}, {2, 5}, {2, 6}, {2, 7}, {2, 8}},
                {{3, 0}, {3, 1}, {3, 2}, {4, 0}, {3, 7}, {3, 8}, {3, 9}, {4, 9}},
                {{4, 1}, {4, 2}, {4, 3}, {4, 4}, {4, 5}, {4, 6}, {4, 7}, {4, 8}},
        };
        boolean[] fromTop = {true, false, false, true, true};
        int[] side = {0, -1, 1, -1, 1}; // 0 = alternate left/right
        for (int gi = 0; gi < groups.length; gi++) {
            for (int j = 0; j < groups[gi].length; j++) {
                Enemy e = new Enemy();
                e.row = groups[gi][j][0];
                e.col = groups[gi][j][1];
                e.kind = e.row == 0 ? Kind.BOSS : e.row <= 2 ? Kind.WASP : Kind.DRONE;
                e.hp = e.kind == Kind.BOSS ? 2 : 1;
                int s = side[gi] != 0 ? side[gi] : (j % 2 == 0 ? -1 : 1);
                e.path = fromTop[gi] ? topEntry(s) : sideEntry(s);
                e.startAt = stageStart + 2.0 + gi * 3.0 + (side[gi] == 0 ? (j / 2) * 0.14 : j * 0.14);
                e.speed = 150 + stage * 6;
                e.x = e.path.get(0)[0];
                e.y = e.path.get(0)[1];
                enemies.add(e);
            }
        }
    }

    // ================================================================== paths

    private static List<float[]> bezier(List<float[]> out, float[] p0, float[] p1, float[] p2, float[] p3) {
        for (int i = out.isEmpty() ? 0 : 1; i <= 16; i++) {
            float t = i / 16f, u = 1 - t;
            out.add(new float[]{
                    u * u * u * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t * t * t * p3[0],
                    u * u * u * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t * t * t * p3[1]});
        }
        return out;
    }

    private static float[] p(float x, float y) { return new float[]{x, y}; }

    /** Swoops down from the top, curls out to the side and loops back up toward the formation. */
    private static List<float[]> topEntry(int s) {
        float c = FW / 2;
        List<float[]> out = new ArrayList<>();
        bezier(out, p(c + s * 20, -16), p(c + s * 20, 80), p(c + s * 100, 90), p(c + s * 90, 170));
        bezier(out, p(c + s * 90, 170), p(c + s * 84, 240), p(c + s * 18, 240), p(c + s * 22, 168));
        bezier(out, p(c + s * 22, 168), p(c + s * 26, 130), p(c + s * 50, 120), p(c + s * 40, 100));
        return out;
    }

    /** Sweeps in low from one side, crosses the middle and loops up. */
    private static List<float[]> sideEntry(int s) {
        float c = FW / 2;
        List<float[]> out = new ArrayList<>();
        bezier(out, p(c + s * 130, 236), p(c + s * 60, 236), p(c + s * 10, 210), p(c - s * 10, 160));
        bezier(out, p(c - s * 10, 160), p(c - s * 30, 110), p(c + s * 30, 70), p(c + s * 40, 120));
        bezier(out, p(c + s * 40, 120), p(c + s * 46, 150), p(c + s * 10, 150), p(c, 110));
        return out;
    }

    /** Peels off with a little loop, then weaves down toward the player and off the bottom. */
    private List<float[]> divePath(Enemy e) {
        int s = e.x < FW / 2 ? -1 : 1;
        List<float[]> out = new ArrayList<>();
        float tx = Math.max(20, Math.min(FW - 20, playerX + (random.nextFloat() - 0.5f) * 40));
        bezier(out, p(e.x, e.y), p(e.x + s * 10, e.y - 30), p(e.x + s * 40, e.y - 16), p(e.x + s * 34, e.y + 18));
        float wig = 30 + random.nextFloat() * 30;
        bezier(out, p(e.x + s * 34, e.y + 18), p(e.x + s * 20, 140), p(tx - s * wig, 170), p(tx, 215));
        bezier(out, p(tx, 215), p(tx + s * wig, 250), p(tx + s * wig * 0.5f, 290), p(tx, FH + 24));
        return out;
    }

    // ================================================================== formation

    private float spread() {
        boolean allIn = true;
        for (Enemy e : enemies) if (e.state == State.WAITING || e.state == State.ENTERING) { allIn = false; break; }
        return allIn ? 1f + 0.09f * (float) Math.sin((time - stageStart) * 1.3) : 1f;
    }

    private float slotX(Enemy e) {
        float sway = (float) Math.sin((time - stageStart) * 0.9) * 10;
        return FW / 2 + (e.col - 4.5f) * 16 * spread() + sway;
    }

    private float slotY(Enemy e) {
        return 34 + e.row * 15;
    }

    // ================================================================== update

    @Override
    protected void update() {
        float dt = (float) STEP;
        // Player.
        if (playerAlive) {
            boolean left = isHeld(GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_A), right = isHeld(GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_D);
            if (left != right) playerX += (left ? -1 : 1) * PLAYER_SPEED * dt;
            playerX = Math.max(8, Math.min(FW - 8, playerX));
            if (isHeld(GLFW.GLFW_KEY_SPACE, GLFW.GLFW_KEY_UP, GLFW.GLFW_KEY_W) && time - lastShotAt > 0.28) fire();
        } else if (time - deadAt > 2.5) {
            if (lives > 0) {
                playerAlive = true;
                playerX = FW / 2;
                invulnUntil = time + 2.0;
            } else if (time - deadAt > 1.5) {
                gameOver();
                return;
            }
        }

        // Shots.
        for (Iterator<Shot> it = shots.iterator(); it.hasNext(); ) {
            Shot s = it.next();
            s.y -= SHOT_SPEED * dt;
            if (s.y < -8) { it.remove(); continue; }
            for (Enemy e : enemies) {
                if (e.state == State.WAITING) continue;
                float hw = e.kind == Kind.BOSS ? 7 : 6;
                if (Math.abs(s.x - e.x) < hw && Math.abs(s.y - e.y) < 6) { hit(e); it.remove(); break; }
            }
        }
        enemies.removeIf(e -> e.hp <= 0);
        for (Iterator<Shot> it = enemyShots.iterator(); it.hasNext(); ) {
            Shot s = it.next();
            s.x += s.vx * dt;
            s.y += s.vy * dt;
            if (s.y > FH + 8 || s.x < -8 || s.x > FW + 8) { it.remove(); continue; }
            if (playerAlive && time > invulnUntil && Math.abs(s.x - playerX) < 4.5f && Math.abs(s.y - PLAYER_Y) < 6) {
                it.remove();
                killPlayer(); // clears enemyShots, so stop walking that list right here
                break;
            }
        }

        // Enemies.
        for (Enemy e : enemies) moveEnemy(e, dt);
        // Diving enemies that touch the ship.
        if (playerAlive && time > invulnUntil) {
            for (Enemy e : enemies) {
                if ((e.state == State.DIVING || e.state == State.ENTERING) && Math.abs(e.x - playerX) < 9 && Math.abs(e.y - PLAYER_Y) < 9) {
                    e.hp = 0;
                    explode(e.x, e.y, e.kind);
                    killPlayer();
                    break;
                }
            }
            enemies.removeIf(e -> e.hp <= 0);
        }
        scheduleDives();

        // Stage cleared?
        if (enemies.isEmpty()) {
            if (stageClearAt < 0) stageClearAt = time;
            else if (time - stageClearAt > 2.5) nextStage();
        }

        // Sparks.
        for (Iterator<Spark> it = sparks.iterator(); it.hasNext(); ) {
            Spark sp = it.next();
            sp.age += dt;
            if (sp.age >= sp.life) { it.remove(); continue; }
            sp.x += sp.vx * dt;
            sp.y += sp.vy * dt;
            sp.vx *= 0.97f;
            sp.vy *= 0.97f;
        }
    }

    private void fire() {
        if (shots.size() >= 2) return;
        Shot s = new Shot();
        s.x = playerX;
        s.y = PLAYER_Y - 8;
        shots.add(s);
        lastShotAt = time;
        sound(SoundEvents.NOTE_BLOCK_HAT.value(), 2.0f, 0.25f);
    }

    private void moveEnemy(Enemy e, float dt) {
        switch (e.state) {
            case WAITING -> {
                if (time >= e.startAt) e.state = State.ENTERING;
            }
            case ENTERING, DIVING -> {
                float step = e.speed * dt;
                if (e.leader != null && e.leader.hp > 0 && e.leader.state == State.DIVING) {
                    // Escorts fly in formation with the overlord.
                    float tx = e.leader.x + e.escortDx, ty = e.leader.y + 10;
                    face(e, tx - e.x, ty - e.y);
                    e.x = tx;
                    e.y = ty;
                } else {
                    while (step > 0 && e.pathIndex < e.path.size()) {
                        float[] tgt = e.path.get(e.pathIndex);
                        float dx = tgt[0] - e.x, dy = tgt[1] - e.y, d = (float) Math.sqrt(dx * dx + dy * dy);
                        if (d <= step) { e.x = tgt[0]; e.y = tgt[1]; step -= d; e.pathIndex++; }
                        else { face(e, dx, dy); e.x += dx / d * step; e.y += dy / d * step; step = 0; }
                    }
                }
                if (e.state == State.DIVING) {
                    // Shoot at the player on the way down.
                    if (e.shotsFired < e.shootAtY.length && e.y >= e.shootAtY[e.shotsFired]) {
                        e.shotsFired++;
                        enemyShoot(e);
                    }
                    if (e.y > FH + 12 || (e.leader != null && e.pathIndex >= e.path.size() && e.y > FH)) {
                        // Off the bottom: come back in from the top to the formation slot.
                        e.y = -16;
                        e.x = slotX(e);
                        e.leader = null;
                        e.state = State.RETURNING;
                    }
                }
                if (e.state == State.ENTERING && e.pathIndex >= e.path.size()) e.state = State.RETURNING;
                if (e.leader != null && (e.leader.hp <= 0 || e.leader.state != State.DIVING) && e.state == State.DIVING
                        && e.pathIndex >= e.path.size()) {
                    e.leader = null;
                    e.path = divePath(e);
                    e.pathIndex = 0;
                }
                if (e.leader != null && (e.leader.hp <= 0 || e.leader.state != State.DIVING)) {
                    // Overlord gone: carry on with a dive of its own.
                    e.leader = null;
                    e.path = divePath(e);
                    e.pathIndex = 0;
                }
            }
            case RETURNING -> {
                float tx = slotX(e), ty = slotY(e);
                float dx = tx - e.x, dy = ty - e.y, d = (float) Math.sqrt(dx * dx + dy * dy);
                float step = e.speed * dt;
                if (d <= step + 0.5f) { e.state = State.FORMATION; e.x = tx; e.y = ty; e.angle = 0; }
                else { face(e, dx, dy); e.x += dx / d * step; e.y += dy / d * step; }
            }
            case FORMATION -> {
                e.x = slotX(e);
                e.y = slotY(e);
                e.angle *= 0.85f;
            }
        }
    }

    /** Points the sprite where it's going (sprites face down, toward the player, by default). */
    private static void face(Enemy e, float dx, float dy) {
        if (dx * dx + dy * dy < 1e-4) return;
        e.angle = (float) Math.toDegrees(Math.atan2(dy, dx)) - 90;
    }

    private void scheduleDives() {
        if (!playerAlive || time < nextDiveAt) return;
        List<Enemy> ready = new ArrayList<>();
        int diving = 0;
        for (Enemy e : enemies) {
            if (e.state == State.FORMATION) ready.add(e);
            else if (e.state == State.DIVING) diving++;
        }
        int maxDivers = Math.min(7, 2 + stage / 2 + (enemies.size() <= 8 ? 3 : 0));
        double gap = Math.max(0.55, 2.4 - stage * 0.2) * (enemies.size() <= 8 ? 0.5 : 1);
        nextDiveAt = time + gap * (0.6 + random.nextDouble() * 0.8);
        if (ready.isEmpty() || diving >= maxDivers) return;
        Enemy e = ready.get(random.nextInt(ready.size()));
        startDive(e);
        if (e.kind == Kind.BOSS) {
            // Up to two wasps from the row below come along as escorts.
            int added = 0;
            for (Enemy w : ready) {
                if (added >= 2 || w == e || w.kind != Kind.WASP || w.row != 1 || Math.abs(w.col - e.col) > 2) continue;
                w.state = State.DIVING;
                w.leader = e;
                w.escortDx = added == 0 ? -12 : 12;
                w.shotsFired = 0;
                w.shootAtY = new float[]{150};
                w.speed = e.speed;
                added++;
            }
        }
    }

    private void startDive(Enemy e) {
        e.state = State.DIVING;
        e.path = divePath(e);
        e.pathIndex = 0;
        e.speed = 150 + stage * 8;
        e.shotsFired = 0;
        int n = Math.min(3, 1 + stage / 3);
        e.shootAtY = new float[n];
        for (int i = 0; i < n; i++) e.shootAtY[i] = 110 + i * 34 + random.nextFloat() * 10;
        sound(SoundEvents.NOTE_BLOCK_FLUTE.value(), 1.6f, 0.25f);
    }

    private void enemyShoot(Enemy e) {
        if (!playerAlive || enemyShots.size() > 8 + stage) return;
        Shot s = new Shot();
        s.x = e.x;
        s.y = e.y + 6;
        float dx = playerX - e.x, dy = PLAYER_Y - e.y;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        s.vx = dx / len * ENEMY_SHOT_SPEED;
        s.vy = Math.max(0.5f * ENEMY_SHOT_SPEED, dy / len * ENEMY_SHOT_SPEED);
        s.vx = Math.max(-60, Math.min(60, s.vx));
        enemyShots.add(s);
    }

    private void hit(Enemy e) {
        e.hp--;
        if (e.hp > 0) {
            hurtFlash = time;
            sound(SoundEvents.NOTE_BLOCK_COW_BELL.value(), 1.4f, 0.4f);
            return;
        }
        boolean diving = e.state == State.DIVING || e.state == State.ENTERING;
        int pts = switch (e.kind) {
            case DRONE -> diving ? 100 : 50;
            case WASP -> diving ? 160 : 80;
            case BOSS -> diving ? 400 : 150;
        };
        addScore(pts);
        explode(e.x, e.y, e.kind);
    }

    private void addScore(int pts) {
        score += pts;
        if (score >= nextExtraLife) {
            lives++;
            nextExtraLife = nextExtraLife == 20_000 ? 70_000 : nextExtraLife + 70_000;
            sound(SoundEvents.PLAYER_LEVELUP, 1.6f, 0.5f);
        }
    }

    private void killPlayer() {
        playerAlive = false;
        deadAt = time;
        lives--;
        shots.clear();
        for (int i = 0; i < 50; i++) spark(playerX, PLAYER_Y, i % 3 == 0 ? 0xFFFF3B3B : i % 3 == 1 ? 0xFFFFE03B : 0xFFFFFFFF, 90, 1.2f);
        sound(SoundEvents.GENERIC_EXPLODE, 1.0f, 0.5f);
        // Divers go home so you get a fair restart.
        for (Enemy e : enemies) if (e.state == State.DIVING) { e.leader = null; e.state = State.RETURNING; }
        enemyShots.clear();
    }

    private void explode(float x, float y, Kind kind) {
        int c1 = kind == Kind.BOSS ? 0xFF35D07A : kind == Kind.WASP ? 0xFFFF3B3B : 0xFF3B7BFF;
        for (int i = 0; i < 22; i++) spark(x, y, i % 2 == 0 ? c1 : (i % 3 == 0 ? 0xFFFFFFFF : 0xFFFFE03B), 70, 0.6f);
        sound(SoundEvents.NOTE_BLOCK_SNARE.value(), 0.7f + random.nextFloat() * 0.3f, 0.45f);
    }

    private void spark(float x, float y, int color, float speed, float life) {
        Spark s = new Spark();
        double a = random.nextDouble() * Math.PI * 2, v = speed * (0.3 + random.nextDouble() * 0.7);
        s.x = x;
        s.y = y;
        s.vx = (float) (Math.cos(a) * v);
        s.vy = (float) (Math.sin(a) * v);
        s.life = life * (0.6f + random.nextFloat() * 0.6f);
        s.size = 1 + random.nextFloat() * 1.5f;
        s.color = color;
        sparks.add(s);
    }

    // ================================================================== drawing

    private float scale() {
        return Math.min((height - 24) / FH, (width - 20) / FW);
    }

    @Override
    protected void draw(GuiGraphics g) {
        float s = scale();
        float ox = width / 2f - FW * s / 2, oy = (height - FH * s) / 2f - 4;
        g.fill((int) ox - 2, (int) oy - 2, (int) (ox + FW * s) + 2, (int) (oy + FH * s) + 2, 0xFF2A2A44);
        g.fill((int) ox, (int) oy, (int) (ox + FW * s), (int) (oy + FH * s), 0xFF000000);
        g.flush(); // batched drawing: finish what's queued before clipping
        g.enableScissor((int) ox, (int) oy, (int) (ox + FW * s), (int) (oy + FH * s));
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(s, s, 1);

        drawStars(g, time, FW, FH);
        int frame = (int) (time * 2.5) % 2;
        for (Enemy e : enemies) {
            if (e.state == State.WAITING) continue;
            boolean hurt = e.kind == Kind.BOSS && e.hp == 1;
            String[] spr = (e.kind == Kind.BOSS ? BOSS : e.kind == Kind.WASP ? WASP : DRONE)[e.state == State.FORMATION ? frame : 1];
            sprite(g, spr, e.x, e.y, e.angle, hurt, hurt && time - hurtFlash < 0.1);
        }
        for (Shot sh : shots) {
            fillF(g, sh.x - 0.5f, sh.y - 3, sh.x + 0.5f, sh.y + 3, 0xFFFFFF8A);
            fillF(g, sh.x - 0.5f, sh.y - 3, sh.x + 0.5f, sh.y - 1, 0xFFFFFFFF);
        }
        for (Shot sh : enemyShots) {
            fillF(g, sh.x - 1, sh.y - 2, sh.x + 1, sh.y + 2, 0xFFFF5A5A);
            fillF(g, sh.x - 0.5f, sh.y - 1, sh.x + 0.5f, sh.y + 1, 0xFFFFFFFF);
        }
        boolean blink = time < invulnUntil && ((int) (time * 10)) % 2 == 0;
        if (playerAlive && !blink) sprite(g, SHIP, playerX, PLAYER_Y, 0, false, false);
        for (Spark sp : sparks) {
            int a = (int) (255 * (1 - sp.age / sp.life));
            fillF(g, sp.x - sp.size / 2, sp.y - sp.size / 2, sp.x + sp.size / 2, sp.y + sp.size / 2, withAlpha(sp.color, a));
        }
        g.pose().popPose();
        g.flush();
        g.disableScissor();

        // HUD.
        int left = (int) ox, right = (int) (ox + FW * s), top = (int) oy;
        g.drawString(font, "SCORE", left + 4, top + 3, 0xFFFF5A5A);
        g.drawString(font, String.format("%,d", score), left + 4, top + 13, TEXT);
        String hi = String.format("%,d", Math.max(score, ClientArcadeData.personalBest(game)));
        g.drawCenteredString(font, "BEST", (left + right) / 2, top + 3, 0xFFFF5A5A);
        g.drawCenteredString(font, hi, (left + right) / 2, top + 13, TEXT);
        String st = "STAGE " + stage;
        g.drawString(font, st, right - font.width(st) - 4, top + 3, 0xFF6FF2FF);
        // Lives as little ships.
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(s, s, 1);
        for (int i = 0; i < Math.min(6, lives - (playerAlive ? 1 : 0)); i++) sprite(g, SHIP, 10 + i * 13, FH - 8, 0, false, false);
        g.pose().popPose();

        if (time - stageStart < 2.2 && stageClearAt < 0) {
            g.drawCenteredString(font, "STAGE " + stage, (left + right) / 2, (int) (oy + FH * s / 2), 0xFF6FF2FF);
            if (stage == 1) g.drawCenteredString(font, "← → move   SPACE fire", (left + right) / 2, (int) (oy + FH * s / 2) + 12, DIM);
        }
        if (stageClearAt >= 0) g.drawCenteredString(font, "STAGE CLEAR!", (left + right) / 2, (int) (oy + FH * s / 2), GOLD);
        if (!playerAlive && lives > 0 && !over && time - deadAt > 0.8) {
            g.drawCenteredString(font, "READY", (left + right) / 2, (int) (oy + FH * s * 0.62f), GOLD);
        }
        g.drawCenteredString(font, "← → move   SPACE fire   P pause   ESC menu", width / 2, height - 11, 0xFF6A6A88);
    }

    /** Draws a pixel sprite centered at (x, y), rotated by deg. */
    static void sprite(GuiGraphics g, String[] rows, float x, float y, float deg, boolean hurt, boolean flash) {
        int h = rows.length, w = rows[0].length();
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        if (deg != 0) g.pose().mulPose(Axis.ZP.rotationDegrees(deg));
        g.pose().translate(-w / 2f, -h / 2f, 0);
        for (int r = 0; r < h; r++) {
            String row = rows[r];
            int run = -1;
            int runColor = 0;
            for (int c = 0; c <= w; c++) {
                int col = c < w ? colorOf(row.charAt(c), hurt) : 0;
                if (flash && col != 0) col = 0xFFFFFFFF;
                if (col != runColor) {
                    if (runColor != 0) fillF(g, run, r, c, r + 1, runColor); // one fill per run of same color
                    run = c;
                    runColor = col;
                }
            }
        }
        g.pose().popPose();
    }

    static void drawStars(GuiGraphics g, double t, float w, float h) {
        Random r = new Random(7);
        for (int i = 0; i < 70; i++) {
            float speed = 15 + r.nextFloat() * 60;
            float x = r.nextFloat() * w;
            float y = (float) ((r.nextFloat() * h + t * speed) % h);
            int[] palette = {0xFFFFFFFF, 0xFF8AB4FF, 0xFFFFE08A, 0xFFFF8AD0, 0xFF8AFFC0};
            int c = palette[r.nextInt(palette.length)];
            float tw = 0.5f + 0.5f * (float) Math.sin(t * (2 + r.nextFloat() * 3) + i);
            if (tw < 0.25f) continue;
            fillF(g, x, y, x + 1, y + 1, withAlpha(c, (int) (120 + 135 * tw)));
        }
    }

    // ================================================================== menu preview

    /** Attract-mode loop for the arcade menu: the swarm swaying, a diver swooping, the ship firing back. */
    public static void drawPreview(GuiGraphics g, int x, int y, int w, int h, double t) {
        float s = Math.min(h / FH, w / FW);
        float ox = x + w / 2f - FW * s / 2, oy = y + h / 2f - FH * s / 2;
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(s, s, 1);
        drawStars(g, t, FW, FH);
        int frame = (int) (t * 2.5) % 2;
        float sway = (float) Math.sin(t * 0.9) * 10;
        int[] counts = {4, 8, 8, 10, 10};
        for (int row = 0; row < 5; row++) {
            for (int i = 0; i < counts[row]; i++) {
                int col = (10 - counts[row]) / 2 + i;
                float ex = FW / 2 + (col - 4.5f) * 16 + sway, ey = 34 + row * 15;
                String[][] kind = row == 0 ? BOSS : row <= 2 ? WASP : DRONE;
                sprite(g, kind[frame], ex, ey, 0, false, false);
            }
        }
        // One diver looping down.
        double dt = t % 4;
        float dx = FW / 2 + (float) Math.sin(dt * 2.2) * 60, dy = 40 + (float) dt * 60;
        sprite(g, WASP[1], dx, dy, (float) Math.toDegrees(Math.atan2(60, Math.cos(dt * 2.2) * 132)) - 90, false, false);
        float px = FW / 2 + (float) Math.sin(t * 1.3) * 50;
        sprite(g, SHIP, px, PLAYER_Y, 0, false, false);
        float shotY = PLAYER_Y - 8 - (float) ((t * 330) % 240);
        fillF(g, px - 0.5f, shotY - 3, px + 0.5f, shotY + 3, 0xFFFFFF8A);
        g.pose().popPose();
    }
}
