package com.sportsmc.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.fml.loading.FMLPaths;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Random;

/**
 * Looks for the air hockey table. Purely cosmetic and personal: each player picks their own theme (the
 * arrows next to the table, or the left / right arrow keys) and it's remembered between sessions.
 *
 * @param myMallet    your mallet's color (theirs uses theirMallet), so you can always tell them apart
 * @param pattern     the animated decoration drawn on the surface
 * @param glow        neon-style glowing lines
 */
public record AirHockeyTheme(String name, int rail, int railLight, int surfaceTop, int surfaceBottom, int detail,
                             int centerLine, int creaseLine, int slot, int myMallet, int theirMallet,
                             int puck, int puckRim, int trail, int accent, Pattern pattern, boolean glow) {

    public enum Pattern { HOLES, STARS, GRID, SPLOTCHES, BUBBLES, WAVES, EMBERS, SNOW }

    public static final List<AirHockeyTheme> THEMES = List.of(
            new AirHockeyTheme("Classic", 0xFF23262E, 0xFF3A3F4A, 0xFF2369C9, 0xFF1A4F9C, 0x40BFE0FF,
                    0xFFE23B3B, 0x90FFFFFF, 0xFF050608, 0xFF3A7BFF, 0xFFFF4A4A, 0xFF15151A, 0xFFFFD23C, 0xFFD23C, 0xFFFFC83D,
                    Pattern.HOLES, false),
            new AirHockeyTheme("Space", 0xFF1A1630, 0xFF3B2F6B, 0xFF0B0820, 0xFF1D1045, 0xFFFFFFFF,
                    0xFFB06CFF, 0x80B9A0FF, 0xFF000000, 0xFF4FC3FF, 0xFFFF7AE0, 0xFFF4F6FF, 0xFF57E3FF, 0x57E3FF, 0xFFB9A0FF,
                    Pattern.STARS, true),
            new AirHockeyTheme("Neon", 0xFF0A0A0F, 0xFFFF2BD6, 0xFF07070C, 0xFF0E0E18, 0xFF00F0FF,
                    0xFFFF2BD6, 0xFF00F0FF, 0xFF000000, 0xFF39FF14, 0xFFFF2BD6, 0xFFFFFFFF, 0xFFFF2BD6, 0xFF2BD6, 0xFF00F0FF,
                    Pattern.GRID, true),
            new AirHockeyTheme("Zombie", 0xFF2B2A22, 0xFF4A4636, 0xFF3D4A33, 0xFF22291C, 0xFF7BC043,
                    0xFF8A0F0F, 0x907BC043, 0xFF0B0D07, 0xFF7BC043, 0xFF8E5BA8, 0xFFE8E2CF, 0xFF4E7A27, 0x7BC043, 0xFF9CE05A,
                    Pattern.SPLOTCHES, false),
            new AirHockeyTheme("Bubblegum", 0xFFE0559C, 0xFFFF8CC6, 0xFFFFB3D9, 0xFFFF7FBF, 0xFFFFFFFF,
                    0xFFFF2E93, 0xC0FFFFFF, 0xFF8A1A55, 0xFF27C7B8, 0xFF9B5CF6, 0xFFFFFFFF, 0xFFFF2E93, 0xFF6EB4, 0xFFFFFFFF,
                    Pattern.BUBBLES, false),
            new AirHockeyTheme("Ocean", 0xFF0F3A4F, 0xFF2C7A92, 0xFF0F6E9C, 0xFF07354F, 0xFFBFF4FF,
                    0xFFE8FFFF, 0x80BFF4FF, 0xFF03141C, 0xFF2FE0C0, 0xFFFF8A4C, 0xFFFF7F50, 0xFFFFE4B5, 0xFFA070, 0xFF7FF5FF,
                    Pattern.WAVES, false),
            new AirHockeyTheme("Lava", 0xFF1C0D08, 0xFF5A1E0E, 0xFF3A0D06, 0xFF120403, 0xFFFF7A1A,
                    0xFFFF5A00, 0x90FFB347, 0xFF000000, 0xFFFFD23C, 0xFFB01E1E, 0xFF161212, 0xFFFF6A00, 0xFF6A00, 0xFFFFB347,
                    Pattern.EMBERS, true),
            new AirHockeyTheme("Arctic", 0xFF9FB8CC, 0xFFE6F2FA, 0xFFEAF6FF, 0xFFBFDDF2, 0xFFFFFFFF,
                    0xFF2E7BD6, 0x902E7BD6, 0xFF35506A, 0xFF1F6FE0, 0xFFE0404A, 0xFF1B2A3A, 0xFFFFFFFF, 0x9FD8FF, 0xFF2E7BD6,
                    Pattern.SNOW, false)
    );

    // ------------------------------------------------------------------ chosen theme (saved)

    private static final Path FILE = FMLPaths.CONFIGDIR.get().resolve("sportsmc-airhockey-theme.txt");
    private static int index = load();

    public static AirHockeyTheme current() {
        return THEMES.get(Math.floorMod(index, THEMES.size()));
    }

    public static void cycle(int step) {
        index = Math.floorMod(index + step, THEMES.size());
        try {
            Files.writeString(FILE, current().name());
        } catch (Exception ignored) {
            // Saving the choice is a convenience only.
        }
    }

    private static int load() {
        try {
            if (Files.exists(FILE)) {
                String name = Files.readString(FILE).trim();
                for (int i = 0; i < THEMES.size(); i++) if (THEMES.get(i).name().equalsIgnoreCase(name)) return i;
            }
        } catch (Exception ignored) {
        }
        return 0;
    }

    // ------------------------------------------------------------------ surface decoration

    /** Draws the theme's animated pattern on the table surface (call with a scissor around the table). */
    public void drawPattern(GuiGraphics g, int l, int t, int w, int h, long ms) {
        Random r = new Random(name.hashCode());
        double sec = ms / 1000.0;
        switch (pattern) {
            case HOLES -> {
                int step = Math.max(8, w / 14);
                for (int y = t + step / 2; y < t + h; y += step)
                    for (int x = l + step / 2; x < l + w; x += step) g.fill(x, y, x + 1, y + 1, detail);
            }
            case STARS -> {
                for (int i = 0; i < 90; i++) {
                    int x = l + r.nextInt(w), y = t + r.nextInt(h);
                    double tw = 0.5 + 0.5 * Math.sin(sec * (1.5 + r.nextDouble() * 2) + i);
                    int a = (int) (40 + 200 * tw);
                    int size = r.nextInt(10) == 0 ? 2 : 1;
                    g.fill(x, y, x + size, y + size, (a << 24) | (detail & 0xFFFFFF));
                }
                // A faint ringed planet in one corner.
                fillCircle(g, l + w * 0.82, t + h * 0.18, w * 0.09, 0x30B06CFF);
                ring(g, l + w * 0.82, t + h * 0.18, w * 0.14, 0x50B9A0FF, Math.PI * 0.9, Math.PI * 2.1);
            }
            case GRID -> {
                int step = Math.max(10, w / 10);
                int shift = (int) (sec * 12) % step;
                for (int y = t - step + shift; y < t + h; y += step) g.fill(l, y, l + w, y + 1, 0x3000F0FF);
                for (int x = l; x < l + w; x += step) g.fill(x, t, x + 1, t + h, 0x30FF2BD6);
            }
            case SPLOTCHES -> {
                for (int i = 0; i < 14; i++) {
                    double x = l + r.nextInt(w), y = t + r.nextInt(h), rad = w * (0.03 + r.nextDouble() * 0.06);
                    fillCircle(g, x, y, rad, 0x305C8A2E);
                    fillCircle(g, x + rad * 0.5, y - rad * 0.3, rad * 0.5, 0x307BC043);
                }
                // Slime dripping from both end rails.
                for (int i = 0; i < 9; i++) {
                    int x = l + r.nextInt(w);
                    double len = h * (0.03 + 0.05 * (0.5 + 0.5 * Math.sin(sec * (0.6 + r.nextDouble()) + i)));
                    g.fill(x, t, x + 2, t + (int) len, 0xB07BC043);
                    fillCircle(g, x + 1, t + len, 2.2, 0xB07BC043);
                    int x2 = l + r.nextInt(w);
                    g.fill(x2, t + h - (int) len, x2 + 2, t + h, 0x907BC043);
                }
            }
            case BUBBLES -> {
                for (int i = 0; i < 26; i++) {
                    double speed = 6 + r.nextDouble() * 14;
                    double x = l + r.nextInt(w) + Math.sin(sec + i) * 3;
                    double y = t + h - ((r.nextDouble() * h + sec * speed) % h);
                    double rad = 2 + r.nextDouble() * 6;
                    ring(g, x, y, rad, 0xA0FFFFFF, 0, Math.PI * 2);
                    g.fill((int) (x - rad * 0.4), (int) (y - rad * 0.4), (int) (x - rad * 0.4) + 1, (int) (y - rad * 0.4) + 1, 0xE0FFFFFF);
                }
            }
            case WAVES -> {
                for (int row = 0; row < 9; row++) {
                    double baseY = t + h * (row + 0.5) / 9.0;
                    for (int x = l; x < l + w; x += 2) {
                        double y = baseY + Math.sin(x * 0.08 + sec * 1.6 + row) * 3;
                        g.fill(x, (int) y, x + 2, (int) y + 1, 0x40BFF4FF);
                    }
                }
                for (int i = 0; i < 16; i++) {
                    double y = t + h - ((r.nextDouble() * h + sec * (8 + r.nextDouble() * 10)) % h);
                    double x = l + r.nextInt(w) + Math.sin(sec * 2 + i) * 2;
                    ring(g, x, y, 1.5 + r.nextDouble() * 2.5, 0x90BFF4FF, 0, Math.PI * 2);
                }
            }
            case EMBERS -> {
                for (int i = 0; i < 12; i++) {
                    // Glowing cracks.
                    double x = l + r.nextInt(w), y = t + r.nextInt(h);
                    double ang = r.nextDouble() * Math.PI;
                    int glow = (int) (60 + 60 * (0.5 + 0.5 * Math.sin(sec * 2 + i)));
                    for (int k = 0; k < 14; k++) {
                        ang += (r.nextDouble() - 0.5) * 0.8;
                        x += Math.cos(ang) * 2;
                        y += Math.sin(ang) * 2;
                        g.fill((int) x, (int) y, (int) x + 2, (int) y + 1, (glow << 24) | 0xFF6A00);
                    }
                }
                for (int i = 0; i < 24; i++) {
                    double y = t + h - ((r.nextDouble() * h + sec * (10 + r.nextDouble() * 20)) % h);
                    double x = l + r.nextInt(w) + Math.sin(sec * 3 + i) * 2;
                    g.fill((int) x, (int) y, (int) x + 1, (int) y + 1, 0xE0FFB347);
                }
            }
            case SNOW -> {
                for (int i = 0; i < 50; i++) {
                    double y = t + ((r.nextDouble() * h + sec * (6 + r.nextDouble() * 10)) % h);
                    double x = l + r.nextInt(w) + Math.sin(sec + i) * 4;
                    int size = r.nextInt(4) == 0 ? 2 : 1;
                    g.fill((int) x, (int) y, (int) x + size, (int) y + size, 0xE0FFFFFF);
                }
                for (int i = 0; i < 6; i++) {
                    double x = l + r.nextInt(w), y = t + r.nextInt(h);
                    g.fill((int) x, (int) y, (int) x + (int) (w * 0.12), (int) y + 1, 0x60FFFFFF); // ice scratches
                }
            }
        }
    }

    // ------------------------------------------------------------------ shape helpers

    public static void fillCircle(GuiGraphics g, double cx, double cy, double r, int color) {
        int r0 = (int) Math.ceil(r);
        for (int dy = -r0; dy <= r0; dy++) {
            double half = Math.sqrt(Math.max(0, r * r - dy * dy));
            if (half <= 0) continue;
            int x0 = (int) Math.round(cx - half), x1 = (int) Math.round(cx + half);
            int y = (int) Math.round(cy + dy);
            g.fill(x0, y, x1, y + 1, color);
        }
    }

    public static void ring(GuiGraphics g, double cx, double cy, double r, int color, double a0, double a1) {
        int n = Math.max(24, (int) (r * 4));
        for (int i = 0; i <= n; i++) {
            double a = a0 + (a1 - a0) * i / n;
            int x = (int) Math.round(cx + Math.cos(a) * r), y = (int) Math.round(cy + Math.sin(a) * r);
            g.fill(x, y, x + 1, y + 1, color);
        }
    }
}
