package com.sportsmc.client;

import com.sportsmc.SportsMC;
import com.sportsmc.entity.TennisPlayerEntity;
import com.sportsmc.lobby.Lobby;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Tennis players: HOME in blue, AWAY in red, racket in hand. */
public class TennisPlayerRenderer extends HumanoidMobRenderer<TennisPlayerEntity, PlayerModel<TennisPlayerEntity>> {

    private static final ResourceLocation HOME = new ResourceLocation(SportsMC.MODID, "textures/entity/tennis_home.png");
    private static final ResourceLocation AWAY = new ResourceLocation(SportsMC.MODID, "textures/entity/tennis_away.png");

    public TennisPlayerRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(TennisPlayerEntity entity) {
        return entity.side() == Lobby.Side.HOME ? HOME : AWAY;
    }
}
