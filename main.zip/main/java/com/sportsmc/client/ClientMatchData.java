package com.sportsmc.client;

import com.sportsmc.network.MatchStatePacket;

import javax.annotation.Nullable;

/** Latest match state for the local player (null/inactive when not in a match). */
public final class ClientMatchData {

    @Nullable private static MatchStatePacket state;
    private static long phaseChangedAt = 0;

    private ClientMatchData() {}

    @Nullable
    public static MatchStatePacket get() {
        return state != null && state.active() ? state : null;
    }

    /** Game time (ms) when the phase last changed; the renderer fades lines in from here. */
    public static long phaseChangedAt() {
        return phaseChangedAt;
    }

    public static void apply(MatchStatePacket packet) {
        boolean changed = state == null || state.phase() != packet.phase() || state.ballYard() != packet.ballYard();
        state = packet;
        if (changed) phaseChangedAt = System.currentTimeMillis();
        com.sportsmc.entity.PassHighlight.set(packet.active() ? packet.passTargets() : null);
    }

    public static void clear() {
        state = null;
        com.sportsmc.entity.PassHighlight.clear();
    }
}
