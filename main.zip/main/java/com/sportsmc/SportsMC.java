package com.sportsmc;

import com.sportsmc.network.ModNetwork;
import com.sportsmc.registry.ModItems;
import com.mojang.logging.LogUtils;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * SportsMC entry point.
 *
 * Server-side event handlers live in {@link com.sportsmc.server.ServerEvents} and client-side ones in
 * {@link com.sportsmc.client.ClientEvents} / {@link com.sportsmc.client.FieldRenderer};
 * they register themselves with @Mod.EventBusSubscriber.
 */
@Mod(SportsMC.MODID)
public class SportsMC {
    public static final String MODID = "sportsmc";
    public static final Logger LOGGER = LogUtils.getLogger();
    /** This build's version (from gradle.properties' mod_version), shown by /sportsmc debug and in the log. */
    public static String VERSION = "?";

    public SportsMC() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modBus);
        com.sportsmc.registry.ModEntities.ENTITIES.register(modBus);
        modBus.addListener(this::addToCreativeTabs);
        ModNetwork.register();
        try {
            VERSION = net.minecraftforge.fml.ModLoadingContext.get().getActiveContainer().getModInfo().getVersion().toString();
        } catch (Exception ignored) {
        }
        LOGGER.info("SportsMC {} loaded - ready for kickoff.", VERSION);
    }

    private void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.FIELD_BLUEPRINT.get());
        }
    }
}
