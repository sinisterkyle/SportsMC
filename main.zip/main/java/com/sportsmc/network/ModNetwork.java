package com.sportsmc.network;

import com.sportsmc.SportsMC;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/** One channel for all SportsMC packets. Bump PROTOCOL whenever a packet format changes. */
public final class ModNetwork {
    private static final String PROTOCOL = "19";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(SportsMC.MODID, "main"),
            () -> PROTOCOL,
            PROTOCOL::equals,
            PROTOCOL::equals);

    private static boolean registered = false;

    private ModNetwork() {}

    public static void register() {
        if (registered) return;
        registered = true;
        int id = 0;

        CHANNEL.messageBuilder(LobbyActionPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(LobbyActionPacket::encode)
                .decoder(LobbyActionPacket::decode)
                .consumerMainThread(LobbyActionPacket::handle)
                .add();

        CHANNEL.messageBuilder(LobbySyncPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(LobbySyncPacket::encode)
                .decoder(LobbySyncPacket::decode)
                .consumerMainThread(LobbySyncPacket::handle)
                .add();

        CHANNEL.messageBuilder(BlueprintPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(BlueprintPacket::encode)
                .decoder(BlueprintPacket::decode)
                .consumerMainThread(BlueprintPacket::handle)
                .add();

        CHANNEL.messageBuilder(MatchStatePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(MatchStatePacket::encode)
                .decoder(MatchStatePacket::decode)
                .consumerMainThread(MatchStatePacket::handle)
                .add();

        CHANNEL.messageBuilder(ControlPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ControlPacket::encode)
                .decoder(ControlPacket::decode)
                .consumerMainThread(ControlPacket::handle)
                .add();

        CHANNEL.messageBuilder(TennisStatePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(TennisStatePacket::encode)
                .decoder(TennisStatePacket::decode)
                .consumerMainThread(TennisStatePacket::handle)
                .add();

        CHANNEL.messageBuilder(AirHockeyStatePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(AirHockeyStatePacket::encode)
                .decoder(AirHockeyStatePacket::decode)
                .consumerMainThread(AirHockeyStatePacket::handle)
                .add();

        CHANNEL.messageBuilder(ArcadeScorePacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ArcadeScorePacket::encode)
                .decoder(ArcadeScorePacket::decode)
                .consumerMainThread(ArcadeScorePacket::handle)
                .add();

        CHANNEL.messageBuilder(ArcadeBoardPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(ArcadeBoardPacket::encode)
                .decoder(ArcadeBoardPacket::decode)
                .consumerMainThread(ArcadeBoardPacket::handle)
                .add();

        CHANNEL.messageBuilder(CardStatePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(CardStatePacket::encode)
                .decoder(CardStatePacket::decode)
                .consumerMainThread(CardStatePacket::handle)
                .add();

        CHANNEL.messageBuilder(CardPickPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(CardPickPacket::encode)
                .decoder(CardPickPacket::decode)
                .consumerMainThread(CardPickPacket::handle)
                .add();

        CHANNEL.messageBuilder(AirHockeyInputPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(AirHockeyInputPacket::encode)
                .decoder(AirHockeyInputPacket::decode)
                .consumerMainThread(AirHockeyInputPacket::handle)
                .add();

        CHANNEL.messageBuilder(BowlingStatePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(BowlingStatePacket::encode)
                .decoder(BowlingStatePacket::decode)
                .consumerMainThread(BowlingStatePacket::handle)
                .add();

        CHANNEL.messageBuilder(BowlingThrowPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(BowlingThrowPacket::encode)
                .decoder(BowlingThrowPacket::decode)
                .consumerMainThread(BowlingThrowPacket::handle)
                .add();
    }

    public static void sendToServer(Object msg) {
        CHANNEL.sendToServer(msg);
    }

    public static void sendTo(ServerPlayer player, Object msg) {
        com.sportsmc.debug.SportsDebug.packetSent(msg);
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), msg);
    }
}
