package com.sportsmc.network;

import com.sportsmc.field.FieldData;
import com.sportsmc.lobby.Difficulty;
import com.sportsmc.lobby.Lobby;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Server -> client: everything the hub, blueprint screen and field renderer need.
 * Sent whenever anything lobby- or field-related changes, so the client never has to guess.
 */
public record LobbySyncPacket(
        @Nullable LobbyView lobby,
        List<PlayerView> invitable,
        List<InviteView> invites,
        List<FieldView> fields,
        boolean multiplayerContext,
        boolean aloneOnServer) {

    public record LobbyView(UUID id, UUID host, Lobby.Mode mode, Lobby.State state,
                            Difficulty difficulty, int quarterMinutes, com.sportsmc.lobby.Sport sport,
                            boolean doubles, int tennisGames, int airGoals, @Nullable UUID selectedField, List<MemberView> members) {}

    public record MemberView(UUID uuid, String name, Lobby.Side side, boolean ready) {}

    public record PlayerView(UUID uuid, String name) {}

    public record InviteView(UUID lobbyId, String hostName) {}

    public record FieldView(FieldData field, boolean inUse) {}

    /** Saved fields of one type (e.g. only football fields for the football lobby). */
    public List<FieldView> fieldsOf(com.sportsmc.field.FieldType type) {
        List<FieldView> out = new ArrayList<>();
        for (FieldView f : fields) if (f.field().type() == type) out.add(f);
        return out;
    }

    @Nullable
    public FieldView field(@Nullable UUID id) {
        if (id == null) return null;
        for (FieldView f : fields) if (f.field().id().equals(id)) return f;
        return null;
    }

    public static void encode(LobbySyncPacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.lobby != null);
        if (msg.lobby != null) {
            LobbyView l = msg.lobby;
            buf.writeUUID(l.id());
            buf.writeUUID(l.host());
            buf.writeEnum(l.mode());
            buf.writeEnum(l.state());
            buf.writeEnum(l.difficulty());
            buf.writeVarInt(l.quarterMinutes());
            buf.writeEnum(l.sport());
            buf.writeBoolean(l.doubles());
            buf.writeVarInt(l.tennisGames());
            buf.writeVarInt(l.airGoals());
            buf.writeBoolean(l.selectedField() != null);
            if (l.selectedField() != null) buf.writeUUID(l.selectedField());
            buf.writeVarInt(l.members().size());
            for (MemberView m : l.members()) {
                buf.writeUUID(m.uuid());
                buf.writeUtf(m.name(), 32);
                buf.writeEnum(m.side());
                buf.writeBoolean(m.ready());
            }
        }
        buf.writeVarInt(msg.invitable.size());
        for (PlayerView p : msg.invitable) {
            buf.writeUUID(p.uuid());
            buf.writeUtf(p.name(), 32);
        }
        buf.writeVarInt(msg.invites.size());
        for (InviteView i : msg.invites) {
            buf.writeUUID(i.lobbyId());
            buf.writeUtf(i.hostName(), 32);
        }
        buf.writeVarInt(msg.fields.size());
        for (FieldView f : msg.fields) {
            f.field().encode(buf);
            buf.writeBoolean(f.inUse());
        }
        buf.writeBoolean(msg.multiplayerContext);
        buf.writeBoolean(msg.aloneOnServer);
    }

    public static LobbySyncPacket decode(FriendlyByteBuf buf) {
        LobbyView lobby = null;
        if (buf.readBoolean()) {
            UUID id = buf.readUUID();
            UUID host = buf.readUUID();
            Lobby.Mode mode = buf.readEnum(Lobby.Mode.class);
            Lobby.State state = buf.readEnum(Lobby.State.class);
            Difficulty diff = buf.readEnum(Difficulty.class);
            int quarterMinutes = buf.readVarInt();
            com.sportsmc.lobby.Sport sport = buf.readEnum(com.sportsmc.lobby.Sport.class);
            boolean doubles = buf.readBoolean();
            int tennisGames = buf.readVarInt();
            int airGoals = buf.readVarInt();
            UUID selected = buf.readBoolean() ? buf.readUUID() : null;
            int n = buf.readVarInt();
            List<MemberView> members = new ArrayList<>(n);
            for (int i = 0; i < n; i++) {
                members.add(new MemberView(buf.readUUID(), buf.readUtf(32),
                        buf.readEnum(Lobby.Side.class), buf.readBoolean()));
            }
            lobby = new LobbyView(id, host, mode, state, diff, quarterMinutes, sport, doubles, tennisGames, airGoals, selected, members);
        }
        int pc = buf.readVarInt();
        List<PlayerView> invitable = new ArrayList<>(pc);
        for (int i = 0; i < pc; i++) invitable.add(new PlayerView(buf.readUUID(), buf.readUtf(32)));
        int ic = buf.readVarInt();
        List<InviteView> invites = new ArrayList<>(ic);
        for (int i = 0; i < ic; i++) invites.add(new InviteView(buf.readUUID(), buf.readUtf(32)));
        int fc = buf.readVarInt();
        List<FieldView> fields = new ArrayList<>(fc);
        for (int i = 0; i < fc; i++) fields.add(new FieldView(FieldData.decode(buf), buf.readBoolean()));
        boolean mp = buf.readBoolean();
        boolean alone = buf.readBoolean();
        return new LobbySyncPacket(lobby, invitable, invites, fields, mp, alone);
    }

    public static void handle(LobbySyncPacket msg, Supplier<NetworkEvent.Context> ctx) {
        // Keep client-only classes out of the dedicated server's class loading.
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> com.sportsmc.client.ClientLobbyData.apply(msg));
    }
}
