package com.sportsmc.network;

import com.sportsmc.arcade.ArcadeGame;
import com.sportsmc.arcade.ArcadeScores;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Server -> client: the top-10 board of every arcade game (names and scores). */
public record ArcadeBoardPacket(List<List<Row>> boards) {

    public record Row(String name, int score) {}

    public static ArcadeBoardPacket from(ArcadeScores scores) {
        List<List<Row>> out = new ArrayList<>();
        for (ArcadeGame g : ArcadeGame.values()) {
            List<Row> rows = new ArrayList<>();
            for (ArcadeScores.Entry e : scores.board(g)) rows.add(new Row(e.name(), e.score()));
            out.add(rows);
        }
        return new ArcadeBoardPacket(out);
    }

    public static void encode(ArcadeBoardPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.boards.size());
        for (List<Row> rows : m.boards) {
            buf.writeVarInt(rows.size());
            for (Row r : rows) {
                buf.writeUtf(r.name(), 32);
                buf.writeVarInt(r.score());
            }
        }
    }

    public static ArcadeBoardPacket decode(FriendlyByteBuf buf) {
        int n = Math.min(buf.readVarInt(), 16);
        List<List<Row>> boards = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            int m = Math.min(buf.readVarInt(), ArcadeScores.TOP);
            List<Row> rows = new ArrayList<>(m);
            for (int j = 0; j < m; j++) rows.add(new Row(buf.readUtf(32), buf.readVarInt()));
            boards.add(rows);
        }
        return new ArcadeBoardPacket(boards);
    }

    public static void handle(ArcadeBoardPacket msg, Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.sportsmc.client.arcade.ClientArcadeData.apply(msg));
    }
}
