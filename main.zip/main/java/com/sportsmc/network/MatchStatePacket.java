package com.sportsmc.network;

import com.sportsmc.lobby.Lobby;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import javax.annotation.Nullable;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Server -> each match participant: what the camera, field lines, scorebug and button hints need.
 * Built per viewer (controlled player, play call and hints differ for each person).
 * Yards are measured from HOME's goal line (0 = HOME goal line, 100 = AWAY goal line).
 *
 * @param callName  for the offense: the play called ("Slants", "Punt", "Kickoff"); for the defense: the coverage
 * @param playClock seconds left to snap (only sent to a human offense), else -1
 */
public record MatchStatePacket(boolean active, @Nullable UUID fieldId, Phase phase, Lobby.Side possession,
                               Lobby.Side viewerSide, float ballYard, float firstDownYard, int down,
                               int followEntityId, int controlledEntityId, String callName, int hints,
                               String homeName, String awayName, int homeScore, int awayScore,
                               int quarter, int clockSeconds, int playClock, boolean halftime, int[] passTargets,
                               float boost, boolean boostExhausted, boolean boostDefense) {

    /** PRE_SNAP / DEAD = between plays (scrimmage + first-down lines shown); LIVE / BALL_IN_AIR = hidden. */
    public enum Phase { PRE_SNAP, LIVE, BALL_IN_AIR, DEAD }

    public static final int HINT_CAN_THROW = 1;
    public static final int HINT_CARRIER = 2;
    public static final int HINT_OFFENSE = 4;      // the viewer's team has the ball
    public static final int HINT_RUN_PLAY = 8;
    public static final int HINT_KICKOFF = 16;     // next/current play is a kickoff (no chains)
    public static final int HINT_KICK_PLAY = 32;   // kickoff, punt or field goal
    public static final int HINT_TRY = 64;         // the try after a touchdown

    public static MatchStatePacket inactive() {
        return new MatchStatePacket(false, null, Phase.PRE_SNAP, Lobby.Side.HOME, Lobby.Side.HOME, 0, 0, 1, -1, -1, "", 0,
                "", "", 0, 0, 1, 0, -1, false, new int[0], 1f, false, false);
    }

    public boolean hint(int flag) {
        return (hints & flag) != 0;
    }

    public boolean betweenPlays() {
        return phase == Phase.PRE_SNAP || phase == Phase.DEAD;
    }

    /** First down line lands on the goal line: "& Goal", no yellow line. */
    public boolean goalToGo() {
        return firstDownYard <= 0.001f || firstDownYard >= 99.999f;
    }

    public String downAndDistance() {
        if (hint(HINT_KICKOFF)) return "Kickoff";
        if (hint(HINT_TRY)) return "Try";
        String ord = switch (down) { case 1 -> "1st"; case 2 -> "2nd"; case 3 -> "3rd"; default -> "4th"; };
        if (goalToGo()) return ord + " & Goal";
        float togo = Math.abs(firstDownYard - ballYard);
        return ord + " & " + (togo < 1 ? "Inches" : String.valueOf((int) Math.ceil(togo - 0.001)));
    }

    public static void encode(MatchStatePacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.active);
        buf.writeBoolean(msg.fieldId != null);
        if (msg.fieldId != null) buf.writeUUID(msg.fieldId);
        buf.writeEnum(msg.phase);
        buf.writeEnum(msg.possession);
        buf.writeEnum(msg.viewerSide);
        buf.writeFloat(msg.ballYard);
        buf.writeFloat(msg.firstDownYard);
        buf.writeVarInt(msg.down);
        buf.writeVarInt(msg.followEntityId);
        buf.writeVarInt(msg.controlledEntityId);
        buf.writeUtf(msg.callName, 64);
        buf.writeVarInt(msg.hints);
        buf.writeUtf(msg.homeName, 64);
        buf.writeUtf(msg.awayName, 64);
        buf.writeVarInt(msg.homeScore);
        buf.writeVarInt(msg.awayScore);
        buf.writeVarInt(msg.quarter);
        buf.writeVarInt(msg.clockSeconds);
        buf.writeVarInt(msg.playClock);
        buf.writeBoolean(msg.halftime);
        buf.writeVarIntArray(msg.passTargets);
        buf.writeFloat(msg.boost);
        buf.writeBoolean(msg.boostExhausted);
        buf.writeBoolean(msg.boostDefense);
    }

    public static MatchStatePacket decode(FriendlyByteBuf buf) {
        boolean active = buf.readBoolean();
        UUID field = buf.readBoolean() ? buf.readUUID() : null;
        Phase phase = buf.readEnum(Phase.class);
        Lobby.Side poss = buf.readEnum(Lobby.Side.class);
        Lobby.Side viewer = buf.readEnum(Lobby.Side.class);
        float ball = buf.readFloat();
        float first = buf.readFloat();
        int down = buf.readVarInt();
        int follow = buf.readVarInt();
        int controlled = buf.readVarInt();
        String call = buf.readUtf(64);
        int hints = buf.readVarInt();
        String home = buf.readUtf(64);
        String away = buf.readUtf(64);
        int hs = buf.readVarInt();
        int as = buf.readVarInt();
        int q = buf.readVarInt();
        int clock = buf.readVarInt();
        int playClock = buf.readVarInt();
        boolean half = buf.readBoolean();
        int[] targets = buf.readVarIntArray(8);
        float boost = buf.readFloat();
        boolean boostOut = buf.readBoolean();
        boolean boostDef = buf.readBoolean();
        return new MatchStatePacket(active, field, phase, poss, viewer, ball, first, down, follow, controlled, call, hints,
                home, away, hs, as, q, clock, playClock, half, targets, boost, boostOut, boostDef);
    }

    public static void handle(MatchStatePacket msg, Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> com.sportsmc.client.ClientMatchData.apply(msg));
    }
}
