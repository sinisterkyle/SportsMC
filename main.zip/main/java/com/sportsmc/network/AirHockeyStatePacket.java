package com.sportsmc.network;

import com.sportsmc.lobby.Lobby;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Server -> each air hockey player, every tick: the table state. Coordinates are in the table frame:
 * x from -0.5 (left) to 0.5 (right), y from -1 (HOME's goal end) to 1 (AWAY's goal end).
 * Velocities are per tick. Each client rotates the table so its own goal is at the bottom.
 *
 * owner: whose game is running the puck right now (0 = the server, 1 = HOME's player, 2 = AWAY's player).
 * lead: how many ticks old this puck state is by the time it reaches this player (the owner's delay to the
 * server plus the server's delay to this player), so the client can run it forward to "now".
 * serverTick: increases every tick, so the client can tell a fresh state from one it already used.
 * ackSeq: the newest input the server had from this player when it sent this, so a player's game can tell
 * whether this state already includes its own latest hit.
 */
public record AirHockeyStatePacket(boolean active, Lobby.Side viewerSide, Phase phase, int phaseTicks,
                                   float puckX, float puckY, float puckVX, float puckVY,
                                   float homeX, float homeY, float awayX, float awayY,
                                   int homeScore, int awayScore, int goalsToWin,
                                   String homeName, String awayName, int lastScorer, String message,
                                   int owner, int lead, int serverTick, int ackSeq) {

    public enum Phase { COUNTDOWN, PLAY, GOAL, OVER }

    public static AirHockeyStatePacket inactive() {
        return new AirHockeyStatePacket(false, Lobby.Side.HOME, Phase.OVER, 0, 0, 0, 0, 0, 0, -0.8f, 0, 0.8f,
                0, 0, 7, "", "", 0, "", 0, 0, 0, 0);
    }

    public static void encode(AirHockeyStatePacket m, FriendlyByteBuf buf) {
        buf.writeBoolean(m.active);
        buf.writeEnum(m.viewerSide);
        buf.writeEnum(m.phase);
        buf.writeVarInt(m.phaseTicks);
        buf.writeFloat(m.puckX);
        buf.writeFloat(m.puckY);
        buf.writeFloat(m.puckVX);
        buf.writeFloat(m.puckVY);
        buf.writeFloat(m.homeX);
        buf.writeFloat(m.homeY);
        buf.writeFloat(m.awayX);
        buf.writeFloat(m.awayY);
        buf.writeVarInt(m.homeScore);
        buf.writeVarInt(m.awayScore);
        buf.writeVarInt(m.goalsToWin);
        buf.writeUtf(m.homeName, 64);
        buf.writeUtf(m.awayName, 64);
        buf.writeByte(m.lastScorer);
        buf.writeUtf(m.message, 128);
        buf.writeByte(m.owner);
        buf.writeByte(m.lead);
        buf.writeVarInt(m.serverTick);
        buf.writeVarInt(m.ackSeq);
    }

    public static AirHockeyStatePacket decode(FriendlyByteBuf buf) {
        return new AirHockeyStatePacket(buf.readBoolean(), buf.readEnum(Lobby.Side.class), buf.readEnum(Phase.class),
                buf.readVarInt(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(),
                buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(),
                buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readUtf(64), buf.readUtf(64),
                buf.readByte(), buf.readUtf(128), buf.readByte(), buf.readByte(), buf.readVarInt(), buf.readVarInt());
    }

    public static void handle(AirHockeyStatePacket msg, Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.sportsmc.client.ClientAirHockeyData.apply(msg));
    }
}
