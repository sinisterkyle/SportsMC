package com.sportsmc.network;

import com.sportsmc.match.MatchManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Client -> server, every client tick while the air hockey table is open: where your mallet is (table frame),
 * and - while the puck is on your half, where your game is the one running it - the puck's state and what
 * happened to it this tick (hit, rail, or a goal against you). Your own hits are therefore instant and exact;
 * the server checks the reports and relays them to your opponent.
 */
public record AirHockeyInputPacket(int seq, float malletX, float malletY, boolean hasPuck,
                                   float puckX, float puckY, float puckVX, float puckVY, int events, float hitStrength) {

    public static final int EV_HIT = 1, EV_WALL = 2, EV_GOAL_AGAINST = 4;

    public static AirHockeyInputPacket malletOnly(int seq, float x, float y) {
        return new AirHockeyInputPacket(seq, x, y, false, 0, 0, 0, 0, 0, 0);
    }

    public static void encode(AirHockeyInputPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.seq);
        buf.writeFloat(m.malletX);
        buf.writeFloat(m.malletY);
        buf.writeBoolean(m.hasPuck);
        if (m.hasPuck) {
            buf.writeFloat(m.puckX);
            buf.writeFloat(m.puckY);
            buf.writeFloat(m.puckVX);
            buf.writeFloat(m.puckVY);
            buf.writeByte(m.events);
            buf.writeFloat(m.hitStrength);
        }
    }

    public static AirHockeyInputPacket decode(FriendlyByteBuf buf) {
        int seq = buf.readVarInt();
        float mx = buf.readFloat(), my = buf.readFloat();
        boolean has = buf.readBoolean();
        if (!has) return malletOnly(seq, mx, my);
        return new AirHockeyInputPacket(seq, mx, my, true, buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(),
                buf.readByte(), buf.readFloat());
    }

    public static void handle(AirHockeyInputPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sender = ctx.get().getSender();
        if (sender == null) return;
        com.sportsmc.debug.SportsDebug.packetReceived(msg);
        long t0 = System.nanoTime();
        MatchManager.get().airHockeyInput(sender, msg);
        com.sportsmc.debug.SportsDebug.add(com.sportsmc.debug.SportsDebug.Part.PACKETS, System.nanoTime() - t0);
    }
}
