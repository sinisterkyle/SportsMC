package com.sportsmc.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Client -> server: the bowler lets go of the ball.
 * @param start -1..1 across the lane (left..right edge), @param aim degrees off straight (+ = right),
 * @param power 0..1 (from how fast they spun the mouse), @param hook -1..1 (spin direction and amount)
 */
public record BowlingThrowPacket(float start, float aim, float power, float hook) {

    public static void encode(BowlingThrowPacket m, FriendlyByteBuf buf) {
        buf.writeFloat(m.start);
        buf.writeFloat(m.aim);
        buf.writeFloat(m.power);
        buf.writeFloat(m.hook);
    }

    public static BowlingThrowPacket decode(FriendlyByteBuf buf) {
        return new BowlingThrowPacket(buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat());
    }

    public static void handle(BowlingThrowPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sender = ctx.get().getSender();
        if (sender == null) return;
        com.sportsmc.debug.SportsDebug.packetReceived(msg);
        com.sportsmc.match.MatchManager.get().bowlingThrow(sender, msg);
    }
}
