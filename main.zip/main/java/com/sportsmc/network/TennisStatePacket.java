package com.sportsmc.network;

import com.sportsmc.lobby.Lobby;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import javax.annotation.Nullable;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Server -> each tennis match participant: what the camera, court lines, scoreboard and stamina bar need.
 *
 * @param pointsText  current game score from the viewer's scoreboard point of view, e.g. "30 - 15", "Deuce", "Ad HOME"
 * @param stamina     0..1 sprint stamina of the player you control
 * @param hint        a short instruction for this viewer ("Press SPACE to serve", "Fault! Second serve", ...)
 */
public record TennisStatePacket(boolean active, @Nullable UUID fieldId, Lobby.Side viewerSide, Phase phase,
                                int controlledEntityId, int ballEntityId,
                                String homeName, String awayName, int homeGames, int awayGames, int gamesToWin,
                                String homePoints, String awayPoints, Lobby.Side serving, boolean doubles,
                                float stamina, boolean exhausted, String hint,
                                int mark, double markX, double markZ, int partnerEntityId, int serveBox) {

    public enum Phase { PRE_SERVE, TOSS, RALLY, POINT_OVER, MATCH_OVER }

    public static TennisStatePacket inactive() {
        return new TennisStatePacket(false, null, Lobby.Side.HOME, Phase.PRE_SERVE, -1, -1, "", "", 0, 0, 1,
                "", "", Lobby.Side.HOME, false, 1f, false, "", 0, 0, 0, -1, 0);
    }

    public static void encode(TennisStatePacket m, FriendlyByteBuf buf) {
        buf.writeBoolean(m.active);
        buf.writeBoolean(m.fieldId != null);
        if (m.fieldId != null) buf.writeUUID(m.fieldId);
        buf.writeEnum(m.viewerSide);
        buf.writeEnum(m.phase);
        buf.writeVarInt(m.controlledEntityId);
        buf.writeVarInt(m.ballEntityId);
        buf.writeUtf(m.homeName, 64);
        buf.writeUtf(m.awayName, 64);
        buf.writeVarInt(m.homeGames);
        buf.writeVarInt(m.awayGames);
        buf.writeVarInt(m.gamesToWin);
        buf.writeUtf(m.homePoints, 16);
        buf.writeUtf(m.awayPoints, 16);
        buf.writeEnum(m.serving);
        buf.writeBoolean(m.doubles);
        buf.writeFloat(m.stamina);
        buf.writeBoolean(m.exhausted);
        buf.writeUtf(m.hint, 128);
        buf.writeByte(m.mark);
        buf.writeDouble(m.markX);
        buf.writeDouble(m.markZ);
        buf.writeVarInt(m.partnerEntityId);
        buf.writeByte(m.serveBox);
    }

    public static TennisStatePacket decode(FriendlyByteBuf buf) {
        boolean active = buf.readBoolean();
        UUID field = buf.readBoolean() ? buf.readUUID() : null;
        Lobby.Side viewer = buf.readEnum(Lobby.Side.class);
        Phase phase = buf.readEnum(Phase.class);
        int controlled = buf.readVarInt();
        int ball = buf.readVarInt();
        String home = buf.readUtf(64);
        String away = buf.readUtf(64);
        int hg = buf.readVarInt();
        int ag = buf.readVarInt();
        int toWin = buf.readVarInt();
        String hp = buf.readUtf(16);
        String ap = buf.readUtf(16);
        Lobby.Side serving = buf.readEnum(Lobby.Side.class);
        boolean doubles = buf.readBoolean();
        float stamina = buf.readFloat();
        boolean exhausted = buf.readBoolean();
        String hint = buf.readUtf(128);
        int mark = buf.readByte();
        double mx = buf.readDouble(), mz = buf.readDouble();
        int partner = buf.readVarInt();
        int box = buf.readByte();
        return new TennisStatePacket(active, field, viewer, phase, controlled, ball, home, away, hg, ag, toWin,
                hp, ap, serving, doubles, stamina, exhausted, hint, mark, mx, mz, partner, box);
    }

    public static void handle(TennisStatePacket msg, Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.sportsmc.client.ClientTennisData.apply(msg));
    }
}
