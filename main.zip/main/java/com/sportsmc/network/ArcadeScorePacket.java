package com.sportsmc.network;

import com.sportsmc.arcade.ArcadeGame;
import com.sportsmc.arcade.ArcadeScores;
import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Client -> server: a finished arcade game's score (score >= 0), or a request for the boards (score < 0).
 * The server records it and sends the boards back; a new #1 is announced to everyone online.
 */
public record ArcadeScorePacket(int game, int score) {

    public static ArcadeScorePacket request() {
        return new ArcadeScorePacket(0, -1);
    }

    public static void encode(ArcadeScorePacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.game);
        buf.writeVarInt(m.score + 1);
    }

    public static ArcadeScorePacket decode(FriendlyByteBuf buf) {
        return new ArcadeScorePacket(buf.readVarInt(), buf.readVarInt() - 1);
    }

    public static void handle(ArcadeScorePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sp = ctx.get().getSender();
        if (sp == null) return;
        com.sportsmc.debug.SportsDebug.packetReceived(msg);
        ArcadeScores scores = ArcadeScores.get(sp.server);
        if (msg.score >= 0) {
            ArcadeGame game = ArcadeGame.byOrdinal(msg.game);
            String name = sp.getGameProfile().getName();
            int rank = scores.submit(game, sp.getUUID(), name, msg.score);
            if (rank == 1) {
                Component shout = Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD)
                        .append(Component.literal("Arcade: " + name + " set a new " + game.title + " high score: "
                                + String.format("%,d", msg.score) + "!").withStyle(ChatFormatting.LIGHT_PURPLE));
                for (ServerPlayer p : sp.server.getPlayerList().getPlayers()) p.sendSystemMessage(shout);
            } else if (rank > 1) {
                sp.sendSystemMessage(Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD)
                        .append(Component.literal("Arcade: that's #" + rank + " on the " + game.title + " board!").withStyle(ChatFormatting.AQUA)));
            }
        }
        ModNetwork.sendTo(sp, ArcadeBoardPacket.from(scores));
    }
}
