package com.sportsmc.network;

import com.sportsmc.field.FieldData;
import com.sportsmc.field.FieldService;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import javax.annotation.Nullable;
import java.util.UUID;
import java.util.function.Supplier;

/** Client -> server: buttons on the blueprint screen. */
public record BlueprintPacket(Action action, String name, @Nullable UUID fieldId) {

    public enum Action { SAVE, UNDO, CLEAR, DELETE_FIELD, TELEPORT, CYCLE_TYPE }

    public static BlueprintPacket of(Action action) {
        return new BlueprintPacket(action, "", null);
    }

    public static BlueprintPacket save(String name) {
        return new BlueprintPacket(Action.SAVE, name, null);
    }

    public static BlueprintPacket field(Action action, UUID fieldId) {
        return new BlueprintPacket(action, "", fieldId);
    }

    public static void encode(BlueprintPacket msg, FriendlyByteBuf buf) {
        buf.writeEnum(msg.action);
        buf.writeUtf(msg.name, FieldData.MAX_NAME_LENGTH * 4);
        buf.writeBoolean(msg.fieldId != null);
        if (msg.fieldId != null) buf.writeUUID(msg.fieldId);
    }

    public static BlueprintPacket decode(FriendlyByteBuf buf) {
        Action a = buf.readEnum(Action.class);
        String name = buf.readUtf(FieldData.MAX_NAME_LENGTH * 4);
        UUID id = buf.readBoolean() ? buf.readUUID() : null;
        return new BlueprintPacket(a, name, id);
    }

    public static void handle(BlueprintPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sender = ctx.get().getSender();
        if (sender == null) return;
        com.sportsmc.debug.SportsDebug.packetReceived(msg);
        switch (msg.action) {
            case SAVE -> FieldService.save(sender, msg.name);
            case UNDO -> FieldService.undo(sender);
            case CLEAR -> FieldService.clear(sender);
            case DELETE_FIELD -> FieldService.delete(sender, msg.fieldId);
            case TELEPORT -> FieldService.teleport(sender, msg.fieldId);
            case CYCLE_TYPE -> FieldService.cycleType(sender);
        }
    }
}
