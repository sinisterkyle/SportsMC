package com.sportsmc.network;

import com.sportsmc.match.MatchManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server (Card Dojo): "I play the card in this hand slot (0-4) this round". */
public record CardPickPacket(int round, int slot) {

    public static void encode(CardPickPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.round);
        buf.writeVarInt(m.slot);
    }

    public static CardPickPacket decode(FriendlyByteBuf buf) {
        return new CardPickPacket(buf.readVarInt(), buf.readVarInt());
    }

    public static void handle(CardPickPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sender = ctx.get().getSender();
        if (sender == null) return;
        com.sportsmc.debug.SportsDebug.packetReceived(msg);
        MatchManager.get().cardPick(sender, msg);
    }
}
