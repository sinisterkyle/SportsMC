package com.sportsmc.network;

import com.sportsmc.lobby.LobbyManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import javax.annotation.Nullable;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Client -> server: "the player clicked something in the hub".
 * target = a player UUID or lobby UUID depending on the action; arg = small int payload (e.g. difficulty ordinal).
 */
public record LobbyActionPacket(Action action, @Nullable UUID target, int arg) {

    public enum Action {
        REQUEST_SYNC,
        CREATE_LOBBY,
        INVITE,          // target = player to invite
        ACCEPT_INVITE,   // target = lobby id
        DECLINE_INVITE,  // target = lobby id
        LEAVE,
        KICK,            // target = player to kick
        TOGGLE_READY,
        SWAP_SIDES,
        START_MATCH,
        START_CPU_MATCH, // arg = difficulty ordinal, target = field id (optional)
        SET_DIFFICULTY,  // arg = difficulty ordinal
        SELECT_FIELD,    // target = field id
        SET_QUARTER_LENGTH, // arg = minutes
        SET_DOUBLES,     // arg = 1 for 2v2 tennis, 0 for singles
        SET_TENNIS_GAMES, // arg = best-of N games
        SET_AIR_GOALS    // arg = air hockey goals to win
    }

    public static LobbyActionPacket of(Action action, @Nullable UUID target, int arg) {
        return new LobbyActionPacket(action, target, arg);
    }

    public static LobbyActionPacket of(Action action) {
        return new LobbyActionPacket(action, null, 0);
    }

    public static LobbyActionPacket of(Action action, UUID target) {
        return new LobbyActionPacket(action, target, 0);
    }

    public static LobbyActionPacket of(Action action, int arg) {
        return new LobbyActionPacket(action, null, arg);
    }

    public static void encode(LobbyActionPacket msg, FriendlyByteBuf buf) {
        buf.writeEnum(msg.action);
        buf.writeBoolean(msg.target != null);
        if (msg.target != null) buf.writeUUID(msg.target);
        buf.writeVarInt(msg.arg);
    }

    public static LobbyActionPacket decode(FriendlyByteBuf buf) {
        Action action = buf.readEnum(Action.class);
        UUID target = buf.readBoolean() ? buf.readUUID() : null;
        int arg = buf.readVarInt();
        return new LobbyActionPacket(action, target, arg);
    }

    public static void handle(LobbyActionPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sender = ctx.get().getSender();
        if (sender == null) return;
        com.sportsmc.debug.SportsDebug.packetReceived(msg);
        long t0 = System.nanoTime();
        LobbyManager.get().handleAction(sender, msg);
        com.sportsmc.debug.SportsDebug.add(com.sportsmc.debug.SportsDebug.Part.PACKETS, System.nanoTime() - t0);
    }
}
