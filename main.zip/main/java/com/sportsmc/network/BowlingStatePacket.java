package com.sportsmc.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import javax.annotation.Nullable;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Server -> client: one bowling lane's game. Sent to both bowlers, and to anyone nearby so they can watch.
 * During a roll it's sent every tick (ball and pin positions); otherwise a few times a second.
 *
 * @param viewer    0 = you bowl as HOME, 1 = AWAY, -1 = you're watching
 * @param turn      0 = HOME is up, 1 = AWAY
 * @param pins      10 pins x {state, x, u, tilt, dir} (lane coordinates, see BowlingPhysics)
 * @param winner    -1 = not over, 0 = HOME, 1 = AWAY, 2 = a tie
 */
public record BowlingStatePacket(boolean active, @Nullable UUID fieldId, int viewer, String homeName, String awayName,
                                 int frames, byte[] homeRolls, byte[] awayRolls, int turn, int phase, int ticksLeft,
                                 String message, boolean ballVisible, float ballX, float ballU, float ballRoll,
                                 float[] pins, int winner) {

    public static final int INTRO = 0, AIM = 1, ROLLING = 2, RESULT = 3, OVER = 4;

    public static BowlingStatePacket inactive() {
        return new BowlingStatePacket(false, null, -1, "", "", 0, new byte[0], new byte[0], 0, INTRO, 0, "", false,
                0, 0, 0, new float[50], -1);
    }

    /** "Off" for one lane: a watcher's client drops it. */
    public static BowlingStatePacket ended(UUID fieldId) {
        return new BowlingStatePacket(false, fieldId, -1, "", "", 0, new byte[0], new byte[0], 0, OVER, 0, "", false,
                0, 0, 0, new float[50], -1);
    }

    public static void encode(BowlingStatePacket m, FriendlyByteBuf buf) {
        buf.writeBoolean(m.active);
        buf.writeBoolean(m.fieldId != null);
        if (m.fieldId != null) buf.writeUUID(m.fieldId);
        buf.writeByte(m.viewer);
        buf.writeUtf(m.homeName, 64);
        buf.writeUtf(m.awayName, 64);
        buf.writeByte(m.frames);
        buf.writeByteArray(m.homeRolls);
        buf.writeByteArray(m.awayRolls);
        buf.writeByte(m.turn);
        buf.writeByte(m.phase);
        buf.writeVarInt(m.ticksLeft);
        buf.writeUtf(m.message, 128);
        buf.writeBoolean(m.ballVisible);
        buf.writeFloat(m.ballX);
        buf.writeFloat(m.ballU);
        buf.writeFloat(m.ballRoll);
        for (int i = 0; i < 50; i++) {
            if (i % 5 == 0) buf.writeByte((int) m.pins[i]);
            else buf.writeFloat(m.pins[i]);
        }
        buf.writeByte(m.winner);
    }

    public static BowlingStatePacket decode(FriendlyByteBuf buf) {
        boolean active = buf.readBoolean();
        UUID id = buf.readBoolean() ? buf.readUUID() : null;
        int viewer = buf.readByte();
        String home = buf.readUtf(64), away = buf.readUtf(64);
        int frames = buf.readByte();
        byte[] hr = buf.readByteArray(32), ar = buf.readByteArray(32);
        int turn = buf.readByte(), phase = buf.readByte(), ticksLeft = buf.readVarInt();
        String message = buf.readUtf(128);
        boolean ballVisible = buf.readBoolean();
        float bx = buf.readFloat(), bu = buf.readFloat(), roll = buf.readFloat();
        float[] pins = new float[50];
        for (int i = 0; i < 50; i++) pins[i] = i % 5 == 0 ? buf.readByte() : buf.readFloat();
        int winner = buf.readByte();
        return new BowlingStatePacket(active, id, viewer, home, away, frames, hr, ar, turn, phase, ticksLeft, message,
                ballVisible, bx, bu, roll, pins, winner);
    }

    public static void handle(BowlingStatePacket msg, Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.sportsmc.client.ClientBowlingData.apply(msg));
    }
}
