package com.sportsmc.network;

import com.sportsmc.match.MatchManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Client -> server, every client tick during a match: the movement direction (already turned into
 * world space using the camera's facing), sprint, and any buttons pressed this tick.
 */
public record ControlPacket(float moveX, float moveZ, boolean sprint, int actions) {

    public static final int HIKE_OR_JUMP = 1;
    public static final int THROW_1 = 1 << 1;
    public static final int THROW_2 = 1 << 2;
    public static final int THROW_3 = 1 << 3;
    public static final int JUKE_LEFT = 1 << 4;
    public static final int JUKE_RIGHT = 1 << 5;
    public static final int TACKLE = 1 << 6;
    public static final int SWITCH = 1 << 7;
    public static final int HANDOFF = 1 << 8;
    public static final int CYCLE_PLAY = 1 << 9;
    /** Held state (not a one-off press): SHIFT is down this tick (tennis: lob). */
    public static final int SNEAK_HELD = 1 << 10;

    public static void encode(ControlPacket msg, FriendlyByteBuf buf) {
        buf.writeFloat(msg.moveX);
        buf.writeFloat(msg.moveZ);
        buf.writeBoolean(msg.sprint);
        buf.writeVarInt(msg.actions);
    }

    public static ControlPacket decode(FriendlyByteBuf buf) {
        return new ControlPacket(buf.readFloat(), buf.readFloat(), buf.readBoolean(), buf.readVarInt());
    }

    public static void handle(ControlPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sender = ctx.get().getSender();
        if (sender == null) return;
        if (!Float.isFinite(msg.moveX) || !Float.isFinite(msg.moveZ)) return;
        com.sportsmc.debug.SportsDebug.packetReceived(msg);
        long t0 = System.nanoTime();
        MatchManager.get().control(sender, msg);
        com.sportsmc.debug.SportsDebug.add(com.sportsmc.debug.SportsDebug.Part.PACKETS, System.nanoTime() - t0);
    }
}
