package com.sportsmc.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * Server -> each Card Dojo player: the table from their point of view. Cards are ids into CardRules.CARDS;
 * -1 = empty. You only ever receive your own hand: the opponent's hand is just a count until cards are revealed.
 *
 * phase: DEAL (cards being dealt), PICK (choose a card), REVEAL (both cards flip; result decided),
 * GAME_OVER (someone completed a set; shows it), MATCH_OVER.
 * roundResult (REVEAL / GAME_OVER): 1 = you won the round, -1 = they did, 0 = tie.
 * winningSet: the 3 cards that won the game (GAME_OVER / MATCH_OVER), for highlighting.
 */
public record CardStatePacket(boolean active, int phase, int phaseTicks, int round, int pickTicksLeft,
                              List<Integer> hand, int oppHandCount, int myPick, boolean oppPicked,
                              int revealMine, int revealTheirs, int roundResult,
                              List<Integer> myBank, List<Integer> theirBank, List<Integer> winningSet, int gameWinner,
                              int myGames, int theirGames, int gamesToWin, String myName, String theirName, String message) {

    public static final int DEAL = 0, PICK = 1, REVEAL = 2, GAME_OVER = 3, MATCH_OVER = 4;

    public static CardStatePacket inactive() {
        return new CardStatePacket(false, MATCH_OVER, 0, 0, 0, List.of(), 0, -1, false, -1, -1, 0,
                List.of(), List.of(), List.of(), 0, 0, 0, 1, "", "", "");
    }

    private static void writeList(FriendlyByteBuf buf, List<Integer> l) {
        buf.writeVarInt(l.size());
        for (int v : l) buf.writeVarInt(v + 1); // -1 -> 0
    }

    private static List<Integer> readList(FriendlyByteBuf buf) {
        int n = Math.min(buf.readVarInt(), 64);
        List<Integer> out = new ArrayList<>(n);
        for (int i = 0; i < n; i++) out.add(buf.readVarInt() - 1);
        return out;
    }

    public static void encode(CardStatePacket m, FriendlyByteBuf buf) {
        buf.writeBoolean(m.active);
        buf.writeVarInt(m.phase);
        buf.writeVarInt(m.phaseTicks);
        buf.writeVarInt(m.round);
        buf.writeVarInt(m.pickTicksLeft);
        writeList(buf, m.hand);
        buf.writeVarInt(m.oppHandCount);
        buf.writeVarInt(m.myPick + 1);
        buf.writeBoolean(m.oppPicked);
        buf.writeVarInt(m.revealMine + 1);
        buf.writeVarInt(m.revealTheirs + 1);
        buf.writeVarInt(m.roundResult + 1);
        writeList(buf, m.myBank);
        writeList(buf, m.theirBank);
        writeList(buf, m.winningSet);
        buf.writeVarInt(m.gameWinner + 1);
        buf.writeVarInt(m.myGames);
        buf.writeVarInt(m.theirGames);
        buf.writeVarInt(m.gamesToWin);
        buf.writeUtf(m.myName, 64);
        buf.writeUtf(m.theirName, 64);
        buf.writeUtf(m.message, 128);
    }

    public static CardStatePacket decode(FriendlyByteBuf buf) {
        boolean active = buf.readBoolean();
        int phase = buf.readVarInt(), phaseTicks = buf.readVarInt(), round = buf.readVarInt(), pickLeft = buf.readVarInt();
        List<Integer> hand = readList(buf);
        int oppCount = buf.readVarInt();
        int myPick = buf.readVarInt() - 1;
        boolean oppPicked = buf.readBoolean();
        int revMine = buf.readVarInt() - 1, revTheirs = buf.readVarInt() - 1, result = buf.readVarInt() - 1;
        List<Integer> myBank = readList(buf), theirBank = readList(buf), win = readList(buf);
        int gameWinner = buf.readVarInt() - 1;
        int myGames = buf.readVarInt(), theirGames = buf.readVarInt(), toWin = buf.readVarInt();
        return new CardStatePacket(active, phase, phaseTicks, round, pickLeft, hand, oppCount, myPick, oppPicked,
                revMine, revTheirs, result, myBank, theirBank, win, gameWinner, myGames, theirGames, toWin,
                buf.readUtf(64), buf.readUtf(64), buf.readUtf(128));
    }

    public static void handle(CardStatePacket msg, Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.sportsmc.client.ClientCardData.apply(msg));
    }
}
