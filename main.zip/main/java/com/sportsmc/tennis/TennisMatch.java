package com.sportsmc.tennis;

import com.sportsmc.entity.TennisBallEntity;
import com.sportsmc.entity.TennisPlayerEntity;
import com.sportsmc.field.FieldData;
import com.sportsmc.game.Role;
import com.sportsmc.lobby.Difficulty;
import com.sportsmc.lobby.Lobby;
import com.sportsmc.match.SportMatch;
import com.sportsmc.network.ControlPacket;
import com.sportsmc.network.ModNetwork;
import com.sportsmc.network.TennisStatePacket;
import com.sportsmc.network.TennisStatePacket.Phase;
import com.sportsmc.registry.ModEntities;
import com.sportsmc.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * A tennis match, singles (1v1) or doubles (2v2), human vs human or human vs CPU.
 *
 * You watch from a high camera behind your own baseline and control one player: WASD to move, CTRL to
 * sprint (drains the stamina bar), LEFT click to swing left (backhand), RIGHT click to swing right
 * (forehand). Hold A / D while swinging to aim, W for a hard flat drive, S for a lob. Swing timing
 * matters: early pulls the ball cross-court, late pushes it the other way, on time hits it cleanest.
 * In doubles you automatically control whichever of your two players the ball is coming to.
 *
 * Real rules: serve diagonally into the service box (two tries), the return must bounce first, one
 * bounce per side, out / net / double bounce lose the point, 0-15-30-40, deuce and advantage, best-of-N games.
 */
public class TennisMatch implements SportMatch {

    // ---- feel / tuning (blocks and ticks; speeds scale with the court size) -------------------
    private static final double RUN_SPEED = 0.165;
    private static final double SPRINT_MULT = 1.65;
    private static final double STAMINA_DRAIN = 0.011;      // per sprinting tick (full bar = ~4.5 s of sprint)
    private static final double STAMINA_REGEN = 0.005;      // per tick once you stop sprinting
    private static final int STAMINA_REGEN_DELAY = 12;
    private static final double STAMINA_RECOVER = 0.3;      // exhausted until the bar is back to 30%
    private static final double SHOT_SPEED = 0.6;           // horizontal ball speed for a normal groundstroke
    private static final double SERVE_SPEED = 0.78;
    private static final double REACH = 1.75;               // how far from the body a racket reaches the ball
    private static final double SWEET_SPOT = 0.9;
    private static final double HIT_MIN_H = 0.15, HIT_MAX_H = 2.9;
    private static final int SWING_WINDOW = 8;              // ticks a swing can make contact
    private static final int SWING_COOLDOWN = 14;
    private static final int POINT_PAUSE = 55;
    private static final double BOOTH_HEIGHT = 16;
    /** A ball that touches the line is in: the ball's radius plus a hair. */
    private static final double LINE_TOL = TennisBallEntity.RADIUS + 0.03;

    public record Participant(@Nullable UUID player, String name, @Nullable Difficulty cpu) {}

    private record ReturnPoint(ResourceKey<Level> dimension, Vec3 pos, float yRot, float xRot, GameType gameType) {}

    private static final class Control {
        Vec3 move = Vec3.ZERO;
        boolean sprint;
        boolean sneak; // SHIFT held: lob
        int pending;
    }

    /** Per-player state: stamina, swing, which half of the court (doubles) they cover. */
    private static final class PState {
        final Lobby.Side side;
        final int index;
        double stamina = 1.0;
        boolean exhausted;
        int sinceSprint = 99;
        int swingAge = -1;
        int swingSide;
        int cooldown;
        double half; // doubles: +1 covers the right half, -1 the left half (singles: 0)

        PState(Lobby.Side side, int index) {
            this.side = side;
            this.index = index;
        }
    }

    private static final class Stats {
        int points, aces, doubleFaults, winners, errors;
    }

    private final Lobby lobby;
    private final FieldData field;
    private final TennisCourt court;
    private final boolean doubles;
    private final int gamesToWin;
    private final Map<Lobby.Side, Participant> sides = new EnumMap<>(Lobby.Side.class);
    private final Map<Lobby.Side, List<TennisPlayerEntity>> team = new EnumMap<>(Lobby.Side.class);
    private final Map<TennisPlayerEntity, PState> pstate = new HashMap<>();
    private final Map<Lobby.Side, TennisPlayerEntity> responsible = new EnumMap<>(Lobby.Side.class);
    private final Map<UUID, Control> controls = new HashMap<>();
    private final Map<UUID, ReturnPoint> returnPoints = new HashMap<>();
    private final Map<Lobby.Side, Integer> points = new EnumMap<>(Lobby.Side.class);
    private final Map<Lobby.Side, Integer> games = new EnumMap<>(Lobby.Side.class);
    private final Map<Lobby.Side, Stats> stats = new EnumMap<>(Lobby.Side.class);

    @Nullable private ServerLevel level;
    @Nullable private TennisBallEntity ball;
    private RandomSource random = RandomSource.create();

    private Phase phase = Phase.PRE_SERVE;
    private int phaseTicks;
    private int age;
    private boolean finished;

    // Serving
    private Lobby.Side firstServer = Lobby.Side.HOME;
    private Lobby.Side serving = Lobby.Side.HOME;
    private int gamesPlayed;
    private boolean deuceCourt = true;
    private int faults;
    @Nullable private TennisPlayerEntity server;
    private int cpuServeAt;
    private double tossApexY;

    // Rally
    @Nullable private Lobby.Side lastHitter;
    @Nullable private TennisPlayerEntity lastHitterEntity;
    private int bounces;
    private boolean isServe;
    private boolean receiverTouched;
    private int ticksSinceHit;
    private Vec3[] prediction = new Vec3[0];
    private int reactionLeft;
    private String pointText = "";
    // Hawk-Eye: where the last shot landed (court x/z) and whether it was in (1) or out (2); 0 = none.
    private double markX, markZ;
    private int mark;

    public TennisMatch(Lobby lobby, FieldData field) {
        this.lobby = lobby;
        this.field = field;
        this.court = new TennisCourt(field.geometry());
        this.doubles = lobby.doubles();
        this.gamesToWin = lobby.tennisGames() / 2 + 1;
        for (Lobby.Member m : lobby.members()) sides.put(m.side, new Participant(m.uuid, m.name, null));
        if (lobby.mode() == Lobby.Mode.VS_CPU) {
            Lobby.Side cpuSide = sides.containsKey(Lobby.Side.HOME) ? Lobby.Side.AWAY : Lobby.Side.HOME;
            sides.put(cpuSide, new Participant(null, "CPU (" + lobby.difficulty().englishName() + ")", lobby.difficulty()));
        }
        for (Lobby.Side s : Lobby.Side.values()) {
            points.put(s, 0);
            games.put(s, 0);
            stats.put(s, new Stats());
        }
    }

    // ================================================================== SportMatch

    @Override public Lobby lobby() { return lobby; }
    @Override public FieldData field() { return field; }
    @Override public boolean isFinished() { return finished; }

    @Override
    public boolean involves(UUID player) {
        return sideOf(player) != null;
    }

    @Nullable
    private Lobby.Side sideOf(UUID player) {
        for (Map.Entry<Lobby.Side, Participant> e : sides.entrySet()) if (player.equals(e.getValue().player())) return e.getKey();
        return null;
    }

    @Nullable
    private UUID humanOf(Lobby.Side side) {
        Participant p = sides.get(side);
        return p == null ? null : p.player();
    }

    private List<UUID> humans() {
        List<UUID> out = new ArrayList<>(2);
        for (Participant p : sides.values()) if (p.player() != null) out.add(p.player());
        return out;
    }

    @Override
    public void control(UUID player, ControlPacket msg) {
        if (finished) return;
        Control c = controls.computeIfAbsent(player, k -> new Control());
        Vec3 mv = new Vec3(msg.moveX(), 0, msg.moveZ());
        c.move = mv.lengthSqr() > 1 ? mv.normalize() : mv;
        c.sprint = msg.sprint();
        c.sneak = (msg.actions() & ControlPacket.SNEAK_HELD) != 0;
        c.pending |= msg.actions() & ~ControlPacket.SNEAK_HELD;
    }

    // ================================================================== start / end

    @Override
    public void kickoff(MinecraftServer srv) {
        level = srv.getLevel(ResourceKey.create(Registries.DIMENSION, field.dimension()));
        if (level == null) { finish(null); return; }
        random = level.getRandom();

        Vec3 booth = court.world(court.L / 2, court.W / 2, court.floorY + BOOTH_HEIGHT);
        for (UUID uuid : humans()) {
            ServerPlayer sp = srv.getPlayerList().getPlayer(uuid);
            if (sp == null) continue;
            com.sportsmc.match.SafeReturn.remember(sp, true);
            returnPoints.put(uuid, new ReturnPoint(sp.level().dimension(), sp.position(), sp.getYRot(), sp.getXRot(),
                    sp.gameMode.getGameModeForPlayer()));
            sp.setGameMode(GameType.SPECTATOR);
            sp.teleportTo(level, booth.x, booth.y, booth.z, 0f, 60f);
        }

        int[] numbers = {1, 2};
        for (Lobby.Side s : Lobby.Side.values()) {
            List<TennisPlayerEntity> list = new ArrayList<>();
            for (int i = 0; i < (doubles ? 2 : 1); i++) {
                TennisPlayerEntity e = ModEntities.TENNIS_PLAYER.get().create(level);
                if (e == null) continue;
                e.setup(s, Role.WR, numbers[i], i);
                e.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.TENNIS_RACKET.get()));
                Vec3 p = court.world(court.baselineX(s), court.W / 2, court.floorY);
                e.moveTo(p.x, p.y, p.z, court.netYaw(s), 0f);
                e.setNetYaw(court.netYaw(s));
                level.addFreshEntity(e);
                list.add(e);
                PState ps = new PState(s, i);
                ps.half = doubles ? (i == 0 ? 1 : -1) : 0;
                pstate.put(e, ps);
            }
            team.put(s, list);
        }
        ball = ModEntities.TENNIS_BALL.get().create(level);
        if (ball != null) {
            ball.setFloorY(court.floorY);
            ball.setHeld(true);
            Vec3 c = court.world(court.L / 2, court.W / 2, court.floorY + 1);
            ball.moveTo(c.x, c.y, c.z, 0, 0);
            level.addFreshEntity(ball);
        }

        firstServer = random.nextBoolean() ? Lobby.Side.HOME : Lobby.Side.AWAY;
        Participant home = sides.get(Lobby.Side.HOME), away = sides.get(Lobby.Side.AWAY);
        broadcast(Component.literal("Tennis at " + field.name() + ": ").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD)
                .append(Component.literal(home.name() + " (HOME) vs " + away.name() + " (AWAY), "
                        + (doubles ? "doubles" : "singles") + ", best of " + lobby.tennisGames() + " games").withStyle(ChatFormatting.WHITE)));
        broadcast(Component.literal(sides.get(firstServer).name() + " serves first. WASD move, CTRL sprint, "
                + "LEFT click = swing left, RIGHT click = swing right. Hold A/D to aim, W to drive, S to lob.").withStyle(ChatFormatting.GRAY));
        title(Component.literal(home.name() + " vs " + away.name()).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                Component.literal(doubles ? "Doubles" : "Singles"));
        setupPoint();
    }

    @Override
    public void finish(@Nullable Lobby.Side forcedWinner) {
        if (finished) return;
        finished = true;
        Lobby.Side winner = forcedWinner;
        if (winner == null) {
            int h = games.get(Lobby.Side.HOME), a = games.get(Lobby.Side.AWAY);
            winner = h == a ? null : h > a ? Lobby.Side.HOME : Lobby.Side.AWAY;
        }
        if (winner != null) {
            title(Component.literal("GAME, SET, MATCH").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                    Component.literal(sides.get(winner).name() + " wins " + games.get(winner) + "-" + games.get(winner.opposite())));
            broadcast(Component.literal("GAME, SET, MATCH - " + sides.get(winner).name() + " wins! ").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)
                    .append(gamesLine()));
            if (ball != null) sound(ball.position(), SoundEvents.FIREWORK_ROCKET_LARGE_BLAST, 2f, 1f);
        } else {
            broadcast(Component.literal("Match ended. ").withStyle(ChatFormatting.YELLOW).append(gamesLine()));
        }
        for (Lobby.Side s : Lobby.Side.values()) {
            Stats st = stats.get(s);
            broadcast(Component.literal(String.format("%s %s | Points %d | Aces %d | Winners %d | Errors %d | Double faults %d",
                    s == Lobby.Side.HOME ? "HOME" : "AWAY", sides.get(s).name(), st.points, st.aces, st.winners, st.errors,
                    st.doubleFaults)).withStyle(ChatFormatting.WHITE));
        }
        for (List<TennisPlayerEntity> list : team.values()) for (TennisPlayerEntity e : list) e.discard();
        team.clear();
        if (ball != null) ball.discard();
        ball = null;
        sendToAll(TennisStatePacket.inactive());
        sendPlayersBack();
    }

    @Override
    public void forfeit(UUID player) {
        Lobby.Side s = sideOf(player);
        if (s == null) return;
        broadcast(Component.literal(sides.get(s).name() + " retired from the match.").withStyle(ChatFormatting.RED));
        finish(s.opposite());
    }

    // ================================================================== points

    /** Places everyone for the next serve and hands the ball to the server. */
    private void setupPoint() {
        if (ball == null || ball.isRemoved() || level == null) { finish(null); return; }
        phase = Phase.PRE_SERVE;
        phaseTicks = 0;
        lastHitter = null;
        lastHitterEntity = null;
        bounces = 0;
        isServe = false;
        receiverTouched = false;
        deuceCourt = (points.get(Lobby.Side.HOME) + points.get(Lobby.Side.AWAY)) % 2 == 0;

        // Who serves this game: singles alternate sides; doubles rotate through all four players.
        serving = gamesPlayed % 2 == 0 ? firstServer : firstServer.opposite();
        List<TennisPlayerEntity> sv = team.get(serving);
        server = sv.get(doubles ? (gamesPlayed / 2) % 2 : 0);
        Lobby.Side recv = serving.opposite();
        double side = deuceCourt ? 1 : -1;

        // Server just behind the baseline on the correct half; partner up at the net on the other half.
        place(server, court.baselineX(serving) - court.toward(serving) * 0.6, side * court.W * 0.12, serving);
        pstate.get(server).half = doubles ? side : 0;
        for (TennisPlayerEntity e : sv) {
            if (e == server) continue;
            place(e, court.netX() - court.toward(serving) * court.L * 0.13, -side * court.W * 0.25, serving);
            pstate.get(e).half = -side;
        }
        // Receiving team keeps its halves: index 0 covers the right (deuce) half, index 1 the left (ad) half.
        TennisPlayerEntity receiver = null;
        for (TennisPlayerEntity e : team.get(recv)) {
            PState ps = pstate.get(e);
            if (!doubles) {
                ps.half = 0;
                receiver = e;
                place(e, court.baselineX(recv) - court.toward(recv) * 0.4, side * court.W * 0.25, recv);
            } else if (ps.half == side) {
                receiver = e;
                place(e, court.baselineX(recv) - court.toward(recv) * 0.4, side * court.W * 0.27, recv);
            } else {
                place(e, court.netX() - court.toward(recv) * court.serviceDist() * 0.85, -side * court.W * 0.25, recv);
            }
        }
        responsible.put(serving, server);
        if (receiver != null) responsible.put(recv, receiver);

        ball.setHeld(true);
        ball.consumeBounce(); // forget bounces from the last point
        mark = 0;
        holdBallAtServer();
        cpuServeAt = 30 + random.nextInt(25);
        for (PState ps : pstate.values()) { ps.swingAge = -1; ps.cooldown = 0; }
        for (Control c : controls.values()) c.pending = 0;
        pushState();
    }

    private void place(TennisPlayerEntity e, double x, double r, Lobby.Side side) {
        Vec3 p = court.world(x, court.zFromRight(side, r), court.floorY);
        e.stopRunning();
        e.setDeltaMovement(Vec3.ZERO);
        e.moveTo(p.x, p.y, p.z, court.netYaw(side), 0f);
        e.setNetYaw(court.netYaw(side));
    }

    private void holdBallAtServer() {
        if (ball == null || server == null) return;
        Vec3 p = server.position().add(court.facing(serving).scale(0.35)).add(court.rightVec(serving).scale(-0.25)).add(0, 1.1, 0);
        ball.setPos(p.x, p.y, p.z);
        ball.setDeltaMovement(Vec3.ZERO);
    }

    /** Point over: show why, then score it after a short pause. */
    private void pointTo(Lobby.Side winner, String reason, boolean winnerShot) {
        if (phase == Phase.POINT_OVER || phase == Phase.MATCH_OVER) return;
        phase = Phase.POINT_OVER;
        phaseTicks = 0;
        pendingWinner = winner;
        stats.get(winner).points++;
        if (winnerShot) stats.get(winner).winners++;
        else if (reason.startsWith("OUT") || reason.startsWith("NET")) stats.get(winner.opposite()).errors++;
        pointText = reason;
        title(Component.empty(), Component.literal(reason + " - point " + sides.get(winner).name())
                .withStyle(winner == Lobby.Side.HOME ? ChatFormatting.AQUA : ChatFormatting.RED));
        Vec3 at = ball != null ? ball.position() : court.world(court.netX(), court.W / 2, court.floorY);
        sound(at, SoundEvents.NOTE_BLOCK_FLUTE.value(), 1.0f, 2.0f);
        if (winnerShot) particles(ParticleTypes.FIREWORK, at.add(0, 0.5, 0), 25, 0.4, 0.4, 0.4, 0.08);
        pushState();
    }

    @Nullable private Lobby.Side pendingWinner;

    private void scorePoint(Lobby.Side winner) {
        Lobby.Side loser = winner.opposite();
        points.merge(winner, 1, Integer::sum);
        int w = points.get(winner), l = points.get(loser);
        faults = 0;
        if (w >= 4 && w - l >= 2) {
            games.merge(winner, 1, Integer::sum);
            points.put(Lobby.Side.HOME, 0);
            points.put(Lobby.Side.AWAY, 0);
            gamesPlayed++;
            sound(court.world(court.netX(), court.W / 2, court.floorY + 1), SoundEvents.PLAYER_LEVELUP, 1f, 1.2f);
            if (games.get(winner) >= gamesToWin) {
                finish(winner);
                return;
            }
            title(Component.literal("GAME " + sides.get(winner).name()).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                    Component.literal("Games: HOME " + games.get(Lobby.Side.HOME) + " - " + games.get(Lobby.Side.AWAY) + " AWAY"));
            broadcast(Component.literal("Game " + sides.get(winner).name() + ". ").withStyle(ChatFormatting.GOLD).append(gamesLine()));
        } else {
            broadcast(Component.literal(pointText + " - ").withStyle(ChatFormatting.GRAY)
                    .append(Component.literal(callScore()).withStyle(ChatFormatting.WHITE)));
        }
        setupPoint();
    }

    /** "15-30", "Deuce", "Advantage HOME" - from the server's point of view like an umpire. */
    private String callScore() {
        int s = points.get(serving), r = points.get(serving.opposite());
        if (s >= 3 && r >= 3) {
            if (s == r) return "Deuce";
            return "Advantage " + sides.get(s > r ? serving : serving.opposite()).name();
        }
        String[] names = {"Love", "15", "30", "40"};
        if (s == r) return names[Math.min(s, 3)] + "-All";
        return names[Math.min(s, 3)] + "-" + names[Math.min(r, 3)];
    }

    private String pointLabel(Lobby.Side side) {
        int p = points.get(side), o = points.get(side.opposite());
        if (p >= 3 && o >= 3) return p > o ? "AD" : "40";
        return new String[]{"0", "15", "30", "40"}[Math.min(p, 3)];
    }

    private Component gamesLine() {
        return Component.literal("[Games HOME " + games.get(Lobby.Side.HOME) + " - " + games.get(Lobby.Side.AWAY) + " AWAY]")
                .withStyle(ChatFormatting.WHITE);
    }

    // ================================================================== tick

    @Override
    public void tick(MinecraftServer srv) {
        if (finished || level == null) return;
        age++;
        phaseTicks++;
        if (ball == null || ball.isRemoved()) { finish(null); return; }
        ball.claim();
        for (List<TennisPlayerEntity> list : team.values()) for (TennisPlayerEntity e : list) e.claim();

        switch (phase) {
            case PRE_SERVE -> tickPreServe();
            case TOSS -> tickToss();
            case RALLY -> tickRally();
            case POINT_OVER -> {
                tickPlayers(false);
                if (phaseTicks >= POINT_PAUSE && pendingWinner != null) scorePoint(pendingWinner);
            }
            default -> {}
        }
        for (PState ps : pstate.values()) if (ps.cooldown > 0) ps.cooldown--;
        if (age % 2 == 0) pushState();
        if (age % 40 == 0) keepInBooth(srv);
    }

    private void tickPreServe() {
        for (TennisPlayerEntity e : allPlayers()) e.stopRunning();
        for (PState ps : pstate.values()) regen(ps, false);
        holdBallAtServer();
        UUID human = humanOf(serving);
        boolean serverIsHuman = human != null;
        int actions = takeActions(human);
        if (serverIsHuman) {
            if ((actions & (ControlPacket.HIKE_OR_JUMP | ControlPacket.TACKLE | ControlPacket.SWITCH)) != 0) toss();
        } else if (phaseTicks >= cpuServeAt) {
            toss();
        }
        clearActions(serving.opposite());
    }

    private void toss() {
        if (ball == null || server == null) return;
        Vec3 p = server.position().add(court.facing(serving).scale(0.45)).add(court.rightVec(serving).scale(0.15)).add(0, 1.5, 0);
        ball.setPos(p.x, p.y, p.z);
        ball.setHeld(false);
        double vy = 0.42;
        ball.setDeltaMovement(0, vy, 0);
        tossApexY = p.y + vy * vy / (2 * TennisBallEntity.GRAVITY);
        phase = Phase.TOSS;
        phaseTicks = 0;
        sound(p, SoundEvents.WOOL_STEP, 0.6f, 1.6f);
        pushState();
    }

    private void tickToss() {
        for (TennisPlayerEntity e : allPlayers()) e.stopRunning();
        if (ball == null || server == null) return;
        double h = ball.getY() - court.floorY;
        UUID human = humanOf(serving);
        boolean serverIsHuman = human != null;
        int actions = takeActions(human);
        clearActions(serving.opposite());
        if (serverIsHuman) {
            int swing = swingFrom(actions);
            if (swing != 0) {
                server.swingRacket(swing);
                sound(server.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 0.6f, 1.4f);
                if (h > 1.9 && h < tossApexY - court.floorY + 0.6) {
                    double q = Math.max(0.2, 1.0 - Math.abs(ball.getY() - tossApexY) / 1.6);
                    serveHit(q, aimFromInput(human, serving), errorFor(serving, q));
                    return;
                }
            }
        } else {
            // CPU hits at (about) the top of the toss.
            Difficulty d = cpuOf(serving);
            int jitter = d == null ? 1 : switch (d) { case ROOKIE -> 4; case PRO -> 2; case ALL_PRO -> 1; case LEGEND -> 0; };
            boolean atTop = ball.getDeltaMovement().y <= 0.02 * (1 + random.nextInt(jitter + 1));
            if (atTop) {
                server.swingRacket(1);
                double q = switch (d == null ? Difficulty.PRO : d) { case ROOKIE -> 0.55; case PRO -> 0.72; case ALL_PRO -> 0.85; case LEGEND -> 0.95; };
                serveHit(q + random.nextDouble() * 0.1, (random.nextDouble() * 2 - 1) * 0.9, errorFor(serving, q));
                return;
            }
        }
        if (h < 1.4 && ball.getDeltaMovement().y < 0) {
            // Let the toss drop: no penalty, toss again.
            ball.setHeld(true);
            phase = Phase.PRE_SERVE;
            phaseTicks = 0;
            cpuServeAt = 20;
            if (serverIsHuman) notifySide(serving, Component.literal("Toss again - click while the ball is up high").withStyle(ChatFormatting.YELLOW));
        }
    }

    private void serveHit(double quality, double aim, double error) {
        if (ball == null || server == null) return;
        Lobby.Side recv = serving.opposite();
        int t = court.toward(serving);
        double half = court.W / 2 - court.singlesInset();
        double boxSign = deuceCourt ? -1 : 1; // in the server's frame the deuce box is to the server's left
        // Aim (A/D) picks wide / body / down the T, but the intended spot always stays well inside the box;
        // the misses come from timing (a mistimed toss hit scatters more), not from aiming at the lines.
        double margin = Math.min(half * 0.3, 0.8 * court.scale());
        double r = boxSign * half * 0.5 + aim * (half * 0.5 - margin);
        double depth = 0.55 + 0.22 * quality;  // never closer than ~1/4 box to the service line
        double x = court.netX() + t * court.serviceDist() * depth;
        double z = court.zFromRight(serving, r);
        double serveError = error * 0.55;
        x += random.nextGaussian() * serveError;
        z += random.nextGaussian() * serveError;
        double speed = SERVE_SPEED * court.scale() * (0.72 + 0.45 * quality);
        launch(x, z, speed, 1.0, 0.15, true);
        isServe = true;
        lastHitter = serving;
        lastHitterEntity = server;
        mark = 0;
        bounces = 0;
        ticksSinceHit = 0;
        receiverTouched = false;
        phase = Phase.RALLY;
        phaseTicks = 0;
        sound(ball.position(), SoundEvents.NOTE_BLOCK_BASEDRUM.value(), 1.0f, 1.7f);
        if (quality > 0.85) sound(ball.position(), SoundEvents.PLAYER_ATTACK_STRONG, 0.6f, 1.3f);
        chooseResponsible(recv);
        reactionLeft = reactionTicks(recv);
        pushState();
    }

    // ------------------------------------------------------------------ rally

    private void tickRally() {
        if (ball == null) return;
        ticksSinceHit++;
        prediction = TennisBallEntity.predict(ball.position(), ball.getDeltaMovement(), court.floorY, 100);
        if (reactionLeft > 0) reactionLeft--;

        // Order matters: net and bounce first (they belong to the shot already in the air), then players move and swing.
        checkNet();
        if (ball.consumeBounce()) onBounce(ball.bouncePos());
        tickPlayers(phase == Phase.RALLY);
        if (phase == Phase.RALLY && ticksSinceHit > 400 && lastHitter != null) pointTo(lastHitter.opposite(), "Dead ball", false);
    }

    /** Ball crossing the net plane below the net cord drops back on the hitter's side. */
    private void checkNet() {
        if (ball == null) return;
        Vec3 prev = ball.previousPos(), now = ball.position();
        double x0 = court.x(prev), x1 = court.x(now), n = court.netX();
        if ((x0 - n) * (x1 - n) >= 0 || x1 == x0) return;
        double f = (n - x0) / (x1 - x0);
        double y = prev.y + (now.y - prev.y) * f - court.floorY;
        double z = court.z(prev) + (court.z(now) - court.z(prev)) * f;
        if (z < -1 || z > court.W + 1) return; // around the post
        if (y < court.netHeight(z)) {
            double back = x0 < n ? -0.15 : 0.15;
            Vec3 p = court.world(n + back, z, prev.y + (now.y - prev.y) * f);
            ball.setPos(p.x, p.y, p.z);
            Vec3 v = ball.getDeltaMovement();
            ball.setDeltaMovement(-v.x * 0.12, Math.min(v.y, 0) * 0.4, -v.z * 0.12);
            sound(p, SoundEvents.WOOL_PLACE, 1f, 0.8f);
        } else if (y < court.netHeight(z) + 0.15) {
            sound(now, SoundEvents.WOOL_STEP, 0.5f, 1.5f); // clipped the net cord but went over
        }
    }

    private void onBounce(Vec3 at) {
        double x = court.x(at), z = court.z(at);
        sound(at, SoundEvents.NOTE_BLOCK_HAT.value(), 0.5f, 1.5f);
        if (lastHitter == null) return;
        Lobby.Side opp = lastHitter.opposite();
        if (bounces == 0) {
            markX = x;
            markZ = z;
            if (isServe) {
                if (court.inServiceBox(opp, deuceCourt, x, z, LINE_TOL)) { bounces = 1; mark = 1; return; }
                mark = 2;
                fault(faultReason(opp, x, z));
                return;
            }
            if (!court.onHalf(opp, x)) { mark = 0; pointTo(opp, "NET", false); return; }
            // House rule: singles and doubles both play to the outer (doubles) lines.
            if (!court.inCourt(x, z, true, LINE_TOL)) {
                mark = 2;
                boolean longBall = x < -LINE_TOL || x > court.L + LINE_TOL;
                pointTo(opp, longBall ? "OUT - long" : "OUT - wide", false);
                return;
            }
            mark = 1;
            bounces = 1;
            return;
        }
        // Second bounce: the shot wasn't returned.
        if (isServe && !receiverTouched) {
            stats.get(lastHitter).aces++;
            pointTo(lastHitter, "ACE!", true);
        } else {
            pointTo(lastHitter, "WINNER!", true);
        }
    }

    /** Why a serve missed the box: "net", "long" (past the service line) or "wide" (outside the box's sideline). */
    private String faultReason(Lobby.Side receiver, double x, double z) {
        if (court.onHalf(lastHitter, x)) return "net";
        double fromNet = Math.abs(x - court.netX());
        if (fromNet > court.serviceDist() + LINE_TOL) return "long";
        return "wide";
    }

    private void fault(String why) {
        pointText = "FAULT - " + why;
        if (faults == 0) {
            faults = 1;
            phase = Phase.POINT_OVER;
            phaseTicks = POINT_PAUSE - 30; // short pause, then the second serve
            pendingWinner = null;
            title(Component.empty(), Component.literal("FAULT (" + why + ") - second serve").withStyle(ChatFormatting.YELLOW));
            sound(ball != null ? ball.position() : Vec3.ZERO, SoundEvents.NOTE_BLOCK_BELL.value(), 0.8f, 1.2f);
            secondServeTimer = 30;
        } else {
            stats.get(serving).doubleFaults++;
            pointTo(serving.opposite(), "DOUBLE FAULT (" + why + ")", false);
        }
    }

    private int secondServeTimer = 0;

    // ------------------------------------------------------------------ players

    private List<TennisPlayerEntity> allPlayers() {
        List<TennisPlayerEntity> out = new ArrayList<>();
        for (List<TennisPlayerEntity> l : team.values()) out.addAll(l);
        return out;
    }

    /** The player a side's human is controlling right now. */
    @Nullable
    private TennisPlayerEntity controlled(Lobby.Side side) {
        List<TennisPlayerEntity> l = team.get(side);
        if (l == null || l.isEmpty()) return null;
        if (!doubles) return l.get(0);
        TennisPlayerEntity r = responsible.get(side);
        return r != null ? r : l.get(0);
    }

    /** Doubles: the teammate on the half where the ball is predicted to land takes it. */
    private void chooseResponsible(Lobby.Side side) {
        List<TennisPlayerEntity> l = team.get(side);
        if (l == null || l.isEmpty()) return;
        if (!doubles || l.size() < 2) { responsible.put(side, l.get(0)); return; }
        Vec3 land = firstBounceOnHalf(side);
        double r = land != null ? court.rightOf(side, court.z(land)) : 0;
        TennisPlayerEntity best = l.get(0);
        for (TennisPlayerEntity e : l) if (Math.signum(pstate.get(e).half) == Math.signum(r == 0 ? 1 : r)) best = e;
        responsible.put(side, best);
    }

    @Nullable
    private Vec3 firstBounceOnHalf(Lobby.Side side) {
        if (ball == null) return null;
        Vec3[] pr = TennisBallEntity.predict(ball.position(), ball.getDeltaMovement(), court.floorY, 120);
        double floor = court.floorY + TennisBallEntity.RADIUS;
        for (Vec3 p : pr) if (p.y <= floor + 1e-6 && court.onHalf(side, court.x(p))) return p;
        return pr.length > 0 ? pr[pr.length - 1] : null;
    }

    private void tickPlayers(boolean live) {
        if (secondServeTimer > 0 && --secondServeTimer == 0 && phase == Phase.POINT_OVER && pendingWinner == null) {
            setupSecondServe();
            return;
        }
        for (Lobby.Side side : Lobby.Side.values()) {
            UUID human = humanOf(side);
            // A human controls their whole side. In doubles that's both players at once, like foosball:
            // WASD moves both (each stays in its own lane) and a click swings both rackets.
            boolean humanTeam = human != null;
            int actions = takeActions(human);
            int swing = swingFrom(actions);
            boolean swung = false;
            for (TennisPlayerEntity e : team.getOrDefault(side, List.of())) {
                PState ps = pstate.get(e);
                if (humanTeam) {
                    moveHuman(e, ps, controls.get(human));
                    if (swing != 0 && ps.cooldown <= 0) {
                        startSwing(e, ps, swing, !swung);
                        swung = true;
                    }
                } else {
                    moveAI(e, ps, live);
                }
                if (live) tryContact(e, ps, humanTeam ? human : null);
                if (ps.swingAge >= 0 && ++ps.swingAge > SWING_WINDOW) ps.swingAge = -1;
            }
        }
    }

    private void setupSecondServe() {
        // Same server, same court, second try.
        Lobby.Side s = serving;
        int f = faults;
        setupPoint();
        serving = s;
        faults = f;
        notifySide(serving, Component.literal("Second serve").withStyle(ChatFormatting.YELLOW));
    }

    private void startSwing(TennisPlayerEntity e, PState ps, int side) {
        startSwing(e, ps, side, true);
    }

    private void startSwing(TennisPlayerEntity e, PState ps, int side, boolean withSound) {
        ps.swingAge = 0;
        ps.swingSide = side;
        ps.cooldown = SWING_COOLDOWN;
        e.swingRacket(side);
        if (withSound) sound(e.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 0.5f, 1.4f);
    }

    private void moveHuman(TennisPlayerEntity e, PState ps, @Nullable Control c) {
        if (c == null || phase != Phase.RALLY && phase != Phase.POINT_OVER) { e.stopRunning(); regen(ps, false); return; }
        Vec3 move = c.move;
        // Don't run into the net.
        double x = court.x(e.position());
        Vec3 f = court.facing(ps.side);
        if (Math.abs(x - court.netX()) < 0.8 && move.dot(f) > 0) move = move.subtract(f.scale(move.dot(f)));
        // Doubles (foosball): each player keeps to its own lane - its half of the court plus a little overlap -
        // so moving both together never stacks them on top of each other.
        if (doubles && ps.half != 0) {
            Vec3 right = court.rightVec(ps.side);
            double r = court.rightOf(ps.side, court.z(e.position()));
            double lat = move.dot(right);
            double overlap = court.W * 0.08, outside = court.W / 2 + 1.5;
            boolean blocked = ps.half > 0 ? (lat < 0 && r <= -overlap) || (lat > 0 && r >= outside)
                                          : (lat > 0 && r >= overlap) || (lat < 0 && r <= -outside);
            if (blocked) move = move.subtract(right.scale(lat));
        }
        boolean moving = move.lengthSqr() > 0.01;
        boolean sprint = c.sprint && moving && !ps.exhausted && ps.stamina > 0;
        regen(ps, sprint);
        double speed = RUN_SPEED * court.scale() * (sprint ? SPRINT_MULT : 1.0);
        e.drive(move, speed * Math.min(1.0, move.length()));
    }

    private void regen(PState ps, boolean sprinting) {
        if (sprinting) {
            ps.stamina = Math.max(0, ps.stamina - STAMINA_DRAIN);
            ps.sinceSprint = 0;
            if (ps.stamina <= 0) ps.exhausted = true;
        } else {
            ps.sinceSprint++;
            if (ps.sinceSprint > STAMINA_REGEN_DELAY) ps.stamina = Math.min(1, ps.stamina + STAMINA_REGEN);
            if (ps.exhausted && ps.stamina >= STAMINA_RECOVER) ps.exhausted = false;
        }
    }

    // ------------------------------------------------------------------ AI movement

    private void moveAI(TennisPlayerEntity e, PState ps, boolean live) {
        if (!live || ball == null || phase != Phase.RALLY) {
            if (phase == Phase.POINT_OVER) goHome(e, ps, false);
            else e.stopRunning();
            regen(ps, false);
            return;
        }
        boolean incoming = lastHitter != null && lastHitter != ps.side;
        if (!incoming || responsible.get(ps.side) != e || reactionLeft > 0 && humanOf(ps.side) == null) {
            goHome(e, ps, false);
            return;
        }
        Difficulty d = cpuOf(ps.side);
        double speedMul = d == null ? 1.0 : switch (d) { case ROOKIE -> 0.86; case PRO -> 0.95; case ALL_PRO -> 1.0; case LEGEND -> 1.07; };
        // Smart players let balls that are going out fly past.
        Vec3 land = firstBounceOnHalf(ps.side);
        boolean willBeOut = bounces == 0 && land != null && (!court.inCourt(court.x(land), court.z(land), true, -0.15)
                || (isServe && !court.inServiceBox(ps.side, deuceCourt, court.x(land), court.z(land), -0.1)));
        if (willBeOut && (d == null || d != Difficulty.ROOKIE)) { goHome(e, ps, false); return; }

        double run = RUN_SPEED * court.scale() * speedMul;
        Vec3 right = court.rightVec(ps.side);
        double floor = court.floorY + TennisBallEntity.RADIUS;
        int bounceCount = bounces;
        Vec3 bestStand = null;
        int bestTick = -1;
        boolean needSprint = false;
        for (int i = 0; i < prediction.length; i++) {
            Vec3 p = prediction[i];
            if (p.y <= floor + 1e-6) { bounceCount++; if (bounceCount >= 2) break; continue; }
            boolean mustBounce = isServe || bounceCount == 0 && !doubles; // singles AI plays groundstrokes
            if (mustBounce && bounceCount < 1) continue;
            if (!court.onHalf(ps.side, court.x(p))) continue;
            double h = p.y - court.floorY;
            if (h < 0.35 || h > 2.1) continue;
            Vec3 fore = p.subtract(right.scale(SWEET_SPOT)), back = p.add(right.scale(SWEET_SPOT));
            Vec3 stand = horizDist(e.position(), fore) <= horizDist(e.position(), back) + 0.6 ? fore : back;
            double dist = horizDist(e.position(), stand);
            if (dist / run <= i) { bestStand = stand; bestTick = i; needSprint = false; break; }
            if (dist / (run * SPRINT_MULT) <= i && !ps.exhausted && ps.stamina > 0.05) {
                bestStand = stand; bestTick = i; needSprint = true; break;
            }
            bestStand = stand; bestTick = i; needSprint = true; // keep the latest chance as a fallback
        }
        if (bestStand == null) { goHome(e, ps, false); return; }
        boolean sprint = needSprint && !ps.exhausted && ps.stamina > 0;
        regen(ps, sprint);
        e.driveTo(new Vec3(bestStand.x, court.floorY, bestStand.z), run * (sprint ? SPRINT_MULT : 1.0));
    }

    private void goHome(TennisPlayerEntity e, PState ps, boolean sprint) {
        double x = court.baselineX(ps.side) - court.toward(ps.side) * court.L * 0.03;
        double r = doubles ? ps.half * court.W * 0.25 : 0;
        // In doubles the partner of the player at the net stays up there.
        if (doubles && phase == Phase.RALLY && responsible.get(ps.side) != e && lastHitter == ps.side) {
            x = court.netX() - court.toward(ps.side) * court.serviceDist() * 0.7;
        }
        Vec3 home = court.world(x, court.zFromRight(ps.side, r), court.floorY);
        regen(ps, false);
        e.driveTo(home, RUN_SPEED * court.scale() * 0.9);
    }

    // ------------------------------------------------------------------ hitting

    private void tryContact(TennisPlayerEntity e, PState ps, @Nullable UUID human) {
        if (ball == null || phase != Phase.RALLY) return;
        if (lastHitter == ps.side) return;                 // one hit per side
        if (isServe && bounces == 0) return;               // the serve must bounce before the return
        Vec3 b = ball.position();
        if (!court.onHalf(ps.side, court.x(b))) return;
        double h = b.y - court.floorY;
        if (h < HIT_MIN_H || h > HIT_MAX_H) return;
        double d = horizDist(e.position(), b);
        if (d > REACH) return;

        double lateral = b.subtract(e.position()).dot(court.rightVec(ps.side)); // + = ball on my right
        if (human == null) {
            // AI: play groundstrokes in singles, and leave balls that are about to land out.
            if (!doubles && bounces == 0) return;
            if (bounces == 0 && landsOut()) return;
            // CPU / AI partner: swings on the side the ball is on, with timing by skill.
            if (ps.swingAge < 0 && ps.cooldown <= 0 && (d < REACH * 0.92 || h < 0.5)) {
                startSwing(e, ps, lateral >= 0 ? 1 : -1);
                Difficulty diff = cpuOf(ps.side);
                double spread = diff == null ? 1.6 : switch (diff) { case ROOKIE -> 2.6; case PRO -> 1.8; case ALL_PRO -> 1.2; case LEGEND -> 0.7; };
                ps.swingAge = (int) Math.round(Math.max(0, Math.min(SWING_WINDOW, 3 + random.nextGaussian() * spread)));
            } else {
                return;
            }
        } else if (ps.swingAge < 0) {
            return; // you have to swing
        }

        boolean wrongSide = lateral * ps.swingSide < -0.25;
        double timing = Math.max(-1, Math.min(1, (ps.swingAge - 3) / 4.0)); // <0 early, >0 late
        double q = 1.0 - 0.45 * Math.abs(d - SWEET_SPOT) / SWEET_SPOT - 0.3 * Math.abs(h - 1.1) / 1.4 - 0.25 * Math.abs(timing);
        q = Math.max(0.15, Math.min(1.0, q));

        // Aim: your A/D input (or the CPU's choice), plus where timing sends it (early = cross-court).
        double aim;
        double depth = 0.76, speedMul = 1.0, arc = 1.0;
        if (human != null) {
            // Movement keys don't change the shot (you're always running). Timing does the aiming below;
            // A / D only nudges it. SHIFT while swinging = lob. A perfectly timed, clean hit comes off a bit faster.
            Control c = controls.get(human);
            Vec3 mv = c != null ? c.move : Vec3.ZERO;
            aim = 0.25 * mv.dot(court.rightVec(ps.side));
            if (c != null && c.sneak) { depth = 0.86; speedMul = 0.62; arc = 1.35; }
            else if (Math.abs(timing) < 0.3 && q > 0.8) speedMul = 1.12;
        } else {
            aim = cpuAim(ps.side);
            if (h > 2.0 && random.nextFloat() < 0.5f) speedMul = 1.3;      // put away high balls
        }
        if (Math.abs(timing) > 0.3) aim += (timing < 0 ? -ps.swingSide : ps.swingSide) * 0.55 * Math.abs(timing);
        aim = Math.max(-1.2, Math.min(1.2, aim));
        double err = errorFor(ps.side, q);
        boolean checkNet = true;
        if (wrongSide) {
            // Framed it: weak, wild and maybe into the net.
            q *= 0.3;
            aim = random.nextDouble() * 2 - 1;
            err *= 3;
            checkNet = random.nextBoolean();
            speedMul *= 0.7;
        }

        Lobby.Side opp = ps.side.opposite();
        double half = court.W / 2 - 0.6 * court.scale();
        double r = aim * half;
        double x = court.netX() + court.toward(ps.side) * (court.L / 2) * depth;
        double z = court.zFromRight(ps.side, r);
        x += random.nextGaussian() * err;
        z += random.nextGaussian() * err;
        double speed = SHOT_SPEED * court.scale() * speedMul * (0.7 + 0.4 * q);
        launch(x, z, speed, arc, 0.3, checkNet);

        if (lastHitter != null && lastHitter != ps.side && isServe) receiverTouched = true;
        lastHitter = ps.side;
        lastHitterEntity = e;
        mark = 0;
        isServe = false;
        bounces = 0;
        ticksSinceHit = 0;
        ps.swingAge = -1;
        float pitch = (float) (1.2 + 0.5 * q);
        sound(b, SoundEvents.NOTE_BLOCK_BASEDRUM.value(), 1.0f, pitch);
        if (q > 0.85 && speedMul >= 1) sound(b, SoundEvents.PLAYER_ATTACK_STRONG, 0.5f, 1.4f);
        if (q > 0.9) particles(ParticleTypes.CRIT, b, 8, 0.2, 0.2, 0.2, 0.2);
        chooseResponsible(opp);
        reactionLeft = reactionTicks(opp);
        if (wrongSide && human != null) notifySide(ps.side, Component.literal("Wrong side! Ball on your "
                + (lateral >= 0 ? "RIGHT - right click" : "LEFT - left click")).withStyle(ChatFormatting.YELLOW));
    }

    /** Will the ball in the air land outside the court (first bounce)? */
    private boolean landsOut() {
        double floor = court.floorY + TennisBallEntity.RADIUS;
        for (Vec3 p : prediction) {
            if (p.y <= floor + 1e-6) return !court.inCourt(court.x(p), court.z(p), true, -0.1);
        }
        return false;
    }

    /** CPU shot choice: aim away from where the opponent is standing. */
    private double cpuAim(Lobby.Side side) {
        Lobby.Side opp = side.opposite();
        TennisPlayerEntity o = controlled(opp);
        double oppR = o != null ? court.rightOf(side, court.z(o.position())) : 0;
        double target = oppR > 0 ? -0.7 : 0.7;
        return target + random.nextGaussian() * 0.25;
    }

    /**
     * Sends the ball to land at court position (x, z): horizontal speed `speed`, `arc` > 1 for a higher,
     * slower ball, and (optionally) makes sure it clears the net by `clearance`.
     */
    private void launch(double x, double z, double speed, double arc, double clearance, boolean checkNet) {
        if (ball == null) return;
        Vec3 from = ball.position();
        Vec3 target = court.world(x, z, court.floorY + TennisBallEntity.RADIUS);
        Vec3 flat = new Vec3(target.x - from.x, 0, target.z - from.z);
        double dist = flat.length();
        // Flight time sets the arc (height grows with time squared), so cap it: normal shots stay below ~6
        // blocks high, lobs below ~9. Only clearing the net may stretch it a little further.
        double maxT = arc > 1 ? 50 : 40;
        double t = Math.min(maxT, Math.max(10, dist / Math.max(0.05, speed)) * arc);
        double netMaxT = maxT * 1.35;
        for (int tries = 0; tries < 30; tries++) {
            double vy = velocityY(from.y, target.y, t);
            if (!checkNet || clearsNet(from, target, t, vy, clearance) || t >= netMaxT) break;
            t = Math.min(netMaxT, t * 1.07);
        }
        double vy = velocityY(from.y, target.y, t);
        ball.setHeld(false);
        ball.setDeltaMovement(flat.x / t, vy, flat.z / t);
    }

    /** Initial vertical speed so that after t ticks of the ball's integrator it's at height y1. */
    private static double velocityY(double y0, double y1, double t) {
        return (y1 - y0 + TennisBallEntity.GRAVITY * t * (t - 1) / 2) / t;
    }

    private boolean clearsNet(Vec3 from, Vec3 to, double t, double vy, double clearance) {
        double x0 = court.x(from), x1 = court.x(to), n = court.netX();
        if ((x0 - n) * (x1 - n) >= 0) return true;
        double tn = t * (n - x0) / (x1 - x0);
        double y = from.y + vy * tn - TennisBallEntity.GRAVITY * tn * (tn - 1) / 2 - court.floorY;
        double z = court.z(from) + (court.z(to) - court.z(from)) * (tn / t);
        return y > court.netHeight(z) + clearance;
    }

    // ------------------------------------------------------------------ skill

    @Nullable
    private Difficulty cpuOf(Lobby.Side side) {
        Participant p = sides.get(side);
        return p == null ? null : p.cpu();
    }

    /** Scatter (blocks) on a shot: worse contact and lower CPU skill miss more. */
    private double errorFor(Lobby.Side side, double quality) {
        Difficulty d = cpuOf(side);
        double base = d == null ? 0.55 : switch (d) { case ROOKIE -> 1.25; case PRO -> 0.8; case ALL_PRO -> 0.55; case LEGEND -> 0.35; };
        return base * court.scale() * (0.5 + (1 - quality) * 1.6);
    }

    private int reactionTicks(Lobby.Side side) {
        Difficulty d = cpuOf(side);
        if (d == null) return 0;
        return switch (d) { case ROOKIE -> 12; case PRO -> 8; case ALL_PRO -> 5; case LEGEND -> 2; };
    }

    private double aimFromInput(@Nullable UUID human, Lobby.Side side) {
        Control c = human == null ? null : controls.get(human);
        return c == null ? 0 : Math.max(-1, Math.min(1, c.move.dot(court.rightVec(side))));
    }

    // ------------------------------------------------------------------ input helpers

    private int takeActions(@Nullable UUID human) {
        if (human == null) return 0;
        Control c = controls.get(human);
        if (c == null) return 0;
        int a = c.pending;
        c.pending = 0;
        return a;
    }

    private void clearActions(Lobby.Side side) {
        takeActions(humanOf(side));
    }

    /** LEFT click swings left (-1), RIGHT click swings right (+1). */
    private static int swingFrom(int actions) {
        if ((actions & ControlPacket.SWITCH) != 0) return 1;
        if ((actions & ControlPacket.TACKLE) != 0) return -1;
        return 0;
    }

    private static double horizDist(Vec3 a, Vec3 b) {
        double dx = a.x - b.x, dz = a.z - b.z;
        return Math.sqrt(dx * dx + dz * dz);
    }

    // ================================================================== client sync

    private TennisStatePacket statePacketFor(UUID viewer) {
        Lobby.Side side = sideOf(viewer);
        if (side == null || finished) return TennisStatePacket.inactive();
        List<TennisPlayerEntity> mineAll = team.getOrDefault(side, List.of());
        TennisPlayerEntity mine = mineAll.isEmpty() ? null : mineAll.get(0);
        TennisPlayerEntity partner = mineAll.size() > 1 ? mineAll.get(1) : null;
        // Stamina bar: both your players sprint together, so show the more tired one.
        double stamina = 1;
        boolean tired = false;
        for (TennisPlayerEntity e : mineAll) {
            PState p = pstate.get(e);
            stamina = Math.min(stamina, p.stamina);
            tired |= p.exhausted;
        }
        String hint = switch (phase) {
            case PRE_SERVE -> serving == side
                    ? (faults == 1 ? "Second serve - " : "") + "SPACE or click to toss  •  hold A / D to aim"
                    : "Get ready to return - the serve has to bounce first";
            case TOSS -> serving == side ? "Click now - hit it at the top of the toss!" : "";
            case POINT_OVER -> pendingWinner == null ? pointText + " - second serve coming" : pointText;
            default -> "";
        };
        Participant home = sides.get(Lobby.Side.HOME), away = sides.get(Lobby.Side.AWAY);
        Vec3 markWorld = court.world(markX, markZ, court.floorY);
        return new TennisStatePacket(true, field.id(), side, phase, mine != null ? mine.getId() : -1,
                ball != null ? ball.getId() : -1, home.name(), away.name(), games.get(Lobby.Side.HOME), games.get(Lobby.Side.AWAY),
                gamesToWin, pointLabel(Lobby.Side.HOME), pointLabel(Lobby.Side.AWAY), serving, doubles,
                (float) stamina, tired, hint, mark, markWorld.x, markWorld.z, partner != null ? partner.getId() : -1,
                serveBox());
    }

    /** Which service box the serve must land in, for the glowing target: 0 none, 1 deuce box, 2 ad box. */
    private int serveBox() {
        boolean serving = phase == Phase.PRE_SERVE || phase == Phase.TOSS || phase == Phase.RALLY && isServe && bounces == 0;
        if (!serving) return 0;
        return deuceCourt ? 1 : 2;
    }

    private void pushState() {
        for (ServerPlayer sp : onlineHumans()) ModNetwork.sendTo(sp, statePacketFor(sp.getUUID()));
    }

    @Override
    public void sendStateTo(ServerPlayer player) {
        ModNetwork.sendTo(player, statePacketFor(player.getUUID()));
    }

    private void sendToAll(TennisStatePacket packet) {
        for (ServerPlayer sp : onlineHumans()) ModNetwork.sendTo(sp, packet);
    }

    // ================================================================== presentation helpers

    private List<ServerPlayer> onlineHumans() {
        List<ServerPlayer> out = new ArrayList<>(2);
        MinecraftServer srv = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (srv == null) return out;
        for (UUID uuid : humans()) {
            ServerPlayer sp = srv.getPlayerList().getPlayer(uuid);
            if (sp != null) out.add(sp);
        }
        return out;
    }

    private void title(Component main, Component sub) {
        for (ServerPlayer sp : onlineHumans()) {
            sp.connection.send(new ClientboundSetTitlesAnimationPacket(4, 30, 10));
            sp.connection.send(new ClientboundSetSubtitleTextPacket(sub));
            sp.connection.send(new ClientboundSetTitleTextPacket(main));
        }
    }

    /** Sound at a spot on the court, sent straight to the players (their bodies are up in the booth). */
    private void sound(Vec3 at, SoundEvent sound, float volume, float pitch) {
        for (ServerPlayer sp : onlineHumans()) {
            sp.connection.send(new ClientboundSoundPacket(BuiltInRegistries.SOUND_EVENT.wrapAsHolder(sound), SoundSource.PLAYERS,
                    at.x, at.y, at.z, volume, pitch, sp.level().getRandom().nextLong()));
        }
    }

    private <T extends ParticleOptions> void particles(T type, Vec3 at, int count, double dx, double dy, double dz, double speed) {
        for (ServerPlayer sp : onlineHumans()) {
            sp.serverLevel().sendParticles(sp, type, true, at.x, at.y, at.z, count, dx, dy, dz, speed);
        }
    }

    private void broadcast(Component msg) {
        Component full = Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD).append(msg);
        for (ServerPlayer sp : onlineHumans()) sp.sendSystemMessage(full);
    }

    private void notifySide(Lobby.Side side, Component msg) {
        UUID uuid = humanOf(side);
        if (uuid == null) return;
        for (ServerPlayer sp : onlineHumans()) if (sp.getUUID().equals(uuid)) sp.displayClientMessage(msg, true);
    }

    private void keepInBooth(MinecraftServer srv) {
        if (level == null) return;
        Vec3 booth = court.world(court.L / 2, court.W / 2, court.floorY + BOOTH_HEIGHT);
        for (UUID uuid : humans()) {
            ServerPlayer sp = srv.getPlayerList().getPlayer(uuid);
            if (sp == null) continue;
            if (sp.level() != level || sp.position().distanceToSqr(booth) > 36) {
                sp.teleportTo(level, booth.x, booth.y, booth.z, sp.getYRot(), sp.getXRot());
            }
            if (!sp.isSpectator()) sp.setGameMode(GameType.SPECTATOR);
        }
    }

    private void sendPlayersBack() {
        MinecraftServer srv = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (srv == null) return;
        for (Map.Entry<UUID, ReturnPoint> e : returnPoints.entrySet()) {
            ServerPlayer sp = srv.getPlayerList().getPlayer(e.getKey());
            ReturnPoint rp = e.getValue();
            ServerLevel lvl = srv.getLevel(rp.dimension());
            if (sp == null || lvl == null) continue;
            sp.setGameMode(rp.gameType());
            sp.teleportTo(lvl, rp.pos().x, rp.pos().y, rp.pos().z, rp.yRot(), rp.xRot());
            com.sportsmc.match.SafeReturn.forget(sp);
        }
        returnPoints.clear();
    }
}
