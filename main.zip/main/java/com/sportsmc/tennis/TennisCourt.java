package com.sportsmc.tennis;

import com.sportsmc.field.FieldGeometry;
import com.sportsmc.lobby.Lobby;
import net.minecraft.world.phys.Vec3;

/**
 * Tennis court coordinates on top of a saved court's geometry.
 *
 *   x = distance along the court from HOME's baseline (0) to AWAY's baseline (L); the net is at L/2.
 *   z = distance across from one doubles sideline (0) to the other (W).
 *
 * Proportions follow a real court (78 ft x 36 ft): singles sidelines 4.5 ft in, service lines 21 ft
 * from the net, net 3 ft high in the middle and 3.5 ft at the posts.
 * A side's "right" is the right hand of a player on that side facing the net.
 */
public final class TennisCourt {

    public final FieldGeometry g;
    public final double L, W;
    public final int floorY;
    private final double homeRightSign;

    public TennisCourt(FieldGeometry g) {
        this.g = g;
        this.L = g.length();
        this.W = g.width();
        this.floorY = g.floorY;
        Vec3 f = g.worldDir(1, 0), zAxis = g.worldDir(0, 1);
        Vec3 right = new Vec3(-f.z, 0, f.x);
        double s = Math.signum(right.dot(zAxis));
        this.homeRightSign = s == 0 ? 1 : s;
    }

    /** How big this court is compared to a regulation 24-block court (speeds scale with it). */
    public double scale() { return Math.max(0.6, Math.min(3.0, L / 24.0)); }

    public Vec3 world(double x, double z, double y) {
        return g.world(g.goalA + g.dir * x, g.side0 + z, y);
    }

    public double x(Vec3 p) {
        double u = g.axis == FieldGeometry.Axis.X ? p.x : p.z;
        return (u - g.goalA) * g.dir;
    }

    public double z(Vec3 p) {
        double v = g.axis == FieldGeometry.Axis.X ? p.z : p.x;
        return v - g.side0;
    }

    public double netX() { return L / 2.0; }
    public double singlesInset() { return W * 4.5 / 36.0; }
    public double serviceDist() { return L * 21.0 / 78.0; }

    /** Net height (above the floor) at a point across the court. */
    public double netHeight(double z) {
        double bpf = L / 78.0;
        double frac = Math.min(1.2, Math.abs(z - W / 2) / (W / 2));
        return Math.max(0.8, (3.0 + 0.5 * frac) * bpf);
    }

    // ------------------------------------------------------------------ sides

    /** +1 if this side faces increasing x (HOME), -1 otherwise. */
    public int toward(Lobby.Side s) { return s == Lobby.Side.HOME ? 1 : -1; }

    public double baselineX(Lobby.Side s) { return s == Lobby.Side.HOME ? 0 : L; }

    public boolean onHalf(Lobby.Side s, double x) { return s == Lobby.Side.HOME ? x < netX() : x > netX(); }

    /** +1 if this side's right hand points toward +z. */
    public double rightSign(Lobby.Side s) { return s == Lobby.Side.HOME ? homeRightSign : -homeRightSign; }

    /** z of a point `r` blocks to a side's right of the center line. */
    public double zFromRight(Lobby.Side s, double r) { return W / 2 + r * rightSign(s); }

    /** Lateral position of a z value, measured to the side's right of the center line. */
    public double rightOf(Lobby.Side s, double z) { return (z - W / 2) * rightSign(s); }

    public Vec3 facing(Lobby.Side s) { return g.worldDir(toward(s), 0); }

    public Vec3 rightVec(Lobby.Side s) {
        Vec3 f = facing(s);
        return new Vec3(-f.z, 0, f.x);
    }

    public float netYaw(Lobby.Side s) { return g.yaw(s == Lobby.Side.HOME); }

    // ------------------------------------------------------------------ lines

    public boolean inCourt(double x, double z, boolean doubles, double tol) {
        double z0 = doubles ? 0 : singlesInset(), z1 = doubles ? W : W - singlesInset();
        return x >= -tol && x <= L + tol && z >= z0 - tol && z <= z1 + tol;
    }

    /** Is (x, z) inside the receiver's deuce (right) or ad (left) service box? */
    public boolean inServiceBox(Lobby.Side receiver, boolean deuce, double x, double z, double tol) {
        double n = netX(), sd = serviceDist();
        boolean xOk = receiver == Lobby.Side.HOME ? x >= n - sd - tol && x <= n + tol : x >= n - tol && x <= n + sd + tol;
        double r = rightOf(receiver, z), half = W / 2 - singlesInset();
        boolean zOk = deuce ? r >= -tol && r <= half + tol : r <= tol && r >= -half - tol;
        return xOk && zOk;
    }
}
