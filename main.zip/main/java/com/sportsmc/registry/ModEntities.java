package com.sportsmc.registry;

import com.sportsmc.SportsMC;
import com.sportsmc.entity.FootballEntity;
import com.sportsmc.entity.FootballPlayerEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = SportsMC.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SportsMC.MODID);

    public static final RegistryObject<EntityType<FootballPlayerEntity>> FOOTBALL_PLAYER = ENTITIES.register("football_player",
            () -> EntityType.Builder.<FootballPlayerEntity>of(FootballPlayerEntity::new, MobCategory.MISC)
                    .sized(0.6f, 1.8f)
                    .clientTrackingRange(10)
                    .updateInterval(2)
                    .build("football_player"));

    public static final RegistryObject<EntityType<FootballEntity>> FOOTBALL = ENTITIES.register("football",
            () -> EntityType.Builder.<FootballEntity>of(FootballEntity::new, MobCategory.MISC)
                    .sized(0.3f, 0.3f)
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .build("football"));

    public static final RegistryObject<EntityType<com.sportsmc.entity.TennisPlayerEntity>> TENNIS_PLAYER = ENTITIES.register("tennis_player",
            () -> EntityType.Builder.<com.sportsmc.entity.TennisPlayerEntity>of(com.sportsmc.entity.TennisPlayerEntity::new, MobCategory.MISC)
                    .sized(0.6f, 1.8f)
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .build("tennis_player"));

    public static final RegistryObject<EntityType<com.sportsmc.entity.TennisBallEntity>> TENNIS_BALL = ENTITIES.register("tennis_ball",
            () -> EntityType.Builder.<com.sportsmc.entity.TennisBallEntity>of(com.sportsmc.entity.TennisBallEntity::new, MobCategory.MISC)
                    .sized(0.25f, 0.25f)
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .build("tennis_ball"));

    private ModEntities() {}

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(FOOTBALL_PLAYER.get(), FootballPlayerEntity.createAttributes().build());
        event.put(TENNIS_PLAYER.get(), FootballPlayerEntity.createAttributes().build());
    }
}
