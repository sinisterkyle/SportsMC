package com.sportsmc.registry;

import com.sportsmc.SportsMC;
import com.sportsmc.item.FieldBlueprintItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SportsMC.MODID);

    public static final RegistryObject<Item> FIELD_BLUEPRINT = ITEMS.register("field_blueprint",
            () -> new FieldBlueprintItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));

    public static final RegistryObject<Item> FOOTBALL = ITEMS.register("football",
            () -> new Item(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> TENNIS_BALL = ITEMS.register("tennis_ball",
            () -> new Item(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> TENNIS_RACKET = ITEMS.register("tennis_racket",
            () -> new Item(new Item.Properties().stacksTo(1)));

    private ModItems() {}
}
