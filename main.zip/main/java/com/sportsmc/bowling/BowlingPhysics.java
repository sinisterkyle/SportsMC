package com.sportsmc.bowling;

/**
 * Bowling ball and pin physics, in lane coordinates (no Minecraft classes, so it can run anywhere):
 *   x = across the lane in blocks, 0 = the lane's center line, + = right as the bowler sees it;
 *   u = along the lane in blocks, 0 = the foul line, increasing toward the pins.
 *
 * Everything sized like a real lane, scaled so the lane surface (without gutters) fills the width you built:
 * a 41.5-inch lane, 15-inch pins 12 inches apart, an 8.5-inch ball. The ball skids on the oiled front of the
 * lane and hooks on the dry back end (slower balls hook more). Pins are knocked over by the ball and by each
 * other: a pin hit hard enough tips over (an inverted pendulum), its top sweeps through anything in the way,
 * and fallen pins slide across the deck, bounce off the side kickbacks, drop into the gutters or the pit.
 * The simulation is deterministic: the same throw always gives the same result (the CPU relies on that).
 */
public final class BowlingPhysics {

    public static final int STANDING = 0, FALLING = 1, DOWN = 2, GONE = 3;

    /** Lane measurements in blocks. */
    public record Dims(double length, double laneHalf, double halfWidth, double scale) {
        /** From the marked area: length along the lane and total width (lane surface + both gutters). */
        public static Dims of(double length, double width) {
            double laneHalf = width / 2 * (41.5 / 60.0); // a 41.5" lane between two 9.25" gutters
            return new Dims(length, laneHalf, width / 2, laneHalf * 2 / 1.0541);
        }
        public double ballR() { return 0.108 * scale; }
        public double pinR() { return 0.0605 * scale; }
        public double pinH() { return 0.381 * scale; }
        public double spacing() { return 0.3048 * scale; }
        public double rowGap() { return 0.2639 * scale; }
        /** The head pin (pin 1), 34 inches in front of the pit. */
        public double headU() { return length - 0.87 * scale; }
        public double gravity() { return 9.81 * scale; }
        /** Pin i (0..9 = pins 1..10): rows 1 / 2-3 / 4-5-6 / 7-8-9-10, left to right as the bowler sees them. */
        public double pinX(int i) { int r = row(i); return (col(i) - r / 2.0) * spacing(); }
        public double pinU(int i) { return headU() + row(i) * rowGap(); }
        private static int row(int i) { return i < 1 ? 0 : i < 3 ? 1 : i < 6 ? 2 : 3; }
        private static int col(int i) { return i < 1 ? i : i < 3 ? i - 1 : i < 6 ? i - 3 : i - 6; }
    }

    public static final class Pin {
        public double x, u, vx, vu;
        /** 0 = upright, PI/2 = lying flat; it falls toward angle dir (atan2(du, dx)). */
        public double tilt, tiltRate, dir;
        public int state;

        Pin copy() {
            Pin p = new Pin();
            p.x = x; p.u = u; p.vx = vx; p.vu = vu; p.tilt = tilt; p.tiltRate = tiltRate; p.dir = dir; p.state = state;
            return p;
        }

        double speed() { return Math.sqrt(vx * vx + vu * vu); }
    }

    private static final double BALL_MASS = 7.0, PIN_MASS = 1.5;
    private static final int SUBSTEPS = 10;

    public final Dims d;
    public final Pin[] pins = new Pin[10];
    /** Pins standing when the current roll started (for counting what this roll knocked down). */
    private final boolean[] upAtStart = new boolean[10];

    public double bx, bu, bvx, bvu, hook, hookAccel;
    /** Ball rotation for drawing (radians rolled). */
    public double ballRoll;
    public boolean ballLive, inGutter;
    public double time;

    public BowlingPhysics(Dims d) {
        this.d = d;
        for (int i = 0; i < 10; i++) pins[i] = new Pin();
        rack();
    }

    public BowlingPhysics copy() {
        BowlingPhysics c = new BowlingPhysics(d);
        for (int i = 0; i < 10; i++) c.pins[i] = pins[i].copy();
        System.arraycopy(upAtStart, 0, c.upAtStart, 0, 10);
        c.bx = bx; c.bu = bu; c.bvx = bvx; c.bvu = bvu; c.hook = hook; c.hookAccel = hookAccel;
        c.ballLive = ballLive; c.inGutter = inGutter; c.time = time; c.ballRoll = ballRoll;
        return c;
    }

    /** All ten pins back on their spots. */
    public void rack() {
        for (int i = 0; i < 10; i++) {
            Pin p = pins[i];
            p.x = d.pinX(i);
            p.u = d.pinU(i);
            p.vx = p.vu = p.tilt = p.tiltRate = p.dir = 0;
            p.state = STANDING;
        }
        ballLive = false;
    }

    /** Clears away knocked pins (the sweep); pins still standing stay where they are. */
    public void sweep() {
        for (Pin p : pins) {
            if (p.state != STANDING) p.state = GONE;
            p.vx = p.vu = p.tilt = p.tiltRate = 0;
        }
        ballLive = false;
    }

    public int standingCount() {
        int n = 0;
        for (Pin p : pins) if (p.state == STANDING) n++;
        return n;
    }

    /** Pins knocked down by the current roll so far. */
    public int knocked() {
        int n = 0;
        for (int i = 0; i < 10; i++) if (upAtStart[i] && pins[i].state != STANDING) n++;
        return n;
    }

    public boolean wasUpAtStart(int i) {
        return upAtStart[i];
    }

    /** Ball speed down the lane for a power of 0..1 (faster balls reach the pins sooner and hook less). */
    public double speedFor(double power) {
        double v = d.length / (3.3 - 1.7 * Math.max(0, Math.min(1, power)));
        return Math.max(d.scale * 3.2, Math.min(d.scale * 11, v));
    }

    /**
     * Rolls the ball.
     * @param start  where it's released, -1 (left edge of the lane) .. 1 (right edge)
     * @param aimDeg angle off straight down the lane, + = to the right
     * @param power  0..1
     * @param hookIn -1 (curves hard left) .. 1 (curves hard right)
     */
    public void launch(double start, double aimDeg, double power, double hookIn) {
        for (int i = 0; i < 10; i++) upAtStart[i] = pins[i].state == STANDING;
        double maxX = d.laneHalf - d.ballR();
        bx = Math.max(-maxX, Math.min(maxX, start * maxX));
        bu = -d.ballR();
        bvu = speedFor(power);
        bvx = bvu * Math.tan(Math.toRadians(Math.max(-8, Math.min(8, aimDeg))));
        hook = Math.max(-1, Math.min(1, hookIn));
        // Full hook at a medium speed moves the ball about 0.9 of a half-lane over the back end.
        double backEnd = d.headU() - d.length * 0.42;
        double vRef = speedFor(0.5);
        hookAccel = 6 * 0.9 * d.laneHalf * (vRef / backEnd) * (vRef / backEnd);
        ballLive = true;
        inGutter = false;
        ballRoll = 0;
        time = 0;
    }

    /** True once the ball has left the lane and every pin has stopped moving. */
    public boolean settled() {
        if (ballLive) return false;
        for (Pin p : pins) {
            if (p.state == GONE) continue;
            if (p.state == FALLING || p.speed() > 0.05 * d.scale) return false;
        }
        return true;
    }

    /** Advances the world by dt seconds (sub-stepped internally). */
    public void step(double dt) {
        double h = dt / SUBSTEPS;
        for (int i = 0; i < SUBSTEPS; i++) substep(h);
        time += dt;
    }

    private void substep(double dt) {
        if (ballLive) moveBall(dt);
        for (Pin p : pins) movePin(p, dt);
        if (ballLive && !inGutter) for (Pin p : pins) ballVsPin(p);
        for (int i = 0; i < 10; i++) {
            for (int j = i + 1; j < 10; j++) pinVsPin(pins[i], pins[j]);
        }
    }

    // ------------------------------------------------------------------ ball

    private void moveBall(double dt) {
        double r = d.ballR();
        // However the pins push back, a 15-pound ball keeps rolling on into the pit.
        double minV = speedFor(0) * 0.3;
        if (bvu < minV) bvu = minV;
        if (inGutter) {
            bu += bvu * dt;
        } else {
            // Oil on the front of the lane: the ball skids straight, then grips and hooks on the back end.
            double ramp = Math.max(0, Math.min(1, (bu - d.length * 0.42) / (d.headU() - d.length * 0.42)));
            bvx += hook * hookAccel * ramp * dt;
            bvu *= Math.exp(-0.04 * dt);
            bx += bvx * dt;
            bu += bvu * dt;
            if (Math.abs(bx) > d.laneHalf) {
                // Off the edge: into the gutter, where it runs straight to the pit without touching a pin.
                inGutter = true;
                bx = Math.signum(bx) * (d.laneHalf + d.halfWidth) / 2;
                bvx = 0;
            }
        }
        ballRoll += Math.sqrt(bvx * bvx + bvu * bvu) * dt / r;
        if (bu > d.length + r) ballLive = false;
    }

    private void ballVsPin(Pin p) {
        if (p.state == GONE) return;
        double[] q = closestOnPin(p, bx, bu);
        double rr = d.ballR() + (p.state == STANDING ? d.pinR() : d.pinR() * 0.8);
        double ox = bx - q[0], ou = bu - q[1], dist2 = ox * ox + ou * ou;
        if (dist2 >= rr * rr || dist2 < 1e-12) return;
        double dist = Math.sqrt(dist2), nx = ox / dist, nu = ou / dist;
        // Separate (the heavy ball barely moves).
        double pen = rr - dist;
        bx += nx * pen * PIN_MASS / (BALL_MASS + PIN_MASS);
        bu += nu * pen * PIN_MASS / (BALL_MASS + PIN_MASS);
        p.x -= nx * pen * BALL_MASS / (BALL_MASS + PIN_MASS);
        p.u -= nu * pen * BALL_MASS / (BALL_MASS + PIN_MASS);
        double rel = (bvx - p.vx) * nx + (bvu - p.vu) * nu;
        if (rel >= 0) return;
        double j = -(1 + 0.62) * rel / (1 / BALL_MASS + 1 / PIN_MASS);
        bvx += j / BALL_MASS * nx;
        bvu += j / BALL_MASS * nu;
        p.vx -= j / PIN_MASS * nx;
        p.vu -= j / PIN_MASS * nu;
        knock(p, -rel);
    }

    // ------------------------------------------------------------------ pins

    private void movePin(Pin p, double dt) {
        if (p.state == GONE) return;
        double g = d.gravity();
        if (p.state == FALLING) {
            // Inverted pendulum about the base: the further it leans, the faster it goes.
            p.tiltRate += 1.5 * g / d.pinH() * Math.sin(Math.max(0.05, p.tilt)) * dt;
            p.tilt += p.tiltRate * dt;
            if (p.tilt >= Math.PI / 2) {
                p.tilt = Math.PI / 2;
                p.tiltRate = 0;
                p.state = DOWN;
                p.vx *= 0.7;
                p.vu *= 0.7;
            }
        }
        // Sliding friction: standing pins grip hardest, lying pins slide furthest.
        double mu = p.state == STANDING ? 0.55 : p.state == FALLING ? 0.25 : 0.32;
        double sp = p.speed();
        if (sp > 0) {
            double nsp = Math.max(0, sp - mu * g * dt);
            p.vx *= nsp / sp;
            p.vu *= nsp / sp;
        }
        p.x += p.vx * dt;
        p.u += p.vu * dt;
        // Side kickbacks (the walls beside the pin deck) bounce flying pins back in.
        double wall = d.halfWidth - d.pinR();
        if (Math.abs(p.x) > wall && p.u > d.headU() - d.spacing() * 2) {
            if (p.speed() > 1.2 * d.scale && Math.signum(p.vx) == Math.signum(p.x)) {
                p.x = Math.signum(p.x) * wall;
                p.vx = -p.vx * 0.5;
                if (p.state == STANDING) knock(p, p.speed());
            }
        }
        // Into a gutter (once it's lost its speed there) or off the back into the pit: gone.
        if (Math.abs(p.x) > d.laneHalf + d.pinR() && p.speed() < 1.2 * d.scale) p.state = GONE;
        else if (Math.abs(p.x) > d.halfWidth + d.pinR()) p.state = GONE;
        if (p.u > d.length + d.pinR() * 0.5) p.state = GONE;
        if (p.state == STANDING && Math.abs(p.x) > d.laneHalf) knock(p, Math.max(p.speed(), 0.5 * d.scale)); // tips into the gutter
    }

    /** A standing pin hit hard enough starts to topple, away from the hit. */
    private void knock(Pin p, double impactSpeed) {
        if (p.state != STANDING) return;
        double sp = p.speed();
        if (sp < 0.22 * d.scale && impactSpeed < 0.35 * d.scale) return; // a nudge: it wobbles but stays up
        p.state = FALLING;
        p.dir = sp > 1e-6 ? Math.atan2(p.vu, p.vx) : p.dir;
        p.tilt = 0.06;
        p.tiltRate = Math.min(14, 0.9 * Math.max(sp, impactSpeed * 0.5) / d.pinH());
    }

    /** Closest point to (x, u) on the pin's body as seen from above (a point when upright, a line as it falls). */
    private double[] closestOnPin(Pin p, double x, double u) {
        if (p.state == STANDING) return new double[]{p.x, p.u};
        double len = d.pinH() * Math.sin(p.tilt);
        double ex = p.x + Math.cos(p.dir) * len, eu = p.u + Math.sin(p.dir) * len;
        double dx = ex - p.x, du = eu - p.u, l2 = dx * dx + du * du;
        double t = l2 < 1e-12 ? 0 : Math.max(0, Math.min(1, ((x - p.x) * dx + (u - p.u) * du) / l2));
        return new double[]{p.x + dx * t, p.u + du * t, t};
    }

    private void pinVsPin(Pin a, Pin b) {
        if (a.state == GONE || b.state == GONE) return;
        if (a.state == STANDING && b.state == STANDING && a.speed() < 1e-4 && b.speed() < 1e-4) return;
        // Closest points between the two bodies (each a point or a segment).
        double[] best = null;
        double bestD2 = Double.MAX_VALUE;
        // Sample: closest point on b to a's segment ends and middle, and vice versa (cheap and good enough).
        double[][] aPts = samples(a), bPts = samples(b);
        for (double[] pa : aPts) {
            double[] qb = closestOnPin(b, pa[0], pa[1]);
            double dx = pa[0] - qb[0], du = pa[1] - qb[1], d2 = dx * dx + du * du;
            if (d2 < bestD2) { bestD2 = d2; best = new double[]{pa[0], pa[1], qb[0], qb[1], pa[2], qb.length > 2 ? qb[2] : 0}; }
        }
        for (double[] pb : bPts) {
            double[] qa = closestOnPin(a, pb[0], pb[1]);
            double dx = qa[0] - pb[0], du = qa[1] - pb[1], d2 = dx * dx + du * du;
            if (d2 < bestD2) { bestD2 = d2; best = new double[]{qa[0], qa[1], pb[0], pb[1], qa.length > 2 ? qa[2] : 0, pb[2]}; }
        }
        double ra = a.state == STANDING ? d.pinR() : d.pinR() * 0.8, rb = b.state == STANDING ? d.pinR() : d.pinR() * 0.8;
        double rr = ra + rb;
        if (best == null || bestD2 >= rr * rr) return;
        double dist = Math.sqrt(Math.max(bestD2, 1e-12));
        double nx = (best[0] - best[2]) / dist, nu = (best[1] - best[3]) / dist; // from b toward a
        if (bestD2 < 1e-12) { nx = 1; nu = 0; }
        double pen = rr - dist;
        a.x += nx * pen / 2; a.u += nu * pen / 2;
        b.x -= nx * pen / 2; b.u -= nu * pen / 2;
        // Contact velocity includes the sweep of a falling pin's top.
        double[] va = contactVel(a, best[4]), vb = contactVel(b, best[5]);
        double rel = (va[0] - vb[0]) * nx + (va[1] - vb[1]) * nu;
        if (rel >= 0) return;
        double j = -(1 + 0.5) * rel / (2 / PIN_MASS);
        a.vx += j / PIN_MASS * nx; a.vu += j / PIN_MASS * nu;
        b.vx -= j / PIN_MASS * nx; b.vu -= j / PIN_MASS * nu;
        knock(a, -rel);
        knock(b, -rel);
    }

    /** Points along a pin's body: {x, u, t (0 = base, 1 = top)}. */
    private double[][] samples(Pin p) {
        if (p.state == STANDING) return new double[][]{{p.x, p.u, 0}};
        double len = d.pinH() * Math.sin(p.tilt);
        double cx = Math.cos(p.dir) * len, cu = Math.sin(p.dir) * len;
        return new double[][]{{p.x, p.u, 0}, {p.x + cx * 0.5, p.u + cu * 0.5, 0.5}, {p.x + cx, p.u + cu, 1}};
    }

    /** Velocity of a point t (0 = base .. 1 = top) along a pin: sliding plus the top's sweep as it falls. */
    private double[] contactVel(Pin p, double t) {
        double vx = p.vx, vu = p.vu;
        if (p.state == FALLING) {
            double sweep = p.tiltRate * d.pinH() * Math.cos(p.tilt) * t;
            vx += Math.cos(p.dir) * sweep;
            vu += Math.sin(p.dir) * sweep;
        }
        return new double[]{vx, vu};
    }
}
