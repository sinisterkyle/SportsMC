package com.sportsmc.bowling;

import com.sportsmc.field.FieldGeometry;
import net.minecraft.world.phys.Vec3;

/**
 * A bowling lane laid out with the Field Blueprint: corner 1 on the foul line (the bowler's end), corner 2 at the
 * far corner past the pins. Maps lane coordinates (x across, + = the bowler's right; u along, 0 = foul line)
 * to the world. The marked width includes both gutters.
 */
public final class BowlingLane {

    public final FieldGeometry g;
    public final BowlingPhysics.Dims dims;
    /** +1 / -1: which way the world's "v" runs relative to the bowler's right hand. */
    private final int side;

    public BowlingLane(FieldGeometry g) {
        this.g = g;
        this.dims = BowlingPhysics.Dims.of(g.length(), g.width());
        this.side = g.axis == FieldGeometry.Axis.X ? g.dir : -g.dir;
    }

    public Vec3 world(double x, double u, double y) {
        return g.world(g.goalA + g.dir * u, g.vCenter() + side * x, y);
    }

    /** World direction (horizontal unit vector) of a lane direction (dx across, du along). */
    public Vec3 worldDir(double dx, double du) {
        double wu = du * g.dir, wv = dx * side;
        Vec3 w = g.axis == FieldGeometry.Axis.X ? new Vec3(wu, 0, wv) : new Vec3(wv, 0, wu);
        return w.lengthSqr() < 1e-12 ? Vec3.ZERO : w.normalize();
    }

    /** Lane coordinates {x, u} of a world position. */
    public double[] laneOf(Vec3 p) {
        double wu = g.axis == FieldGeometry.Axis.X ? p.x : p.z;
        double wv = g.axis == FieldGeometry.Axis.X ? p.z : p.x;
        return new double[]{(wv - g.vCenter()) * side, (wu - g.goalA) * g.dir};
    }

    /** Facing down the lane toward the pins. */
    public float yawToPins() {
        return g.yaw(true);
    }

    public int floorY() {
        return g.floorY;
    }

    /** Where the bowler stands to throw: just behind the foul line, in the middle. */
    public Vec3 approach() {
        return world(0, -1.6, g.floorY);
    }

    /** Where the bowler who's waiting stands: a little further back. */
    public Vec3 bench() {
        return world(0, -3.4, g.floorY);
    }

    public Vec3 pinDeck() {
        return world(0, dims.headU() + dims.rowGap() * 1.5, g.floorY + 0.3);
    }
}
