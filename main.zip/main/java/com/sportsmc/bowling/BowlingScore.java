package com.sportsmc.bowling;

import java.util.ArrayList;
import java.util.List;

/**
 * Ten-pin scoring for one bowler from the list of pins knocked down by each ball.
 * A strike scores 10 + the next two balls, a spare 10 + the next ball. The last frame of the game
 * (frame 3, 5 or 10, depending on the game length) gives the bonus balls right away: up to three balls.
 */
public final class BowlingScore {

    private BowlingScore() {}

    /** Where a bowler is in their game. */
    public record Position(int frame, int ball, int pinsUp, boolean frameDone, boolean gameDone) {}

    /** Works out the current frame and ball from the rolls so far. */
    public static Position position(List<Integer> rolls, int frames) {
        int i = 0;
        for (int f = 0; f < frames; f++) {
            boolean last = f == frames - 1;
            if (!last) {
                if (i >= rolls.size()) return new Position(f, 0, 10, false, false);
                if (rolls.get(i) == 10) { i++; continue; }
                if (i + 1 >= rolls.size()) return new Position(f, 1, 10 - rolls.get(i), false, false);
                i += 2;
                continue;
            }
            // Last frame: up to three balls; the rack is reset after a strike or a spare.
            int n = rolls.size() - i;
            if (n == 0) return new Position(f, 0, 10, false, false);
            int r1 = rolls.get(i);
            if (n == 1) return new Position(f, 1, r1 == 10 ? 10 : 10 - r1, false, false);
            int r2 = rolls.get(i + 1);
            boolean bonus = r1 == 10 || r1 + r2 == 10;
            if (!bonus) return new Position(f, 2, 0, true, true);
            if (n == 2) {
                int up = r1 == 10 ? (r2 == 10 ? 10 : 10 - r2) : 10;
                return new Position(f, 2, up, false, false);
            }
            return new Position(f, 3, 0, true, true);
        }
        return new Position(frames - 1, 0, 0, true, true);
    }

    /** True if the ball that was just added finished its frame. */
    public static boolean frameEndedAfter(List<Integer> rolls, int frames) {
        if (rolls.isEmpty()) return false;
        Position before = position(rolls.subList(0, rolls.size() - 1), frames);
        Position after = position(rolls, frames);
        return after.gameDone() || after.frame() != before.frame();
    }

    /** Running total after each frame, or -1 for frames that can't be scored yet (waiting on bonus balls). */
    public static int[] cumulative(List<Integer> rolls, int frames) {
        int[] out = new int[frames];
        int total = 0, i = 0;
        for (int f = 0; f < frames; f++) {
            out[f] = -1;
            boolean last = f == frames - 1;
            if (i >= rolls.size()) { fillRest(out, f); return out; }
            if (last) {
                int n = rolls.size() - i;
                int r1 = rolls.get(i);
                if (n < 2) { fillRest(out, f); return out; }
                int r2 = rolls.get(i + 1);
                if (r1 == 10 || r1 + r2 == 10) {
                    if (n < 3) { fillRest(out, f); return out; }
                    total += r1 + r2 + rolls.get(i + 2);
                } else total += r1 + r2;
                out[f] = total;
                return out;
            }
            int r1 = rolls.get(i);
            if (r1 == 10) {
                if (i + 2 >= rolls.size()) { fillRest(out, f); return out; }
                total += 10 + rolls.get(i + 1) + rolls.get(i + 2);
                i += 1;
            } else {
                if (i + 1 >= rolls.size()) { fillRest(out, f); return out; }
                int r2 = rolls.get(i + 1);
                if (r1 + r2 == 10) {
                    if (i + 2 >= rolls.size()) { fillRest(out, f); return out; }
                    total += 10 + rolls.get(i + 2);
                } else total += r1 + r2;
                i += 2;
            }
            out[f] = total;
        }
        return out;
    }

    private static void fillRest(int[] out, int from) {
        for (int k = from; k < out.length; k++) out[k] = -1;
    }

    /** Score so far, counting only frames that can already be scored. */
    public static int total(List<Integer> rolls, int frames) {
        int best = 0;
        for (int v : cumulative(rolls, frames)) if (v >= 0) best = v;
        return best;
    }

    /** Score if no more pins fell (bonus balls not yet thrown count as zero): used to rank a finished game. */
    public static int finalTotal(List<Integer> rolls, int frames) {
        List<Integer> padded = new ArrayList<>(rolls);
        for (int k = 0; k < 3; k++) padded.add(0);
        int[] c = cumulative(padded, frames);
        int best = 0;
        for (int v : c) if (v >= 0) best = v;
        return best;
    }

    /** What to print in each frame's little boxes: "X", "/", "-" (miss) or a number. */
    public static List<String[]> marks(List<Integer> rolls, int frames) {
        List<String[]> out = new ArrayList<>();
        int i = 0;
        for (int f = 0; f < frames; f++) {
            boolean last = f == frames - 1;
            String[] m = new String[last ? 3 : 2];
            for (int k = 0; k < m.length; k++) m[k] = "";
            if (!last) {
                if (i < rolls.size()) {
                    int r1 = rolls.get(i);
                    if (r1 == 10) { m[1] = "X"; i++; }
                    else {
                        m[0] = num(r1);
                        if (i + 1 < rolls.size()) {
                            int r2 = rolls.get(i + 1);
                            m[1] = r1 + r2 == 10 ? "/" : num(r2);
                        }
                        i += Math.min(2, rolls.size() - i);
                    }
                }
            } else {
                int prev = -1; // pins of the previous ball in this rack (-1 = fresh rack)
                for (int k = 0; k < 3 && i < rolls.size(); k++, i++) {
                    int r = rolls.get(i);
                    if (prev < 0) { m[k] = r == 10 ? "X" : num(r); prev = r == 10 ? -1 : r; }
                    else { m[k] = prev + r == 10 ? "/" : num(r); prev = -1; }
                }
            }
            out.add(m);
        }
        return out;
    }

    private static String num(int n) {
        return n == 0 ? "-" : String.valueOf(n);
    }
}
