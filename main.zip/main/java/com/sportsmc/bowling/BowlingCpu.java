package com.sportsmc.bowling;

import com.sportsmc.lobby.Difficulty;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The CPU bowler. It tries out candidate throws on a copy of the lane (the physics is deterministic, so a test roll
 * shows exactly what that throw would do), keeps the one that knocks down the most pins, then throws it with some
 * human error: lots for a Rookie, almost none for a Legend. The work is spread over several ticks (a few test rolls
 * per tick) so the server never stalls.
 */
public final class BowlingCpu {

    /** Thinking time allowed per server tick (the search just takes a few more ticks if it needs them). */
    private static final long BUDGET_NANOS = 2_000_000L;
    /** Best full-rack throws found so far, per lane size: every lane of the same size plays the same. */
    private static final java.util.Map<String, double[]> STRIKE_LINES = new java.util.concurrent.ConcurrentHashMap<>();

    private final BowlingPhysics base;
    private final List<double[]> candidates = new ArrayList<>();
    private int next = 0;
    private double[] best;
    private double bestScore = -1;
    private final Difficulty difficulty;
    private final Random random;

    /**
     * @param knownStrikeLine the best full-rack throw found earlier on this lane (the lane doesn't change, so a full
     *                        rack never needs searching twice), or null to search
     */
    public BowlingCpu(BowlingPhysics lane, Difficulty difficulty, Random random, double[] knownStrikeLine) {
        this.base = lane.copy();
        this.difficulty = difficulty;
        this.random = random;
        BowlingPhysics.Dims d = lane.d;
        double[] known = knownStrikeLine != null ? knownStrikeLine : STRIKE_LINES.get(key(d));
        if (lane.standingCount() == 10 && known != null) {
            best = known;
            bestScore = 10;
        } else if (lane.standingCount() == 10) {
            // A full rack: look for a strike line (outside start, hooking back into the pocket), plus straight balls.
            for (double start = -1; start <= 1.001; start += 0.25)
                for (double hook : new double[]{-1, -0.6, 0, 0.6, 1})
                    for (double power : new double[]{0.6, 0.85})
                        for (double aim = -1.5; aim <= 1.501; aim += 1.5)
                            candidates.add(new double[]{start, aim, power, hook});
        } else {
            // A spare: roll straight at each pin that's left, from a few starting spots.
            for (BowlingPhysics.Pin p : lane.pins) {
                if (p.state != BowlingPhysics.STANDING) continue;
                for (double start = -0.8; start <= 0.801; start += 0.4) {
                    double sx = start * (d.laneHalf() - d.ballR());
                    for (double off : new double[]{-0.5, 0, 0.5}) {
                        double aim = Math.toDegrees(Math.atan2(p.x + off * d.pinR() * 2 - sx, p.u));
                        if (Math.abs(aim) > 3) continue;
                        candidates.add(new double[]{start, aim, 0.75, 0});
                        candidates.add(new double[]{start, aim, 0.95, 0});
                    }
                }
            }
            if (candidates.isEmpty()) candidates.add(new double[]{0, 0, 0.7, 0});
        }
    }

    private static String key(BowlingPhysics.Dims d) {
        return Math.round(d.length() * 4) + "x" + Math.round(d.halfWidth() * 8);
    }

    /** Does a few more test rolls (within a small time budget); true once it has decided. */
    public boolean think() {
        long until = System.nanoTime() + BUDGET_NANOS;
        while (next < candidates.size()) {
            double[] c = candidates.get(next++);
            double score = testRoll(c) - Math.abs(c[1]) * 0.01; // among equals, a gentler aim (more forgiving)
            if (score > bestScore) { bestScore = score; best = c; }
            if (System.nanoTime() > until) break;
        }
        boolean done = next >= candidates.size();
        if (done && best != null && fullRack() && bestScore >= 9.5) STRIKE_LINES.putIfAbsent(key(base.d), best);
        return done;
    }

    /** Pins a throw would knock down. Stops early: a gutter ball before the pins, or once the action has died down. */
    private int testRoll(double[] c) {
        BowlingPhysics sim = base.copy();
        sim.launch(c[0], c[1], c[2], c[3]);
        double reach = sim.d.headU() - sim.d.ballR() * 2;
        int ticks = 0, afterHit = 0;
        while (!sim.settled() && ticks < 160) {
            sim.step(0.05);
            ticks++;
            if (sim.inGutter && sim.bu < reach && sim.knocked() == 0) return 0;
            if (sim.knocked() > 0 || sim.bu > sim.d.length()) afterHit++;
            if (afterHit > 30) break; // 1.5 s after the hit: the count is all but final
        }
        return sim.knocked();
    }

    /** The best throw found (before the CPU's error), to remember for the next full rack. */
    public double[] bestThrow() {
        return best;
    }

    /** True if this search was for a full rack (so its result is worth remembering). */
    public boolean fullRack() {
        return base.standingCount() == 10;
    }

    /** The chosen throw with this CPU's error added: {start, aim, power, hook}. */
    public double[] decision() {
        double[] c = best != null ? best : new double[]{0, 0, 0.7, 0};
        double[] err = switch (difficulty) {
            case ROOKIE -> new double[]{0.22, 0.9, 0.12, 0.35};
            case PRO -> new double[]{0.10, 0.45, 0.07, 0.18};
            case ALL_PRO -> new double[]{0.05, 0.22, 0.04, 0.09};
            case LEGEND -> new double[]{0.025, 0.1, 0.02, 0.045};
        };
        return new double[]{
                clamp(c[0] + random.nextGaussian() * err[0], -1, 1),
                clamp(c[1] + random.nextGaussian() * err[1], -3, 3),
                clamp(c[2] + random.nextGaussian() * err[2], 0.15, 1),
                clamp(c[3] + random.nextGaussian() * err[3], -1, 1)};
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
