package com.sportsmc.bowling;

import com.sportsmc.field.FieldData;
import com.sportsmc.lobby.Difficulty;
import com.sportsmc.lobby.Lobby;
import com.sportsmc.match.SportMatch;
import com.sportsmc.network.BowlingStatePacket;
import com.sportsmc.network.BowlingThrowPacket;
import com.sportsmc.network.ControlPacket;
import com.sportsmc.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * A game of ten-pin bowling on one lane: two bowlers (or a bowler and the CPU) take turns, a frame each,
 * for 3, 5 or 10 frames. The ball and pins are simulated here on the server (BowlingPhysics) so everyone
 * watching sees the same roll; clients only draw what they're sent.
 *
 * Flow: INTRO -> for each ball: AIM (the bowler lines up and spins the mouse to throw) -> ROLLING -> RESULT
 * -> ... -> OVER. Bowlers are put in Adventure mode at the lane for the game and sent back afterwards.
 */
public final class BowlingMatch implements SportMatch {

    private static final int INTRO_TICKS = 60, RESULT_TICKS = 50, OVER_TICKS = 140;
    private static final int AIM_LIMIT_TICKS = 20 * 45;   // a bowler who doesn't throw gets a straight ball rolled for them
    private static final int MAX_ROLL_TICKS = 20 * 10;
    private static final double WATCH_RANGE = 48;

    public record Bowler(@Nullable UUID player, String name, @Nullable Difficulty cpu) {}

    private record ReturnPoint(ResourceKey<Level> dimension, Vec3 pos, float yRot, float xRot, GameType gameType, boolean invulnerable) {}

    private final Lobby lobby;
    private final FieldData field;
    private final BowlingLane lane;
    private final BowlingPhysics physics;
    private final int frames;
    private final Map<Lobby.Side, Bowler> bowlers = new EnumMap<>(Lobby.Side.class);
    private final Map<Lobby.Side, List<Integer>> rolls = new EnumMap<>(Lobby.Side.class);
    private final Map<UUID, ReturnPoint> returnPoints = new HashMap<>();
    /** Players who were sent this lane's state last time (so watchers who walk away get an "ended"). */
    private final Set<UUID> watchers = new HashSet<>();
    private final Random random = new Random();

    private ServerLevel level;
    private boolean finished;
    private int phase = BowlingStatePacket.INTRO;
    private int phaseTicks;
    private Lobby.Side turn = Lobby.Side.HOME;
    private String message = "";
    private int messageTicks;
    @Nullable private BowlingCpu cpu;
    @Nullable private double[] strikeLine;
    private boolean pinSoundPlayed, gutterSoundPlayed;
    private int tick;

    public BowlingMatch(Lobby lobby, FieldData field) {
        this.lobby = lobby;
        this.field = field;
        this.lane = new BowlingLane(field.geometry());
        this.physics = new BowlingPhysics(lane.dims);
        this.frames = lobby.airGoals() <= 3 ? 3 : lobby.airGoals() <= 5 ? 5 : 10; // the lobby's "frames" option
        for (Lobby.Member m : lobby.members()) bowlers.put(m.side, new Bowler(m.uuid, m.name, null));
        if (lobby.mode() == Lobby.Mode.VS_CPU || bowlers.size() < 2) {
            Lobby.Side cpuSide = bowlers.containsKey(Lobby.Side.HOME) ? Lobby.Side.AWAY : Lobby.Side.HOME;
            bowlers.put(cpuSide, new Bowler(null, "CPU (" + lobby.difficulty().englishName() + ")", lobby.difficulty()));
        }
        for (Lobby.Side s : Lobby.Side.values()) rolls.put(s, new ArrayList<>());
    }

    // ================================================================== SportMatch

    @Override public Lobby lobby() { return lobby; }
    @Override public FieldData field() { return field; }
    @Override public boolean isFinished() { return finished; }

    @Override
    public boolean involves(UUID player) {
        return sideOf(player) != null;
    }

    @Nullable
    private Lobby.Side sideOf(UUID player) {
        for (Map.Entry<Lobby.Side, Bowler> e : bowlers.entrySet()) if (player.equals(e.getValue().player())) return e.getKey();
        return null;
    }

    @Override
    public void kickoff(MinecraftServer server) {
        level = server.getLevel(ResourceKey.create(Registries.DIMENSION, field.dimension()));
        if (level == null) { finish(null); return; }
        for (Bowler b : bowlers.values()) {
            if (b.player() == null) continue;
            ServerPlayer sp = server.getPlayerList().getPlayer(b.player());
            if (sp == null) continue;
            com.sportsmc.match.SafeReturn.remember(sp, true);
            returnPoints.put(b.player(), new ReturnPoint(sp.level().dimension(), sp.position(), sp.getYRot(), sp.getXRot(),
                    sp.gameMode.getGameModeForPlayer(), sp.isInvulnerable()));
            sp.setGameMode(GameType.ADVENTURE);
            sp.setInvulnerable(true);
        }
        // Whoever bowls first: a coin toss.
        turn = random.nextBoolean() ? Lobby.Side.HOME : Lobby.Side.AWAY;
        physics.rack();
        placeBowlers();
        Bowler home = bowlers.get(Lobby.Side.HOME), away = bowlers.get(Lobby.Side.AWAY);
        broadcast(Component.literal("Bowling on " + field.name() + ": ").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD)
                .append(Component.literal(home.name() + " vs " + away.name() + ", " + frames + " frames. "
                        + bowlers.get(turn).name() + " bowls first.").withStyle(ChatFormatting.WHITE)));
        broadcast(Component.literal("On your turn: A/D moves your spot. Grab the ball (hold left mouse), circle the mouse to put "
                + "spin on it if you want a curve ball, then flick the mouse UP and let go - flick harder to roll it faster.").withStyle(ChatFormatting.GRAY));
        title(Component.literal(home.name() + " vs " + away.name()).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                Component.literal(frames + " frames"));
        setPhase(BowlingStatePacket.INTRO);
        say(bowlers.get(turn).name() + " is up", 60);
    }

    @Override
    public void tick(MinecraftServer server) {
        if (finished) return;
        tick++;
        phaseTicks++;
        if (messageTicks > 0) messageTicks--;
        switch (phase) {
            case BowlingStatePacket.INTRO -> { if (phaseTicks >= INTRO_TICKS) startAim(); }
            case BowlingStatePacket.AIM -> tickAim();
            case BowlingStatePacket.ROLLING -> tickRolling();
            case BowlingStatePacket.RESULT -> { if (phaseTicks >= RESULT_TICKS) afterResult(); }
            case BowlingStatePacket.OVER -> { if (phaseTicks >= OVER_TICKS) finish(null); }
        }
        if (finished) return;
        // Positions every tick while the ball is rolling, otherwise a few times a second.
        if (phase == BowlingStatePacket.ROLLING || tick % 5 == 0) sendState(server);
    }

    @Override
    public void finish(@Nullable Lobby.Side forcedWinner) {
        if (finished) return;
        finished = true;
        Lobby.Side winner = forcedWinner != null ? forcedWinner : leader();
        int h = BowlingScore.finalTotal(rolls.get(Lobby.Side.HOME), frames), a = BowlingScore.finalTotal(rolls.get(Lobby.Side.AWAY), frames);
        if (winner != null) {
            broadcast(Component.literal(bowlers.get(winner).name() + " wins " + Math.max(h, a) + " to " + Math.min(h, a) + "!")
                    .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        } else {
            broadcast(Component.literal("Bowling over: " + h + " - " + a + (h == a ? " (a tie)" : "")).withStyle(ChatFormatting.YELLOW));
        }
        MinecraftServer srv = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (srv != null) {
            for (UUID id : new ArrayList<>(watchers)) {
                ServerPlayer sp = srv.getPlayerList().getPlayer(id);
                if (sp != null) ModNetwork.sendTo(sp, BowlingStatePacket.ended(field.id()));
            }
            for (Bowler b : bowlers.values()) {
                if (b.player() == null) continue;
                ServerPlayer sp = srv.getPlayerList().getPlayer(b.player());
                if (sp != null) ModNetwork.sendTo(sp, BowlingStatePacket.inactive());
            }
        }
        watchers.clear();
        sendPlayersBack();
    }

    @Override
    public void forfeit(UUID player) {
        Lobby.Side s = sideOf(player);
        if (s == null) return;
        broadcast(Component.literal(bowlers.get(s).name() + " left the lanes.").withStyle(ChatFormatting.RED));
        finish(s.opposite());
    }

    @Override
    public void control(UUID player, ControlPacket msg) {
        // Bowling uses its own throw packet.
    }

    @Override
    public void sendStateTo(ServerPlayer player) {
        ModNetwork.sendTo(player, state(viewerOf(player.getUUID())));
    }

    // ================================================================== turns

    private void setPhase(int p) {
        phase = p;
        phaseTicks = 0;
    }

    private void startAim() {
        setPhase(BowlingStatePacket.AIM);
        cpu = null;
        placeBowlers();
        Bowler b = bowlers.get(turn);
        if (b.cpu() != null) {
            cpu = new BowlingCpu(physics, b.cpu(), random, strikeLine);
        } else {
            ServerPlayer sp = player(b.player());
            if (sp != null) sp.displayClientMessage(Component.literal("Your turn! Grab the ball and flick the mouse UP to bowl.")
                    .withStyle(ChatFormatting.GOLD), true);
        }
    }

    private void tickAim() {
        Bowler b = bowlers.get(turn);
        if (cpu != null) {
            // The CPU "lines up": a short pause even when it already knows its throw.
            boolean done = cpu.think();
            if (done && phaseTicks >= 30) {
                if (cpu.fullRack() && strikeLine == null) strikeLine = cpu.bestThrow();
                double[] c = cpu.decision();
                cpu = null;
                roll(c[0], c[1], c[2], c[3]);
            }
            return;
        }
        if (b.player() != null && player(b.player()) == null) {
            // Their bowler disconnected: LobbyManager will forfeit them; just wait.
            return;
        }
        if (phaseTicks >= AIM_LIMIT_TICKS) {
            ServerPlayer sp = player(b.player());
            if (sp != null) sp.displayClientMessage(Component.literal("Time! A ball was rolled for you.").withStyle(ChatFormatting.RED), true);
            roll(0, 0, 0.5, 0);
        }
    }

    /** A bowler let go of the ball. */
    public void throwBall(ServerPlayer player, BowlingThrowPacket msg) {
        if (finished || phase != BowlingStatePacket.AIM) return;
        Lobby.Side s = sideOf(player.getUUID());
        if (s == null || s != turn) return;
        roll(safe(msg.start(), -1, 1), safe(msg.aim(), -3, 3), safe(msg.power(), 0, 1), safe(msg.hook(), -1, 1));
    }

    private static double safe(float v, double lo, double hi) {
        return Float.isFinite(v) ? Math.max(lo, Math.min(hi, v)) : 0;
    }

    private void roll(double start, double aim, double power, double hook) {
        physics.launch(start, aim, power, hook);
        pinSoundPlayed = false;
        gutterSoundPlayed = false;
        setPhase(BowlingStatePacket.ROLLING);
        sound(lane.approach(), SoundEvents.WOOL_PLACE, 1.0f, 0.6f);
    }

    private void tickRolling() {
        physics.step(0.05);
        if (!pinSoundPlayed && physics.knocked() > 0) {
            pinSoundPlayed = true;
            float loud = 0.5f + physics.knocked() * 0.08f;
            sound(lane.pinDeck(), SoundEvents.ZOMBIE_ATTACK_WOODEN_DOOR, loud, 1.5f);
            sound(lane.pinDeck(), SoundEvents.WOOD_BREAK, 1f, 0.8f);
            particles(net.minecraft.core.particles.ParticleTypes.CRIT, 12, 0.25);
        }
        if (!gutterSoundPlayed && physics.inGutter) {
            gutterSoundPlayed = true;
            sound(lane.world(0, physics.bu, lane.floorY()), SoundEvents.WOOD_HIT, 0.8f, 0.6f);
        }
        if (physics.settled() || phaseTicks >= MAX_ROLL_TICKS) endRoll();
    }

    private void endRoll() {
        List<Integer> mine = rolls.get(turn);
        BowlingScore.Position before = BowlingScore.position(mine, frames);
        int knocked = Math.min(physics.knocked(), before.pinsUp());
        mine.add(knocked);
        boolean freshRack = before.pinsUp() == 10;
        if (freshRack && knocked == 10) {
            say("STRIKE!", RESULT_TICKS + 10);
            sound(lane.pinDeck(), SoundEvents.PLAYER_LEVELUP, 1f, 1.2f);
            sound(lane.pinDeck(), SoundEvents.FIREWORK_ROCKET_TWINKLE, 1f, 1f);
        } else if (!freshRack && knocked == before.pinsUp()) {
            say("SPARE!", RESULT_TICKS + 10);
            sound(lane.pinDeck(), SoundEvents.PLAYER_LEVELUP, 0.8f, 1.5f);
        } else if (physics.inGutter && knocked == 0) {
            say("Gutter ball", RESULT_TICKS);
        } else if (freshRack && isSplit()) {
            say("SPLIT! " + knocked + " pins", RESULT_TICKS);
        } else {
            say(knocked == 0 ? "Missed!" : knocked + (knocked == 1 ? " pin" : " pins"), RESULT_TICKS);
        }
        if (knocked == 10 && freshRack) particles(net.minecraft.core.particles.ParticleTypes.FIREWORK, 50, 0.12);
        else if (!freshRack && knocked == before.pinsUp() && knocked > 0) particles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER, 24, 0.05);
        setPhase(BowlingStatePacket.RESULT);
    }

    /** After a first ball: the head pin is down and the pins left are in separate groups (with a gap between). */
    private boolean isSplit() {
        if (physics.pins[0].state == BowlingPhysics.STANDING) return false;
        List<Integer> up = new ArrayList<>();
        for (int i = 0; i < 10; i++) if (physics.pins[i].state == BowlingPhysics.STANDING) up.add(i);
        if (up.size() < 2) return false;
        // Group pins that are next to each other (within one pin spacing on the spots).
        double reach = lane.dims.spacing() * 1.05;
        Set<Integer> seen = new HashSet<>();
        List<Integer> stack = new ArrayList<>(List.of(up.get(0)));
        while (!stack.isEmpty()) {
            int p = stack.remove(stack.size() - 1);
            if (!seen.add(p)) continue;
            for (int q : up) {
                double dx = lane.dims.pinX(p) - lane.dims.pinX(q), du = lane.dims.pinU(p) - lane.dims.pinU(q);
                if (!seen.contains(q) && Math.sqrt(dx * dx + du * du) < reach) stack.add(q);
            }
        }
        return seen.size() < up.size();
    }

    private void afterResult() {
        List<Integer> mine = rolls.get(turn);
        BowlingScore.Position pos = BowlingScore.position(mine, frames);
        boolean frameEnded = BowlingScore.frameEndedAfter(mine, frames);
        if (!frameEnded) {
            // Same bowler again: a fresh rack in the last frame after a strike or spare, else clear the fallen pins.
            if (pos.pinsUp() == 10) physics.rack();
            else physics.sweep();
            startAim();
            return;
        }
        Lobby.Side other = turn.opposite();
        boolean otherDone = BowlingScore.position(rolls.get(other), frames).gameDone();
        boolean meDone = pos.gameDone();
        if (otherDone && meDone) {
            gameOver();
            return;
        }
        // Frames alternate: the other bowler's turn (unless they've finished their game).
        if (!otherDone) turn = other;
        physics.rack();
        say(bowlers.get(turn).name() + " - frame " + (BowlingScore.position(rolls.get(turn), frames).frame() + 1), 40);
        startAim();
    }

    private void gameOver() {
        setPhase(BowlingStatePacket.OVER);
        Lobby.Side w = leader();
        int h = BowlingScore.finalTotal(rolls.get(Lobby.Side.HOME), frames), a = BowlingScore.finalTotal(rolls.get(Lobby.Side.AWAY), frames);
        say(w == null ? "It's a tie! " + h + " - " + a : bowlers.get(w).name() + " wins!", OVER_TICKS);
        title(Component.literal(w == null ? "TIE GAME" : bowlers.get(w).name() + " WINS").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                Component.literal(h + " - " + a));
        sound(lane.pinDeck(), SoundEvents.FIREWORK_ROCKET_LARGE_BLAST, 2f, 1f);
    }

    @Nullable
    private Lobby.Side leader() {
        int h = BowlingScore.finalTotal(rolls.get(Lobby.Side.HOME), frames), a = BowlingScore.finalTotal(rolls.get(Lobby.Side.AWAY), frames);
        return h == a ? null : h > a ? Lobby.Side.HOME : Lobby.Side.AWAY;
    }

    /** The bowler who's up stands at the foul line facing the pins; the other waits behind them. */
    private void placeBowlers() {
        if (level == null) return;
        for (Map.Entry<Lobby.Side, Bowler> e : bowlers.entrySet()) {
            ServerPlayer sp = player(e.getValue().player());
            if (sp == null) continue;
            Vec3 p = e.getKey() == turn ? lane.approach() : lane.bench();
            sp.teleportTo(level, p.x, p.y, p.z, lane.yawToPins(), e.getKey() == turn ? 5f : 3f); // eyes level with the pins
        }
    }

    // ================================================================== state for clients

    private int viewerOf(UUID id) {
        Lobby.Side s = sideOf(id);
        return s == null ? -1 : s == Lobby.Side.HOME ? 0 : 1;
    }

    private BowlingStatePacket state(int viewer) {
        float[] pins = new float[50];
        for (int i = 0; i < 10; i++) {
            BowlingPhysics.Pin p = physics.pins[i];
            pins[i * 5] = p.state;
            pins[i * 5 + 1] = (float) p.x;
            pins[i * 5 + 2] = (float) p.u;
            pins[i * 5 + 3] = (float) p.tilt;
            pins[i * 5 + 4] = (float) p.dir;
        }
        int ticksLeft = switch (phase) {
            case BowlingStatePacket.AIM -> Math.max(0, AIM_LIMIT_TICKS - phaseTicks);
            case BowlingStatePacket.OVER -> Math.max(0, OVER_TICKS - phaseTicks);
            default -> 0;
        };
        Lobby.Side w = phase == BowlingStatePacket.OVER ? leader() : null;
        int winner = phase != BowlingStatePacket.OVER ? -1 : w == null ? 2 : w == Lobby.Side.HOME ? 0 : 1;
        return new BowlingStatePacket(true, field.id(), viewer, bowlers.get(Lobby.Side.HOME).name(), bowlers.get(Lobby.Side.AWAY).name(),
                frames, bytes(rolls.get(Lobby.Side.HOME)), bytes(rolls.get(Lobby.Side.AWAY)), turn == Lobby.Side.HOME ? 0 : 1,
                phase, ticksLeft, messageTicks > 0 ? message : "", physics.ballLive, (float) physics.bx, (float) physics.bu,
                (float) physics.ballRoll, pins, winner);
    }

    private static byte[] bytes(List<Integer> list) {
        byte[] out = new byte[list.size()];
        for (int i = 0; i < out.length; i++) out[i] = (byte) (int) list.get(i);
        return out;
    }

    /** The bowlers always get the state; anyone else within range of the lane gets it too, to watch. */
    private void sendState(MinecraftServer server) {
        BowlingStatePacket spectator = state(-1);
        Set<UUID> now = new HashSet<>();
        Vec3 center = lane.world(0, lane.dims.length() / 2, lane.floorY());
        for (ServerPlayer sp : server.getPlayerList().getPlayers()) {
            UUID id = sp.getUUID();
            if (involves(id)) {
                ModNetwork.sendTo(sp, state(viewerOf(id)));
                continue;
            }
            if (sp.level() != level || sp.position().distanceTo(center) > WATCH_RANGE + lane.dims.length() / 2) continue;
            // Watchers get every other roll update (enough to look smooth with interpolation).
            if (phase == BowlingStatePacket.ROLLING && tick % 2 != 0 && watchers.contains(id)) { now.add(id); continue; }
            ModNetwork.sendTo(sp, spectator);
            now.add(id);
        }
        for (UUID gone : watchers) {
            if (now.contains(gone)) continue;
            ServerPlayer sp = server.getPlayerList().getPlayer(gone);
            if (sp != null) ModNetwork.sendTo(sp, BowlingStatePacket.ended(field.id()));
        }
        watchers.clear();
        watchers.addAll(now);
    }

    // ================================================================== helpers

    private void particles(net.minecraft.core.particles.ParticleOptions type, int count, double speed) {
        if (level == null) return;
        Vec3 p = lane.pinDeck();
        double spread = lane.dims.spacing() * 1.2;
        level.sendParticles(type, p.x, p.y + lane.dims.pinH() * 0.6, p.z, count, spread, lane.dims.pinH() * 0.5, spread, speed);
    }

    private void say(String text, int ticks) {
        message = text;
        messageTicks = ticks;
    }

    @Nullable
    private ServerPlayer player(@Nullable UUID id) {
        MinecraftServer srv = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        return srv == null || id == null ? null : srv.getPlayerList().getPlayer(id);
    }

    private void sound(Vec3 at, SoundEvent sound, float volume, float pitch) {
        if (level != null) level.playSound(null, BlockPos.containing(at), sound, SoundSource.PLAYERS, volume, pitch);
    }

    private void broadcast(Component msg) {
        for (Bowler b : bowlers.values()) {
            ServerPlayer sp = player(b.player());
            if (sp != null) sp.sendSystemMessage(Component.literal("[SportsMC] ").withStyle(ChatFormatting.GOLD).append(msg));
        }
    }

    private void broadcastQuiet(Component msg) {
        for (Bowler b : bowlers.values()) {
            ServerPlayer sp = player(b.player());
            if (sp != null) sp.sendSystemMessage(msg);
        }
    }

    private void title(Component title, Component subtitle) {
        for (Bowler b : bowlers.values()) {
            ServerPlayer sp = player(b.player());
            if (sp == null) continue;
            sp.connection.send(new ClientboundSetTitlesAnimationPacket(5, 40, 10));
            sp.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
            sp.connection.send(new ClientboundSetTitleTextPacket(title));
        }
    }

    private void sendPlayersBack() {
        MinecraftServer srv = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (srv == null) return;
        for (Map.Entry<UUID, ReturnPoint> e : returnPoints.entrySet()) {
            ServerPlayer sp = srv.getPlayerList().getPlayer(e.getKey());
            ReturnPoint rp = e.getValue();
            ServerLevel lvl = srv.getLevel(rp.dimension());
            if (sp == null || lvl == null) continue;
            sp.setGameMode(rp.gameType());
            sp.setInvulnerable(rp.invulnerable());
            sp.teleportTo(lvl, rp.pos().x, rp.pos().y, rp.pos().z, rp.yRot(), rp.xRot());
            com.sportsmc.match.SafeReturn.forget(sp);
        }
        returnPoints.clear();
    }
}
