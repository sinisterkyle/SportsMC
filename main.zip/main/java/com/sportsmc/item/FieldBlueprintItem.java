package com.sportsmc.item;

import com.sportsmc.field.FieldGeometry;
import com.sportsmc.field.FieldType;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * Field Blueprint: the one tool for laying out a football field.
 *
 *  Right-click a block  -> set a corner: corner 1 = on HOME's goal line, corner 2 = the diagonally OPPOSITE corner
 *                          on AWAY's goal line. That's 100 yards; 10-yard end zones are added beyond each goal line.
 *  Shift + right-click  -> open the blueprint screen (measurements, name, save, undo, clear, saved fields)
 *  Right-click in the air -> open the blueprint screen
 *
 * In-progress corners live in the stack's NBT, so they survive relogs and the client can preview them.
 */
public class FieldBlueprintItem extends Item {

    public static final String[] STEP_NAMES = {
            "Corner 1 - on HOME's goal line", "Corner 2 - opposite corner, AWAY's goal line"};

    private static final String TAG_POINTS = "Points";
    private static final String TAG_DIM = "Dim";
    private static final String TAG_TYPE = "FieldType";

    public FieldBlueprintItem(Properties props) {
        super(props);
    }

    // ------------------------------------------------------------------ interaction

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Player player = ctx.getPlayer();
        Level level = ctx.getLevel();
        if (player == null) return InteractionResult.PASS;

        if (player.isShiftKeyDown()) {
            if (level.isClientSide) openScreen();
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            addPoint(ctx.getItemInHand(), ctx.getClickedPos(), level, sp);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide) openScreen();
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }

    /** Stops creative players from breaking the block they're trying to mark. */
    @Override
    public boolean canAttackBlock(BlockState state, Level level, BlockPos pos, Player player) {
        return false;
    }

    private static void openScreen() {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.sportsmc.client.ClientHooks.openBlueprintScreen());
    }

    // ------------------------------------------------------------------ point logic (server)

    private static void addPoint(ItemStack stack, BlockPos pos, Level level, ServerPlayer player) {
        String dim = level.dimension().location().toString();
        CompoundTag tag = stack.getOrCreateTag();
        if (!getPoints(stack).isEmpty() && !dim.equals(tag.getString(TAG_DIM))) {
            clear(stack);
            bar(player, Component.literal("Started over - corners from another dimension were cleared.").withStyle(ChatFormatting.YELLOW));
        }

        List<BlockPos> points = getPoints(stack);
        if (points.size() >= 2) {
            bar(player, Component.literal("Both corners are set. Shift + right-click to save, or Undo there.").withStyle(ChatFormatting.YELLOW));
            return;
        }
        FieldType type = getType(stack);
        String noun = type.noun.toLowerCase();
        if (points.size() == 1 && points.get(0).getX() == pos.getX() && points.get(0).getZ() == pos.getZ()) {
            bar(player, Component.literal("That's the same corner - walk to the OPPOSITE corner of the " + noun + ".").withStyle(ChatFormatting.RED));
            return;
        }

        points.add(pos.immutable());
        setPoints(stack, points);
        tag.putString(TAG_DIM, dim);
        level.playSound(null, pos, SoundEvents.BOOK_PAGE_TURN, SoundSource.PLAYERS, 1.0f, 1.0f + points.size() * 0.15f);

        if (points.size() == 1) {
            String other = type == FieldType.TENNIS ? "on the other baseline"
                    : type == FieldType.BOWLING ? "at the far end, past where the pins go" : "on the other goal line";
            bar(player, Component.literal(type.displayName + " corner 1 set at " + pos.getX() + ", " + pos.getY() + ", " + pos.getZ()
                    + " - now click the OPPOSITE corner " + other).withStyle(ChatFormatting.AQUA));
            return;
        }
        FieldGeometry.Result r = FieldGeometry.validate(points.get(0), points.get(1), type);
        if (r.ok()) {
            FieldGeometry g = r.geometry();
            String msg = type == FieldType.TENNIS
                    ? "Court: " + g.summary() + " (regulation 24 x 11). Shift + right-click to save!"
                    : type == FieldType.BOWLING
                    ? "Lane: " + g.summary() + ", pins " + String.format("%.1f", com.sportsmc.bowling.BowlingPhysics.Dims.of(g.length(), g.width()).pinH())
                            + " blocks tall. Shift + right-click to save!"
                    : "100 yds = " + FieldGeometry.fmt(g.length()) + " blocks (" + FieldGeometry.fmt(g.blocksPerYard())
                      + " per yard), end zones +" + FieldGeometry.fmt(g.endZoneDepth()) + " each. Shift + right-click to save!";
            bar(player, Component.literal(msg).withStyle(ChatFormatting.GREEN));
            level.playSound(null, pos, SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.6f, 1.4f);
        } else {
            bar(player, Component.literal(r.error() + " (Undo in the blueprint screen)").withStyle(ChatFormatting.RED));
        }
    }

    private static void bar(ServerPlayer p, Component msg) {
        p.displayClientMessage(msg, true);
    }

    // ------------------------------------------------------------------ NBT helpers (both sides)

    public static List<BlockPos> getPoints(ItemStack stack) {
        List<BlockPos> out = new ArrayList<>();
        CompoundTag tag = stack.getTag();
        if (tag == null) return out;
        for (long l : tag.getLongArray(TAG_POINTS)) out.add(BlockPos.of(l));
        return out;
    }

    public static void setPoints(ItemStack stack, List<BlockPos> points) {
        long[] arr = new long[points.size()];
        for (int i = 0; i < arr.length; i++) arr[i] = points.get(i).asLong();
        stack.getOrCreateTag().putLongArray(TAG_POINTS, arr);
    }

    /** What this blueprint is marking (football field by default). */
    public static FieldType getType(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag == null || !tag.contains(TAG_TYPE) ? FieldType.FOOTBALL : FieldType.byKey(tag.getString(TAG_TYPE));
    }

    /** Switches to the next field type. Corners already marked are kept and re-checked for the new type. */
    public static FieldType cycleType(ItemStack stack) {
        FieldType next = getType(stack).next();
        stack.getOrCreateTag().putString(TAG_TYPE, next.key);
        return next;
    }

    @Nullable
    public static String getDimension(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag == null || !tag.contains(TAG_DIM) ? null : tag.getString(TAG_DIM);
    }

    public static void undo(ItemStack stack) {
        List<BlockPos> points = getPoints(stack);
        if (!points.isEmpty()) points.remove(points.size() - 1);
        setPoints(stack, points);
    }

    public static void clear(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        if (tag != null) {
            tag.remove(TAG_POINTS);
            tag.remove(TAG_DIM);
        }
    }

    /** Validation of the current layout for the blueprint's field type, or null if fewer than 2 corners are set. */
    @Nullable
    public static FieldGeometry.Result layout(ItemStack stack) {
        List<BlockPos> p = getPoints(stack);
        return p.size() < 2 ? null : FieldGeometry.validate(p.get(0), p.get(1), getType(stack));
    }

    // ------------------------------------------------------------------ display

    @Override
    public boolean isFoil(ItemStack stack) {
        FieldGeometry.Result r = layout(stack);
        return r != null && r.ok();
    }

    /** "Field Blueprint (Tennis Court)" etc. */
    @Override
    public Component getName(ItemStack stack) {
        return Component.translatable(getDescriptionId(stack)).append(" (" + getType(stack).displayName + ")");
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        FieldType type = getType(stack);
        tooltip.add(Component.literal("Marking: " + type.displayName).withStyle(ChatFormatting.GOLD));
        List<BlockPos> points = getPoints(stack);
        String[] steps = {type.corner1Hint, type.corner2Hint};
        for (int i = 0; i < steps.length; i++) {
            boolean done = i < points.size();
            boolean next = i == points.size();
            tooltip.add(Component.literal((done ? "\u2714 " : next ? "\u27A4 " : "  ") + steps[i])
                    .withStyle(done ? ChatFormatting.GREEN : next ? ChatFormatting.YELLOW : ChatFormatting.DARK_GRAY));
        }
        FieldGeometry.Result r = layout(stack);
        if (r != null) {
            String size = type == FieldType.FOOTBALL
                    ? r.ok() ? r.geometry().summary() + " (" + FieldGeometry.fmt(r.geometry().blocksPerYard()) + " blocks/yd)" : ""
                    : r.ok() ? r.geometry().summary() : "";
            tooltip.add(r.ok()
                    ? Component.literal(type.noun + ": " + size).withStyle(ChatFormatting.AQUA)
                    : Component.literal(r.error()).withStyle(ChatFormatting.RED));
        }
        tooltip.add(Component.literal("Right-click two opposite corners to mark").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Shift + right-click: open (switch type, save)").withStyle(ChatFormatting.GRAY));
    }
}
